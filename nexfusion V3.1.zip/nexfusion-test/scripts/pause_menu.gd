class_name MenuPausa
extends Control
## Menu de pausa (ESC): resumo da build, configurações rápidas de áudio/vídeo
## e saída. As configurações são aplicadas na hora (e salvas pelo GlobalManager).

signal continuar_solicitado
signal menu_solicitado

var _resumo: VBoxContainer
var _config: PanelContainer
var _b_config: Button
var _check_tela: CheckButton
var _combo_qualidade: OptionButton
var _check_mobile: CheckButton
var _sliders: Dictionary = {}
var _pcts: Dictionary = {}
var _cartas_box: HFlowContainer = null
var _scroll_cartas: ScrollContainer = null

const LARGURA_SLIDER: float = 300.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false
	var fundo: ColorRect = ColorRect.new()
	fundo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fundo.color = Color(0.02, 0.03, 0.05, 0.85)
	add_child(fundo)
	var centro: VBoxContainer = VBoxContainer.new()
	centro.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	centro.alignment = BoxContainer.ALIGNMENT_CENTER
	centro.add_theme_constant_override("separation", 12)
	add_child(centro)
	centro.add_child(UI.titulo("PAUSADO", 52, UI.COR_CIANO))
	var sub: Label = UI.rotulo("O experimento aguarda", 15, UI.COR_TEXTO_FRACO)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	centro.add_child(sub)
	_resumo = VBoxContainer.new()
	_resumo.add_theme_constant_override("separation", 2)
	centro.add_child(_resumo)
	var lbl_cartas: Label = UI.rotulo("CATALISADORES COLETADOS", 12, UI.COR_MAGENTA)
	lbl_cartas.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	centro.add_child(lbl_cartas)
	_scroll_cartas = ScrollContainer.new()
	_scroll_cartas.custom_minimum_size = Vector2(680, 128)
	_scroll_cartas.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_scroll_cartas.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_scroll_cartas.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	centro.add_child(_scroll_cartas)
	_cartas_box = HFlowContainer.new()
	_cartas_box.alignment = FlowContainer.ALIGNMENT_CENTER
	_cartas_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_cartas_box.add_theme_constant_override("h_separation", 6)
	_cartas_box.add_theme_constant_override("v_separation", 6)
	_scroll_cartas.add_child(_cartas_box)
	centro.add_child(UI.separador(10.0))
	var linha: HBoxContainer = HBoxContainer.new()
	linha.alignment = BoxContainer.ALIGNMENT_CENTER
	linha.add_theme_constant_override("separation", 12)
	centro.add_child(linha)
	var b_continuar: Button = UI.botao("CONTINUAR", 20, UI.COR_CIANO)
	b_continuar.pressed.connect(func() -> void: continuar_solicitado.emit())
	linha.add_child(b_continuar)
	_b_config = UI.botao("CONFIGURAÇÕES", 20, UI.COR_VIOLETA)
	_b_config.pressed.connect(_ao_alternar_config)
	linha.add_child(_b_config)
	var b_menu: Button = UI.botao("SAIR PARA O MENU", 20, UI.COR_VERMELHO)
	b_menu.pressed.connect(func() -> void: menu_solicitado.emit())
	linha.add_child(b_menu)
	_construir_config(centro)
	GlobalManager.tela_cheia_alterada.connect(_ao_tela_cheia)


func _construir_config(pai: VBoxContainer) -> void:
	_config = PanelContainer.new()
	_config.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.05, 0.08, 0.12, 0.96), UI.COR_VIOLETA.darkened(0.3), 6))
	_config.custom_minimum_size = Vector2(600, 0)
	_config.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_config.visible = false
	pai.add_child(_config)
	var vb: VBoxContainer = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 8)
	_config.add_child(vb)
	vb.add_child(UI.rotulo("CONFIGURAÇÕES", 16, UI.COR_VIOLETA))
	vb.add_child(_linha_slider("Música", GlobalManager.volume_musica, "musica"))
	vb.add_child(_linha_slider("Efeitos (SFX)", GlobalManager.volume_sfx, "sfx"))
	var linha_tela: HBoxContainer = HBoxContainer.new()
	linha_tela.add_theme_constant_override("separation", 10)
	var lbl: Label = UI.rotulo("Tela cheia", 15, UI.COR_TEXTO)
	lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	linha_tela.add_child(lbl)
	_check_tela = CheckButton.new()
	_check_tela.button_pressed = GlobalManager.tela_cheia
	_check_tela.toggled.connect(func(ativa: bool) -> void: GlobalManager.definir_tela_cheia(ativa))
	linha_tela.add_child(_check_tela)
	vb.add_child(linha_tela)
	var linha_qual: HBoxContainer = HBoxContainer.new()
	linha_qual.add_theme_constant_override("separation", 10)
	var lbl_qual: Label = UI.rotulo("Qualidade", 15, UI.COR_TEXTO)
	lbl_qual.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	linha_qual.add_child(lbl_qual)
	_combo_qualidade = OptionButton.new()
	_combo_qualidade.custom_minimum_size = Vector2(190, 34)
	for q: Dictionary in GlobalManager.QUALIDADES:
		_combo_qualidade.add_item(String(q["nome"]))
	_combo_qualidade.selected = GlobalManager.qualidade
	_combo_qualidade.item_selected.connect(func(indice: int) -> void: GlobalManager.definir_qualidade(indice))
	linha_qual.add_child(_combo_qualidade)
	vb.add_child(linha_qual)
	var linha_mobile: HBoxContainer = HBoxContainer.new()
	linha_mobile.add_theme_constant_override("separation", 10)
	var lbl_mobile: Label = UI.rotulo("Modo mobile (toque)", 15, UI.COR_TEXTO)
	lbl_mobile.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	linha_mobile.add_child(lbl_mobile)
	_check_mobile = CheckButton.new()
	_check_mobile.button_pressed = GlobalManager.modo_mobile
	_check_mobile.toggled.connect(func(ativo: bool) -> void: GlobalManager.definir_modo_mobile(ativo))
	linha_mobile.add_child(_check_mobile)
	vb.add_child(linha_mobile)
	vb.add_child(UI.rotulo("F11 alterna tela cheia. Mudanças de mobile valem ao reiniciar a partida.", 12, UI.COR_TEXTO_FRACO))


func _linha_slider(nome: String, valor: float, tipo: String) -> Control:
	var h: HBoxContainer = HBoxContainer.new()
	h.add_theme_constant_override("separation", 12)
	var lbl: Label = UI.rotulo(nome, 14, UI.COR_TEXTO)
	lbl.custom_minimum_size = Vector2(120, 26)
	h.add_child(lbl)
	var slider: HSlider = HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.05
	slider.value = valor
	slider.custom_minimum_size = Vector2(LARGURA_SLIDER, 24)
	slider.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(slider)
	var pct: Label = UI.rotulo("%d%%" % int(round(valor * 100.0)), 13, UI.COR_CIANO)
	pct.custom_minimum_size = Vector2(52, 26)
	pct.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	h.add_child(pct)
	slider.value_changed.connect(func(v: float) -> void:
		pct.text = "%d%%" % int(round(v * 100.0))
		if tipo == "musica":
			GlobalManager.definir_volume_musica(v)
		else:
			GlobalManager.definir_volume_sfx(v))
	slider.drag_ended.connect(func(_alterado: bool) -> void:
		if tipo == "sfx":
			AudioManager.tocar_sfx("hit", -14.0, 0.05))
	_sliders[tipo] = slider
	_pcts[tipo] = pct
	return h


func _ao_alternar_config() -> void:
	_config.visible = not _config.visible
	_b_config.text = "FECHAR CONFIG." if _config.visible else "CONFIGURAÇÕES"
	if _config.visible:
		AudioManager.tocar_sfx("clique", -8.0, 0.02)


func _ao_tela_cheia(ativa: bool) -> void:
	if _check_tela != null:
		_check_tela.set_pressed_no_signal(ativa)


func atualizar() -> void:
	for filho: Node in _resumo.get_children():
		filho.queue_free()
	var arma: DadosArma = GlobalManager.arma_atual()
	var texto: String = "Arma: %s  •  Nível %d  •  Horda %d" % [
		arma.nome if arma != null else "—",
		GlobalManager.nivel_run,
		GlobalManager.horda_atual,
	]
	var l: Label = UI.rotulo(texto, 15, UI.COR_TEXTO)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_resumo.add_child(l)
	_atualizar_cartas()
	_sincronizar_config()


func _atualizar_cartas() -> void:
	if _cartas_box == null:
		return
	for filho: Node in _cartas_box.get_children():
		filho.queue_free()
	var contagem: Dictionary = {}
	for id: String in GlobalManager.cartas_coletadas:
		contagem[id] = int(contagem.get(id, 0)) + 1
	if contagem.is_empty():
		_cartas_box.add_child(UI.rotulo("Nenhuma carta coletada nesta tentativa.", 12, UI.COR_TEXTO_FRACO))
		return
	for id_v: Variant in contagem.keys():
		var id: String = String(id_v)
		var qtd: int = int(contagem[id_v])
		var painel: PanelContainer = PanelContainer.new()
		painel.custom_minimum_size = Vector2(64, 92)
		painel.tooltip_text = "%s ×%d" % [id, qtd]
		painel.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.07, 0.09, 0.14, 0.98), UI.COR_MAGENTA.darkened(0.25), 4))
		var arte: TextureRect = TextureRect.new()
		var caminho: String = "res://sprites/cartas/%s.png" % id
		if ResourceLoader.exists(caminho):
			arte.texture = load(caminho) as Texture2D
		arte.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		arte.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		arte.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		arte.custom_minimum_size = Vector2(56, 76)
		arte.mouse_filter = Control.MOUSE_FILTER_IGNORE
		painel.add_child(arte)
		if qtd > 1:
			var selo: Label = UI.rotulo("×%d" % qtd, 14, UI.COR_AMBAR)
			selo.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
			selo.offset_left = -34
			selo.offset_top = -22
			selo.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
			selo.mouse_filter = Control.MOUSE_FILTER_IGNORE
			painel.add_child(selo)
		_cartas_box.add_child(painel)


func _sincronizar_config() -> void:
	if _check_tela != null:
		_check_tela.set_pressed_no_signal(GlobalManager.tela_cheia)
	if _combo_qualidade != null:
		_combo_qualidade.selected = GlobalManager.qualidade
	if _check_mobile != null:
		_check_mobile.set_pressed_no_signal(GlobalManager.modo_mobile)
	var musica: HSlider = _sliders.get("musica", null) as HSlider
	if musica != null:
		musica.set_value_no_signal(GlobalManager.volume_musica)
		var pm: Label = _pcts.get("musica", null) as Label
		if pm != null:
			pm.text = "%d%%" % int(round(GlobalManager.volume_musica * 100.0))
	var sfx: HSlider = _sliders.get("sfx", null) as HSlider
	if sfx != null:
		sfx.set_value_no_signal(GlobalManager.volume_sfx)
		var ps: Label = _pcts.get("sfx", null) as Label
		if ps != null:
			ps.text = "%d%%" % int(round(GlobalManager.volume_sfx * 100.0))
