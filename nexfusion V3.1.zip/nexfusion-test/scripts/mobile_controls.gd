class_name ControlesMoveis
extends CanvasLayer
## Controles de toque para o modo mobile: analógico virtual à esquerda e
## botões de tiro, dash, aparar e secundário à direita; inventário e pausa no topo.

var entrada: Vector2 = Vector2.ZERO
var atirando: bool = false
var secundario_pendente: bool = false
var dash_pendente: bool = false
var parar_pendente: bool = false

var _joystick: Joystick
var _ativo: bool = true
var _toque_id: int = -1
var _mouse_pressionado: bool = false


class Joystick extends Control:
	var entrada: Vector2 = Vector2.ZERO
	var ativo: bool = false

	func _draw() -> void:
		var centro: Vector2 = size * 0.5
		var raio: float = minf(size.x, size.y) * 0.42
		draw_circle(centro, raio, Color(0.05, 0.09, 0.13, 0.55))
		draw_arc(centro, raio, 0.0, TAU, 40, Color(0.55, 0.95, 1.0, 0.45), 2.0, true)
		draw_arc(centro, raio * 0.55, 0.0, TAU, 32, Color(0.4, 0.7, 0.8, 0.25), 1.0, true)
		var pos_knob: Vector2 = centro + entrada.limit_length(1.0) * raio * 0.7
		draw_circle(pos_knob, raio * 0.28, Color(0.55, 0.95, 1.0, 0.55 if ativo else 0.35))
		draw_circle(pos_knob, raio * 0.14, Color(0.85, 1.0, 1.0, 0.8))


func _ready() -> void:
	add_to_group("mobile_controls")
	layer = 25
	var raiz: Control = Control.new()
	raiz.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	raiz.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(raiz)

	_joystick = Joystick.new()
	_joystick.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	_joystick.offset_left = 36.0
	_joystick.offset_top = -232.0
	_joystick.offset_right = 36.0 + 196.0
	_joystick.offset_bottom = -36.0
	_joystick.mouse_filter = Control.MOUSE_FILTER_IGNORE
	raiz.add_child(_joystick)

	# ATIRAR (segurar)
	var b_atirar: Button = _criar_botao("ATIRAR", UI.COR_CIANO)
	b_atirar.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	b_atirar.offset_left = -196.0
	b_atirar.offset_top = -196.0
	b_atirar.offset_right = -84.0
	b_atirar.offset_bottom = -84.0
	b_atirar.button_down.connect(func() -> void: atirando = true)
	b_atirar.button_up.connect(func() -> void: atirando = false)
	raiz.add_child(b_atirar)

	var b_dash: Button = _criar_botao("DASH", UI.COR_VERDE)
	b_dash.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	b_dash.offset_left = -320.0
	b_dash.offset_top = -150.0
	b_dash.offset_right = -216.0
	b_dash.offset_bottom = -92.0
	b_dash.pressed.connect(func() -> void: dash_pendente = true)
	raiz.add_child(b_dash)

	var b_parar: Button = _criar_botao("APARAR", UI.COR_AMBAR)
	b_parar.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	b_parar.offset_left = -320.0
	b_parar.offset_top = -238.0
	b_parar.offset_right = -216.0
	b_parar.offset_bottom = -180.0
	b_parar.pressed.connect(func() -> void: parar_pendente = true)
	raiz.add_child(b_parar)

	var b_sec: Button = _criar_botao("SECUND.", UI.COR_MAGENTA)
	b_sec.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	b_sec.offset_left = -146.0
	b_sec.offset_top = -300.0
	b_sec.offset_right = -36.0
	b_sec.offset_bottom = -240.0
	b_sec.pressed.connect(func() -> void: secundario_pendente = true)
	raiz.add_child(b_sec)

	var b_inv: Button = _criar_botao("INVENTÁRIO", UI.COR_MAGENTA)
	b_inv.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	b_inv.offset_left = -150.0
	b_inv.offset_top = 92.0
	b_inv.offset_right = -16.0
	b_inv.offset_bottom = 124.0
	b_inv.pressed.connect(_ao_inventario)
	raiz.add_child(b_inv)

	var b_pausa: Button = _criar_botao("PAUSA", UI.COR_CIANO)
	b_pausa.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	b_pausa.offset_left = -150.0
	b_pausa.offset_top = 130.0
	b_pausa.offset_right = -16.0
	b_pausa.offset_bottom = 162.0
	b_pausa.pressed.connect(_ao_pausa)
	raiz.add_child(b_pausa)

	var dica: Label = UI.rotulo("MODO MOBILE  ·  arraste o analógico para andar", 11, UI.COR_TEXTO_FRACO)
	dica.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	dica.offset_left = -300.0
	dica.offset_right = 300.0
	dica.offset_top = -22.0
	dica.offset_bottom = -4.0
	dica.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	dica.mouse_filter = Control.MOUSE_FILTER_IGNORE
	raiz.add_child(dica)


func _criar_botao(texto: String, cor: Color) -> Button:
	var b: Button = UI.botao(texto, 14, cor)
	b.custom_minimum_size = Vector2.ZERO
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_stylebox_override("normal", UI.estilo_painel(Color(0.06, 0.09, 0.14, 0.72), cor.darkened(0.25), 30))
	b.add_theme_stylebox_override("hover", UI.estilo_painel(Color(0.1, 0.15, 0.21, 0.85), cor, 30))
	b.add_theme_stylebox_override("pressed", UI.estilo_painel(Color(0.03, 0.05, 0.09, 0.9), cor, 30))
	return b


func _input(evento: InputEvent) -> void:
	if not _ativo:
		return
	if evento is InputEventScreenTouch:
		var toque: InputEventScreenTouch = evento as InputEventScreenTouch
		var local: Vector2 = _joystick.get_global_rect().position
		if toque.pressed and _toque_id == -1 and Rect2(local, _joystick.size).has_point(toque.position):
			_toque_id = toque.index
			_joystick.ativo = true
			_ao_mover(toque.position - (local + _joystick.size * 0.5))
			get_viewport().set_input_as_handled()
		elif not toque.pressed and toque.index == _toque_id:
			_toque_id = -1
			_joystick.ativo = false
			entrada = Vector2.ZERO
			_joystick.entrada = Vector2.ZERO
			_joystick.queue_redraw()
			get_viewport().set_input_as_handled()
	elif evento is InputEventScreenDrag:
		var arrasto: InputEventScreenDrag = evento as InputEventScreenDrag
		if arrasto.index == _toque_id:
			var local2: Vector2 = _joystick.get_global_rect().position
			_ao_mover(arrasto.position - (local2 + _joystick.size * 0.5))
			get_viewport().set_input_as_handled()
	elif evento is InputEventMouseButton:
		var clique: InputEventMouseButton = evento as InputEventMouseButton
		if clique.button_index != MOUSE_BUTTON_LEFT:
			return
		var rect: Rect2 = _joystick.get_global_rect()
		if clique.pressed and rect.has_point(clique.position):
			_mouse_pressionado = true
			_joystick.ativo = true
			_ao_mover(clique.position - rect.position - rect.size * 0.5)
			get_viewport().set_input_as_handled()
		elif not clique.pressed and _mouse_pressionado:
			_mouse_pressionado = false
			_joystick.ativo = false
			entrada = Vector2.ZERO
			_joystick.entrada = Vector2.ZERO
			_joystick.queue_redraw()
	elif evento is InputEventMouseMotion and _mouse_pressionado:
		var movimento: InputEventMouseMotion = evento as InputEventMouseMotion
		var rect2: Rect2 = _joystick.get_global_rect()
		_ao_mover(movimento.position - rect2.position - rect2.size * 0.5)


func _ao_mover(deslocamento: Vector2) -> void:
	var raio: float = minf(_joystick.size.x, _joystick.size.y) * 0.42
	entrada = (deslocamento / raio).limit_length(1.0)
	_joystick.entrada = entrada
	_joystick.queue_redraw()


func _ao_inventario() -> void:
	var hud: Node = get_tree().get_first_node_in_group("hud")
	if hud != null and hud.has_method("alternar_inventario"):
		hud.call("alternar_inventario")


func _ao_pausa() -> void:
	var hud: Node = get_tree().get_first_node_in_group("hud")
	if hud != null and hud.has_method("alternar_pausa"):
		hud.call("alternar_pausa")


func definir_ativa(ativa: bool) -> void:
	_ativo = ativa
	visible = ativa
	if not ativa:
		entrada = Vector2.ZERO
		atirando = false
		secundario_pendente = false
		dash_pendente = false
		parar_pendente = false
		_toque_id = -1
		_mouse_pressionado = false
		if _joystick != null:
			_joystick.ativo = false
			_joystick.entrada = Vector2.ZERO
			_joystick.queue_redraw()
