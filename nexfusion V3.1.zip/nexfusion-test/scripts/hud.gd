class_name HUD
extends CanvasLayer
## HUD completo da arena: vida, dash, XP, estilo, horda, pontuação, combo,
## barra de chefe, mira, banner, level up, pausa e tela de morte.

signal recomecar_solicitado(horda: int)
signal loja_solicitada
signal menu_solicitado

var jogador: Player
var _raiz: Control
var _barra_vida: ProgressBar
var _barra_vida_fantasma: ProgressBar
var _label_vida: Label
var _segmentos_dash: Array[ColorRect] = []
var _barra_xp: ProgressBar
var _label_nivel: Label
var _label_horda: Label
var _label_pontuacao: Label
var _label_moedas: Label
var _label_estilo: Label
var _label_multiplicador: Label
var _acoes: VBoxContainer
var _label_combo: Label
var _label_banner: Label
var _label_banner_sub: Label
var _painel_chefe: PanelContainer
var _barra_chefe: ProgressBar
var _label_chefe: Label
var _vinheta: ColorRect
var _faixa_topo: ColorRect
var _faixa_baixo: ColorRect
var _mira: Control
var _banner_timer: float = 0.0
var _ov: LevelUpOverlay
var _pausa: MenuPausa
var _tela_morte: TelaMorte
var _dev: PainelDev
var _inventario: TelaInventario
var _pausado: bool = false
var _banner_tween: Tween
var _toast: PanelContainer = null
var _toast_icone: TextureRect = null
var _toast_nome: Label = null
var _toast_desc: Label = null
var _toast_fila: Array[Dictionary] = []
var _toast_ocupado: bool = false
var _label_fps: Label
var _label_ping: Label
var _b_inventario: Button
var _debug_timer: float = 0.0
var _loja: Control = null
var _transicao_inventario: bool = false


class Mira extends Control:
	func _draw() -> void:
		var c: Color = Color(0.85, 0.98, 1.0, 0.85)
		draw_arc(Vector2.ZERO, 9.0, 0.0, TAU, 24, Color(c.r, c.g, c.b, 0.45), 1.5, true)
		draw_line(Vector2(-15, 0), Vector2(-6, 0), c, 2.0)
		draw_line(Vector2(6, 0), Vector2(15, 0), c, 2.0)
		draw_line(Vector2(0, -15), Vector2(0, -6), c, 2.0)
		draw_line(Vector2(0, 6), Vector2(0, 15), c, 2.0)
		draw_circle(Vector2.ZERO, 1.6, c)


func _ready() -> void:
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	add_to_group("hud")
	_construir()
	_conectar()
	_atualizar_tudo()


func _construir() -> void:
	_raiz = Control.new()
	_raiz.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_raiz.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_raiz)

	# ---- XP (topo, largura total)
	_barra_xp = UI.barra(UI.COR_CIANO, 8.0, 1280.0)
	_barra_xp.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	_barra_xp.offset_bottom = 8.0
	_barra_xp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(_barra_xp)

	# ---- vida / dash / nível (topo-esquerda)
	var painel_vida: PanelContainer = PanelContainer.new()
	painel_vida.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.05, 0.08, 0.12, 0.85), UI.COR_BORDA, 4))
	painel_vida.position = Vector2(18, 22)
	painel_vida.custom_minimum_size = Vector2(320, 96)
	painel_vida.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(painel_vida)
	var vb_vida: VBoxContainer = VBoxContainer.new()
	vb_vida.add_theme_constant_override("separation", 4)
	painel_vida.add_child(vb_vida)
	var linha: HBoxContainer = HBoxContainer.new()
	vb_vida.add_child(linha)
	_label_vida = UI.rotulo("VIDA 100/100", 14, UI.COR_VERMELHO)
	linha.add_child(_label_vida)
	_label_nivel = UI.rotulo("NÍVEL 1", 13, UI.COR_CIANO)
	_label_nivel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_label_nivel.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	linha.add_child(_label_nivel)
	var pilha: Control = Control.new()
	pilha.custom_minimum_size = Vector2(0, 22)
	vb_vida.add_child(pilha)
	_barra_vida_fantasma = UI.barra(Color(1.0, 0.55, 0.65), 18.0, 296.0)
	_barra_vida_fantasma.position = Vector2(0, 2)
	_barra_vida_fantasma.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pilha.add_child(_barra_vida_fantasma)
	_barra_vida = UI.barra(UI.COR_VERMELHO, 18.0, 296.0)
	_barra_vida.position = Vector2.ZERO
	_barra_vida.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pilha.add_child(_barra_vida)
	var linha_dash: HBoxContainer = HBoxContainer.new()
	linha_dash.add_theme_constant_override("separation", 4)
	linha_dash.add_child(UI.rotulo("DASH", 11, UI.COR_TEXTO_FRACO))
	for i: int in range(3):
		var seg: ColorRect = ColorRect.new()
		seg.custom_minimum_size = Vector2(52, 8)
		seg.color = UI.COR_CIANO
		linha_dash.add_child(seg)
		_segmentos_dash.append(seg)
	vb_vida.add_child(linha_dash)

	# ---- horda (topo-centro)
	_label_horda = UI.titulo("HORDA 1", 28, UI.COR_AMBAR)
	_label_horda.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	_label_horda.offset_left = -120
	_label_horda.offset_right = 120
	_label_horda.offset_top = 20
	_label_horda.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(_label_horda)

	# ---- pontuação / moedas (topo-direita)
	var vb_dados: VBoxContainer = VBoxContainer.new()
	vb_dados.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	vb_dados.offset_left = -300
	vb_dados.offset_right = -18
	vb_dados.offset_top = 22
	vb_dados.alignment = BoxContainer.ALIGNMENT_END
	vb_dados.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(vb_dados)
	_label_pontuacao = UI.rotulo("0", 22, UI.COR_TEXTO)
	_label_pontuacao.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	vb_dados.add_child(_label_pontuacao)
	_label_moedas = UI.rotulo("◈ 0", 16, UI.COR_AMBAR)
	_label_moedas.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	vb_dados.add_child(_label_moedas)
	_b_inventario = UI.botao("INVENTÁRIO  [TAB]", 12, UI.COR_MAGENTA)
	_b_inventario.custom_minimum_size = Vector2(176, 30)
	_b_inventario.focus_mode = Control.FOCUS_NONE
	_b_inventario.pressed.connect(alternar_inventario)
	_b_inventario.size_flags_horizontal = Control.SIZE_SHRINK_END
	# No mobile o botão de toque já abre o inventário; o atalho de teclado
	# ficava sobreposto aos controles no canto superior direito.
	_b_inventario.visible = not GlobalManager.modo_mobile
	vb_dados.add_child(_b_inventario)

	# ---- painel de estilo (direita)
	var painel_estilo: PanelContainer = PanelContainer.new()
	painel_estilo.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.05, 0.08, 0.12, 0.8), Color(0.25, 0.45, 0.6), 4))
	painel_estilo.set_anchors_and_offsets_preset(Control.PRESET_CENTER_RIGHT)
	painel_estilo.offset_left = -190
	painel_estilo.offset_right = -18
	if GlobalManager.modo_mobile:
		# Sobe o painel para não encostar no botão SECUND. dos controles de toque.
		painel_estilo.offset_top = -200
		painel_estilo.offset_bottom = 40
	else:
		painel_estilo.offset_top = -110
		painel_estilo.offset_bottom = 130
	painel_estilo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(painel_estilo)
	var vb_estilo: VBoxContainer = VBoxContainer.new()
	vb_estilo.add_theme_constant_override("separation", 2)
	painel_estilo.add_child(vb_estilo)
	var lbl_estilo_titulo: Label = UI.rotulo("ESTILO", 11, UI.COR_TEXTO_FRACO)
	lbl_estilo_titulo.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	vb_estilo.add_child(lbl_estilo_titulo)
	_label_estilo = UI.titulo("D", 42, UI.COR_CIANO)
	_label_estilo.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	vb_estilo.add_child(_label_estilo)
	_label_multiplicador = UI.rotulo("x1.00", 14, UI.COR_AMBAR)
	_label_multiplicador.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	vb_estilo.add_child(_label_multiplicador)
	vb_estilo.add_child(UI.separador(6.0))
	_acoes = VBoxContainer.new()
	_acoes.add_theme_constant_override("separation", 1)
	vb_estilo.add_child(_acoes)

	# ---- boss bar
	_painel_chefe = PanelContainer.new()
	_painel_chefe.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.08, 0.03, 0.05, 0.9), UI.COR_VERMELHO, 4))
	_painel_chefe.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	_painel_chefe.offset_left = -280
	_painel_chefe.offset_right = 280
	_painel_chefe.offset_top = 62
	_painel_chefe.offset_bottom = 116
	_painel_chefe.visible = false
	_painel_chefe.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(_painel_chefe)
	var vb_chefe: VBoxContainer = VBoxContainer.new()
	vb_chefe.add_theme_constant_override("separation", 2)
	_painel_chefe.add_child(vb_chefe)
	_label_chefe = UI.rotulo("CHEFE", 14, Color("ffb3b3"))
	_label_chefe.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb_chefe.add_child(_label_chefe)
	_barra_chefe = UI.barra(UI.COR_VERMELHO, 14.0, 540.0)
	vb_chefe.add_child(_barra_chefe)

	# ---- combo
	_label_combo = UI.titulo("", 34, UI.COR_AMBAR)
	_label_combo.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	_label_combo.offset_left = -300
	_label_combo.offset_right = 300
	_label_combo.offset_top = -170
	_label_combo.offset_bottom = -120
	_label_combo.visible = false
	_label_combo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(_label_combo)

	# ---- banner de horda
	_label_banner = UI.titulo("", 46, UI.COR_CIANO)
	_label_banner.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_label_banner.offset_left = -420
	_label_banner.offset_right = 420
	_label_banner.offset_top = -90
	_label_banner.offset_bottom = -20
	_label_banner.modulate.a = 0.0
	_label_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(_label_banner)
	_label_banner_sub = UI.rotulo("", 18, UI.COR_TEXTO_FRACO)
	_label_banner_sub.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_label_banner_sub.offset_left = -420
	_label_banner_sub.offset_right = 420
	_label_banner_sub.offset_top = -16
	_label_banner_sub.offset_bottom = 10
	_label_banner_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label_banner_sub.modulate.a = 0.0
	_label_banner_sub.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(_label_banner_sub)

	# ---- vinheta de dano
	_vinheta = ColorRect.new()
	_vinheta.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_vinheta.color = Color(0.9, 0.12, 0.2, 0.0)
	_vinheta.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(_vinheta)

	# ---- notificação de conquista (com medalha)
	_toast = PanelContainer.new()
	_toast.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.055, 0.07, 0.11, 0.97), UI.COR_AMBAR, 8))
	_toast.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_toast.offset_left = -310.0
	_toast.offset_right = 310.0
	_toast.offset_top = -196.0
	_toast.offset_bottom = -102.0
	_toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_toast.visible = false
	_toast.modulate.a = 0.0
	_raiz.add_child(_toast)
	var margem_toast: MarginContainer = MarginContainer.new()
	margem_toast.add_theme_constant_override("margin_left", 12)
	margem_toast.add_theme_constant_override("margin_right", 16)
	margem_toast.add_theme_constant_override("margin_top", 8)
	margem_toast.add_theme_constant_override("margin_bottom", 8)
	_toast.add_child(margem_toast)
	var linha_toast: HBoxContainer = HBoxContainer.new()
	linha_toast.add_theme_constant_override("separation", 14)
	margem_toast.add_child(linha_toast)
	_toast_icone = TextureRect.new()
	_toast_icone.custom_minimum_size = Vector2(72, 72)
	_toast_icone.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_toast_icone.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_toast_icone.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	linha_toast.add_child(_toast_icone)
	var textos_toast: VBoxContainer = VBoxContainer.new()
	textos_toast.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	textos_toast.alignment = BoxContainer.ALIGNMENT_CENTER
	textos_toast.add_theme_constant_override("separation", 1)
	linha_toast.add_child(textos_toast)
	var selo: Label = UI.rotulo("CONQUISTA DESBLOQUEADA", 11, UI.COR_AMBAR)
	textos_toast.add_child(selo)
	_toast_nome = UI.titulo("", 20, UI.COR_TEXTO)
	textos_toast.add_child(_toast_nome)
	_toast_desc = UI.rotulo("", 12, UI.COR_TEXTO_FRACO)
	_toast_desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	textos_toast.add_child(_toast_desc)

	# ---- faixas de cinema (cutscene do chefe final)
	_faixa_topo = ColorRect.new()
	_faixa_topo.color = Color(0.01, 0.01, 0.02, 0.94)
	_faixa_topo.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	_faixa_topo.offset_bottom = 78.0
	_faixa_topo.visible = false
	_faixa_topo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(_faixa_topo)
	_faixa_baixo = ColorRect.new()
	_faixa_baixo.color = Color(0.01, 0.01, 0.02, 0.94)
	_faixa_baixo.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	_faixa_baixo.offset_top = -78.0
	_faixa_baixo.visible = false
	_faixa_baixo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(_faixa_baixo)

	# ---- mira
	_mira = Mira.new()
	_mira.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_mira.z_index = 100
	_raiz.add_child(_mira)

	# ---- FPS / ping (opcionais nas configurações)
	_label_fps = UI.rotulo("", 12, UI.COR_VERDE)
	_label_fps.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	_label_fps.offset_left = 16
	_label_fps.offset_top = -30
	_label_fps.offset_bottom = -10
	_label_fps.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(_label_fps)
	_label_ping = UI.rotulo("", 12, UI.COR_CIANO)
	_label_ping.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	_label_ping.offset_left = 96
	_label_ping.offset_top = -30
	_label_ping.offset_bottom = -10
	_label_ping.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(_label_ping)

	# ---- overlays
	_ov = LevelUpOverlay.new()
	_raiz.add_child(_ov)
	_ov.carta_selecionada.connect(_ao_carta)
	_pausa = MenuPausa.new()
	_raiz.add_child(_pausa)
	_pausa.continuar_solicitado.connect(func() -> void: alternar_pausa(false))
	_pausa.menu_solicitado.connect(func() -> void: menu_solicitado.emit())
	_tela_morte = TelaMorte.new()
	_raiz.add_child(_tela_morte)
	_tela_morte.recomecar_solicitado.connect(func(horda: int) -> void: recomecar_solicitado.emit(horda))
	_tela_morte.loja_solicitada.connect(func() -> void: loja_solicitada.emit())
	_tela_morte.menu_solicitado.connect(func() -> void: menu_solicitado.emit())
	# O painel de dev fica numa camada acima do HUD: nada do jogo aparece por cima.
	var camada_dev: CanvasLayer = CanvasLayer.new()
	camada_dev.layer = 80
	add_child(camada_dev)
	_dev = PainelDev.new()
	camada_dev.add_child(_dev)
	_dev.fechar_solicitado.connect(func() -> void: alternar_dev())
	_inventario = TelaInventario.new()
	_raiz.add_child(_inventario)
	_inventario.fechar_solicitado.connect(func() -> void: alternar_inventario())


func _conectar() -> void:
	GlobalManager.pontuacao_alterada.connect(func(v: int) -> void: _label_pontuacao.text = UI.formatar(v))
	GlobalManager.moedas_alteradas.connect(func(v: int) -> void:
		var partida: int = GlobalManager.moedas_partida
		_label_moedas.text = "◈ %s" % UI.formatar(partida if GlobalManager.partida_ativa else v))
	GlobalManager.xp_alterado.connect(_ao_xp)
	GlobalManager.nivel_subiu.connect(_ao_nivel)
	GlobalManager.estilo_alterado.connect(_ao_estilo)
	GlobalManager.acao_estilo.connect(_ao_acao)
	GlobalManager.combo_realizado.connect(_ao_combo)
	GlobalManager.combo_encerrado.connect(_ao_combo_fim)
	GlobalManager.horda_alterada.connect(_ao_horda)
	GlobalManager.fase_alterada.connect(func(_f: int) -> void: _ao_horda(GlobalManager.horda_atual))
	GlobalManager.chefe_surgiu.connect(_ao_chefe)
	GlobalManager.chefe_vida.connect(_ao_chefe_vida)
	GlobalManager.boss_derrotado.connect(func(_n: String) -> void: _painel_chefe.visible = false)
	GlobalManager.chefe_aviso.connect(_ao_chefe_aviso)
	GlobalManager.dano_recebido.connect(_ao_dano)
	GlobalManager.conquista_desbloqueada.connect(_ao_conquista)


func configurar(jogador_ref: Player) -> void:
	jogador = jogador_ref
	_atualizar_tudo()


func _ao_horda(horda: int) -> void:
	_label_horda.text = "HORDA %d · FASE %d" % [horda, GlobalManager.fase]


func _atualizar_tudo() -> void:
	_ao_horda(GlobalManager.horda_atual)
	_label_pontuacao.text = UI.formatar(GlobalManager.pontuacao)
	_label_moedas.text = "◈ %s" % UI.formatar(GlobalManager.moedas_partida)
	_label_nivel.text = "NÍVEL %d" % GlobalManager.nivel_run
	_barra_xp.max_value = float(GlobalManager.xp_necessario)
	_barra_xp.value = float(GlobalManager.xp_run)
	if jogador != null:
		atualizar_vida(jogador.vida, jogador.vida_maxima)
		atualizar_cargas(jogador.dash_cargas, Player.CARGAS_DASH_MAX)
		atualizar_arma()


func atualizar_arma() -> void:
	if jogador == null:
		return
	var arma: DadosArma = GlobalManager.arma_atual()
	if arma == null:
		return
	_label_vida.tooltip_text = arma.nome


func atualizar_vida(atual: float, maxima: float) -> void:
	_barra_vida.max_value = maxima
	_barra_vida.value = atual
	_barra_vida_fantasma.max_value = maxima
	_barra_vida_fantasma.value = atual
	_label_vida.text = "VIDA %d/%d" % [int(ceil(atual)), int(maxima)]
	if atual / maxf(1.0, maxima) < 0.3:
		_barra_vida.add_theme_stylebox_override("fill", UI.estilo_barra(Color("ff3b5c")))
	else:
		_barra_vida.add_theme_stylebox_override("fill", UI.estilo_barra(UI.COR_VERMELHO))


func atualizar_cargas(atual: int, maxima: int) -> void:
	for i: int in range(_segmentos_dash.size()):
		var ativa: bool = i < atual
		_segmentos_dash[i].color = UI.COR_CIANO if ativa else Color(0.16, 0.22, 0.3)
		_segmentos_dash[i].custom_minimum_size = Vector2(52, 12 if ativa else 6)


func _process(delta: float) -> void:
	_debug_timer -= delta
	if _debug_timer <= 0.0:
		_debug_timer = 0.5
		_atualizar_debug()
	var loja_aberta: bool = _loja != null and is_instance_valid(_loja)
	var janela_aberta: bool = _pausado or _ov.visible or _tela_morte.visible or _dev.visible or _inventario.visible or loja_aberta
	var sobre_botao: bool = _b_inventario != null and _b_inventario.visible and _b_inventario.get_global_rect().has_point(get_viewport().get_mouse_position())
	GlobalManager.definir_cursor(janela_aberta or sobre_botao)
	if _mira != null:
		_mira.visible = not janela_aberta and not sobre_botao
		_mira.position = _raiz.get_local_mouse_position()
	if jogador != null and is_instance_valid(jogador):
		# fantasma de cura recente
		var alvo: float = jogador.vida
		_barra_vida_fantasma.value = lerpf(_barra_vida_fantasma.value, alvo, clampf(delta * 3.0, 0.0, 1.0))
	if _banner_timer > 0.0:
		_banner_timer -= delta


func _atualizar_debug() -> void:
	if _label_fps != null:
		_label_fps.visible = GlobalManager.mostrar_fps
		if GlobalManager.mostrar_fps:
			_label_fps.text = "FPS %d" % Engine.get_frames_per_second()
	if _label_ping != null:
		var em_rede: bool = NetworkManager.modo != "off"
		_label_ping.visible = GlobalManager.mostrar_ping and em_rede
		if _label_ping.visible:
			if NetworkManager.modo == "client":
				_label_ping.text = "PING %d ms" % NetworkManager.ping_ms
			else:
				_label_ping.text = "PING HOST"


func mostrar_banner(texto: String, cor: Color = UI.COR_CIANO, subtitulo: String = "") -> void:
	_label_banner.text = texto
	_label_banner.add_theme_color_override("font_color", cor)
	_label_banner_sub.text = subtitulo
	if _banner_tween != null and _banner_tween.is_valid():
		_banner_tween.kill()
	_label_banner.modulate.a = 0.0
	_label_banner_sub.modulate.a = 0.0
	_label_banner.scale = Vector2(0.8, 0.8)
	_banner_tween = create_tween()
	_banner_tween.set_parallel(true)
	_banner_tween.tween_property(_label_banner, "modulate:a", 1.0, 0.25)
	_banner_tween.tween_property(_label_banner, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_banner_tween.tween_property(_label_banner_sub, "modulate:a", 1.0, 0.4)
	_banner_tween.chain().tween_property(_label_banner, "modulate:a", 0.0, 0.5).set_delay(1.4)
	_banner_tween.tween_property(_label_banner_sub, "modulate:a", 0.0, 0.5)


func _ao_xp(xp: int, necessario: int, nivel: int) -> void:
	_barra_xp.max_value = float(necessario)
	_barra_xp.value = float(xp)
	_label_nivel.text = "NÍVEL %d" % nivel


func _ao_nivel(nivel: int) -> void:
	mostrar_banner("NÍVEL %d" % nivel, UI.COR_MAGENTA, "ESCOLHA UM CATALISADOR")
	AudioManager.tocar_sfx("levelup", -4.0, 0.02)
	_abrir_level_up(nivel)


func _ao_estilo(rank: String, mult: float) -> void:
	_label_estilo.text = rank
	var cor: Color = GlobalManager.cor_rank(rank)
	_label_estilo.add_theme_color_override("font_color", cor)
	_label_estilo.add_theme_font_size_override("font_size", 42 if rank.length() <= 3 else (26 if rank.length() <= 6 else 17))
	_label_multiplicador.text = "x%.2f" % mult
	_label_multiplicador.add_theme_color_override("font_color", cor)
	if rank == "ULTRAQUÍMICO":
		mostrar_banner("ULTRAQUÍMICO", cor, "ESTILO MÁXIMO")
		Efeitos.tremor(6.0)


func _ao_acao(texto: String, cor: Color) -> void:
	var l: Label = UI.rotulo("+%s" % texto, 12, cor)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_acoes.add_child(l)
	_acoes.move_child(l, 0)
	while _acoes.get_child_count() > 4:
		var velho: Node = _acoes.get_child(_acoes.get_child_count() - 1)
		_acoes.remove_child(velho)
		velho.queue_free()
	var tw: Tween = l.create_tween()
	tw.tween_interval(1.6)
	tw.tween_property(l, "modulate:a", 0.0, 0.6)
	tw.tween_callback(l.queue_free)


func _ao_combo(quantidade: int, nome: String) -> void:
	_label_combo.text = nome
	_label_combo.visible = true
	var cor: Color = UI.COR_AMBAR if quantidade < 4 else UI.COR_MAGENTA
	_label_combo.add_theme_color_override("font_color", cor)
	_label_combo.pivot_offset = _label_combo.size * 0.5
	_label_combo.scale = Vector2(1.5, 1.5)
	var tw: Tween = _label_combo.create_tween()
	tw.tween_property(_label_combo, "scale", Vector2.ONE, 0.22).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	AudioManager.tocar_sfx("horda", -14.0, 0.1)


func _ao_combo_fim() -> void:
	_label_combo.visible = false


func _ao_chefe(nome: String, vida_maxima: float) -> void:
	_painel_chefe.visible = true
	_label_chefe.text = nome.to_upper()
	_barra_chefe.max_value = vida_maxima
	_barra_chefe.value = vida_maxima
	if GlobalManager.horda_atual >= GlobalManager.HORDA_MAXIMA:
		return
	mostrar_banner("CHEFE: %s" % nome.to_upper(), UI.COR_VERMELHO, "FÚRIA ABAIXO DE 50% DE VIDA")


func _ao_chefe_aviso(titulo: String, subtitulo: String) -> void:
	mostrar_banner(titulo, UI.COR_VERMELHO, subtitulo)


func iniciar_cinema(titulo: String, subtitulo: String) -> void:
	_faixa_topo.visible = true
	_faixa_baixo.visible = true
	_faixa_topo.modulate.a = 0.0
	_faixa_baixo.modulate.a = 0.0
	var tw: Tween = create_tween()
	tw.set_parallel(true)
	tw.tween_property(_faixa_topo, "modulate:a", 1.0, 0.35)
	tw.tween_property(_faixa_baixo, "modulate:a", 1.0, 0.35)
	mostrar_banner(titulo, UI.COR_VERMELHO, subtitulo)


func encerrar_cinema() -> void:
	var tw: Tween = create_tween()
	tw.set_parallel(true)
	tw.tween_property(_faixa_topo, "modulate:a", 0.0, 0.5)
	tw.tween_property(_faixa_baixo, "modulate:a", 0.0, 0.5)
	tw.chain().tween_callback(func() -> void:
		_faixa_topo.visible = false
		_faixa_baixo.visible = false)


func _ao_chefe_vida(vida: float, maxima: float) -> void:
	_barra_chefe.max_value = maxf(1.0, maxima)
	_barra_chefe.value = vida
	if vida <= 0.0:
		_painel_chefe.visible = false


func _ao_conquista(id: String, nome: String, descricao: String) -> void:
	_toast_fila.append({"id": id, "nome": nome, "desc": descricao})
	if not _toast_ocupado:
		_mostrar_proxima_conquista()


func _mostrar_proxima_conquista() -> void:
	if _toast == null or _toast_fila.is_empty():
		_toast_ocupado = false
		return
	_toast_ocupado = true
	var dados: Dictionary = _toast_fila.pop_front() as Dictionary
	var id: String = String(dados.get("id", ""))
	var nome: String = String(dados.get("nome", ""))
	_toast_nome.text = nome.to_upper()
	_toast_desc.text = String(dados.get("desc", ""))
	var info: Dictionary = {}
	if GlobalManager.CONQUISTAS.has(id):
		info = GlobalManager.CONQUISTAS[id] as Dictionary
	var caminho: String = String(info.get("icone", ""))
	_toast_icone.texture = null
	if caminho != "" and ResourceLoader.exists(caminho):
		_toast_icone.texture = load(caminho) as Texture2D
	_toast.visible = true
	_toast.modulate.a = 0.0
	_toast.pivot_offset = _toast.size * 0.5
	_toast.scale = Vector2(0.92, 0.92)
	var tw: Tween = create_tween()
	tw.set_parallel(true)
	tw.tween_property(_toast, "modulate:a", 1.0, 0.25)
	tw.tween_property(_toast, "scale", Vector2.ONE, 0.32).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.set_parallel(false)
	tw.tween_interval(3.1)
	tw.tween_property(_toast, "modulate:a", 0.0, 0.4)
	tw.tween_callback(func() -> void:
		_toast.visible = false
		_toast_ocupado = false
		_mostrar_proxima_conquista())
	AudioManager.tocar_sfx("levelup", -2.0, 0.02)
	Efeitos.tremor(5.0)


func _ao_dano() -> void:
	_vinheta.color = Color(0.9, 0.12, 0.2, 0.34)
	var tw: Tween = _vinheta.create_tween()
	tw.tween_property(_vinheta, "color:a", 0.0, 0.45)


func _abrir_level_up(nivel: int) -> void:
	if jogador == null or not jogador.vivo:
		return
	if _tela_morte.visible or _pausa.visible or (_loja != null and is_instance_valid(_loja)):
		return
	get_tree().paused = true
	_ov.abrir(nivel, jogador)
	_atualizar_controles_moveis()


func _ao_carta(carta: CartaRoguelite) -> void:
	if jogador != null and is_instance_valid(jogador):
		jogador.aplicar_carta(carta)
		AudioManager.tocar_sfx("levelup", -6.0, 0.05)
		var extra: String = String(carta.descricao)
		if carta.atributo == "ressurreicao":
			extra += "  ·  CARGAS: %d" % GlobalManager.cargas_ressurreicao
		mostrar_banner(String(carta.nome).to_upper(), UI.cor_raridade(carta.raridade), extra)
	_ov.fechar()
	get_tree().paused = false


func alternar_dev() -> void:
	## Shift+P: painel de desenvolvedor (pausa a partida enquanto aberto).
	if _dev == null:
		return
	if _dev.visible:
		_dev.fechar()
		_atualizar_controles_moveis()
		if not _pausado and not _ov.visible and not _tela_morte.visible and not _inventario.visible:
			get_tree().paused = false
		AudioManager.tocar_sfx("clique", -8.0, 0.02)
		return
	if _tela_morte.visible or _ov.visible or _inventario.visible or (_loja != null and is_instance_valid(_loja)):
		return
	_pausa.visible = false
	_pausado = false
	var sm: SpawnManager = get_tree().get_first_node_in_group("spawn_manager") as SpawnManager
	_dev.abrir(sm, jogador)
	get_tree().paused = true
	_atualizar_controles_moveis()
	AudioManager.tocar_sfx("clique", -4.0, 0.02)


func inventario_aberto() -> bool:
	return _inventario != null and _inventario.visible


func alternar_inventario() -> void:
	## TAB: inventário + Caderno de Registros.
	if _inventario == null or _transicao_inventario:
		return
	_transicao_inventario = true
	if _inventario.visible:
		_inventario.fechar()
		_atualizar_controles_moveis()
		if not _pausado and not _ov.visible and not _tela_morte.visible and not _dev.visible:
			get_tree().paused = false
		_transicao_inventario = false
		return
	if _tela_morte.visible or _ov.visible or _dev.visible or (_loja != null and is_instance_valid(_loja)):
		_transicao_inventario = false
		return
	_pausa.visible = false
	_pausado = false
	_inventario.abrir()
	get_tree().paused = true
	_atualizar_controles_moveis()
	AudioManager.tocar_sfx("clique", -6.0, 0.02)
	_transicao_inventario = false


func alternar_pausa(forcar: bool = false) -> void:
	if _tela_morte.visible or _ov.visible or _dev.visible or _inventario.visible or (_loja != null and is_instance_valid(_loja)):
		return
	var abrir: bool = not _pausado if not forcar else not _pausado
	if _pausado and abrir:
		return
	_pausado = abrir
	_pausa.visible = _pausado
	get_tree().paused = _pausado
	if _pausado:
		_pausa.atualizar()
		AudioManager.tocar_sfx("clique", -8.0, 0.02)
	_atualizar_controles_moveis()


func _atualizar_controles_moveis() -> void:
	var controles: Node = get_tree().get_first_node_in_group("mobile_controls")
	if controles != null and controles.has_method("definir_ativa"):
		var fechar: bool = _pausado or _ov.visible or _tela_morte.visible or _dev.visible or _inventario.visible or (_loja != null and is_instance_valid(_loja))
		controles.call("definir_ativa", not fechar)


func abrir_loja() -> void:
	## Loja embutida: mantém a run (e a tela de morte) por baixo.
	if _loja != null and is_instance_valid(_loja):
		return
	var cena_loja: Script = load("res://scripts/shop.gd") as Script
	if cena_loja == null:
		return
	_loja = cena_loja.new() as Control
	if _loja == null:
		return
	_loja.set("embutida", true)
	_raiz.add_child(_loja)
	_loja.connect("fechado", _fechar_loja)
	get_tree().paused = true
	_atualizar_controles_moveis()
	GlobalManager.definir_cursor(true)
	AudioManager.tocar_sfx("clique", -8.0, 0.02)


func _fechar_loja() -> void:
	_loja = null
	GlobalManager.definir_cursor(true)
	_atualizar_controles_moveis()


func mostrar_morte(venceu: bool) -> void:
	get_tree().paused = true
	_pausa.visible = false
	_ov.fechar()
	_tela_morte.mostrar(venceu, GlobalManager.ultimo_resultado)
	_atualizar_controles_moveis()
	GlobalManager.definir_cursor(true)
	AudioManager.tocar_bgm("menu")
