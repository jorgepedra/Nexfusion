class_name Enemy
extends CharacterBody2D
## Base modular de inimigos. Comportamentos: perseguir, ziguezague, investida,
## atirador (e subclasses: divisor/granadeiro/chefe).
## Sangue químico: morrer perto do jogador libera isótopos de cura (estilo ULTRAKILL).

signal morreu(inimigo: Enemy)

const CENA_COLETAVEL: String = "res://scenes/coletavel.tscn"
const CENA_PROJETIL: String = "res://scenes/projetil.tscn"
const ESCALA_PIXEL: float = 3.0
const DISTANCIA_CURA: float = 165.0

@export var dados: DadosInimigo

var vida: float = 10.0
var vida_max: float = 10.0
var velocidade: float = 80.0
var dano_contato: float = 6.0
var comportamento: String = "perseguir"
var raio: float = 14.0
var horda: int = 1
var morto: bool = false
var invulneravel: float = 0.0
var escala_visual: float = 1.0

var jogador: Player = null
var animador: AnimadorSprite = null
## No modo LAN o cliente apenas desenha o inimigo; a simulação roda no host.
var autoridade_remota: bool = false
## Chefe derrotado que voltou como inimigo comum (não anuncia nem toca tema de chefe).
var como_comum: bool = false
var id_rede: int = 0
var _arena: Rect2 = Rect2(0.0, 0.0, 2400.0, 1500.0)
var _dano_timer: float = 0.0
var _tempo: float = 0.0
var _separacao_timer: float = 0.0
var _empurrao: Vector2 = Vector2.ZERO
var _knockback: Vector2 = Vector2.ZERO
var _estado: String = "normal"
var _estado_timer: float = 0.0
var _tiro_timer: float = 0.0
var _fase_salto: float = 0.0
var _tempo_preso: float = 0.0
var _ultima_pos: Vector2 = Vector2.ZERO
var _salto_tempo: float = 0.0
var _salto_duracao: float = 0.45
var _cena_projetil: PackedScene = null
var _cena_coletavel: PackedScene = null

@onready var corpo: Sprite2D = $Corpo
@onready var colisao: CollisionShape2D = $Colisao


func _ready() -> void:
	add_to_group("inimigos")
	z_index = 5
	collision_layer = 2
	collision_mask = 4
	_fase_salto = randf() * TAU
	if ResourceLoader.exists(CENA_PROJETIL):
		_cena_projetil = load(CENA_PROJETIL) as PackedScene
	if ResourceLoader.exists(CENA_COLETAVEL):
		_cena_coletavel = load(CENA_COLETAVEL) as PackedScene
	if dados != null:
		_aplicar_dados(dados, horda)
		GlobalManager.registrar_inimigo_descoberto(dados.id)
	_aplicar_visual()
	_tiro_timer = randf_range(0.6, 1.6)


func _aplicar_dados(d: DadosInimigo, horda_atual: int) -> void:
	dados = d
	horda = horda_atual
	var nivel: int = maxi(0, horda_atual - d.horda_minima)
	var escala_horda: float = 1.0 + d.escala_vida_horda * float(nivel)
	var escala_fase: float = GlobalManager.multiplicador_fase()
	var escala_jogadores: float = 1.0 + 0.35 * float(_jogadores_na_partida() - 1)
	vida_max = d.vida * escala_horda * escala_fase * escala_jogadores
	vida = vida_max
	velocidade = d.velocidade * (1.0 + minf(0.45, float(nivel) * 0.025))
	dano_contato = d.dano_contato * (1.0 + float(nivel) * 0.04) * escala_fase * (1.0 + 0.22 * float(_jogadores_na_partida() - 1))
	comportamento = d.comportamento
	raio = d.raio * (escala_visual if escala_visual != 1.0 else d.escala)
	escala_visual = d.escala if escala_visual == 1.0 else escala_visual


func configurar(d: DadosInimigo, horda_atual: int = 1) -> void:
	_aplicar_dados(d, horda_atual)
	if is_inside_tree():
		_aplicar_visual()
	queue_redraw()


func _aplicar_visual() -> void:
	if corpo == null:
		return
	if dados != null and dados.textura != "" and ResourceLoader.exists(dados.textura):
		corpo.texture = load(dados.textura) as Texture2D
	corpo.scale = Vector2.ONE * ESCALA_PIXEL * escala_visual
	if colisao != null:
		var forma: CircleShape2D = colisao.shape as CircleShape2D
		if forma != null:
			forma = forma.duplicate() as CircleShape2D
			forma.radius = maxf(8.0, raio)
			colisao.shape = forma
	if dados != null:
		z_index = 6 if dados.is_boss else 5
	if GlobalManager.animar_inimigos():
		_garantir_animador()
		if animador != null and dados != null:
			animador.configurar(dados.textura)
	elif animador != null:
		# Qualidade leve: inimigos ficam com sprite estático, só o jogador anima.
		animador.parar()
	queue_redraw()


func _garantir_animador() -> void:
	## Folha 4x4 (idle/andar/ataque/dano) derivada da textura do inimigo.
	if animador != null or corpo == null or not is_inside_tree():
		return
	animador = AnimadorSprite.new()
	animador.name = "Animador"
	animador.sprite = corpo
	add_child(animador)


func _physics_process(delta: float) -> void:
	if morto or autoridade_remota:
		return
	_tempo += delta
	_atualizar_salto(delta)
	invulneravel = maxf(0.0, invulneravel - delta)
	_dano_timer = maxf(0.0, _dano_timer - delta)
	if jogador == null or not is_instance_valid(jogador) or not jogador.vivo:
		jogador = _jogador_mais_proximo()
	if jogador == null:
		return
	if not jogador.vivo:
		velocity = Vector2.ZERO
		move_and_slide()
		return
	_atualizar_empurrao(delta)
	var dir: Vector2 = _calcular_direcao(delta)
	velocity = dir * velocidade + _empurrao + _knockback
	_knockback = _knockback.lerp(Vector2.ZERO, clampf(delta * 8.0, 0.0, 1.0))
	move_and_slide()
	_detectar_obstaculo(delta)
	_checar_limites()
	_z_index_por_posicao()
	_checar_contato()
	if animador != null:
		animador.definir_movendo(velocity.length() > 20.0)


func _jogador_mais_proximo() -> Player:
	## Funciona em co-op LAN: cada inimigo persegue o jogador vivo mais perto.
	var melhor: Player = null
	var melhor_dist: float = INF
	for n: Node in get_tree().get_nodes_in_group("player"):
		var p: Player = n as Player
		if p == null or not is_instance_valid(p) or not p.vivo:
			continue
		var d: float = global_position.distance_squared_to(p.global_position)
		if d < melhor_dist:
			melhor_dist = d
			melhor = p
	return melhor


func _detectar_obstaculo(delta: float) -> void:
	## Se o corpo está empurrando mas não sai do lugar, o inimigo "salta"
	## por cima do obstáculo (colisão temporariamente desligada + arco visual).
	if _salto_tempo > 0.0:
		return
	var deslocou: float = global_position.distance_to(_ultima_pos)
	var esperado: float = velocity.length() * delta * 0.45
	if velocity.length() > 25.0 and deslocou < esperado:
		_tempo_preso += delta
	else:
		_tempo_preso = maxf(0.0, _tempo_preso - delta * 2.0)
	_ultima_pos = global_position
	if _tempo_preso > 0.42:
		_iniciar_salto()


func _iniciar_salto() -> void:
	_tempo_preso = 0.0
	_salto_tempo = _salto_duracao
	collision_mask = 0
	Efeitos.particulas(get_parent(), global_position, Color(0.55, 0.95, 1.0), 5, 80.0, 0.25, 2.0)


func _atualizar_salto(delta: float) -> void:
	if _salto_tempo <= 0.0:
		return
	_salto_tempo = maxf(0.0, _salto_tempo - delta)
	var p: float = 1.0 - _salto_tempo / _salto_duracao
	if corpo != null:
		corpo.offset.y = -sin(p * PI) * 38.0
	if _salto_tempo <= 0.0:
		collision_mask = 4
		if corpo != null:
			corpo.offset.y = 0.0
		_ultima_pos = global_position


func aplicar_qualidade() -> void:
	## Trocar o perfil gráfico não pode recarregar textura/escala do sprite
	## (isso quebrava a animação e o tamanho dos slimes). Só liga/desliga.
	if GlobalManager.animar_inimigos():
		_garantir_animador()
		if animador != null and dados != null:
			animador.configurar(dados.textura)
	elif animador != null:
		animador.parar()


func _checar_limites() -> void:
	## Fora da arena: volta imediatamente para o centro (sem ficar preso na borda).
	if _arena.size == Vector2.ZERO:
		var sm: Node = get_tree().get_first_node_in_group("spawn_manager")
		if sm != null and "arena" in sm:
			_arena = sm.arena as Rect2
	var limite: Rect2 = _arena.grow(-8.0)
	if limite.has_point(global_position):
		return
	global_position = _arena.get_center() + Vector2(randf_range(-60.0, 60.0), randf_range(-60.0, 60.0))
	velocity = Vector2.ZERO
	_knockback = Vector2.ZERO
	Efeitos.anel(get_parent(), global_position, 48.0, Color(1.0, 0.35, 0.35, 0.8), 0.35, 2.0)


func _z_index_por_posicao() -> void:
	z_index = 4 + int(global_position.y / 100.0)


func _calcular_direcao(delta: float) -> Vector2:
	var para_jogador: Vector2 = jogador.global_position - global_position
	var dir: Vector2 = para_jogador.normalized() if para_jogador.length() > 1.0 else Vector2.ZERO
	match comportamento:
		"ziguezague":
			var perp: Vector2 = dir.orthogonal()
			return (dir + perp * sin(_tempo * 4.2 + _fase_salto) * 0.75).normalized()
		"investida":
			return _dir_investida(dir, delta)
		"atirador":
			return _dir_atirador(dir, para_jogador.length(), delta)
		_:
			return dir


func _dir_investida(dir: Vector2, delta: float) -> Vector2:
	_estado_timer -= delta
	match _estado:
		"normal":
			if _estado_timer <= 0.0 and global_position.distance_to(jogador.global_position) < 360.0:
				_estado = "preparando"
				_estado_timer = 0.65
				if corpo != null:
					var tw: Tween = create_tween()
					tw.tween_property(corpo, "modulate", Color(1.0, 0.6, 0.4), 0.12)
					tw.tween_property(corpo, "modulate", Color.WHITE, 0.2)
				AudioManager.tocar_sfx("perigo", -16.0, 0.1)
			return dir * 0.6
		"preparando":
			if _estado_timer <= 0.0:
				_estado = "investindo"
				_estado_timer = 0.34
				AudioManager.tocar_sfx("dash", -12.0, 0.12)
			return dir * 0.1
		"investindo":
			if _estado_timer <= 0.0:
				_estado = "recuperando"
				_estado_timer = 0.7
			return dir * 3.1
		_:
			if _estado_timer <= 0.0:
				_estado = "normal"
				_estado_timer = 1.1
			return dir * 0.25


func _dir_atirador(dir: Vector2, dist: float, delta: float) -> Vector2:
	_tiro_timer -= delta
	var movimento: Vector2 = Vector2.ZERO
	if dist < 220.0:
		movimento = -dir
	elif dist > 360.0:
		movimento = dir
	else:
		movimento = dir.orthogonal() * 0.6
	if _tiro_timer <= 0.0:
		_tiro_timer = maxf(0.9, 1.9 - float(horda) * 0.03)
		_atirar_em(dir)
	return movimento.normalized()


func _atirar_em(dir: Vector2) -> void:
	if _cena_projetil == null or jogador == null:
		return
	var p: Projetil = _cena_projetil.instantiate() as Projetil
	if p == null:
		return
	get_parent().add_child(p)
	p.global_position = global_position + dir * (raio + 10.0)
	var el: String = dados.elemento if dados != null else ""
	var cfg: Dictionary = {
		"amigavel": false,
		"direcao": dir,
		"dano": 7.0 + float(horda) * 0.35,
		"velocidade": 330.0,
		"cor": Color("ff7a59") if dados != null else Color.WHITE,
		"tamanho": 1.0,
		"alcance": 900.0,
		"elemento": el,
	}
	# Coerência elemental: cada espécie atira do jeito do seu elemento.
	match el:
		"H":
			cfg["velocidade"] = 560.0
			cfg["tamanho"] = 0.8
			cfg["cor"] = Color("bff7ff")
		"Cl", "Na":
			cfg["velocidade"] = 290.0
			cfg["tamanho"] = 1.5
			cfg["cor"] = Color("9dff5a")
		"Hg":
			cfg["velocidade"] = 260.0
			cfg["tamanho"] = 1.4
			cfg["ricochetes"] = 4
			cfg["duracao"] = 2.5
			cfg["cor"] = Color("d8e8ff")
		"U", "X":
			cfg["velocidade"] = 190.0
			cfg["tamanho"] = 2.0
			cfg["dano"] = (7.0 + float(horda) * 0.35) * 1.4
			cfg["cor"] = Color("b6ff5a")
		"Fe":
			cfg["velocidade"] = 540.0
			cfg["tamanho"] = 1.25
			cfg["cor"] = Color("d7b08a")
	p.configurar(cfg)
	AudioManager.tocar_sfx("tiro_pesado", -18.0, 0.1)
	if animador != null:
		animador.tocar("ataque")


func _atualizar_empurrao(delta: float) -> void:
	_separacao_timer -= delta
	if _separacao_timer > 0.0:
		return
	_separacao_timer = 0.1
	var soma: Vector2 = Vector2.ZERO
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		if n == self:
			continue
		var outro: Enemy = n as Enemy
		if outro == null or not is_instance_valid(outro) or outro.morto:
			continue
		var dv: Vector2 = global_position - outro.global_position
		var d: float = dv.length()
		var minimo: float = raio + outro.raio + 4.0
		if d < minimo and d > 0.01:
			soma += dv.normalized() * (1.0 - d / minimo)
	_empurrao = soma.limit_length(1.0) * 90.0


func _checar_contato() -> void:
	if _dano_timer > 0.0 or jogador == null or not jogador.vivo:
		return
	if global_position.distance_to(jogador.global_position) <= raio + 14.0:
		_dano_timer = 0.55
		jogador.receber_dano(dano_contato)
		if dados != null and dados.elemento != "" and dados.elemento != "Polímero":
			jogador.aplicar_efeito_elemental(dados.elemento)
		if animador != null:
			animador.tocar("ataque")


func _jogadores_na_partida() -> int:
	## Escalonamento cooperativo: mais jogadores = inimigos mais fortes.
	if not is_inside_tree():
		return 1
	var total: int = 0
	for n: Node in get_tree().get_nodes_in_group("player"):
		var p: Player = n as Player
		if p != null and is_instance_valid(p):
			total += 1
	return maxi(1, total)


func tornar_comum() -> void:
	## Chefe derrotado passa a reaparecer como inimigo comum, bem mais fraco.
	vida_max *= 0.3
	vida = vida_max
	dano_contato *= 0.5
	escala_visual *= 0.72
	_aplicar_visual()


func receber_dano(valor: float, critico: bool = false) -> void:
	if autoridade_remota or morto or valor <= 0.0:
		return
	if invulneravel > 0.0:
		return
	vida -= valor
	queue_redraw()
	if animador != null:
		animador.tocar("dano")
	var cor_texto: Color = Color("ffd166") if not critico else Color("ff5f5f")
	Efeitos.texto_flutuante(get_parent(), global_position, str(int(round(valor))), cor_texto, 12 if not critico else 16, critico)
	if corpo != null:
		corpo.modulate = Color(2.2, 2.2, 2.2)
		var tw: Tween = corpo.create_tween()
		tw.tween_property(corpo, "modulate", Color.WHITE, 0.12)
	if GlobalManager.partida_ativa:
		# Dano não segura o rank: só abates/combos renovam o tempo de estilo.
		GlobalManager.registrar_estilo("DANO", 0.6, cor_texto, false)
	if vida <= 0.0:
		_morrer()


func aplicar_knockback(v: Vector2) -> void:
	_knockback += v


func _morrer() -> void:
	if morto:
		return
	morto = true
	_empurrao = Vector2.ZERO
	velocity = Vector2.ZERO
	collision_layer = 0
	collision_mask = 0
	if GlobalManager.partida_ativa:
		GlobalManager.registrar_abate(int(dados.pontos) if dados != null else 5)
	var dividiu: bool = _dividir()
	if dividiu:
		_soltar_morte(false)
		morreu.emit(self)
		queue_free()
		return
	_soltar_morte(true)
	morreu.emit(self)
	queue_free()


## Retorna true se o inimigo se dividiu em fragmentos (não solta drops normais).
func _dividir() -> bool:
	return false


func _soltar_morte(com_drops: bool) -> void:
	var cor_morte: Color = dados.cor if dados != null else Color("8ff3ff")
	Efeitos.particulas(get_parent(), global_position, cor_morte, 12 if not _eh_chefe() else 24, 200.0, 0.55, 2.5, "fogo" if _eh_chefe() else "sangue")
	Efeitos.anel(get_parent(), global_position, raio * 2.4, Color(cor_morte.r, cor_morte.g, cor_morte.b, 0.6), 0.32, 2.0)
	AudioManager.tocar_sfx(dados.som_morte if dados != null else "morte_inimigo", -12.0, 0.12)
	if not com_drops or dados == null:
		return
	# Cura por sangue químico: abates à queima-roupa liberam isótopos.
	if jogador != null and is_instance_valid(jogador) and jogador.vivo:
		if global_position.distance_to(jogador.global_position) <= DISTANCIA_CURA:
			jogador.curar(2.5 + float(dados.moedas) * 0.2)
			Efeitos.particulas(get_parent(), jogador.global_position, Color("ff5f92"), 5, 90.0, 0.35, 2.0, "estrela")
	if _cena_coletavel == null:
		return
	if dados.moedas > 0:
		var moeda: Coletavel = _cena_coletavel.instantiate() as Coletavel
		if moeda != null:
			get_parent().add_child(moeda)
			moeda.global_position = global_position + Vector2(randf_range(-14.0, 14.0), randf_range(-14.0, 14.0))
			moeda.configurar("moeda", int(dados.moedas))
	if dados.xp_drop > 0:
		var orbs: int = 1 if dados.xp_drop < 6 else 2
		for i: int in range(orbs):
			var orb: Coletavel = _cena_coletavel.instantiate() as Coletavel
			if orb != null:
				get_parent().add_child(orb)
				orb.global_position = global_position + Vector2(randf_range(-20.0, 20.0), randf_range(-20.0, 20.0))
				orb.configurar("xp", int(round(float(dados.xp_drop) / float(orbs))))


func _eh_chefe() -> bool:
	return dados != null and dados.is_boss


func percentual_vida() -> float:
	return clampf(vida / maxf(1.0, vida_max), 0.0, 1.0)


func _draw() -> void:
	## Barra de vida acima do inimigo (some quando a vida está cheia).
	if morto or dados == null or vida >= vida_max - 0.01:
		return
	var largura: float = clampf(30.0 + raio * 1.2, 34.0, 120.0)
	var altura: float = 5.0
	var topo: float = -36.0 * escala_visual - 12.0
	var caixa: Rect2 = Rect2(-largura * 0.5, topo, largura, altura)
	draw_rect(caixa.grow(1.0), Color(0.02, 0.03, 0.05, 0.9))
	draw_rect(caixa, Color(0.15, 0.06, 0.08, 0.95))
	var pct: float = percentual_vida()
	var cor: Color = Color("5fe08a") if pct > 0.5 else (Color("ffcf4a") if pct > 0.22 else Color("ff5f5f"))
	draw_rect(Rect2(caixa.position, Vector2(largura * pct, altura)), cor)
