class_name DadosInimigo
extends Resource
## Dados modulares de um inimigo. Cada .tres em res://resources/inimigos/ define uma espécie.

@export var id: String = ""
@export var nome: String = ""
@export var textura: String = ""
@export var cena: String = "res://scenes/enemy.tscn"
@export var vida: float = 20.0
@export var velocidade: float = 90.0
@export var dano_contato: float = 8.0
@export var comportamento: String = "perseguir"
@export var pontos: int = 10
@export var moedas: int = 1
@export var xp_drop: int = 3
@export var horda_minima: int = 1
@export var peso_spawn: float = 1.0
@export var escala: float = 1.0
@export var raio: float = 12.0
@export var cor: Color = Color(0.8, 0.9, 1.0)
@export var is_boss: bool = false
@export var divisoes: int = 0
@export var escala_vida_horda: float = 0.075
@export var elemento: String = ""
@export var som_morte: String = "morte_inimigo"
@export_range(0, 20) var ordem_chefe: int = 0
