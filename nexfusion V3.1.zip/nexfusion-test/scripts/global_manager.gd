extends Node
## GlobalManager (Autoload)
## Estado da partida, economia, estilo/combo, meta-progressão e persistência.
## Toda a lógica de save/load passa por aqui (user://save.cfg via ConfigFile).

const ARQUIVO_SAVE_BASE: String = "user://save_slot_%d.cfg"
const ARQUIVO_SAVE_LEGADO: String = "user://save.cfg"
const SLOTS_SAVE: int = 3
const HORDA_MAXIMA: int = 31
const TAMANHO_FASE: int = 10
const JANELA_COMBO: float = 1.5
const DECAIMENTO_ESTILO: float = 16.0
const PERDA_ESTILO_DANO: float = 45.0
const PENALIDADE_PONTOS_DANO: int = 35
const VERSAO_SAVE: int = 1

# ------------------------------------------------------------------ sinais
signal horda_alterada(horda: int)
signal horda_concluida(horda: int)
signal pontuacao_alterada(pontuacao: int)
signal moedas_alteradas(moedas: int)
signal combo_realizado(quantidade: int, nome: String)
signal combo_encerrado()
signal estilo_alterado(rank: String, multiplicador: float)
signal acao_estilo(texto: String, cor: Color)
signal xp_alterado(xp: int, necessario: int, nivel: int)
signal nivel_subiu(nivel: int)
signal partida_iniciada()
signal partida_encerrada(venceu: bool)
signal tela_tremeu(forca: float)
signal boss_derrotado(nome: String)
signal chefe_surgiu(nome: String, vida_maxima: float)
signal chefe_vida(vida: float, vida_maxima: float)
signal chefe_aviso(titulo: String, subtitulo: String)
signal fase_alterada(fase: int)
signal slot_alterado(slot: int)
signal tela_cheia_alterada(ativa: bool)
signal dano_recebido()
signal vida_jogador(atual: float, maxima: float)
signal qualidade_alterada(nivel: int)
signal modo_mobile_alterado(ativo: bool)
signal aparencia_alterada()
signal conquista_desbloqueada(id: String, nome: String, descricao: String)

# ------------------------------------------------------------------ ranks
const RANKS := [
	{"nome": "D", "min": 0.0, "cor": Color("7c8798")},
	{"nome": "C", "min": 25.0, "cor": Color("68b7ff")},
	{"nome": "B", "min": 60.0, "cor": Color("5fe08a")},
	{"nome": "A", "min": 110.0, "cor": Color("e8d24a")},
	{"nome": "S", "min": 170.0, "cor": Color("ff9b3d")},
	{"nome": "SS", "min": 240.0, "cor": Color("ff5f5f")},
	{"nome": "SSS", "min": 320.0, "cor": Color("ff5fd2")},
	{"nome": "ULTRAQUÍMICO", "min": 430.0, "cor": Color("8ff3ff")},
]

const RANKS_FINAIS := [
	{"nome": "C", "min": 0, "mult": 1.0, "cor": Color("7c8798")},
	{"nome": "B", "min": 1200, "mult": 1.15, "cor": Color("5fe08a")},
	{"nome": "A", "min": 2400, "mult": 1.5, "cor": Color("e8d24a")},
	{"nome": "S", "min": 3800, "mult": 1.6, "cor": Color("ff9b3d")},
	{"nome": "S++", "min": 5400, "mult": 1.7, "cor": Color("8ff3ff")},
]

## Cartas de habilidade PERMANENTES: bônus sutis, até 20 cópias de cada.
## Substituem os antigos upgrades numéricos diretos.
const UPGRADES := {
	"vida_maxima": {"nome": "Carta Vital", "desc": "+2 de vida máxima por cópia", "max": 20, "preco": 30, "crescimento": 1.12, "simbolo": "♥"},
	"dano": {"nome": "Carta de Impacto", "desc": "+1% de dano por cópia", "max": 20, "preco": 34, "crescimento": 1.12, "simbolo": "✦"},
	"cadencia": {"nome": "Carta de Fluxo", "desc": "+0,8% de cadência por cópia", "max": 20, "preco": 32, "crescimento": 1.12, "simbolo": "≫"},
	"velocidade": {"nome": "Carta Cinética", "desc": "+0,6% de velocidade por cópia", "max": 20, "preco": 28, "crescimento": 1.12, "simbolo": "➜"},
	"critico": {"nome": "Carta de Precisão", "desc": "+0,4% de crítico por cópia", "max": 20, "preco": 36, "crescimento": 1.13, "simbolo": "◎"},
	"recarga_dash": {"nome": "Carta de Esquiva", "desc": "+0,7% de recarga do dash por cópia", "max": 20, "preco": 30, "crescimento": 1.12, "simbolo": "↯"},
}

const CONQUISTAS := {
	"derrotar_cloro": {
		"nome": "Cloro Neutralizado",
		"desc": "Derrote o mini-boss Cloro.",
		"simbolo": "Cl",
		"icone": "res://sprites/conquistas/cloro.png",
	},
	"derrotar_mercurio": {
		"nome": "Metal Líquido",
		"desc": "Derrote o mini-boss Mercúrio.",
		"simbolo": "Hg",
		"icone": "res://sprites/conquistas/mercurio.png",
	},
	"derrotar_uranio": {
		"nome": "Fissão Controlada",
		"desc": "Derrote o mini-boss Urânio.",
		"simbolo": "U",
		"icone": "res://sprites/conquistas/uranio.png",
	},
	"derrotar_elemento_supremo": {
		"nome": "Além da Tabela",
		"desc": "Derrote o Elemento Supremo.",
		"simbolo": "X",
		"icone": "res://sprites/conquistas/supremo.png",
	},
}

const ARMAS_ELEMENTOS: Array[String] = ["tungstenio", "helio", "ferro", "litio", "neonio", "mercurio"]

## Qualidade gráfica: 0 leve, 1 moderada, 2 pesada.
const QUALIDADES := [
	{
		"nome": "LEVE",
		"cor": Color("5fe08a"),
		"resumo": "Para computadores modestos.",
		"itens": ["Poucas partículas", "Animação de sprite só no jogador", "Sem luzes e sombras"],
	},
	{
		"nome": "MODERADA",
		"cor": Color("8ff3ff"),
		"resumo": "Equilíbrio entre visual e desempenho.",
		"itens": ["Partículas completas", "Animações em todos os personagens", "Sem luzes dinâmicas"],
	},
	{
		"nome": "PESADA",
		"cor": Color("a78bfa"),
		"resumo": "Visual máximo, exige mais da máquina.",
		"itens": ["Todas as partículas", "Animações completas", "Luz dinâmica e sombras"],
	},
]

const SKINS_JOGADOR := [
	{"nome": "CIANO", "cor": Color(0.72, 0.95, 1.0)},
	{"nome": "MAGENTA", "cor": Color(1.0, 0.62, 0.9)},
	{"nome": "VERDE", "cor": Color(0.66, 1.0, 0.7)},
	{"nome": "ÂMBAR", "cor": Color(1.0, 0.85, 0.45)},
	{"nome": "VERMELHO", "cor": Color(1.0, 0.55, 0.55)},
	{"nome": "BRANCO", "cor": Color(1.0, 1.0, 1.0)},
]

const SKINS_ARMA := [
	{"nome": "AÇO", "cor": Color(1.0, 1.0, 1.0)},
	{"nome": "OURO", "cor": Color(1.0, 0.85, 0.42)},
	{"nome": "NEON", "cor": Color(0.6, 1.0, 1.0)},
	{"nome": "TÓXICO", "cor": Color(0.66, 1.0, 0.5)},
	{"nome": "MAGENTA", "cor": Color(1.0, 0.55, 0.9)},
]

# ------------------------------------------------------------------ estado permanente
var moedas: int = 0
var maior_horda_alcancada: int = 0
var total_abates: int = 0
var partidas_jogadas: int = 0
var niveis_upgrade: Dictionary = {}
var armas_desbloqueadas: Array[String] = ["tungstenio"]
var arma_equipada: String = "tungstenio"
var volume_musica: float = 0.75
var volume_sfx: float = 0.85
var tela_cheia: bool = false
var config_teclas: Dictionary = {}
var qualidade: int = 1
var modo_mobile: bool = false
var dispositivo_escolhido: bool = false
## Tutorial inicial: aparece antes da primeira partida de um save novo.
var tutorial_visto: bool = false
var mostrar_fps: bool = false
var mostrar_ping: bool = false
var nick: String = "JOGADOR"
var skin_player: int = 0
var skin_arma: int = 0
# Co-op LAN: cargas de ressurreição ganhas ao escolher a carta própria.
var cargas_ressurreicao: int = 0

# ------------------------------------------------------------------ estado da run
var partida_ativa: bool = false
var horda_atual: int = 1
var horda_inicial: int = 1
var pontuacao: int = 0
var moedas_partida: int = 0
var nivel_run: int = 1
var xp_run: int = 0
var xp_necessario: int = 14
var abates_run: int = 0
var tempo_run: float = 0.0
var estilo_pontos: float = 0.0
var estilo_maximo: float = 0.0
var rank_estilo: String = "D"
var multiplicador_estilo: float = 1.0
var combo_contagem: int = 0
var cartas_coletadas: Array[String] = []
var ultimo_resultado: Dictionary = {}
var horda_skip_alvo: int = 1
var slot_ativo: int = 1
var fase: int = 1
var cartas_descobertas: Array[String] = []
var inimigos_descobertos: Array[String] = []
var conquistas: Dictionary = {}

var _combo_tempo: float = 0.0
var _tempo_sem_estilo: float = 0.0
var _cache_armas: Dictionary = {}
var _salvar_pendente: bool = false
var _salvar_timer: float = 0.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	garantir_acoes_padrao()
	carregar()
	_aplicar_config_teclas()


func _input(evento: InputEvent) -> void:
	## F11 alterna tela cheia em qualquer tela (menu, pausa, partida).
	var tecla: InputEventKey = evento as InputEventKey
	if tecla == null or not tecla.pressed or tecla.echo:
		return
	var codigo: int = tecla.physical_keycode if tecla.physical_keycode != 0 else tecla.keycode
	if codigo == KEY_F11:
		alternar_tela_cheia()
		get_viewport().set_input_as_handled()


func alternar_tela_cheia() -> void:
	definir_tela_cheia(not tela_cheia)


func _process(delta: float) -> void:
	# Save adiado (sliders de volume, skins): evita gravar o arquivo a cada tick.
	if _salvar_pendente:
		_salvar_timer += delta
		if _salvar_timer >= 0.6:
			_salvar_pendente = false
			_salvar_timer = 0.0
			salvar()
	if not partida_ativa or get_tree().paused:
		return
	tempo_run += delta
	if _combo_tempo > 0.0:
		_combo_tempo -= delta
		if _combo_tempo <= 0.0 and combo_contagem > 0:
			combo_contagem = 0
			combo_encerrado.emit()
	_tempo_sem_estilo += delta
	# A nota só cai depois de um tempo REAL sem abates (atirar não segura o rank).
	if _tempo_sem_estilo > 2.4 and estilo_pontos > 0.0:
		estilo_pontos = maxf(0.0, estilo_pontos - DECAIMENTO_ESTILO * delta)
		_atualizar_rank()


# ------------------------------------------------------------------ partida
func iniciar_partida(horda_inicial_run: int = 1) -> void:
	var h: int = clampi(horda_inicial_run, 1, HORDA_MAXIMA)
	horda_inicial = h
	horda_atual = h
	partida_ativa = true
	pontuacao = 0
	moedas_partida = 0
	nivel_run = 1
	xp_run = 0
	xp_necessario = _xp_para_nivel(1)
	abates_run = 0
	tempo_run = 0.0
	fase = 1
	estilo_pontos = 0.0
	estilo_maximo = 0.0
	rank_estilo = "D"
	multiplicador_estilo = 1.0
	combo_contagem = 0
	cargas_ressurreicao = 0
	_combo_tempo = 0.0
	_tempo_sem_estilo = 0.0
	cartas_coletadas.clear()
	partidas_jogadas += 1
	partida_iniciada.emit()
	fase_alterada.emit(fase)
	horda_alterada.emit(horda_atual)
	pontuacao_alterada.emit(pontuacao)
	xp_alterado.emit(xp_run, xp_necessario, nivel_run)
	estilo_alterado.emit(rank_estilo, multiplicador_estilo)


func concluir_horda() -> void:
	if not partida_ativa:
		return
	var concluida: int = horda_atual
	if maior_horda_alcancada < concluida:
		maior_horda_alcancada = concluida
	horda_concluida.emit(concluida)
	if horda_atual < HORDA_MAXIMA:
		horda_atual += 1
		horda_alterada.emit(horda_atual)
	salvar()


func finalizar_partida(venceu: bool) -> void:
	if not partida_ativa:
		return
	partida_ativa = false
	var rank: Dictionary = _calcular_rank_final()
	var missao: float = float(rank["mult"])
	var moedas_finais: int = int(round(float(moedas_partida) * missao))
	moedas += moedas_finais
	if maior_horda_alcancada < horda_atual:
		maior_horda_alcancada = horda_atual
	ultimo_resultado = {
		"venceu": venceu,
		"horda": horda_atual,
		"nivel": nivel_run,
		"pontuacao": pontuacao,
		"abates": abates_run,
		"tempo": tempo_run,
		"rank": String(rank["nome"]),
		"multiplicador": missao,
		"moedas_base": moedas_partida,
		"moedas_finais": moedas_finais,
		"estilo_maximo": estilo_maximo,
		"cartas": cartas_coletadas.duplicate(),
	}
	combo_contagem = 0
	salvar()
	moedas_alteradas.emit(moedas)
	partida_encerrada.emit(venceu)


func _calcular_rank_final() -> Dictionary:
	var valor: int = pontuacao + horda_atual * 120 + nivel_run * 50 + abates_run * 6 + int(estilo_maximo)
	var escolhido: Dictionary = RANKS_FINAIS[0]
	for r: Dictionary in RANKS_FINAIS:
		if valor >= int(r["min"]):
			escolhido = r
	return escolhido


func _xp_para_nivel(nivel: int) -> int:
	return 14 + int(pow(float(nivel), 1.42) * 9.0)


# ------------------------------------------------------------------ pontuação / estilo
func adicionar_pontos(base: int) -> void:
	if not partida_ativa:
		return
	var ganho: int = int(round(float(base) * multiplicador_estilo))
	pontuacao = maxi(0, pontuacao + ganho)
	pontuacao_alterada.emit(pontuacao)


func registrar_estilo(acao: String, valor: float = 8.0, cor: Color = Color("8ff3ff"), renovar_timer: bool = true) -> void:
	if not partida_ativa:
		return
	estilo_pontos = minf(estilo_pontos + valor, 900.0)
	estilo_maximo = maxf(estilo_maximo, estilo_pontos)
	if renovar_timer:
		_tempo_sem_estilo = 0.0
	acao_estilo.emit(acao, cor)
	_atualizar_rank()


func _atualizar_rank() -> void:
	var novo: String = "D"
	var mult: float = 1.0
	for i: int in range(RANKS.size()):
		var r: Dictionary = RANKS[i]
		if estilo_pontos >= float(r["min"]):
			novo = String(r["nome"])
			mult = 1.0 + float(i) * 0.28
	if novo != rank_estilo:
		rank_estilo = novo
		multiplicador_estilo = mult
		estilo_alterado.emit(rank_estilo, multiplicador_estilo)
	else:
		multiplicador_estilo = mult


func cor_rank(nome: String) -> Color:
	for r: Dictionary in RANKS:
		if String(r["nome"]) == nome:
			return r["cor"]
	return Color("7c8798")


func registrar_abate(pontos: int) -> void:
	if not partida_ativa:
		return
	abates_run += 1
	total_abates += 1
	combo_contagem += 1
	_combo_tempo = JANELA_COMBO
	# Abate isolado vale pouco; multi-kill escala de forma agressiva.
	var ganho: int = int(round(float(pontos) * 0.55))
	if combo_contagem >= 2:
		combo_realizado.emit(combo_contagem, _nome_combo(combo_contagem))
		ganho += int(round(float(pontos) * pow(float(combo_contagem - 1), 2.0) * 1.8))
	adicionar_pontos(ganho)
	registrar_estilo("ABATE", 2.0 + float(combo_contagem) * 1.5, Color("5fe08a"), true)


func _nome_combo(qtd: int) -> String:
	match qtd:
		2:
			return "DOUBLE KILL"
		3:
			return "TRIPLE KILL"
		4:
			return "MULTI KILL x4"
		_:
			return "MULTI KILL x%d" % qtd


func sofrer_dano_penalidade() -> void:
	if not partida_ativa:
		return
	pontuacao = maxi(0, pontuacao - PENALIDADE_PONTOS_DANO)
	pontuacao_alterada.emit(pontuacao)
	# Dano derruba a classificação na hora (não é só um desconto gradual).
	estilo_pontos = maxf(0.0, estilo_pontos - PERDA_ESTILO_DANO * 1.8)
	_tempo_sem_estilo = 0.0
	combo_contagem = 0
	_combo_tempo = 0.0
	_atualizar_rank()
	dano_recebido.emit()


# ------------------------------------------------------------------ xp / moedas
func adicionar_xp(valor: int) -> void:
	if not partida_ativa:
		return
	xp_run += valor
	var subiu: bool = false
	while xp_run >= xp_necessario:
		xp_run -= xp_necessario
		nivel_run += 1
		xp_necessario = _xp_para_nivel(nivel_run)
		subiu = true
	xp_alterado.emit(xp_run, xp_necessario, nivel_run)
	if subiu:
		nivel_subiu.emit(nivel_run)


func desbloquear_conquista(id: String) -> bool:
	if not CONQUISTAS.has(id) or bool(conquistas.get(id, false)):
		return false
	conquistas[id] = true
	salvar()
	var dados: Dictionary = CONQUISTAS[id] as Dictionary
	conquista_desbloqueada.emit(id, String(dados["nome"]), String(dados["desc"]))
	return true


func conquista_obtida(id: String) -> bool:
	return bool(conquistas.get(id, false))


func registrar_carta(id: String) -> void:
	cartas_coletadas.append(id)
	if not cartas_descobertas.has(id):
		cartas_descobertas.append(id)


func registrar_inimigo_descoberto(id: String) -> void:
	if id == "" or inimigos_descobertos.has(id):
		return
	inimigos_descobertos.append(id)


# ------------------------------------------------------------------ fases
func avancar_fase() -> void:
	fase += 1
	fase_alterada.emit(fase)
	salvar()


func multiplicador_fase() -> float:
	## Cada nova volta na arena deixa os inimigos mais duros (vida e dano).
	return 1.0 + float(fase - 1) * 0.35


func adicionar_moedas_partida(valor: int) -> void:
	moedas_partida = maxi(0, moedas_partida + valor)
	moedas_alteradas.emit(moedas + moedas_partida)


func gastar_moedas_partida(valor: int) -> bool:
	## Mercador de cartas: paga com o dinheiro coletado na run.
	if valor <= 0:
		return true
	if moedas_partida < valor:
		return false
	moedas_partida -= valor
	moedas_alteradas.emit(moedas + moedas_partida)
	return true


# ------------------------------------------------------------------ upgrades permanentes
func nivel_upgrade(id: String) -> int:
	return int(niveis_upgrade.get(id, 0))


func preco_upgrade(id: String) -> int:
	if not UPGRADES.has(id):
		return 0
	var dados: Dictionary = UPGRADES[id]
	var nivel: int = nivel_upgrade(id)
	return int(round(float(dados["preco"]) * pow(float(dados["crescimento"]), float(nivel))))


func pode_comprar_upgrade(id: String) -> bool:
	if not UPGRADES.has(id):
		return false
	if nivel_upgrade(id) >= int(UPGRADES[id]["max"]):
		return false
	return moedas >= preco_upgrade(id)


func comprar_upgrade(id: String) -> bool:
	if not pode_comprar_upgrade(id):
		return false
	moedas -= preco_upgrade(id)
	niveis_upgrade[id] = nivel_upgrade(id) + 1
	salvar()
	moedas_alteradas.emit(moedas)
	return true


func vida_maxima_bonus() -> float:
	return float(nivel_upgrade("vida_maxima")) * 2.0


func multiplicador_velocidade() -> float:
	return 1.0 + float(nivel_upgrade("velocidade")) * 0.006


func multiplicador_recarga_dash() -> float:
	return maxf(0.6, 1.0 - float(nivel_upgrade("recarga_dash")) * 0.007)


func multiplicador_dano_permanente() -> float:
	return 1.0 + float(nivel_upgrade("dano")) * 0.01


func multiplicador_cadencia_permanente() -> float:
	return 1.0 + float(nivel_upgrade("cadencia")) * 0.008


func bonus_critico_permanente() -> float:
	return float(nivel_upgrade("critico")) * 0.004


# ------------------------------------------------------------------ arsenal
func arma_desbloqueada(id: String) -> bool:
	return armas_desbloqueadas.has(id)


func custo_arma(id: String) -> int:
	var dados: DadosArma = carregar_arma(id)
	if dados == null:
		return 0
	return dados.custo


func comprar_arma(id: String) -> bool:
	if arma_desbloqueada(id):
		return false
	var custo: int = custo_arma(id)
	if moedas < custo:
		return false
	moedas -= custo
	armas_desbloqueadas.append(id)
	arma_equipada = id
	salvar()
	moedas_alteradas.emit(moedas)
	return true


func equipar_arma(id: String) -> bool:
	if not arma_desbloqueada(id):
		return false
	arma_equipada = id
	salvar()
	return true


func carregar_arma(id: String) -> DadosArma:
	## Cache: os tiros consultam a arma com frequência; evita load() repetido.
	if _cache_armas.has(id):
		return _cache_armas[id] as DadosArma
	var caminho: String = "res://resources/armas/%s.tres" % id
	if not ResourceLoader.exists(caminho):
		return null
	var rec: Resource = load(caminho)
	if rec is DadosArma:
		var dados: DadosArma = rec as DadosArma
		_cache_armas[id] = dados
		return dados
	return null


func arma_atual() -> DadosArma:
	var dados: DadosArma = carregar_arma(arma_equipada)
	if dados == null:
		dados = carregar_arma("tungstenio")
	return dados


# ------------------------------------------------------------------ save / load
func caminho_save(slot: int = 0) -> String:
	var alvo: int = slot if slot > 0 else slot_ativo
	return ARQUIVO_SAVE_BASE % clampi(alvo, 1, SLOTS_SAVE)


func info_slot(slot: int) -> Dictionary:
	var cfg: ConfigFile = ConfigFile.new()
	if cfg.load(caminho_save(slot)) != OK:
		return {"existe": false, "horda": 0, "moedas": 0, "fase": 1}
	return {
		"existe": true,
		"horda": int(cfg.get_value("progresso", "maior_horda", 0)),
		"moedas": int(cfg.get_value("progresso", "moedas", 0)),
		"fase": int(cfg.get_value("progresso", "fase", 1)),
	}


func definir_slot(slot: int) -> void:
	var alvo: int = clampi(slot, 1, SLOTS_SAVE)
	if alvo == slot_ativo:
		return
	salvar()
	slot_ativo = alvo
	carregar()
	slot_alterado.emit(slot_ativo)
	moedas_alteradas.emit(moedas)


func salvar() -> void:
	var cfg: ConfigFile = ConfigFile.new()
	cfg.set_value("progresso", "moedas", moedas)
	cfg.set_value("progresso", "maior_horda", maior_horda_alcancada)
	cfg.set_value("progresso", "total_abates", total_abates)
	cfg.set_value("progresso", "partidas", partidas_jogadas)
	cfg.set_value("progresso", "versao", VERSAO_SAVE)
	for id: String in UPGRADES.keys():
		cfg.set_value("upgrades", id, nivel_upgrade(id))
	cfg.set_value("armas", "desbloqueadas", PackedStringArray(armas_desbloqueadas))
	cfg.set_value("armas", "equipada", arma_equipada)
	cfg.set_value("audio", "musica", volume_musica)
	cfg.set_value("audio", "sfx", volume_sfx)
	cfg.set_value("video", "tela_cheia", tela_cheia)
	cfg.set_value("input", "teclas", JSON.stringify(config_teclas))
	cfg.set_value("video", "qualidade", qualidade)
	cfg.set_value("video", "mostrar_fps", mostrar_fps)
	cfg.set_value("video", "mostrar_ping", mostrar_ping)
	cfg.set_value("geral", "modo_mobile", modo_mobile)
	cfg.set_value("geral", "dispositivo_escolhido", dispositivo_escolhido)
	cfg.set_value("geral", "tutorial_visto", tutorial_visto)
	cfg.set_value("geral", "nick", nick)
	cfg.set_value("geral", "skin_player", skin_player)
	cfg.set_value("geral", "skin_arma", skin_arma)
	cfg.set_value("progresso", "fase", fase)
	cfg.set_value("registros", "cartas", PackedStringArray(cartas_descobertas))
	cfg.set_value("registros", "inimigos", PackedStringArray(inimigos_descobertos))
	for id: String in CONQUISTAS.keys():
		cfg.set_value("conquistas", id, bool(conquistas.get(id, false)))
	cfg.set_value("save", "slot", slot_ativo)
	var err: int = cfg.save(caminho_save())
	if err != OK:
		push_warning("GlobalManager: não foi possível salvar (%s)" % err)


func carregar() -> void:
	var cfg: ConfigFile = ConfigFile.new()
	if cfg.load(caminho_save()) != OK:
		if slot_ativo == 1 and cfg.load(ARQUIVO_SAVE_LEGADO) == OK:
			pass
		else:
			_zerar_estado()
			_garantir_padroes()
			return
	moedas = int(cfg.get_value("progresso", "moedas", 0))
	maior_horda_alcancada = int(cfg.get_value("progresso", "maior_horda", 0))
	total_abates = int(cfg.get_value("progresso", "total_abates", 0))
	partidas_jogadas = int(cfg.get_value("progresso", "partidas", 0))
	for id: String in UPGRADES.keys():
		niveis_upgrade[id] = int(cfg.get_value("upgrades", id, 0))
	var desbloqueadas: PackedStringArray = cfg.get_value("armas", "desbloqueadas", PackedStringArray(["tungstenio"]))
	armas_desbloqueadas.clear()
	for a: String in desbloqueadas:
		if not armas_desbloqueadas.has(a):
			armas_desbloqueadas.append(a)
	if armas_desbloqueadas.is_empty():
		armas_desbloqueadas.append("tungstenio")
	if not armas_desbloqueadas.has("tungstenio"):
		armas_desbloqueadas.append("tungstenio")
	arma_equipada = String(cfg.get_value("armas", "equipada", "tungstenio"))
	if not armas_desbloqueadas.has(arma_equipada):
		arma_equipada = "tungstenio"
	volume_musica = clampf(float(cfg.get_value("audio", "musica", 0.75)), 0.0, 1.0)
	volume_sfx = clampf(float(cfg.get_value("audio", "sfx", 0.85)), 0.0, 1.0)
	tela_cheia = bool(cfg.get_value("video", "tela_cheia", false))
	qualidade = clampi(int(cfg.get_value("video", "qualidade", 1)), 0, QUALIDADES.size() - 1)
	mostrar_fps = bool(cfg.get_value("video", "mostrar_fps", false))
	mostrar_ping = bool(cfg.get_value("video", "mostrar_ping", false))
	modo_mobile = bool(cfg.get_value("geral", "modo_mobile", false))
	dispositivo_escolhido = bool(cfg.get_value("geral", "dispositivo_escolhido", false))
	tutorial_visto = bool(cfg.get_value("geral", "tutorial_visto", false))
	nick = String(cfg.get_value("geral", "nick", "JOGADOR")).strip_edges()
	if nick == "":
		nick = "JOGADOR"
	skin_player = clampi(int(cfg.get_value("geral", "skin_player", 0)), 0, SKINS_JOGADOR.size() - 1)
	skin_arma = clampi(int(cfg.get_value("geral", "skin_arma", 0)), 0, SKINS_ARMA.size() - 1)
	fase = maxi(1, int(cfg.get_value("progresso", "fase", 1)))
	cartas_descobertas.clear()
	for c: String in cfg.get_value("registros", "cartas", PackedStringArray()):
		cartas_descobertas.append(c)
	inimigos_descobertos.clear()
	for i: String in cfg.get_value("registros", "inimigos", PackedStringArray()):
		inimigos_descobertos.append(i)
	conquistas.clear()
	for id: String in CONQUISTAS.keys():
		conquistas[id] = bool(cfg.get_value("conquistas", id, false))
	var json_teclas: String = String(cfg.get_value("input", "teclas", "{}"))
	var parsed: Variant = JSON.parse_string(json_teclas)
	if parsed is Dictionary:
		config_teclas = parsed as Dictionary
	_garantir_padroes()
	_aplicar_tela()


func _zerar_estado() -> void:
	moedas = 0
	maior_horda_alcancada = 0
	total_abates = 0
	partidas_jogadas = 0
	niveis_upgrade.clear()
	armas_desbloqueadas = ["tungstenio"]
	arma_equipada = "tungstenio"
	fase = 1
	cartas_descobertas.clear()
	inimigos_descobertos.clear()
	conquistas.clear()
	tutorial_visto = false


func _garantir_padroes() -> void:
	for id: String in UPGRADES.keys():
		if not niveis_upgrade.has(id):
			niveis_upgrade[id] = 0


func resetar_progresso() -> void:
	_zerar_estado()
	_garantir_padroes()
	salvar()
	moedas_alteradas.emit(moedas)


# ------------------------------------------------------------------ configurações
func definir_volume_musica(v: float) -> void:
	volume_musica = clampf(v, 0.0, 1.0)
	if AudioManager != null:
		AudioManager.definir_volume(AudioManager.BUS_MUSICA, volume_musica)
	agendar_salvamento()


func definir_volume_sfx(v: float) -> void:
	volume_sfx = clampf(v, 0.0, 1.0)
	if AudioManager != null:
		AudioManager.definir_volume(AudioManager.BUS_SFX, volume_sfx)
	agendar_salvamento()


func agendar_salvamento() -> void:
	_salvar_pendente = true
	_salvar_timer = 0.0


# ------------------------------------------------------------------ aparência / qualidade
func definir_qualidade(nivel: int) -> void:
	qualidade = clampi(nivel, 0, QUALIDADES.size() - 1)
	agendar_salvamento()
	qualidade_alterada.emit(qualidade)


func nome_qualidade() -> String:
	return String((QUALIDADES[qualidade] as Dictionary)["nome"])


func particulas_reduzidas() -> bool:
	return qualidade == 0


func animar_inimigos() -> bool:
	return qualidade > 0


func luzes_ativas() -> bool:
	return qualidade >= 2


func definir_modo_mobile(ativo: bool) -> void:
	if modo_mobile == ativo:
		return
	modo_mobile = ativo
	salvar()
	modo_mobile_alterado.emit(modo_mobile)


func definir_tutorial_visto() -> void:
	## Chamado ao concluir ou pular o tutorial inicial.
	if tutorial_visto:
		return
	tutorial_visto = true
	salvar()


func definir_dispositivo(mobile: bool) -> void:
	modo_mobile = mobile
	dispositivo_escolhido = true
	salvar()
	modo_mobile_alterado.emit(modo_mobile)


func definir_nick(novo: String) -> void:
	var limpo: String = novo.strip_edges().substr(0, 16)
	if limpo == "":
		limpo = "JOGADOR"
	nick = limpo.to_upper()
	agendar_salvamento()


func definir_mostrar_fps(ativo: bool) -> void:
	mostrar_fps = ativo
	agendar_salvamento()


func definir_mostrar_ping(ativo: bool) -> void:
	mostrar_ping = ativo
	agendar_salvamento()


func definir_skin_player(indice: int) -> void:
	skin_player = clampi(indice, 0, SKINS_JOGADOR.size() - 1)
	agendar_salvamento()
	aparencia_alterada.emit()


func definir_skin_arma(indice: int) -> void:
	skin_arma = clampi(indice, 0, SKINS_ARMA.size() - 1)
	agendar_salvamento()
	aparencia_alterada.emit()


func cor_skin_player() -> Color:
	return (SKINS_JOGADOR[skin_player] as Dictionary)["cor"] as Color


func cor_skin_arma() -> Color:
	return (SKINS_ARMA[skin_arma] as Dictionary)["cor"] as Color


func nome_skin_player() -> String:
	return String((SKINS_JOGADOR[skin_player] as Dictionary)["nome"])


func nome_skin_arma() -> String:
	return String((SKINS_ARMA[skin_arma] as Dictionary)["nome"])


func definir_cursor(visivel: bool) -> void:
	## Esconde o cursor durante a partida; menus e janelas mostram de novo.
	if DisplayServer.get_name() == "headless":
		return
	var modo: Input.MouseMode = Input.MOUSE_MODE_VISIBLE if visivel else Input.MOUSE_MODE_HIDDEN
	if Input.get_mouse_mode() != modo:
		Input.set_mouse_mode(modo)


func definir_tela_cheia(ativa: bool) -> void:
	tela_cheia = ativa
	_aplicar_tela()
	salvar()
	tela_cheia_alterada.emit(tela_cheia)


func _aplicar_tela() -> void:
	if DisplayServer.get_name() == "headless":
		return
	var modo: DisplayServer.WindowMode = DisplayServer.WINDOW_MODE_FULLSCREEN if tela_cheia else DisplayServer.WINDOW_MODE_WINDOWED
	DisplayServer.window_set_mode(modo)


# ------------------------------------------------------------------ input
func garantir_acoes_padrao() -> void:
	var padroes: Dictionary = {
		"mover_esquerda": [KEY_A, KEY_LEFT],
		"mover_direita": [KEY_D, KEY_RIGHT],
		"mover_cima": [KEY_W, KEY_UP],
		"mover_baixo": [KEY_S, KEY_DOWN],
		"dash_esquiva": [KEY_SPACE, KEY_SHIFT],
		"aparar_melee": [KEY_F],
		"pausar": [KEY_ESCAPE],
	}
	for acao: String in padroes.keys():
		if not InputMap.has_action(acao):
			InputMap.add_action(acao)
		if InputMap.action_get_events(acao).is_empty():
			for tecla: int in padroes[acao]:
				var ev: InputEventKey = InputEventKey.new()
				ev.physical_keycode = tecla
				InputMap.action_add_event(acao, ev)
	for acao_mouse: String in ["tiro_primario", "tiro_carregado"]:
		if not InputMap.has_action(acao_mouse):
			InputMap.add_action(acao_mouse)


func remapear_acao(acao: String, evento: InputEvent) -> void:
	if not InputMap.has_action(acao):
		InputMap.add_action(acao)
	InputMap.action_erase_events(acao)
	InputMap.action_add_event(acao, evento)
	var entrada: Dictionary = {"tipo": "mouse" if evento is InputEventMouseButton else "tecla"}
	if evento is InputEventKey:
		var k: InputEventKey = evento as InputEventKey
		entrada["keycode"] = k.physical_keycode if k.physical_keycode != 0 else k.keycode
	elif evento is InputEventMouseButton:
		entrada["botao"] = (evento as InputEventMouseButton).button_index
	config_teclas[acao] = entrada
	salvar()


func _aplicar_config_teclas() -> void:
	for acao_v: Variant in config_teclas.keys():
		var acao: String = String(acao_v)
		var dado: Variant = config_teclas[acao_v]
		if not dado is Dictionary:
			continue
		var d: Dictionary = dado as Dictionary
		var ev: InputEvent = null
		if String(d.get("tipo", "tecla")) == "mouse":
			var mb: InputEventMouseButton = InputEventMouseButton.new()
			mb.button_index = int(d.get("botao", 1))
			ev = mb
		else:
			var k: InputEventKey = InputEventKey.new()
			k.physical_keycode = int(d.get("keycode", 0))
			ev = k
		if ev != null:
			if not InputMap.has_action(acao):
				InputMap.add_action(acao)
			InputMap.action_erase_events(acao)
			InputMap.action_add_event(acao, ev)


func nome_tecla(acao: String) -> String:
	var eventos: Array[InputEvent] = InputMap.action_get_events(acao)
	if eventos.is_empty():
		return "—"
	var ev: InputEvent = eventos[0]
	if ev is InputEventKey:
		var k: InputEventKey = ev as InputEventKey
		var code: int = k.physical_keycode if k.physical_keycode != 0 else k.keycode
		return OS.get_keycode_string(code)
	if ev is InputEventMouseButton:
		match (ev as InputEventMouseButton).button_index:
			MOUSE_BUTTON_LEFT:
				return "Botão Esq."
			MOUSE_BUTTON_RIGHT:
				return "Botão Dir."
			MOUSE_BUTTON_MIDDLE:
				return "Botão Meio"
			_:
				return "Botão %d" % (ev as InputEventMouseButton).button_index
	return "—"


func nome_teclas(acao: String) -> String:
	## Lista todos os atalhos da ação (ex.: "Espaço / Shift").
	var eventos: Array[InputEvent] = InputMap.action_get_events(acao)
	if eventos.is_empty():
		return "—"
	var partes: Array[String] = []
	for ev: InputEvent in eventos:
		var texto: String = ""
		if ev is InputEventKey:
			var k: InputEventKey = ev as InputEventKey
			var code: int = k.physical_keycode if k.physical_keycode != 0 else k.keycode
			texto = OS.get_keycode_string(code)
		elif ev is InputEventMouseButton:
			match (ev as InputEventMouseButton).button_index:
				MOUSE_BUTTON_LEFT:
					texto = "Botão Esq."
				MOUSE_BUTTON_RIGHT:
					texto = "Botão Dir."
				MOUSE_BUTTON_MIDDLE:
					texto = "Botão Meio"
				_:
					texto = "Botão %d" % (ev as InputEventMouseButton).button_index
		if texto != "" and not partes.has(texto):
			partes.append(texto)
	return " / ".join(partes) if not partes.is_empty() else "—"
