extends Node
## Verificação isolada da transição dimensional 3D (executar com janela).

var falhas: int = 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	await get_tree().process_frame
	var fase: Fase3D = Fase3D.new()
	add_child(fase)
	for _i: int in range(6):
		await get_tree().process_frame
	_ok(fase._viewport != null and fase._camera != null and fase._camera.current, "câmera 3D em primeira pessoa ativa")
	_ok(fase._eletrons.size() == 18, "asas com 18 elétrons orbitando")
	_ok(fase._arena != null and fase._arena.position.y < -2.0, "arena flutuante sob a batalha")
	_ok(fase._terra != null and (fase._terra.mesh as SphereMesh).radius >= 100.0, "Terra gigante visível abaixo da arena")
	_ok(fase._planetas.size() >= 3, "outros planetas ao redor (%d)" % fase._planetas.size())
	_ok(fase._estrelas != null and fase._estrelas.multimesh != null and fase._estrelas.multimesh.instance_count >= 500, "campo de estrelas em volta da arena")
	_ok(AudioManager._musica_atual == "espaco", "música espacial toca na batalha 3D")
	_ok(get_tree().paused, "mundo 2D pausado durante a dimensão 3D")
	fase._onda_radial()
	fase._rajada_mirada()
	_ok(fase._tiros.size() >= 21, "ondas de projéteis 3D são criadas (%d)" % fase._tiros.size())
	_ok(fase._sprite_arma != null and fase._sprite_arma.texture != null, "arma equipada aparece na tela em primeira pessoa")
	# Mira no chefe para as balas atravessarem a arena.
	var alvo: Vector3 = fase._chefe.global_position
	var para_alvo: Vector3 = alvo - fase._camera.global_position
	fase._yaw = atan2(-para_alvo.x, -para_alvo.z)
	fase._pitch = atan2(para_alvo.y, Vector2(para_alvo.x, para_alvo.z).length())
	fase._atualizar_camera(0.0)
	_ok(fase._flash_vm != null, "viewmodel tem flash de cano")
	var dano_tungstenio: float = fase._dano_tiro
	var vel_tungstenio: float = fase._vel_bala
	var balas_antes: int = fase._balas.size()
	fase._atirar()
	_ok(fase._balas.size() > balas_antes, "tiro 3D cria balas visíveis que viajam")
	_ok(fase._rastros.size() >= 1, "tiro 3D cria rastro visível")
	_ok(fase._flash_tempo > 0.0 and fase._recuo > 0.0, "tiro 3D dispara flash e recuo do viewmodel")
	# Arma diferente muda o combate 3D (bala, dano, cadência e cor).
	var arma_mercurio: DadosArma = load("res://resources/armas/mercurio.tres") as DadosArma
	fase._arma = arma_mercurio
	fase._calcular_stats()
	_ok(not is_equal_approx(fase._dano_tiro, dano_tungstenio) and not is_equal_approx(fase._vel_bala, vel_tungstenio), "trocar de arma muda dano e velocidade das balas na 3D")
	_ok(fase._cor_arma.is_equal_approx(arma_mercurio.cor), "balas usam a cor da arma equipada")
	fase._arma = load("res://resources/armas/tungstenio.tres") as DadosArma
	fase._calcular_stats()
	fase._vida_chefe = 1.0
	fase._cooldown_tiro = 0.0
	fase._atirar()
	for _i: int in range(30):
		await get_tree().process_frame
		if not is_instance_valid(fase):
			break
		if fase._vida_chefe <= 0.0 or fase._terminando:
			break
	_ok(not is_instance_valid(fase) or fase._vida_chefe <= 0.0 or fase._terminando, "balas visíveis causam dano no chefe")
	if is_instance_valid(fase):
		fase._finalizar(true)
	await get_tree().process_frame
	_ok(not is_instance_valid(fase) or fase._terminando, "fase 3D encerra ao derrotar o chefe")
	_ok(not get_tree().paused, "pausa é liberada ao voltar ao 2D")
	print("=== RESULTADO 3D: %d falha(s) ===" % falhas)
	get_tree().quit(1 if falhas > 0 else 0)


func _ok(condicao: bool, texto: String) -> void:
	if condicao:
		print("[OK] ", texto)
	else:
		falhas += 1
		print("[FALHA] ", texto)
