extends Node
## AudioManager (Autoload)
## Áudio 100% procedural: sintetiza SFX e trilhas em AudioStreamWAV (sem assets),
## cria os buses "Música"/"SFX", faz pooling de vozes e crossfade de BGM.

const BUS_MUSICA: String = "Música"
const BUS_SFX: String = "SFX"
const TAXA: int = 22050
const VOZES_SFX: int = 16

var _sfx_cache: Dictionary = {}
var _bgm_cache: Dictionary = {}
var _vozes: Array[AudioStreamPlayer] = []
var _indice_voz: int = 0
var _musica_a: AudioStreamPlayer
var _musica_b: AudioStreamPlayer
var _musica_atual: String = ""
var _tween_musica: Tween
var _thread_chefe: Thread = null


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_criar_buses()
	for i: int in range(VOZES_SFX):
		var p: AudioStreamPlayer = AudioStreamPlayer.new()
		p.bus = BUS_SFX
		add_child(p)
		_vozes.append(p)
	_musica_a = AudioStreamPlayer.new()
	_musica_a.bus = BUS_MUSICA
	_musica_a.volume_db = -80.0
	add_child(_musica_a)
	_musica_b = AudioStreamPlayer.new()
	_musica_b.bus = BUS_MUSICA
	_musica_b.volume_db = -80.0
	add_child(_musica_b)
	_aplicar_volumes_salvos()
	get_tree().node_added.connect(_ao_adicionar_no)
	_preparar_tema_chefe()


func _exit_tree() -> void:
	if _thread_chefe != null and _thread_chefe.is_started():
		_thread_chefe.wait_to_finish()
		_thread_chefe = null


# ---------------------------------------------------------------- tema do chefe
func _preparar_tema_chefe() -> void:
	## O tema do chefe leva ~1,3 s para ser sintetizado: gerar em segundo plano
	## evita travar a partida quando o chefe aparece (a horda 10 demora bem mais).
	_thread_chefe = Thread.new()
	_thread_chefe.start(_gerar_tema_chefe)


func _gerar_tema_chefe() -> AudioStreamWAV:
	var stream: AudioStreamWAV = _musica_chefe()
	call_deferred("_guardar_tema_chefe", stream)
	return stream


func _guardar_tema_chefe(stream: AudioStreamWAV) -> void:
	if stream != null:
		_bgm_cache["chefe"] = stream


func _coletar_tema_chefe() -> void:
	if _thread_chefe == null or not _thread_chefe.is_started():
		return
	var gerado: Variant = _thread_chefe.wait_to_finish()
	_thread_chefe = null
	if gerado is AudioStreamWAV:
		_bgm_cache["chefe"] = gerado


func _stream_chefe() -> AudioStreamWAV:
	if _bgm_cache.has("chefe"):
		return _bgm_cache["chefe"] as AudioStreamWAV
	if _thread_chefe != null and _thread_chefe.is_started():
		var gerado: Variant = _thread_chefe.wait_to_finish()
		_thread_chefe = null
		if gerado is AudioStreamWAV:
			_bgm_cache["chefe"] = gerado
			return gerado as AudioStreamWAV
	var reserva: AudioStreamWAV = _musica_chefe()
	_bgm_cache["chefe"] = reserva
	return reserva


func _criar_buses() -> void:
	for nome: String in [BUS_MUSICA, BUS_SFX]:
		if AudioServer.get_bus_index(nome) == -1:
			var idx: int = AudioServer.bus_count
			AudioServer.add_bus(idx)
			AudioServer.set_bus_name(idx, nome)
			AudioServer.set_bus_send(idx, "Master")


func _aplicar_volumes_salvos() -> void:
	# GlobalManager é o primeiro autoload: já está disponível aqui.
	definir_volume(BUS_MUSICA, GlobalManager.volume_musica)
	definir_volume(BUS_SFX, GlobalManager.volume_sfx)


func definir_volume(bus: String, linear: float) -> void:
	var idx: int = AudioServer.get_bus_index(bus)
	if idx == -1:
		return
	var v: float = clampf(linear, 0.0, 1.0)
	AudioServer.set_bus_mute(idx, v <= 0.001)
	AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(v, 0.0001)))


# ---------------------------------------------------------------- SFX
func tocar_sfx(nome: String, volume_db: float = 0.0, variacao_pitch: float = 0.08) -> void:
	if not _sfx_cache.has(nome):
		_sfx_cache[nome] = _sintetizar_sfx(nome)
	var stream: AudioStreamWAV = _sfx_cache[nome] as AudioStreamWAV
	if stream == null:
		return
	if _vozes.is_empty():
		return
	var p: AudioStreamPlayer = _vozes[_indice_voz]
	_indice_voz = (_indice_voz + 1) % _vozes.size()
	p.stream = stream
	## Todos os efeitos ficam numa faixa curta de volume: quem controla o
	## volume é o slider de SFX, não sons individuais mais altos que os outros.
	p.volume_db = clampf(volume_db, -11.0, -3.0)
	p.pitch_scale = clampf(1.0 + randf_range(-variacao_pitch, variacao_pitch), 0.4, 2.5)
	p.play()


func _ao_adicionar_no(no: Node) -> void:
	if no is BaseButton:
		var b: BaseButton = no as BaseButton
		if not b.pressed.is_connected(_ao_clicar_botao):
			b.pressed.connect(_ao_clicar_botao)


func _ao_clicar_botao() -> void:
	tocar_sfx("clique", -6.0, 0.03)


# ---------------------------------------------------------------- BGM
func aquecer_temas(temas: Array) -> void:
	## Sintetiza as trilhas antes da ação começar: evita engasgo no meio da horda.
	_coletar_tema_chefe()
	for tema_v: Variant in temas:
		var tema: String = String(tema_v)
		if _bgm_cache.has(tema) or tema == "chefe":
			continue
		_bgm_cache[tema] = _sintetizar_musica(tema)


func tocar_bgm(tema: String) -> void:
	if _musica_atual == tema:
		return
	_musica_atual = tema
	if not _bgm_cache.has(tema):
		_bgm_cache[tema] = _sintetizar_musica(tema)
	var stream: AudioStreamWAV = _bgm_cache[tema] as AudioStreamWAV
	if stream == null:
		return
	var saindo: AudioStreamPlayer = _musica_a
	var entrando: AudioStreamPlayer = _musica_b
	if saindo.playing and entrando.playing:
		saindo.stop()
		var tmp: AudioStreamPlayer = saindo
		saindo = entrando
		entrando = tmp
	entrando.stream = stream
	entrando.volume_db = -60.0
	entrando.play()
	if _tween_musica != null and _tween_musica.is_valid():
		_tween_musica.kill()
	_tween_musica = create_tween().set_parallel(true)
	_tween_musica.tween_property(entrando, "volume_db", -4.0, 1.2)
	if saindo.playing:
		_tween_musica.tween_property(saindo, "volume_db", -60.0, 1.0)
		_tween_musica.chain().tween_callback(saindo.stop)


func parar_bgm() -> void:
	_musica_atual = ""
	for p: AudioStreamPlayer in [_musica_a, _musica_b]:
		p.stop()


# ---------------------------------------------------------------- síntese
func _wav(amostras: PackedFloat32Array, looping: bool = false) -> AudioStreamWAV:
	var bytes: PackedByteArray = PackedByteArray()
	bytes.resize(amostras.size() * 2)
	for i: int in range(amostras.size()):
		var s: float = clampf(amostras[i], -1.0, 1.0)
		var v: int = int(round(s * 32000.0))
		bytes.encode_s16(i * 2, v)
	var w: AudioStreamWAV = AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = TAXA
	w.stereo = false
	w.data = bytes
	if looping:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = amostras.size()
	return w


func _sintetizar_sfx(nome: String) -> AudioStreamWAV:
	var dur: float = 0.12
	var dados: PackedFloat32Array = PackedFloat32Array()
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = hash(nome)
	match nome:
		"clique":
			dur = 0.05
			dados = _tom(1040.0, 1500.0, dur, "quadrada", 0.35)
		"tiro":
			dur = 0.09
			dados = _misturar(_tom(420.0, 130.0, dur, "quadrada", 0.5), _ruido(dur, 0.35, 0.7, rng))
			dados = _decair(dados, 2.2)
		"tiro_helio":
			dur = 0.17
			dados = _misturar(_ruido(dur, 0.7, 0.35, rng), _tom(180.0, 70.0, dur, "serrilhada", 0.5))
			dados = _decair(dados, 1.4)
		"tiro_pesado":
			dur = 0.26
			dados = _misturar(_tom(120.0, 48.0, dur, "serrilhada", 0.7), _ruido(dur, 0.5, 0.4, rng))
			dados = _decair(dados, 1.5)
		"hit":
			dur = 0.06
			dados = _misturar(_tom(760.0, 520.0, dur, "quadrada", 0.28), _ruido(dur, 0.35, 0.2, rng))
		"morte_inimigo":
			dur = 0.2
			dados = _misturar(_ruido(dur, 0.5, 0.6, rng), _tom(380.0, 90.0, dur, "quadrada", 0.4))
			dados = _decair(dados, 1.8)
		"dano":
			dur = 0.28
			dados = _misturar(_tom(190.0, 62.0, dur, "serrilhada", 0.6), _ruido(dur, 0.4, 0.35, rng))
			dados = _decair(dados, 1.6)
		"dash":
			dur = 0.2
			dados = _misturar(_ruido(dur, 0.55, 0.15, rng), _tom(220.0, 660.0, dur, "quadrada", 0.22))
			dados = _decair(dados, 1.2)
		"parry":
			dur = 0.34
			var a: PackedFloat32Array = _tom(1480.0, 1480.0, dur, "quadrada", 0.28)
			var b: PackedFloat32Array = _tom(2260.0, 2170.0, dur, "quadrada", 0.16)
			dados = _decair(_misturar(a, b), 2.6)
		"ricochete":
			dur = 0.22
			dados = _decair(_misturar(_tom(2100.0, 2400.0, dur, "quadrada", 0.24), _tom(3200.0, 3000.0, dur * 0.6, "senoide", 0.12)), 2.4)
		"moeda":
			dur = 0.14
			var n1: PackedFloat32Array = _nota(1318.5, 0.07, "quadrada", 0.22)
			var n2: PackedFloat32Array = _nota(1975.5, 0.07, "quadrada", 0.18)
			dados = _concatenar([n1, n2])
		"explosao":
			dur = 0.6
			dados = _misturar(_ruido(dur, 0.9, 0.18, rng), _tom(80.0, 34.0, dur, "serrilhada", 0.55))
			dados = _decair(dados, 3.0)
		"cura":
			dur = 0.22
			dados = _decair(_tom(620.0, 1180.0, dur, "senoide", 0.3), 2.0)
		"levelup":
			dur = 0.5
			dados = _concatenar([
				_nota(523.25, 0.1, "quadrada", 0.26),
				_nota(659.25, 0.1, "quadrada", 0.26),
				_nota(783.99, 0.1, "quadrada", 0.26),
				_nota(1046.5, 0.2, "quadrada", 0.3),
			])
		"chefe":
			dur = 1.1
			dados = _misturar(_tom(70.0, 42.0, dur, "serrilhada", 0.55), _ruido(dur, 0.6, 0.12, rng))
			dados = _decair(dados, 1.2)
		"horda":
			dur = 0.4
			dados = _misturar(_tom(330.0, 440.0, dur, "quadrada", 0.3), _tom(165.0, 220.0, dur, "triangular", 0.2))
			dados = _decair(dados, 1.4)
		"perigo":
			dur = 0.18
			dados = _decair(_tom(880.0, 700.0, dur, "quadrada", 0.2), 2.0)
		"revive":
			dur = 0.6
			dados = _concatenar([
				_nota(392.0, 0.12, "senoide", 0.26),
				_nota(523.25, 0.12, "senoide", 0.26),
				_nota(783.99, 0.16, "senoide", 0.3),
				_nota(1046.5, 0.2, "senoide", 0.24),
			])
		"escudo":
			dur = 0.3
			dados = _decair(_misturar(_tom(300.0, 900.0, dur, "senoide", 0.3), _tom(600.0, 1800.0, dur, "triangular", 0.16)), 1.6)
		_:
			dur = 0.08
			dados = _tom(520.0, 380.0, dur, "quadrada", 0.25)
	# Normaliza o pico: nenhum SFX sai muito mais alto que os outros.
	return _wav(_normalizar(dados, 0.55))


func _normalizar(dados: PackedFloat32Array, alvo: float) -> PackedFloat32Array:
	var pico: float = 0.0
	for v: float in dados:
		pico = maxf(pico, absf(v))
	if pico <= 0.001:
		return dados
	var ganho: float = alvo / pico
	for i: int in range(dados.size()):
		dados[i] *= ganho
	return dados


func _tom(f0: float, f1: float, dur: float, tipo: String, vol: float) -> PackedFloat32Array:
	var n: int = int(dur * float(TAXA))
	var out: PackedFloat32Array = PackedFloat32Array()
	out.resize(n)
	var fase: float = 0.0
	for i: int in range(n):
		var t: float = float(i) / float(n)
		var f: float = lerpf(f0, f1, t)
		fase += f / float(TAXA)
		var s: float = _oscilador(tipo, fase)
		var env: float = minf(1.0, float(i) / 90.0) * (1.0 - t * 0.15)
		out[i] = s * vol * env
	return out


func _nota(freq: float, dur: float, tipo: String, vol: float) -> PackedFloat32Array:
	var n: int = int(dur * float(TAXA))
	var out: PackedFloat32Array = PackedFloat32Array()
	out.resize(n)
	var fase: float = 0.0
	for i: int in range(n):
		var t: float = float(i) / float(n)
		fase += freq / float(TAXA)
		var env: float = minf(1.0, float(i) / 120.0) * pow(1.0 - t, 0.6)
		out[i] = _oscilador(tipo, fase) * vol * env
	return out


func _oscilador(tipo: String, fase: float) -> float:
	var f: float = fposmod(fase, 1.0)
	match tipo:
		"quadrada":
			return 1.0 if f < 0.5 else -1.0
		"serrilhada":
			return f * 2.0 - 1.0
		"triangular":
			return 1.0 - 4.0 * absf(f - 0.5)
		"senoide":
			return sin(f * TAU)
		_:
			return 0.0


func _ruido(dur: float, vol: float, amortecimento: float, rng: RandomNumberGenerator) -> PackedFloat32Array:
	var n: int = int(dur * float(TAXA))
	var out: PackedFloat32Array = PackedFloat32Array()
	out.resize(n)
	var anterior: float = 0.0
	for i: int in range(n):
		var t: float = float(i) / float(n)
		var branco: float = rng.randf_range(-1.0, 1.0)
		anterior = lerpf(anterior, branco, clampf(1.0 - amortecimento, 0.05, 0.95))
		out[i] = anterior * vol * pow(1.0 - t, 1.2)
	return out


func _misturar(a: PackedFloat32Array, b: PackedFloat32Array) -> PackedFloat32Array:
	var n: int = maxi(a.size(), b.size())
	var out: PackedFloat32Array = PackedFloat32Array()
	out.resize(n)
	for i: int in range(n):
		var va: float = a[i] if i < a.size() else 0.0
		var vb: float = b[i] if i < b.size() else 0.0
		out[i] = (va + vb) * 0.72
	return out


func _concatenar(partes: Array[PackedFloat32Array]) -> PackedFloat32Array:
	var out: PackedFloat32Array = PackedFloat32Array()
	for p: PackedFloat32Array in partes:
		out.append_array(p)
	return out


func _decair(a: PackedFloat32Array, forca: float) -> PackedFloat32Array:
	var n: int = a.size()
	for i: int in range(n):
		var t: float = float(i) / float(maxi(1, n))
		a[i] = a[i] * pow(1.0 - t, forca)
	return a


# ---------------------------------------------------------------- tema do chefe
# Recriação do groove da faixa enviada (129 BPM, centro em F): chimbal em
# semicolcheias, bumbo sincopado, baixo octavado em colcheias e arpejo menor.
# Tudo sintetizado aqui, sem usar o MP3 em tempo de execução.
const BPM_CHEFE: float = 129.0
const COMPASSOS_CHEFE: int = 8
var _mix_buf: PackedFloat32Array = PackedFloat32Array()
var _tabelas: Dictionary = {}


func _musica_chefe() -> AudioStreamWAV:
	var passo16: float = 60.0 / BPM_CHEFE / 4.0
	var amostras_passo: float = passo16 * float(TAXA)
	var total: int = int(round(amostras_passo * 16.0 * float(COMPASSOS_CHEFE)))
	_mix_buf = PackedFloat32Array()
	_mix_buf.resize(total)
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = 1337
	# Fm | Fm | Db | Eb | Fm | Fm | Db | Cm
	var raizes: Array[int] = [41, 41, 37, 39, 41, 41, 37, 36]
	var acordes: Array = [
		[65, 68, 72], [65, 68, 72], [61, 65, 68], [63, 67, 70],
		[65, 68, 72], [65, 68, 72], [61, 65, 68], [60, 63, 67],
	]
	for comp: int in range(COMPASSOS_CHEFE):
		var base_comp: int = int(round(float(comp) * 16.0 * amostras_passo))
		var acorde: Array = acordes[comp]
		var raiz: int = raizes[comp]
		# tapete sustentado (dá peso de "boss" sem competir com o arpejo)
		_somar_nota(base_comp, raiz, passo16 * 16.0, "triangular", 0.05, 0.14)
		_somar_nota(base_comp, int(acorde[2]), passo16 * 16.0, "senoide", 0.03, 0.22)
		for passo: int in range(16):
			var i: int = base_comp + int(round(float(passo) * amostras_passo))
			# bumbo sincopado (1, e-do-3, 3, e-do-4, contratempo)
			if passo == 0 or passo == 3 or passo == 6 or passo == 8 or passo == 11 or passo == 14:
				_somar_bumbo(i, 0.46, 150.0, 42.0)
			# caixa no 2 e no 4
			if passo == 4 or passo == 12:
				_somar_caixa(i, 0.30, rng)
			# chimbal em semicolcheias
			if passo % 2 == 0:
				_somar_chimbal(i, 0.12 if passo % 4 == 0 else 0.075, rng, 0.05, false)
			elif comp % 2 == 1:
				_somar_chimbal(i, 0.045, rng, 0.03, false)
			if passo == 14 and comp % 2 == 1:
				_somar_chimbal(i, 0.08, rng, 0.42, true)
			# baixo em colcheias, com oitava e quinta
			if passo % 2 == 0:
				var oitava: int = 12 if passo == 2 or passo == 10 else 0
				var quinta: int = 7 if passo == 12 else 0
				_somar_nota(i, raiz + oitava + quinta, passo16 * 1.7, "triangular", 0.19, 0.004)
				_somar_nota(i, raiz + oitava + quinta + 12, passo16 * 1.1, "serrilhada", 0.035, 0.004)
			# arpejo menor em semicolcheias
			_somar_nota(i, int(acorde[passo % acorde.size()]) + 12, passo16 * 0.95, "quadrada", 0.05, 0.003)
			# stabs de lead na segunda metade
			if comp >= 4 and (passo == 0 or passo == 6 or passo == 10):
				_somar_nota(i, int(acorde[0]) + 12, passo16 * 3.0, "quadrada", 0.085, 0.006)
		# prato nas viradas de 4 compassos
		if comp == 0 or comp == 4:
			_somar_chimbal(base_comp, 0.13, rng, 0.8, true)
		# preenchimento de tambores no último compasso
		if comp == COMPASSOS_CHEFE - 1:
			var tons: Array[int] = [60, 56, 53, 48]
			for k: int in range(4):
				var it: int = base_comp + int(round(float(12 + k) * amostras_passo))
				_somar_bumbo(it, 0.3, 220.0 - float(k) * 26.0, 70.0 - float(k) * 9.0)
				_somar_nota(it, tons[k], passo16 * 1.3, "triangular", 0.11, 0.003)
	# normaliza para evitar clipping e deixa o loop no mesmo nível do resto
	var pico: float = 0.0
	for i: int in range(total):
		pico = maxf(pico, absf(_mix_buf[i]))
	if pico > 0.001:
		var ganho: float = 0.92 / pico
		for i: int in range(total):
			_mix_buf[i] *= ganho
	var fade: int = mini(total, int(0.006 * float(TAXA)))
	for i: int in range(fade):
		_mix_buf[i] *= float(i) / float(maxi(1, fade))
	return _wav(_mix_buf, true)


func _tabela(tipo: String) -> PackedFloat32Array:
	## Tabela de onda em cache: evita chamar o oscilador amostra por amostra.
	if _tabelas.has(tipo):
		return _tabelas[tipo] as PackedFloat32Array
	var n: int = 1024
	var t: PackedFloat32Array = PackedFloat32Array()
	t.resize(n)
	for i: int in range(n):
		t[i] = _oscilador(tipo, float(i) / float(n))
	_tabelas[tipo] = t
	return t


func _somar_bumbo(i: int, vol: float, f0: float, f1: float) -> void:
	var n: int = int(0.2 * float(TAXA))
	var fase: float = 0.0
	var tabela: PackedFloat32Array = _tabela("senoide")
	for s: int in range(n):
		var j: int = i + s
		if j < 0 or j >= _mix_buf.size():
			break
		var t: float = float(s) / float(n)
		fase = fposmod(fase + lerpf(f0, f1, t) / float(TAXA), 1.0)
		var env: float = 1.0 - t
		env *= env * env
		_mix_buf[j] += tabela[int(fase * 1024.0) & 1023] * vol * env


func _somar_caixa(i: int, vol: float, rng: RandomNumberGenerator) -> void:
	var n: int = int(0.17 * float(TAXA))
	var fase: float = 0.0
	var tabela: PackedFloat32Array = _tabela("senoide")
	for s: int in range(n):
		var j: int = i + s
		if j < 0 or j >= _mix_buf.size():
			break
		var t: float = float(s) / float(n)
		fase = fposmod(fase + (210.0 - 90.0 * t) / float(TAXA), 1.0)
		var corpo: float = tabela[int(fase * 1024.0) & 1023] * 0.5
		var ruido: float = rng.randf_range(-1.0, 1.0)
		var env: float = 1.0 - t
		_mix_buf[j] += (ruido * 0.6 + corpo) * vol * env * env


func _somar_chimbal(i: int, vol: float, rng: RandomNumberGenerator, duracao: float, aberto: bool) -> void:
	var n: int = maxi(8, int(duracao * float(TAXA)))
	var anterior: float = 0.0
	for s: int in range(n):
		var j: int = i + s
		if j < 0 or j >= _mix_buf.size():
			break
		var branco: float = rng.randf_range(-1.0, 1.0)
		var agudo: float = branco - anterior
		anterior = branco
		var t: float = float(s) / float(n)
		var env: float = 1.0 - t
		env *= env * env
		if not aberto:
			env *= env
		_mix_buf[j] += agudo * vol * env


func _somar_nota(i: int, midi: int, dur: float, tipo: String, vol: float, ataque: float) -> void:
	var freq: float = 440.0 * pow(2.0, (float(midi) - 69.0) / 12.0)
	var n: int = maxi(4, int(dur * float(TAXA)))
	var tabela: PackedFloat32Array = _tabela(tipo)
	var inc: float = freq / float(TAXA)
	var inc2: float = inc * 1.004
	var fase: float = 0.0
	var fase2: float = 0.0
	var n_ataque: int = maxi(1, int(ataque * float(TAXA)))
	for s: int in range(n):
		var j: int = i + s
		if j < 0 or j >= _mix_buf.size():
			break
		fase = fposmod(fase + inc, 1.0)
		fase2 = fposmod(fase2 + inc2, 1.0)
		var t: float = float(s) / float(n)
		var env: float = 1.0 - t
		env = minf(1.0, float(s) / float(n_ataque)) * env * (1.0 - t * 0.5)
		var v: float = tabela[int(fase * 1024.0) & 1023] * 0.72 + tabela[int(fase2 * 1024.0) & 1023] * 0.28
		_mix_buf[j] += v * vol * env


# ---------------------------------------------------------------- música
func _sintetizar_musica(tema: String) -> AudioStreamWAV:
	if tema == "chefe":
		return _stream_chefe()
	# A síntese usa um buffer compartilhado: espera o tema do chefe (thread)
	# terminar antes de gerar outro tema para não corromper as amostras.
	_coletar_tema_chefe()
	if tema == "calmo":
		return _musica_calma()
	# Chiptune sequenciado: lead quadrado, baixo triangular e hats de ruído.
	var bpm: float = 176.0
	var escalas: Dictionary = {
		"menu": {"lead": [0, 3, 7, 10, 12, 10, 7, 3], "raiz": 220.0, "passo": 0.25, "bpm": 120.0},
		"jogo": {"lead": [0, 7, 3, 10, 0, 7, 12, 7], "raiz": 196.0, "passo": 0.0625, "bpm": 176.0},
		"chefe": {"lead": [0, 1, 5, 6, 12, 6, 5, 1], "raiz": 146.8, "passo": 0.0625, "bpm": 129.0},
	}
	var cfg: Dictionary = escalas.get(tema, escalas["jogo"]) as Dictionary
	bpm = float(cfg.get("bpm", bpm))
	var lead: Array = cfg["lead"] as Array
	var raiz: float = float(cfg["raiz"])
	var passo: float = float(cfg["passo"])
	var passo_dur: float = 60.0 / bpm * passo * 4.0
	var repeticoes: int = 8 if tema != "chefe" else 12
	var total_n: int = int(passo_dur * float(lead.size() * repeticoes) * float(TAXA))
	var out: PackedFloat32Array = PackedFloat32Array()
	out.resize(total_n)
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = 4242
	var fase_lead: float = 0.0
	var fase_bass: float = 0.0
	var pos: int = 0
	var idx_global: int = 0
	while pos < total_n:
		var nota_semi: int = int(lead[idx_global % lead.size()])
		var freq_lead: float = raiz * pow(2.0, float(nota_semi) / 12.0) * 2.0
		var freq_bass: float = raiz * 0.5 * pow(2.0, float(int(lead[(idx_global / 2) % lead.size()]) % 12) / 12.0)
		var bloco: int = int(passo_dur * float(TAXA))
		for i: int in range(bloco):
			if pos + i >= total_n:
				break
			fase_lead += freq_lead / float(TAXA)
			fase_bass += freq_bass / float(TAXA)
			var env: float = 1.0
			var t_bloco: float = float(i) / float(maxi(1, bloco))
			env = pow(1.0 - t_bloco, 0.7)
			var lead_s: float = _oscilador("quadrada", fase_lead) * 0.16 * env
			var bass_s: float = _oscilador("triangular", fase_bass) * 0.20
			var hat: float = rng.randf_range(-1.0, 1.0) * 0.05 if i < int(0.03 * float(TAXA)) else 0.0
			var bumbo: float = 0.0
			if i < int(0.07 * float(TAXA)):
				var tb: float = float(i) / (0.07 * float(TAXA))
				bumbo = sin(TAU * lerpf(120.0, 46.0, tb) * float(i) / float(TAXA)) * 0.24 * pow(1.0 - tb, 2.0)
			out[pos + i] = (lead_s + bass_s + hat + bumbo)
		pos += maxi(1, bloco)
		idx_global += 1
	var fade: int = int(0.02 * float(TAXA))
	for i: int in range(mini(fade, total_n)):
		out[i] *= float(i) / float(maxi(1, fade))
	return _wav(out, true)


func _musica_calma() -> AudioStreamWAV:
	## Ambiente de laboratório vazio: pad lento e sinos suaves, sem percussão.
	var bpm: float = 66.0
	var compassos: int = 4
	var duracao_compasso: float = 60.0 / bpm * 4.0
	var total_n: int = int(duracao_compasso * float(compassos) * float(TAXA))
	var out: PackedFloat32Array = PackedFloat32Array()
	out.resize(total_n)
	_mix_buf = out
	# Fm | Db | Ab | Eb — acorde sustentado e arpejo espaçado.
	var acordes: Array = [[53, 56, 60, 65], [49, 53, 56, 61], [44, 48, 51, 56], [51, 55, 58, 63]]
	for comp: int in range(compassos):
		var inicio: int = int(round(float(comp) * duracao_compasso * float(TAXA)))
		var acorde: Array = acordes[comp]
		for nota_i: int in range(acorde.size()):
			_somar_nota(inicio, int(acorde[nota_i]), duracao_compasso * 0.95, "senoide", 0.035, 1.4)
		for passo: int in range(4):
			var idx: int = inicio + int(round(duracao_compasso * 0.25 * float(passo) * float(TAXA)))
			_somar_nota(idx, int(acorde[passo % acorde.size()]) + 12, duracao_compasso * 0.18, "triangular", 0.05, 0.05)
	out = _mix_buf
	var fade_n: int = int(0.03 * float(TAXA))
	for i: int in range(mini(fade_n, total_n)):
		out[i] *= float(i) / float(maxi(1, fade_n))
	return _wav(out, true)
