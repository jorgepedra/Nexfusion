shader_type canvas_item;
render_mode unshaded;

// Protected base: pulsing cyan energy rim that turns red as integrity drops.

uniform vec4 core_color : source_color = vec4(0.35, 0.9, 1.0, 1.0);
uniform float danger : hint_range(0.0, 1.0) = 0.0;
uniform float glow : hint_range(0.0, 2.0) = 0.9;

void fragment() {
	vec4 tex = texture(TEXTURE, UV);
	vec2 px = TEXTURE_PIXEL_SIZE;
	float n = texture(TEXTURE, UV + vec2(px.x, 0.0)).a
		+ texture(TEXTURE, UV - vec2(px.x, 0.0)).a
		+ texture(TEXTURE, UV + vec2(0.0, px.y)).a
		+ texture(TEXTURE, UV - vec2(0.0, px.y)).a;
	float rim = clamp((n * 0.25 - tex.a) * 3.0, 0.0, 1.0);
	float pulse = 0.62 + 0.38 * sin(TIME * 2.1);
	vec3 col = tex.rgb + core_color.rgb * rim * glow * pulse;
	col = mix(col, vec3(1.0, 0.28, 0.22), danger * rim * (0.55 + 0.45 * sin(TIME * 7.0)));
	float a = max(tex.a, rim * 0.85);
	COLOR = vec4(col, a);
}
