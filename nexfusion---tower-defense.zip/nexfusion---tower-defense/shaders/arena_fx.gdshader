shader_type canvas_item;
render_mode blend_mix, unshaded;

// Full-arena overlay: cyan haze, CRT scanlines, film grain and a red pulse
// driven by danger (base integrity / leaks). Drawn as a translucent ColorRect.

uniform float danger : hint_range(0.0, 1.0) = 0.0;
uniform float vignette : hint_range(0.0, 1.2) = 0.6;
uniform float scanline : hint_range(0.0, 0.12) = 0.03;
uniform vec4 haze : source_color = vec4(0.16, 0.44, 0.66, 1.0);

void fragment() {
	vec2 uv = SCREEN_UV;
	vec2 c = uv - vec2(0.5);
	float d = length(c * vec2(1.0, 1.06)) * 1.5;
	float vig = smoothstep(0.30, 1.15, d) * vignette;
	float scan = (sin(uv.y * 900.0) * 0.5 + 0.5) * scanline;
	float grain = fract(sin(dot(uv * vec2(931.0, 733.0) + vec2(TIME * 11.0, TIME * 6.0), vec2(12.9898, 78.233))) * 43758.5453) - 0.5;
	float pulse = danger * (0.55 + 0.45 * sin(TIME * 5.0));
	float edge = smoothstep(0.35, 1.0, length(c) * 1.6);
	vec3 col = mix(haze.rgb, vec3(0.95, 0.18, 0.12), pulse);
	float alpha = vig + scan + pulse * 0.3 * edge + abs(grain) * 0.035;
	alpha *= 1.0 - smoothstep(0.0, 0.3, d) * 0.35;
	COLOR = vec4(col, clamp(alpha, 0.0, 0.82));
}
