shader_type canvas_item;
render_mode unshaded;

// Rim glow for hazards: samples the baked sprite alpha to draw a pulsing halo
// in the hazard colour, plus white damage flash, cold slow tint and boss danger.

uniform vec4 glow_color : source_color = vec4(0.55, 0.95, 0.45, 1.0);
uniform float glow : hint_range(0.0, 3.0) = 0.85;
uniform float pulse : hint_range(0.0, 1.0) = 0.5;
uniform float flash : hint_range(0.0, 1.0) = 0.0;
uniform float freeze : hint_range(0.0, 1.0) = 0.0;
uniform float danger : hint_range(0.0, 1.0) = 0.0;

void fragment() {
	vec4 tex = texture(TEXTURE, UV);
	vec2 px = TEXTURE_PIXEL_SIZE;
	float n = texture(TEXTURE, UV + vec2(px.x, 0.0)).a
		+ texture(TEXTURE, UV - vec2(px.x, 0.0)).a
		+ texture(TEXTURE, UV + vec2(0.0, px.y)).a
		+ texture(TEXTURE, UV - vec2(0.0, px.y)).a;
	float rim = clamp((n * 0.25 - tex.a) * 3.0, 0.0, 1.0);
	vec3 col = tex.rgb + glow_color.rgb * rim * glow * (1.0 + pulse * 0.85);
	float a = max(tex.a, rim * 0.85);
	col = mix(col, vec3(1.0, 0.97, 0.88), flash * 0.9);
	a = max(a, tex.a * flash);
	col = mix(col, col * vec3(0.55, 0.85, 1.35) + vec3(0.0, 0.06, 0.16), freeze);
	col = mix(col, vec3(1.0, 0.32, 0.26), danger * rim * (0.55 + 0.45 * pulse));
	COLOR = vec4(col, a);
}
