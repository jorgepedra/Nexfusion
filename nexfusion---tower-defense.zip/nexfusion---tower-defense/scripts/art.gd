class_name Art
extends Object
## Procedural pixel-art drawing helpers shared by every screen.
## Every sprite, icon and effect in the game is drawn here (no external assets).

const OUTLINE := Color("#1b2333")
const INK := Color("#101826")


static func hex(h: String) -> Color:
	return Color(h)


static func _ellipse(ci: CanvasItem, center: Vector2, radii: Vector2, col: Color) -> void:
	ci.draw_set_transform(center, 0.0, radii)
	ci.draw_circle(Vector2.ZERO, 1.0, col)
	ci.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


static func _polyline_closed(ci: CanvasItem, pts: PackedVector2Array, col: Color, w: float) -> void:
	var arr := PackedVector2Array(pts)
	arr.append(pts[0])
	ci.draw_polyline(arr, col, w)


static func _shadow(ci: CanvasItem, c: Vector2, s: float) -> void:
	_ellipse(ci, c + Vector2(0, s * 0.78), Vector2(s * 0.82, s * 0.3), Color(0.04, 0.07, 0.12, 0.35))


static func _eyes(ci: CanvasItem, c: Vector2, s: float, look: Vector2, closed: bool, blink: bool) -> void:
	var eye_r := s * 0.16
	var off := s * 0.22
	for side in [-1.0, 1.0]:
		var e := c + Vector2(off * side, -s * 0.05)
		if closed or blink:
			ci.draw_line(e - Vector2(eye_r, 0), e + Vector2(eye_r, 0), INK, max(1.5, s * 0.05))
		else:
			_ellipse(ci, e, Vector2(eye_r, eye_r * 1.12), Color("#fdfdf5"))
			ci.draw_circle(e + look * eye_r * 0.45, eye_r * 0.52, INK)
			ci.draw_circle(e + look * eye_r * 0.45 + Vector2(-eye_r * 0.16, -eye_r * 0.18), eye_r * 0.18, Color("#ffffff"))


static func _trefoil(ci: CanvasItem, c: Vector2, r: float, col: Color) -> void:
	for i in 3:
		var a := -PI / 2.0 + i * TAU / 3.0
		ci.draw_circle(c + Vector2(cos(a), sin(a)) * r * 0.62, r * 0.26, col)
	ci.draw_circle(c, r * 0.2, col)


static func draw_check(ci: CanvasItem, c: Vector2, s: float, col: Color) -> void:
	ci.draw_line(c + Vector2(-s * 0.32, 0) + Vector2(0, s * 0.02), c + Vector2(-s * 0.06, s * 0.28), col, s * 0.14)
	ci.draw_line(c + Vector2(-s * 0.06, s * 0.28), c + Vector2(s * 0.36, -s * 0.3), col, s * 0.14)


static func draw_enemy(ci: CanvasItem, def: Dictionary, layer: Dictionary, c: Vector2, s: float, t: float, state: String, face_left: bool) -> void:
	var col: Color = hex(layer.get("color", def.get("color", "#ffffff")))
	var shape: String = layer.get("shape", def.get("shape", "cloud"))
	var alpha := 1.0
	if state == "dying":
		alpha = clampf(1.0 - (t - floor(t)), 0.0, 1.0)
	var bob := sin(t * 5.0) * s * 0.05
	var cc := c + Vector2(0, bob)
	var closed := state == "dying"
	var blink := state != "dying" and fmod(t + s, 4.2) < 0.12
	var look := Vector2(-1 if face_left else 1, 0.15)
	var puls := 1.0 + sin(t * 4.0) * 0.04
	var glow := Color(col.r, col.g, col.b, 0.22 * alpha)

	match shape:
		"canister":
			ci.draw_circle(cc, s * 0.95 * puls, glow)
			ci.draw_rect(Rect2(cc - Vector2(s * 0.42, s * 0.62), Vector2(s * 0.84, s * 1.16)), col)
			ci.draw_rect(Rect2(cc - Vector2(s * 0.42, s * 0.62), Vector2(s * 0.84, s * 1.16)), OUTLINE, false, s * 0.06)
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.2, -s * 0.78), Vector2(s * 0.4, s * 0.2)), Color("#9aa7bb"))
			ci.draw_line(cc + Vector2(-s * 0.28, s * 0.2), cc + Vector2(s * 0.28, s * 0.2), Color(1, 1, 1, 0.45), s * 0.07)
			_trefoil(ci, cc + Vector2(s * 0.32 if face_left else -s * 0.32, s * 0.24), s * 0.19, Color("#fff08a"))
		"cloud":
			ci.draw_circle(cc, s * 0.95 * puls, glow)
			for off in [Vector2(-0.42, 0.12), Vector2(0.0, -0.22), Vector2(0.44, 0.1), Vector2(0.1, 0.24)]:
				ci.draw_circle(cc + off * s, s * 0.46, Color(col.r, col.g, col.b, 0.88 * alpha))
			for off in [Vector2(-0.42, 0.12), Vector2(0.0, -0.22), Vector2(0.44, 0.1), Vector2(0.1, 0.24)]:
				ci.draw_arc(cc + off * s, s * 0.46, 0, TAU, 18, Color(OUTLINE.r, OUTLINE.g, OUTLINE.b, 0.55 * alpha), s * 0.045)
			ci.draw_circle(cc + Vector2(0, -s * 0.05), s * 0.34, Color(col.r, col.g, col.b, 0.95 * alpha))
			_eyes(ci, cc + Vector2(0, -s * 0.06), s, look, closed, blink)
		"bottle":
			var pts := PackedVector2Array([
				cc + Vector2(-s * 0.32, -s * 0.5), cc + Vector2(s * 0.32, -s * 0.5),
				cc + Vector2(s * 0.34, s * 0.12), cc + Vector2(s * 0.24, s * 0.6),
				cc + Vector2(-s * 0.24, s * 0.6), cc + Vector2(-s * 0.34, s * 0.12)])
			ci.draw_colored_polygon(pts, col)
			_polyline_closed(ci, pts, OUTLINE, s * 0.06)
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.11, -s * 0.66), Vector2(s * 0.22, s * 0.18)), Color("#cfd8e6"))
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.22, s * 0.18), Vector2(s * 0.44, s * 0.22)), Color(1, 1, 1, 0.35))
			_eyes(ci, cc + Vector2(0, -s * 0.02), s * 0.9, look, closed, blink)
		"chunk":
			ci.draw_circle(cc, s * 1.0 * puls, glow)
			var poly := PackedVector2Array([
				cc + Vector2(-s * 0.55, -s * 0.18), cc + Vector2(-s * 0.18, -s * 0.55),
				cc + Vector2(s * 0.42, -s * 0.42), cc + Vector2(s * 0.56, s * 0.12),
				cc + Vector2(s * 0.2, s * 0.52), cc + Vector2(-s * 0.42, s * 0.38)])
			ci.draw_colored_polygon(poly, col)
			_polyline_closed(ci, poly, OUTLINE, s * 0.07)
			ci.draw_line(cc + Vector2(-s * 0.2, -s * 0.4), cc + Vector2(-s * 0.05, s * 0.4), Color(1, 1, 1, 0.3), s * 0.07)
			_eyes(ci, cc + Vector2(0, 0), s, look, closed, blink)
		"droplet":
			ci.draw_circle(cc, s * 0.95 * puls, glow)
			ci.draw_circle(cc + Vector2(0, s * 0.08), s * 0.5, col)
			var tip := PackedVector2Array([cc + Vector2(-s * 0.4, s * 0.0), cc + Vector2(0, -s * 0.82), cc + Vector2(s * 0.4, s * 0.0)])
			ci.draw_colored_polygon(tip, col)
			ci.draw_arc(cc + Vector2(0, s * 0.08), s * 0.5, 0, PI, 16, OUTLINE, s * 0.055)
			ci.draw_circle(cc + Vector2(-s * 0.16, s * 0.16), s * 0.12, Color(1, 1, 1, 0.5))
			_eyes(ci, cc + Vector2(0, s * 0.06), s * 0.9, look, closed, blink)
		"vial":
			ci.draw_circle(cc, s * 0.9 * puls, glow)
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.22, -s * 0.62), Vector2(s * 0.44, s * 1.2)), col)
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.22, -s * 0.62), Vector2(s * 0.44, s * 1.2)), OUTLINE, false, s * 0.06)
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.17, -s * 0.2), Vector2(s * 0.34, s * 0.42)), Color(1, 1, 1, 0.35))
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.13, -s * 0.8), Vector2(s * 0.26, s * 0.18)), Color("#d8c59b"))
			_eyes(ci, cc + Vector2(0, -s * 0.05), s * 0.85, look, closed, blink)
		"boss_reactor":
			ci.draw_circle(cc, s * 1.25 * puls, glow)
			ci.draw_rect(Rect2(cc - Vector2(s * 0.7, s * 0.62), Vector2(s * 1.4, s * 1.24)), col)
			ci.draw_rect(Rect2(cc - Vector2(s * 0.7, s * 0.62), Vector2(s * 1.4, s * 1.24)), OUTLINE, false, s * 0.07)
			for i in 3:
				ci.draw_rect(Rect2(cc + Vector2(-s * 0.54, -s * 0.36 + i * s * 0.4), Vector2(s * 1.08, s * 0.1)), Color(0.05, 0.08, 0.1, 0.55))
			ci.draw_circle(cc + Vector2(0, -s * 0.12), s * 0.3, Color("#f6ff8a"))
			ci.draw_circle(cc + Vector2(0, -s * 0.12), s * 0.18, Color("#ffffff"))
			_eyes(ci, cc + Vector2(0, s * 0.26), s * 1.15, look, closed, blink)
		"boss_cloud":
			ci.draw_circle(cc, s * 1.35 * puls, glow)
			for off in [Vector2(-0.55, 0.1), Vector2(-0.2, -0.32), Vector2(0.3, -0.25), Vector2(0.62, 0.12), Vector2(0.1, 0.3)]:
				ci.draw_circle(cc + off * s, s * 0.55, Color(col.r, col.g, col.b, 0.85 * alpha))
			ci.draw_circle(cc, s * 0.55, Color(col.r * 1.15, col.g * 1.1, col.b * 1.1, alpha))
			_eyes(ci, cc, s * 1.4, look, closed, blink)
		_:
			ci.draw_circle(cc, s * 0.6, col)
			_eyes(ci, cc, s, look, closed, blink)

	if state == "dying":
		draw_check(ci, cc + Vector2(0, -s * 1.12), s * 0.7, Color("#7dfa9a"))
	elif state == "hurt":
		ci.draw_circle(cc, s * 0.9, Color(1, 1, 1, 0.22))


static func draw_tower(ci: CanvasItem, id: String, c: Vector2, s: float, t: float, kick: float, disabled: bool) -> void:
	var def: Dictionary = DB.TOWERS[id]
	var col := hex(def.color)
	var dark := col.darkened(0.35)
	var bob := sin(t * 2.0 + c.x * 0.01) * s * 0.02
	var cc := c + Vector2(0, bob - kick * s * 0.18)
	_shadow(ci, c, s)
	# lab pad
	_ellipse(ci, c + Vector2(0, s * 0.5), Vector2(s * 0.82, s * 0.3), Color("#2c3a55"))
	_ellipse(ci, c + Vector2(0, s * 0.47), Vector2(s * 0.78, s * 0.26), Color("#44597c"))
	match def.shape:
		"lead":
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.44, -s * 0.4), Vector2(s * 0.88, s * 0.95)), dark)
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.38, -s * 0.5), Vector2(s * 0.76, s * 0.34)), col)
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.38, -s * 0.5), Vector2(s * 0.76, s * 0.34)), OUTLINE, false, s * 0.05)
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.3, s * 0.02), Vector2(s * 0.6, s * 0.22)), Color("#9aa7bb"))
			_ellipse(ci, cc + Vector2(0, -s * 0.56), Vector2(s * 0.3, s * 0.16), Color("#cfd8e6"))
		"bicarb":
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.3, -s * 0.34), Vector2(s * 0.6, s * 0.82)), Color("#eef4ff"))
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.3, -s * 0.34), Vector2(s * 0.6, s * 0.82)), OUTLINE, false, s * 0.05)
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.34, s * 0.26), Vector2(s * 0.68, s * 0.2)), col)
			ci.draw_circle(cc + Vector2(-s * 0.08, -s * 0.48), s * 0.12, Color("#ffffff"))
			ci.draw_circle(cc + Vector2(s * 0.12, -s * 0.6), s * 0.08, Color("#ffffff"))
		"charcoal":
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.38, -s * 0.36), Vector2(s * 0.76, s * 0.86)), Color("#2b2b33"))
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.38, -s * 0.36), Vector2(s * 0.76, s * 0.86)), OUTLINE, false, s * 0.05)
			for i in 5:
				ci.draw_circle(cc + Vector2(-s * 0.24 + (i % 3) * s * 0.24, -s * 0.16 + int(i / 3) * s * 0.26), s * 0.05, Color("#5a5f73"))
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.3, -s * 0.46), Vector2(s * 0.6, s * 0.12)), col)
		"vinegar":
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.3, -s * 0.28), Vector2(s * 0.6, s * 0.76)), col)
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.3, -s * 0.28), Vector2(s * 0.6, s * 0.76)), OUTLINE, false, s * 0.05)
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.12, -s * 0.58), Vector2(s * 0.24, s * 0.3)), Color("#e6d6b8"))
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.24, s * 0.02), Vector2(s * 0.48, s * 0.28)), Color(1, 1, 1, 0.32))
		"water":
			ci.draw_circle(cc, s * 0.42, Color("#63c8ff"))
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.4, -s * 0.1), Vector2(s * 0.8, s * 0.56)), Color("#2f7fb5"))
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.4, -s * 0.1), Vector2(s * 0.8, s * 0.56)), OUTLINE, false, s * 0.05)
			ci.draw_line(cc + Vector2(-s * 0.3, s * 0.1), cc + Vector2(s * 0.3, s * 0.1), Color(1, 1, 1, 0.4), s * 0.06)
		"co2":
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.26, -s * 0.34), Vector2(s * 0.52, s * 0.9)), Color("#d9453f"))
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.26, -s * 0.34), Vector2(s * 0.52, s * 0.9)), OUTLINE, false, s * 0.05)
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.2, -s * 0.1), Vector2(s * 0.4, s * 0.3)), Color("#f4f4f4"))
			ci.draw_line(cc + Vector2(-s * 0.12, s * 0.62), cc + Vector2(s * 0.05, s * 0.86), Color("#333"), s * 0.07)
		"sand":
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.42, -s * 0.05), Vector2(s * 0.84, s * 0.6)), col)
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.42, -s * 0.05), Vector2(s * 0.84, s * 0.6)), OUTLINE, false, s * 0.05)
			ci.draw_line(cc + Vector2(-s * 0.4, -s * 0.05), cc + Vector2(s * 0.4, -s * 0.05), Color("#b98a4a"), s * 0.08)
			ci.draw_circle(cc + Vector2(-s * 0.2, -s * 0.2), s * 0.08, Color("#e8c48e"))
			ci.draw_circle(cc + Vector2(s * 0.18, -s * 0.14), s * 0.06, Color("#e8c48e"))
		"edta":
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.12, -s * 0.2), Vector2(s * 0.24, s * 0.6)), dark)
			ci.draw_arc(cc + Vector2(-s * 0.28, -s * 0.36), s * 0.28, 0.2, 5.6, 18, col, s * 0.13)
			ci.draw_arc(cc + Vector2(s * 0.28, -s * 0.36), s * 0.28, -2.5, 2.9, 18, col, s * 0.13)
			ci.draw_circle(cc + Vector2(0, -s * 0.44), s * 0.13, Color("#f0e6ff"))
		"thio":
			for i in 3:
				var off := Vector2(-s * 0.3 + i * s * 0.3, 0.1 * s * (i % 2))
				ci.draw_colored_polygon(PackedVector2Array([cc + off + Vector2(0, -s * 0.55), cc + off + Vector2(s * 0.2, s * 0.2), cc + off + Vector2(-s * 0.2, s * 0.2)]), col.lightened(0.15))
				_polyline_closed(ci, PackedVector2Array([cc + off + Vector2(0, -s * 0.55), cc + off + Vector2(s * 0.2, s * 0.2), cc + off + Vector2(-s * 0.2, s * 0.2)]), OUTLINE, s * 0.04)
		"oil":
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.36, -s * 0.3), Vector2(s * 0.72, s * 0.8)), col)
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.36, -s * 0.3), Vector2(s * 0.72, s * 0.8)), OUTLINE, false, s * 0.05)
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.36, -s * 0.08), Vector2(s * 0.72, s * 0.14)), Color("#3b2b14"))
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.2, s * 0.3), Vector2(s * 0.4, s * 0.14)), Color("#ffe6a0"))
		"dryice":
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.44, -s * 0.34), Vector2(s * 0.88, s * 0.78)), Color("#c9f2ff"))
			ci.draw_rect(Rect2(cc + Vector2(-s * 0.44, -s * 0.34), Vector2(s * 0.88, s * 0.78)), OUTLINE, false, s * 0.05)
			ci.draw_line(cc + Vector2(-s * 0.44, s * 0.02), cc + Vector2(s * 0.44, s * 0.02), Color(1, 1, 1, 0.6), s * 0.05)
			for i in 3:
				ci.draw_circle(cc + Vector2(-s * 0.3 + i * s * 0.28, -s * 0.52 - sin(t * 1.6 + i) * s * 0.08), s * 0.1, Color(0.85, 0.97, 1, 0.5))
	# face on the tower body
	var face_y := cc + Vector2(0, s * 0.06)
	if disabled:
		ci.draw_line(face_y + Vector2(-s * 0.24, -s * 0.08), face_y + Vector2(-s * 0.05, s * 0.1), Color("#ff6b6b"), s * 0.05)
		ci.draw_line(face_y + Vector2(-s * 0.05, -s * 0.08), face_y + Vector2(-s * 0.24, s * 0.1), Color("#ff6b6b"), s * 0.05)
		ci.draw_line(face_y + Vector2(s * 0.05, s * 0.0), face_y + Vector2(s * 0.24, s * 0.0), Color("#ff6b6b"), s * 0.05)
	else:
		_eyes(ci, face_y, s * 0.8, Vector2(0, 0.1), false, fmod(t + c.y * 0.02, 5.0) < 0.1)


static func draw_projectile(ci: CanvasItem, kind: String, c: Vector2, angle: float, col: Color, t: float) -> void:
	match kind:
		"capsule":
			ci.draw_set_transform(c, angle, Vector2.ONE)
			ci.draw_rect(Rect2(Vector2(-7, -4), Vector2(14, 8)), Color("#cfd8e6"))
			ci.draw_rect(Rect2(Vector2(-7, -4), Vector2(14, 8)), OUTLINE, false, 1.5)
			ci.draw_circle(Vector2(7, 0), 4, col)
			ci.draw_set_transform(Vector2.ZERO, 0, Vector2.ONE)
		"foam":
			for i in 3:
				ci.draw_circle(c + Vector2(sin(t * 12 + i * 2.1) * 3, cos(t * 9 + i) * 3), 4.2 - i * 0.6, Color(0.95, 1, 1, 0.9))
		"cloud":
			ci.draw_circle(c, 8, Color(col.r, col.g, col.b, 0.6))
			ci.draw_circle(c + Vector2(-5, 2), 4, Color(0.2, 0.2, 0.25, 0.8))
		"drop":
			ci.draw_circle(c, 5.5, Color(col.r, col.g, col.b, 0.9))
			ci.draw_circle(c + Vector2(-1.5, -1.5), 1.8, Color(1, 1, 1, 0.7))
		"spray":
			for i in 4:
				var a := angle + (i - 1.5) * 0.18
				ci.draw_line(c, c + Vector2(cos(a), sin(a)) * (4 + i * 2), Color(col.r, col.g, col.b, 0.85), 2)
		"snow":
			ci.draw_set_transform(c, t * 3.0, Vector2.ONE)
			for i in 3:
				var a := i * PI / 3.0
				ci.draw_line(Vector2(-cos(a), -sin(a)) * 6, Vector2(cos(a), sin(a)) * 6, Color("#d8f8ff"), 2)
			ci.draw_set_transform(Vector2.ZERO, 0, Vector2.ONE)
		_:
			ci.draw_circle(c, 5, col)


static func draw_icon(ci: CanvasItem, kind: String, c: Vector2, s: float, col: Color) -> void:
	match kind:
		"play":
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-s * 0.32, -s * 0.44), c + Vector2(s * 0.46, 0), c + Vector2(-s * 0.32, s * 0.44)]), col)
		"fast":
			for i in 2:
				var o := Vector2(-s * 0.38 + i * s * 0.42, 0)
				ci.draw_colored_polygon(PackedVector2Array([c + o + Vector2(-s * 0.18, -s * 0.4), c + o + Vector2(s * 0.28, 0), c + o + Vector2(-s * 0.18, s * 0.4)]), col)
		"pause":
			ci.draw_rect(Rect2(c + Vector2(-s * 0.3, -s * 0.4), Vector2(s * 0.2, s * 0.8)), col)
			ci.draw_rect(Rect2(c + Vector2(s * 0.1, -s * 0.4), Vector2(s * 0.2, s * 0.8)), col)
		"gear":
			ci.draw_circle(c, s * 0.38, col)
			for i in 8:
				var a := i * TAU / 8.0
				ci.draw_rect(Rect2(c + Vector2(cos(a), sin(a)) * s * 0.42 - Vector2(s * 0.09, s * 0.09), Vector2(s * 0.18, s * 0.18)), col)
			ci.draw_circle(c, s * 0.15, OUTLINE)
		"flask":
			var pts := PackedVector2Array([
				c + Vector2(-s * 0.16, -s * 0.46), c + Vector2(s * 0.16, -s * 0.46),
				c + Vector2(s * 0.16, -s * 0.12), c + Vector2(s * 0.4, s * 0.34),
				c + Vector2(s * 0.3, s * 0.46), c + Vector2(-s * 0.3, s * 0.46),
				c + Vector2(-s * 0.4, s * 0.34), c + Vector2(-s * 0.16, -s * 0.12)])
			_polyline_closed(ci, pts, col, max(2.0, s * 0.07))
			ci.draw_circle(c + Vector2(0, s * 0.24), s * 0.13, Color(col.r, col.g, col.b, 0.8))
			ci.draw_circle(c + Vector2(s * 0.12, s * 0.06), s * 0.05, Color(col.r, col.g, col.b, 0.7))
		"book":
			ci.draw_rect(Rect2(c + Vector2(-s * 0.42, -s * 0.34), Vector2(s * 0.84, s * 0.68)), col)
			ci.draw_rect(Rect2(c + Vector2(-s * 0.42, -s * 0.34), Vector2(s * 0.84, s * 0.68)), OUTLINE, false, max(1.5, s * 0.05))
			ci.draw_rect(Rect2(c + Vector2(-s * 0.34, -s * 0.24), Vector2(s * 0.29, s * 0.48)), Color("#f6f2e4"))
			ci.draw_rect(Rect2(c + Vector2(s * 0.05, -s * 0.24), Vector2(s * 0.29, s * 0.48)), Color("#f6f2e4"))
			ci.draw_line(c + Vector2(0, -s * 0.28), c + Vector2(0, s * 0.28), OUTLINE, max(1.5, s * 0.05))
		"back":
			ci.draw_polyline(PackedVector2Array([c + Vector2(s * 0.2, -s * 0.38), c + Vector2(-s * 0.24, 0), c + Vector2(s * 0.2, s * 0.38)]), col, max(2.0, s * 0.09))
		"close":
			ci.draw_line(c + Vector2(-s * 0.3, -s * 0.3), c + Vector2(s * 0.3, s * 0.3), col, max(2.0, s * 0.09))
			ci.draw_line(c + Vector2(s * 0.3, -s * 0.3), c + Vector2(-s * 0.3, s * 0.3), col, max(2.0, s * 0.09))
		"heart":
			ci.draw_circle(c + Vector2(-s * 0.2, -s * 0.12), s * 0.26, col)
			ci.draw_circle(c + Vector2(s * 0.2, -s * 0.12), s * 0.26, col)
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-s * 0.44, -s * 0.02), c + Vector2(s * 0.44, -s * 0.02), c + Vector2(0, s * 0.44)]), col)
		"coin":
			ci.draw_circle(c, s * 0.42, col)
			ci.draw_circle(c, s * 0.3, Color(0, 0, 0, 0.12))
			for i in 3:
				var a := -PI / 2 + i * TAU / 3.0
				ci.draw_circle(c + Vector2(cos(a), sin(a)) * s * 0.14, s * 0.055, col.darkened(0.35))
		"star":
			var pts := PackedVector2Array()
			for i in 10:
				var r := s * (0.46 if i % 2 == 0 else 0.2)
				var a := -PI / 2 + i * PI / 5.0
				pts.append(c + Vector2(cos(a), sin(a)) * r)
			ci.draw_colored_polygon(pts, col)
		"lock":
			ci.draw_rect(Rect2(c + Vector2(-s * 0.3, -s * 0.02), Vector2(s * 0.6, s * 0.44)), col)
			ci.draw_arc(c + Vector2(0, -s * 0.04), s * 0.22, PI, TAU, 12, col, max(2.0, s * 0.08))
		"check":
			draw_check(ci, c, s, col)
		"auto":
			ci.draw_arc(c, s * 0.3, 0.6, 5.6, 16, col, max(1.6, s * 0.08))
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(s * 0.26, -s * 0.34), c + Vector2(s * 0.42, -s * 0.1), c + Vector2(s * 0.1, -s * 0.06)]), col)
		"radiation":
			_trefoil(ci, c, s * 0.82, col)
		"acid":
			ci.draw_circle(c + Vector2(0, s * 0.1), s * 0.34, col)
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-s * 0.26, s * 0.02), c + Vector2(0, -s * 0.46), c + Vector2(s * 0.26, s * 0.02)]), col)
			ci.draw_circle(c + Vector2(-s * 0.1, s * 0.16), s * 0.07, Color(1, 1, 1, 0.5))
		"gas":
			for off in [Vector2(-0.22, 0.06), Vector2(0.02, -0.16), Vector2(0.24, 0.06), Vector2(0.02, 0.22)]:
				ci.draw_circle(c + off * s, s * 0.24, Color(col.r, col.g, col.b, 0.85))
		"flame":
			ci.draw_colored_polygon(PackedVector2Array([
				c + Vector2(0, -s * 0.46), c + Vector2(s * 0.3, s * 0.02), c + Vector2(s * 0.16, s * 0.36),
				c + Vector2(-s * 0.16, s * 0.36), c + Vector2(-s * 0.3, s * 0.02)]), col)
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(0, -s * 0.12), c + Vector2(s * 0.12, s * 0.14), c + Vector2(-s * 0.12, s * 0.14)]), Color("#ffe08a"))
		"boom":
			var pts := PackedVector2Array()
			for i in 12:
				var r := s * (0.46 if i % 2 == 0 else 0.24)
				var a := i * TAU / 12.0
				pts.append(c + Vector2(cos(a), sin(a)) * r)
			ci.draw_colored_polygon(pts, col)
		"metal":
			ci.draw_rect(Rect2(c + Vector2(-s * 0.28, -s * 0.36), Vector2(s * 0.56, s * 0.72)), col)
			ci.draw_circle(c + Vector2(0, -s * 0.36), s * 0.2, col.lightened(0.2))
			ci.draw_rect(Rect2(c + Vector2(-s * 0.12, s * 0.0), Vector2(s * 0.24, s * 0.16)), Color(1, 1, 1, 0.35))
		"oxid":
			ci.draw_arc(c, s * 0.34, 0, TAU, 24, col, max(2.0, s * 0.1))
			ci.draw_circle(c + Vector2(s * 0.3, -s * 0.25), s * 0.1, col)
			ci.draw_circle(c + Vector2(-s * 0.32, s * 0.2), s * 0.08, col)
		"snow":
			for i in 3:
				var a := i * PI / 3.0
				ci.draw_line(c + Vector2(cos(a), sin(a)) * s * 0.42, c - Vector2(cos(a), sin(a)) * s * 0.42, col, max(1.6, s * 0.08))
		"base":
			ci.draw_rect(Rect2(c + Vector2(-s * 0.38, -s * 0.14), Vector2(s * 0.76, s * 0.52)), col)
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-s * 0.46, -s * 0.14), c + Vector2(0, -s * 0.48), c + Vector2(s * 0.46, -s * 0.14)]), col.lightened(0.15))
			ci.draw_rect(Rect2(c + Vector2(-s * 0.1, s * 0.16), Vector2(s * 0.2, s * 0.22)), OUTLINE)
		"water":
			ci.draw_circle(c + Vector2(0, s * 0.08), s * 0.3, col)
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-s * 0.24, s * 0.02), c + Vector2(0, -s * 0.42), c + Vector2(s * 0.24, s * 0.02)]), col)
		"target":
			ci.draw_arc(c, s * 0.4, 0, TAU, 24, col, max(2.0, s * 0.08))
			ci.draw_arc(c, s * 0.2, 0, TAU, 20, col, max(2.0, s * 0.08))
			ci.draw_circle(c, s * 0.07, col)
		"question":
			ci.draw_arc(c + Vector2(0, -s * 0.12), s * 0.22, PI, TAU + 0.6, 20, col, max(2.5, s * 0.1))
			ci.draw_line(c + Vector2(s * 0.12, s * 0.06), c + Vector2(0, s * 0.2), col, max(2.5, s * 0.1))
			ci.draw_circle(c + Vector2(0, s * 0.38), s * 0.07, col)
		"sell":
			ci.draw_rect(Rect2(c + Vector2(-s * 0.4, -s * 0.08), Vector2(s * 0.8, s * 0.4)), Color("#b33a3a"))
			ci.draw_line(c + Vector2(-s * 0.08, -s * 0.02), c + Vector2(-s * 0.08, s * 0.26), Color.WHITE, max(2.0, s * 0.08))
			ci.draw_line(c + Vector2(s * 0.08, -s * 0.02), c + Vector2(s * 0.08, s * 0.26), Color.WHITE, max(2.0, s * 0.08))
			ci.draw_line(c + Vector2(-s * 0.08, s * 0.26), c + Vector2(s * 0.08, s * 0.26), Color.WHITE, max(2.0, s * 0.06))
		"heat":
			ci.draw_line(c + Vector2(0, s * 0.3), c + Vector2(0, -s * 0.1), Color("#a7b0c2"), max(2.0, s * 0.08))
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-s * 0.2, -s * 0.1), c + Vector2(0, -s * 0.46), c + Vector2(s * 0.2, -s * 0.1)]), Color("#63c8ff"))
		"search":
			ci.draw_arc(c + Vector2(-s * 0.08, -s * 0.08), s * 0.26, 0, TAU, 20, col, max(2.0, s * 0.08))
			ci.draw_line(c + Vector2(s * 0.12, s * 0.12), c + Vector2(s * 0.4, s * 0.4), col, max(2.5, s * 0.1))
		"plus":
			ci.draw_line(c + Vector2(-s * 0.32, 0), c + Vector2(s * 0.32, 0), col, max(2.5, s * 0.12))
			ci.draw_line(c + Vector2(0, -s * 0.32), c + Vector2(0, s * 0.32), col, max(2.5, s * 0.12))
		_:
			ci.draw_circle(c, s * 0.3, col)


static func draw_hazard_icon(ci: CanvasItem, hazard: String, c: Vector2, s: float) -> void:
	var hz: Dictionary = DB.HAZARDS.get(hazard, {"color": "#ffffff", "icon": "gas"})
	draw_icon(ci, hz.get("icon", "gas"), c, s, hex(hz.color))


static func draw_flask(ci: CanvasItem, c: Vector2, s: float, fill: Color, t: float, bubbles: bool) -> void:
	# glass beaker body
	var pts := PackedVector2Array([
		c + Vector2(-s * 0.33, -s * 0.55), c + Vector2(s * 0.33, -s * 0.55),
		c + Vector2(s * 0.33, s * 0.15), c + Vector2(s * 0.42, s * 0.52),
		c + Vector2(-s * 0.42, s * 0.52), c + Vector2(-s * 0.33, s * 0.15)])
	ci.draw_colored_polygon(pts, Color(0.75, 0.88, 1.0, 0.08))
	_polyline_closed(ci, pts, Color(0.78, 0.9, 1.0, 0.75), max(1.5, s * 0.035))
	ci.draw_line(c + Vector2(-s * 0.24, -s * 0.34), c + Vector2(-s * 0.27, s * 0.12), Color(1, 1, 1, 0.22), max(1.0, s * 0.03))
	_ellipse(ci, c + Vector2(0, s * 0.47), Vector2(s * 0.36, s * 0.08), Color(0.75, 0.88, 1.0, 0.14))
	if fill.a > 0.02:
		var liq := PackedVector2Array([
			c + Vector2(-s * 0.35, s * 0.12), c + Vector2(s * 0.35, s * 0.12),
			c + Vector2(s * 0.41, s * 0.49), c + Vector2(-s * 0.41, s * 0.49)])
		ci.draw_colored_polygon(liq, fill)
		ci.draw_line(c + Vector2(-s * 0.34, s * 0.12), c + Vector2(s * 0.34, s * 0.12), fill.lightened(0.3), max(2.0, s * 0.05))
		if bubbles:
			for i in 4:
				var by := s * 0.44 - fmod(t * s * 0.18 + i * s * 0.11, s * 0.3)
				ci.draw_circle(c + Vector2(-s * 0.2 + i * s * 0.14, by), s * 0.035 + i * s * 0.008, Color(1, 1, 1, 0.55))
	ci.draw_rect(Rect2(c + Vector2(-s * 0.36, -s * 0.6), Vector2(s * 0.72, s * 0.08)), Color("#cfdae8"))


static func draw_base(ci: CanvasItem, c: Vector2, s: float, t: float, integrity: float) -> void:
	_shadow(ci, c, s)
	ci.draw_rect(Rect2(c + Vector2(-s * 0.62, -s * 0.35), Vector2(s * 1.24, s * 0.9)), Color("#2f4468"))
	ci.draw_rect(Rect2(c + Vector2(-s * 0.62, -s * 0.35), Vector2(s * 1.24, s * 0.9)), OUTLINE, false, s * 0.05)
	ci.draw_colored_polygon(PackedVector2Array([
		c + Vector2(-s * 0.72, -s * 0.35), c + Vector2(0, -s * 0.8), c + Vector2(s * 0.72, -s * 0.35)]), Color("#4d6b96"))
	ci.draw_circle(c + Vector2(0, s * 0.05), s * 0.3, Color("#8fe6ff"))
	ci.draw_circle(c + Vector2(0, s * 0.05), s * 0.18, Color("#e9fbff"))
	var shield_col := Color("#7dfa9a") if integrity > 35.0 else Color("#ff9a6a")
	var pulse := 1.0 + sin(t * 3.0) * 0.08
	ci.draw_arc(c + Vector2(0, s * 0.05), s * 0.52 * pulse, 0, TAU, 28, Color(shield_col.r, shield_col.g, shield_col.b, 0.55), max(2.0, s * 0.05))
	for i in 4:
		var a := t * 0.5 + i * TAU / 4.0
		ci.draw_circle(c + Vector2(cos(a), sin(a)) * s * 0.72, s * 0.04, Color(0.7, 0.95, 1, 0.6))


static func draw_lab_background(ci: CanvasItem, size: Vector2, t: float, dim: bool) -> void:
	# tiled wall
	var tile := 48.0
	var cols := int(size.x / tile) + 1
	var rows := int(size.y / tile) + 1
	ci.draw_rect(Rect2(Vector2.ZERO, size), Color("#dfeaf2"))
	for y in rows:
		for x in cols:
			var col := Color("#e8f1f8") if (x + y) % 2 == 0 else Color("#dce9f2")
			ci.draw_rect(Rect2(Vector2(x * tile, y * tile), Vector2(tile - 2, tile - 2)), col)
	ci.draw_rect(Rect2(0, size.y * 0.66, size.x, size.y * 0.34), Color("#c6d5e0"))
	ci.draw_line(Vector2(0, size.y * 0.66), Vector2(size.x, size.y * 0.66), Color("#a7bccc"), 4)
	# windows with blinking sky light
	for i in 3:
		var r := Rect2(size.x * 0.62 + i * 120, 46 + (i % 2) * 8, 96, 120)
		ci.draw_rect(r, Color("#9fd3ea"))
		ci.draw_rect(r, Color("#7fbcd8"), false, 4)
		ci.draw_line(r.position + Vector2(r.size.x / 2, 0), r.position + Vector2(r.size.x / 2, r.size.y), Color("#7fbcd8"), 3)
		ci.draw_circle(r.position + Vector2(28, 30), 14, Color(1, 1, 1, 0.25 + 0.1 * sin(t + i)))
	# emergency shower
	var sx := size.x * 0.08
	ci.draw_line(Vector2(sx, 70), Vector2(sx, 240), Color("#8fa3b5"), 6)
	ci.draw_line(Vector2(sx, 70), Vector2(sx + 54, 70), Color("#8fa3b5"), 6)
	ci.draw_circle(Vector2(sx + 54, 78), 12, Color("#b9c9d6"))
	# shelves with flasks
	for i in 4:
		var fc := Vector2(size.x * 0.2 + i * 84, size.y * 0.2 + sin(t * 1.2 + i) * 4)
		ci.draw_rect(Rect2(fc + Vector2(-26, 26), Vector2(52, 8)), Color("#9fb3c4"))
		draw_flask(ci, fc, 44, [Color("#8fe6a8"), Color("#ffd36e"), Color("#ff9d6e"), Color("#9fd0ff")][i], t + i, true)
	# floating sparkles
	for i in 10:
		var p := Vector2(fmod(i * 173.0 + t * 18.0, size.x), fmod(i * 91.0 + sin(t + i) * 30.0, size.y * 0.6))
		ci.draw_circle(p, 1.6 + (i % 3), Color(1, 1, 1, 0.45))
	if dim:
		ci.draw_rect(Rect2(Vector2.ZERO, size), Color(0.03, 0.06, 0.12, 0.5))


static func draw_waving_tower(ci: CanvasItem, id: String, c: Vector2, s: float, t: float, phase: float) -> void:
	draw_tower(ci, id, c, s, t + phase, 0.0, false)
	# waving arm
	var a := sin(t * 2.4 + phase) * 0.5
	var hand := c + Vector2(s * 0.75, -s * 0.35 + sin(a) * s * 0.3)
	ci.draw_line(c + Vector2(s * 0.45, -s * 0.05), hand, Color("#e8c39a"), max(3.0, s * 0.1))
	ci.draw_circle(hand, s * 0.11, Color("#f2d3ae"))
