class_name MapBase
extends Node2D
## One scenario: baked background, native Path2D tracks, base and entity containers.

const BASE_SHADER := preload("res://shaders/base_core.gdshader")

var map_id := 0
var map: Dictionary = {}
var path_nodes: Array = []
var base_mat: ShaderMaterial
var dust: CPUParticles2D

@onready var background: TextureRect = $Background
@onready var obstacles: Node2D = $Obstacles
@onready var paths_root: Node2D = $Paths
@onready var path_a: Path2D = $Paths/PathA
@onready var path_b: Path2D = $Paths/PathB
@onready var line_a_border: Line2D = $Paths/PathA/LineBorder
@onready var line_a: Line2D = $Paths/PathA/Line
@onready var line_b_border: Line2D = $Paths/PathB/LineBorder
@onready var line_b: Line2D = $Paths/PathB/Line
@onready var base_point: Marker2D = $BasePoint
@onready var base_sprite: Sprite2D = $BasePoint/BaseSprite
@onready var base_glow: CPUParticles2D = $BasePoint/BaseGlow
@onready var towers_container: Node2D = $TowersContainer
@onready var projectiles_container: Node2D = $ProjectilesContainer


func setup(id: int) -> void:
	map_id = id
	map = DB.MAPS[id]
	background.texture = Sprites.get_map(id)
	base_sprite.texture = Sprites.get_effect("base")
	base_point.position = map.base
	_style_paths()
	_build_tracks()
	_base_decoration()
	_base_fx()
	_shade_base()
	_ambient_dust()


func _style_paths() -> void:
	var border := Color("#6d7d8b")
	var inner := Color("#a9b7c3")
	match String(map.theme):
		"nuclear":
			border = Color("#1c2822")
			inner = Color("#3d4a44")
		"industrial":
			border = Color("#3a2c22")
			inner = Color("#6d5847")
	for line in [line_a_border, line_b_border]:
		line.default_color = border
		line.width = 66.0
	for line in [line_a, line_b]:
		line.default_color = inner
		line.width = 54.0


func _build_tracks() -> void:
	var paths: Array = map.paths
	path_a.curve = _curve_for(paths[0])
	_set_line_points(line_a_border, paths[0])
	_set_line_points(line_a, paths[0])
	path_nodes = [path_a]
	_place_entrance(path_a, paths[0])
	if paths.size() > 1:
		path_b.visible = true
		path_b.curve = _curve_for(paths[1])
		_set_line_points(line_b_border, paths[1])
		_set_line_points(line_b, paths[1])
		path_nodes.append(path_b)
		_place_entrance(path_b, paths[1])
	else:
		path_b.visible = false
		path_b.curve = null


func _set_line_points(line: Line2D, points: Array) -> void:
	var packed := PackedVector2Array()
	for p in points:
		packed.append(p)
	line.points = packed


func _curve_for(points: Array) -> Curve2D:
	var curve := Curve2D.new()
	for p in points:
		curve.add_point(p)
	return curve


func _place_entrance(path: Path2D, points: Array) -> void:
	var marker := Sprite2D.new()
	marker.texture = Sprites.get_effect("entrance")
	marker.position = Vector2(points[0]) + Vector2(34, -30)
	marker.z_index = 2
	path.add_child(marker)


func _base_decoration() -> void:
	var label := Label.new()
	label.text = "BASE"
	label.position = Vector2(-44, 50)
	label.size = Vector2(88, 18)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", 12)
	label.add_theme_color_override("font_color", Color(0.85, 1.0, 0.9, 0.85))
	label.add_theme_color_override("font_outline_color", Color(0.03, 0.07, 0.1, 0.9))
	label.add_theme_constant_override("outline_size", 5)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	base_point.add_child(label)


func _base_fx() -> void:
	base_glow.texture = Sprites.get_effect("dot")
	base_glow.amount = 16
	base_glow.lifetime = 1.8
	base_glow.preprocess = 1.0
	base_glow.emission_shape = CPUParticles2D.EMISSION_SHAPE_SPHERE
	base_glow.emission_sphere_radius = 34.0
	base_glow.direction = Vector2(0, -1)
	base_glow.spread = 20.0
	base_glow.gravity = Vector2(0, -18)
	base_glow.initial_velocity_min = 5.0
	base_glow.initial_velocity_max = 16.0
	base_glow.scale_amount_min = 0.15
	base_glow.scale_amount_max = 0.4
	base_glow.color = Color(0.6, 1.0, 0.85, 0.45)
	base_glow.emitting = true


func _shade_base() -> void:
	base_mat = ShaderMaterial.new()
	base_mat.shader = BASE_SHADER
	base_sprite.material = base_mat
	set_danger(0.0)


func set_danger(v: float) -> void:
	if base_mat == null:
		return
	base_mat.set_shader_parameter("danger", clampf(v, 0.0, 1.0))


func _ambient_dust() -> void:
	dust = CPUParticles2D.new()
	dust.name = "Dust"
	dust.texture = Sprites.get_effect("dot")
	dust.amount = 26
	dust.lifetime = 6.0
	dust.preprocess = 3.0
	dust.position = Vector2(480, 360)
	dust.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	dust.emission_rect_extents = Vector2(470, 345)
	dust.direction = Vector2(0, -1)
	dust.spread = 45.0
	dust.gravity = Vector2(0, -4)
	dust.initial_velocity_min = 2.0
	dust.initial_velocity_max = 9.0
	dust.scale_amount_min = 0.08
	dust.scale_amount_max = 0.26
	dust.color = Color(0.72, 0.9, 1.0, 0.22)
	dust.emitting = true
	add_child(dust)
	move_child(dust, 1)


func path_at(index: int) -> Path2D:
	if path_nodes.is_empty():
		return null
	return path_nodes[clampi(index, 0, path_nodes.size() - 1)]
