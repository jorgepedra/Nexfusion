class_name EnemyUnit
extends PathFollow2D
## A walking hazard. Its position along the track is computed by the C++ engine.

var battle = null
var id := ""
var layer_index := 0
var hp := 1.0
var max_hp := 1.0
var speed := 40.0
var hp_mult := 1.0
var speed_mult := 1.0
var reward := 5
var leak := 1
var hazard := "gas"
var props: Array = []
var weak: Array = []
var display_name := ""
var layer_count := 1
var slow_factor := 1.0
var slow_time := 0.0
var stun_time := 0.0
var is_dying := false
var alive := true
var die_t := 0.0
var hurt_t := 0.0
var heal_flash := 0.0
var effect_t := 0.0
var face_left := false
var _last_x := 0.0
var glow_mat: ShaderMaterial

var pos: Vector2:
	get:
		return global_position

var dist: float:
	get:
		return progress

@onready var sprite: Sprite2D = $Sprite
@onready var hp_bar: ProgressBar = $HpBar
@onready var hazard_icon: Sprite2D = $HazardIcon
@onready var particles: CPUParticles2D = $Particles
@onready var hitbox: Area2D = $Hitbox
@onready var hit_shape: CollisionShape2D = $Hitbox/CollisionShape2D


func _ready() -> void:
	glow_mat = ShaderMaterial.new()
	glow_mat.shader = preload("res://shaders/hazard_glow.gdshader")
	sprite.material = glow_mat
	_setup_bar()
	particles.emitting = false


func _setup_bar() -> void:
	hp_bar.max_value = 100.0
	hp_bar.value = 100.0
	hp_bar.show_percentage = false
	hp_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.05, 0.08, 0.12, 0.85)
	bg.corner_radius_top_left = 3
	bg.corner_radius_top_right = 3
	bg.corner_radius_bottom_left = 3
	bg.corner_radius_bottom_right = 3
	hp_bar.add_theme_stylebox_override("background", bg)
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color("#7dfa9a")
	fill.corner_radius_top_left = 3
	fill.corner_radius_top_right = 3
	fill.corner_radius_bottom_left = 3
	fill.corner_radius_bottom_right = 3
	hp_bar.add_theme_stylebox_override("fill", fill)


func setup(enemy_id: String, hp_multiplier: float, speed_multiplier: float) -> void:
	id = enemy_id
	progress = 0.0
	layer_index = 0
	hp_mult = hp_multiplier
	speed_mult = speed_multiplier
	_last_x = global_position.x
	_apply_layer()


func _apply_layer() -> void:
	var def: Dictionary = DB.ENEMIES[id]
	var layer: Dictionary = DB.enemy_layer(id, layer_index)
	display_name = str(layer.get("name", def.name))
	layer_count = (def.layers as Array).size()
	hazard = str(layer.get("hazard", def.hazard))
	props = def.props
	weak = layer.get("weak", def.weak)
	max_hp = float(layer.hp) * hp_mult
	hp = max_hp
	speed = float(layer.speed) * speed_mult
	reward = int(layer.get("reward", 5))
	leak = int(layer.get("leak", 1))
	if sprite != null:
		sprite.texture = Sprites.get_enemy(id, layer_index)
	if hazard_icon != null:
		hazard_icon.texture = Sprites.get_hazard(hazard)
		hazard_icon.visible = hazard != ""
	var boss := is_boss()
	if hp_bar != null:
		hp_bar.visible = layer_count > 1 or boss or hp < max_hp
		hp_bar.offset_left = -60.0 if boss else -24.0
		hp_bar.offset_top = -86.0 if boss else -40.0
		hp_bar.offset_right = 60.0 if boss else 24.0
		hp_bar.offset_bottom = -78.0 if boss else -34.0
	if hit_shape != null:
		var shape := hit_shape.shape as CircleShape2D
		if shape != null:
			shape.radius = 34.0 if boss else 18.0 * float(def.scale)
	if particles != null:
		_setup_particles(Color(DB.HAZARDS.get(hazard, {"color": "#ffffff"}).color))
	_update_bar()
	_sync_glow()


func _sync_glow() -> void:
	if glow_mat == null:
		return
	var hz: Dictionary = DB.HAZARDS.get(hazard, {"color": "#ffffff"})
	glow_mat.set_shader_parameter("glow_color", Color(hz.color))
	glow_mat.set_shader_parameter("pulse", 0.5 + 0.5 * sin(float(Time.get_ticks_msec()) * 0.005 + float(get_instance_id() % 64)))
	glow_mat.set_shader_parameter("flash", clampf(hurt_t / 0.14, 0.0, 1.0))
	glow_mat.set_shader_parameter("freeze", 1.0 if slow_time > 0.0 else 0.0)
	glow_mat.set_shader_parameter("danger", 1.0 if is_boss() else 0.0)


func _setup_particles(col: Color) -> void:
	particles.emitting = not is_dying
	particles.amount = 12 if is_boss() else 7
	particles.lifetime = 1.1
	particles.texture = Sprites.get_effect("dot")
	particles.color = Color(col.r, col.g, col.b, 0.5)
	particles.emission_shape = CPUParticles2D.EMISSION_SHAPE_SPHERE
	particles.emission_sphere_radius = 14.0 if not is_boss() else 26.0
	particles.direction = Vector2(0, -1)
	particles.spread = 30.0
	particles.gravity = Vector2(0, -12)
	particles.initial_velocity_min = 6.0
	particles.initial_velocity_max = 18.0
	particles.scale_amount_min = 0.15
	particles.scale_amount_max = 0.45


func is_boss() -> bool:
	return "boss" in props


func advance(dt: float) -> String:
	hurt_t = maxf(0.0, hurt_t - dt)
	heal_flash = maxf(0.0, heal_flash - dt)
	_sync_glow()
	if is_dying:
		die_t += dt
		if die_t > 0.7:
			alive = false
		return ""
	if slow_time > 0.0:
		slow_time -= dt
		if slow_time <= 0.0:
			slow_factor = 1.0
	if stun_time > 0.0:
		stun_time -= dt
		return ""
	var f := slow_factor if slow_time > 0.0 else 1.0
	progress += speed * f * dt
	var gx := global_position.x
	if absf(gx - _last_x) > 0.01:
		face_left = gx < _last_x
		_last_x = gx
		if sprite != null:
			sprite.flip_h = face_left
	if hp_bar != null and hp_bar.visible:
		hp_bar.value = hp_fraction() * 100.0
	if progress_ratio >= 0.999:
		return "leak"
	return ""


func hit(amount: float) -> bool:
	hp -= amount
	hurt_t = 0.14
	_update_bar()
	if hp <= 0.0:
		hp = 0.0
		return true
	return false


func transition_layer() -> bool:
	var def: Dictionary = DB.ENEMIES[id]
	if layer_index + 1 < (def.layers as Array).size():
		layer_index += 1
		_apply_layer()
		return true
	return false


func _update_bar() -> void:
	if hp_bar == null:
		return
	hp_bar.value = hp_fraction() * 100.0
	hp_bar.visible = layer_count > 1 or is_boss() or hp < max_hp


func apply_slow(factor: float, time: float) -> void:
	if factor < slow_factor or slow_time <= 0.0:
		slow_factor = factor
	slow_time = maxf(slow_time, time)


func hp_fraction() -> float:
	return clampf(hp / maxf(1.0, max_hp), 0.0, 1.0)


func burst_death() -> void:
	if particles != null:
		particles.one_shot = true
		particles.explosiveness = 1.0
		particles.amount = 22 if is_boss() else 14
		particles.lifetime = 0.8
		particles.restart()
	if sprite != null:
		var tw := create_tween()
		tw.set_parallel(true)
		tw.tween_property(sprite, "modulate:a", 0.0, 0.5)
		tw.tween_property(sprite, "scale", Vector2(0.7, 0.7), 0.5)
	if hp_bar != null:
		hp_bar.visible = false
