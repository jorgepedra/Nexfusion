extends Node2D
## Draws the translucent firing range of a tower only while it is selected or a ghost.

var tower: TowerUnit


func _ready() -> void:
	tower = get_parent() as TowerUnit


func _process(_delta: float) -> void:
	if tower == null:
		return
	if tower.is_selected or tower.is_ghost:
		queue_redraw()


func _draw() -> void:
	if tower == null:
		return
	if not (tower.is_selected or tower.is_ghost):
		return
	var r: float = maxf(24.0, tower.display_range)
	var col := Color(0.55, 0.9, 1.0, 0.75)
	if tower.is_ghost:
		col = Color(0.35, 0.45, 0.55, 0.7) if tower.ghost_invalid else Color(0.45, 1.0, 0.55, 0.85)
	draw_circle(Vector2.ZERO, r, Color(col.r, col.g, col.b, 0.08))
	draw_arc(Vector2.ZERO, r, 0, TAU, 56, Color(col.r, col.g, col.b, 0.62), 2.0)
	if tower.is_ghost:
		draw_circle(Vector2.ZERO, 30, Color(col.r, col.g, col.b, 0.12))
		if tower.ghost_invalid:
			draw_line(Vector2(-13, -13), Vector2(13, 13), Color(1, 0.3, 0.3, 0.95), 3.0)
			draw_line(Vector2(13, -13), Vector2(-13, 13), Color(1, 0.3, 0.3, 0.95), 3.0)
	else:
		draw_arc(Vector2.ZERO, 31.0, 0, TAU, 32, Color(0.6, 0.95, 1.0, 0.8), 2.0)
		if "shield_aura" in tower.stats.flags:
			draw_arc(Vector2.ZERO, 112.0, 0, TAU, 50, Color(1.0, 0.9, 0.4, 0.45), 2.0)
