class_name ProjectileUnit
extends Area2D
## Homing shot. Moves natively through the scene tree; the battle ticks it so
## game speed and pause apply.

var battle = null
var target: EnemyUnit = null
var tower = null
var tower_id := ""
var speed := 720.0
var kind := "drop"
var color := Color.WHITE
var damage := 1.0
var splash := 0.0
var stun := 0.0
var slow_factor := 1.0
var slow_time := 0.0
var kickback := 0.0
var pierce := 0
var pierced: Array = []
var life := 2.2
var trail: CPUParticles2D

@onready var sprite: Sprite2D = $Sprite
@onready var notifier: VisibleOnScreenNotifier2D = $ScreenNotifier


func _ready() -> void:
	notifier.screen_exited.connect(queue_free)
	trail = CPUParticles2D.new()
	trail.name = "Trail"
	trail.texture = Sprites.get_effect("dot")
	trail.amount = 10
	trail.lifetime = 0.26
	trail.local_coords = false
	trail.emission_shape = CPUParticles2D.EMISSION_SHAPE_SPHERE
	trail.emission_sphere_radius = 3.0
	trail.direction = Vector2(0, 1)
	trail.spread = 180.0
	trail.gravity = Vector2.ZERO
	trail.initial_velocity_min = 4.0
	trail.initial_velocity_max = 18.0
	trail.scale_amount_min = 0.12
	trail.scale_amount_max = 0.42
	trail.color = Color(1, 1, 1, 0.5)
	trail.z_index = -1
	add_child(trail)
	trail.emitting = true


func configure(p: Vector2, enemy: EnemyUnit, from_tower, id: String, proj_kind: String, col: Color) -> void:
	global_position = p
	target = enemy
	tower = from_tower
	tower_id = id
	kind = proj_kind
	color = col
	sprite.texture = Sprites.get_projectile(kind, color)
	if trail != null:
		trail.color = Color(col.r, col.g, col.b, 0.55)


func tick(dt: float) -> bool:
	life -= dt
	if not is_instance_valid(target) or target.is_queued_for_deletion() or target.is_dying or not target.alive:
		return true
	if life <= 0.0:
		return true
	var tpos: Vector2 = target.pos
	global_position = global_position.move_toward(tpos, speed * dt)
	if sprite != null:
		sprite.rotation = (tpos - global_position).angle() + PI * 0.5
	return global_position.distance_to(tpos) <= 16.0
