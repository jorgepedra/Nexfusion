class_name TowerUnit
extends Area2D
## Player unit: a chemical protection tower.
## Enemies are detected by the native RangeArea, so no tower ever scans the map.

var battle = null
var id := ""
var level_a := 0
var level_b := 0
var cooldown := 0.0
var kills := 0
var target_priority := "primeiro"
var spent := 0
var disabled := 0.0
var emitter_timer := 0.0
var corrosion_cd := 0.0
var puddle_cd := 0.0
var purify_cd := 0.0
var anim := 0.0
var stats: Dictionary = {}
var enemies_in_range: Array = []
var display_range := 120.0
var is_ghost := false
var ghost_invalid := false
var aura_particles: CPUParticles2D

var is_selected := false:
	set(v):
		is_selected = v
		if overlay != null:
			overlay.queue_redraw()

var is_hovered := false:
	set(v):
		is_hovered = v
		if overlay != null:
			overlay.queue_redraw()

@onready var body: Sprite2D = $BodySprite
@onready var pad: Sprite2D = $BasePad
@onready var hitbox: CollisionShape2D = $Hitbox
@onready var muzzle: Marker2D = $Muzzle
@onready var range_area: Area2D = $RangeArea
@onready var range_shape: CollisionShape2D = $RangeArea/RangeShape
@onready var overlay: Node2D = $RangeOverlay
@onready var anim_player: AnimationPlayer = $AnimPlayer


func _ready() -> void:
	pad.texture = Sprites.get_effect("pad")
	pad.z_index = -1
	range_area.area_entered.connect(_on_area_entered)
	range_area.area_exited.connect(_on_area_exited)
	mouse_entered.connect(func() -> void: is_hovered = true)
	mouse_exited.connect(func() -> void: is_hovered = false)
	_build_animations()
	_build_aura()
	if id != "":
		refresh()


func _build_aura() -> void:
	aura_particles = CPUParticles2D.new()
	aura_particles.name = "Aura"
	aura_particles.texture = Sprites.get_effect("dot")
	aura_particles.amount = 5
	aura_particles.lifetime = 1.6
	aura_particles.preprocess = 0.8
	aura_particles.emission_shape = CPUParticles2D.EMISSION_SHAPE_SPHERE
	aura_particles.emission_sphere_radius = 13.0
	aura_particles.direction = Vector2(0, -1)
	aura_particles.spread = 25.0
	aura_particles.gravity = Vector2(0, -14)
	aura_particles.initial_velocity_min = 3.0
	aura_particles.initial_velocity_max = 10.0
	aura_particles.scale_amount_min = 0.1
	aura_particles.scale_amount_max = 0.32
	aura_particles.color = Color(0.7, 1.0, 0.8, 0.32)
	aura_particles.z_index = -1
	add_child(aura_particles)
	aura_particles.emitting = true


func _build_animations() -> void:
	var lib := AnimationLibrary.new()
	var idle := Animation.new()
	idle.length = 2.0
	idle.loop_mode = Animation.LOOP_LINEAR
	var t := idle.add_track(Animation.TYPE_VALUE)
	idle.track_set_path(t, "BodySprite:position")
	idle.track_insert_key(t, 0.0, Vector2(0, 0))
	idle.track_insert_key(t, 1.0, Vector2(0, -2.5))
	idle.track_insert_key(t, 2.0, Vector2(0, 0))
	lib.add_animation("idle", idle)
	var shoot := Animation.new()
	shoot.length = 0.22
	var st := shoot.add_track(Animation.TYPE_VALUE)
	shoot.track_set_path(st, "BodySprite:position")
	shoot.track_insert_key(st, 0.0, Vector2(0, 4))
	shoot.track_insert_key(st, 0.22, Vector2(0, 0))
	lib.add_animation("shoot", shoot)
	anim_player.add_animation_library("", lib)
	anim_player.play("idle")


func setup(tower_id: String, p: Vector2, ghost: bool = false) -> void:
	id = tower_id
	position = p
	spent = int(DB.TOWERS[id].price)
	is_ghost = ghost
	refresh()
	if ghost:
		_apply_ghost()
		overlay.queue_redraw()


func refresh() -> void:
	stats = DB.tower_stats(id, level_a, level_b)
	if body != null:
		body.texture = Sprites.get_tower(id, disabled > 0.0)
	var shape := range_shape.shape as CircleShape2D
	if shape != null:
		shape.radius = maxf(24.0, float(stats.range))
	display_range = float(stats.range)
	if aura_particles != null and DB.TOWERS.has(id):
		var c := Color(DB.CATEGORIES[DB.TOWERS[id].cat].color)
		aura_particles.color = Color(c.r, c.g, c.b, 0.32)


func _apply_ghost() -> void:
	collision_layer = 0
	input_pickable = false
	hitbox.set_deferred("disabled", true)
	range_area.set_deferred("monitoring", false)
	if aura_particles != null:
		aura_particles.emitting = false


func tick(dt: float) -> void:
	anim = maxf(0.0, anim - dt * 5.0)
	corrosion_cd = maxf(0.0, corrosion_cd - dt)
	puddle_cd = maxf(0.0, puddle_cd - dt)
	emitter_timer = maxf(0.0, emitter_timer - dt)
	var was_disabled := disabled > 0.0
	disabled = maxf(0.0, disabled - dt)
	if was_disabled and disabled <= 0.0:
		refill_texture()
	if disabled > 0.0:
		return
	cooldown -= dt
	if cooldown > 0.0:
		return
	if battle == null:
		return
	var targets := pick_targets(display_range)
	if targets.is_empty():
		return
	for e in targets:
		battle.fire_at(self, e)
	cooldown = 1.0 / maxf(0.05, float(stats.rate) * battle.rate_mult(self))
	anim = 0.28
	if anim_player.has_animation("shoot"):
		anim_player.play("shoot")
		anim_player.queue("idle")
	battle.play_shoot(self)


func refill_texture() -> void:
	if body != null:
		body.texture = Sprites.get_tower(id, disabled > 0.0)


func set_disabled(seconds: float) -> void:
	if seconds <= 0.0:
		return
	disabled = maxf(disabled, seconds)
	refill_texture()


func set_range_radius(r: float) -> void:
	var shape := range_shape.shape as CircleShape2D
	if shape != null and absf(shape.radius - r) > 0.5:
		shape.radius = maxf(24.0, r)


func pick_targets(rng: float) -> Array:
	var arr: Array = []
	var i := enemies_in_range.size() - 1
	while i >= 0:
		var e = enemies_in_range[i]
		if not is_instance_valid(e) or e.is_queued_for_deletion():
			enemies_in_range.remove_at(i)
			i -= 1
			continue
		if e.alive and not e.is_dying and global_position.distance_to(e.global_position) <= rng:
			arr.append(e)
		i -= 1
	if arr.is_empty():
		return arr
	if battle != null:
		var pri: String = target_priority
		arr.sort_custom(func(a, b) -> bool: return battle.compare_priority(a, b, pri))
	return arr.slice(0, mini(int(stats.targets), arr.size()))


func forget_enemy(e) -> void:
	enemies_in_range.erase(e)


func _on_area_entered(area: Area2D) -> void:
	var e = area.get_parent()
	if e is EnemyUnit and e.alive and not e.is_dying:
		if not enemies_in_range.has(e):
			enemies_in_range.append(e)


func _on_area_exited(area: Area2D) -> void:
	var e = area.get_parent()
	if e != null:
		enemies_in_range.erase(e)


func _input_event(_viewport: Node, event: InputEvent, _shape_idx: int) -> void:
	if is_ghost or battle == null:
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		battle.select_tower(self)


func total_levels() -> int:
	return level_a + level_b


func sell_value() -> int:
	return int(floor(spent * 0.7))


func can_buy(path: String) -> bool:
	return DB.can_upgrade(level_a, level_b, path)


func next_cost(path: String) -> int:
	var lvl := level_a if path == "A" else level_b
	return DB.upgrade_cost(id, path, lvl)
