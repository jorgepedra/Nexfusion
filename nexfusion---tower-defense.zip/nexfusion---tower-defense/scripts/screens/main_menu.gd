extends Control
## Main menu: NEXFUSION branding, animated flask and waving tower mascots.

var buttons: Array = []
var flask: TextureRect
var mascots: Array = []
var menu_time := 0.0


func setup(_args: Dictionary) -> void:
	var bg := TextureRect.new()
	bg.texture = Sprites.get_map(0)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	bg.modulate = Color(0.42, 0.52, 0.62, 1.0)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)

	var veil := ColorRect.new()
	veil.color = Color(0.02, 0.06, 0.11, 0.55)
	veil.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	veil.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(veil)

	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 48)
	margin.add_theme_constant_override("margin_right", 48)
	margin.add_theme_constant_override("margin_top", 22)
	margin.add_theme_constant_override("margin_bottom", 20)
	add_child(margin)

	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 2)
	margin.add_child(col)

	flask = TextureRect.new()
	flask.texture = Sprites.get_effect("flask_green")
	flask.custom_minimum_size = Vector2(84, 84)
	flask.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	flask.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	flask.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var flask_row := HBoxContainer.new()
	flask_row.alignment = BoxContainer.ALIGNMENT_CENTER
	flask_row.add_child(flask)
	col.add_child(flask_row)

	var title := UiTheme.label("NEXFUSION", 64, Color("#b6f24a"))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_color_override("font_outline_color", Color("#07202b"))
	title.add_theme_constant_override("outline_size", 14)
	col.add_child(title)

	var title2 := UiTheme.label("TOWER DEFENSE", 44, Color("#58d8ff"))
	title2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title2.add_theme_color_override("font_outline_color", Color("#07202b"))
	title2.add_theme_constant_override("outline_size", 11)
	col.add_child(title2)

	var sub := UiTheme.label("DEFESA QUÍMICA · CIÊNCIA REAL", 14, Color("#cfe9f7"))
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.add_theme_color_override("font_outline_color", Color(0.03, 0.09, 0.14, 0.85))
	sub.add_theme_constant_override("outline_size", 6)
	col.add_child(sub)

	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, 8)
	col.add_child(spacer)

	var center := CenterContainer.new()
	center.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(center)

	var stack := VBoxContainer.new()
	stack.custom_minimum_size = Vector2(380, 0)
	stack.add_theme_constant_override("separation", 10)
	center.add_child(stack)

	_add_menu_button(stack, "JOGAR", "play", func() -> void: get_parent().go("maps"))
	_add_menu_button(stack, "TUTORIAL", "book", func() -> void: get_parent().go("battle", {"map_id": 0, "diff": "facil", "tutorial": true}))
	_add_menu_button(stack, "LABORATÓRIO", "flask", func() -> void: get_parent().go("lab"))
	_add_menu_button(stack, "QUIMIDEX", "book", func() -> void: get_parent().go("quimidex"))
	_add_menu_button(stack, "OPÇÕES", "gear", func() -> void: get_parent().go("options"))
	_add_menu_button(stack, "SAIR", "close", func() -> void: get_tree().quit())

	_spawn_mascots()

	var version := UiTheme.label("Nexfusion Tower Defense · v1.0", 13, Color(0.8, 0.9, 0.97, 0.8))
	version.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	version.position = Vector2(-262, -30)
	version.size = Vector2(248, 22)
	version.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	add_child(version)

	var hint := UiTheme.label("Mouse e toque · Espaço = iniciar round", 13, Color(0.8, 0.9, 0.97, 0.65))
	hint.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	hint.position = Vector2(28, -30)
	hint.size = Vector2(420, 22)
	add_child(hint)


func _spawn_mascots() -> void:
	var entries := [["lead", Vector2(120, 600)], ["bicarb", Vector2(1160, 610)], ["charcoal", Vector2(230, 660)]]
	for e in entries:
		var s := Sprite2D.new()
		s.texture = Sprites.get_tower(str(e[0]))
		s.position = e[1]
		s.scale = Vector2(1.7, 1.7)
		add_child(s)
		mascots.append(s)
		var tw := create_tween()
		tw.set_loops()
		tw.tween_property(s, "position:y", s.position.y - 12.0, 1.4 + randf() * 0.6)
		tw.tween_property(s, "position:y", s.position.y, 1.4 + randf() * 0.6)
		var w := create_tween()
		w.set_loops()
		w.tween_property(s, "rotation", 0.18, 1.8)
		w.tween_property(s, "rotation", -0.18, 1.8)


func _process(delta: float) -> void:
	menu_time += delta
	if flask != null:
		flask.scale = Vector2.ONE * (1.0 + sin(menu_time * 2.2) * 0.06)
		flask.modulate = Color(1.0, 1.0, 1.0, 0.9 + sin(menu_time * 3.0) * 0.1)


func _add_menu_button(stack: VBoxContainer, text: String, icon: String, action: Callable) -> void:
	var b := UiTheme.button(text, icon, 22, Color("#1679b8"))
	b.custom_minimum_size = Vector2(380, 48)
	b.pivot_offset = Vector2(190, 24)
	stack.add_child(b)
	b.pressed.connect(_menu_press.bind(action))
	b.mouse_entered.connect(_hover_grow.bind(b, 1.04))
	b.mouse_exited.connect(_hover_grow.bind(b, 1.0))
	buttons.append(b)


func _menu_press(action: Callable) -> void:
	Snd.play_sfx("click")
	action.call()


func _hover_grow(b: Button, factor: float) -> void:
	var tw := b.create_tween()
	tw.tween_property(b, "scale", Vector2(factor, factor), 0.12)
