extends Control
## Options screen: volumes, default speed, educational tips and progress reset.

var speed_buttons := {}
var wipe_feedback: Label


func setup(_args: Dictionary) -> void:
	var bg := LabBackdrop.new()
	bg.show_towers = false
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 32)
	margin.add_theme_constant_override("margin_right", 32)
	margin.add_theme_constant_override("margin_top", 18)
	margin.add_theme_constant_override("margin_bottom", 24)
	add_child(margin)

	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 12)
	margin.add_child(col)

	var header := HBoxContainer.new()
	col.add_child(header)
	var back := UiTheme.button("Voltar", "back", 17, Color("#27506e"))
	back.custom_minimum_size = Vector2(132, 42)
	header.add_child(back)
	back.pressed.connect(_go_menu)
	var title := UiTheme.label("OPÇÕES", 30, Color("#eaf6ff"))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	var sp := Control.new()
	sp.custom_minimum_size = Vector2(132, 42)
	header.add_child(sp)

	var center := CenterContainer.new()
	center.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(center)

	var panel := UiTheme.panel(Color(0.05, 0.13, 0.2, 0.95), 18, 2, Color("#5f93b8"))
	panel.custom_minimum_size = Vector2(700, 0)
	center.add_child(panel)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 16)
	panel.add_child(box)

	box.add_child(_slider_row("Volume dos efeitos (SFX)", "sfx"))
	box.add_child(UiTheme.hsep(1, Color("#31536d")))

	var speed_row := HBoxContainer.new()
	speed_row.add_theme_constant_override("separation", 12)
	box.add_child(speed_row)
	var sl := UiTheme.label("Velocidade padrão", 17)
	sl.custom_minimum_size = Vector2(260, 0)
	speed_row.add_child(sl)
	for key in [1, 2]:
		var b := UiTheme.button(str(key) + "x", "", 17, Color("#1b618d"))
		b.custom_minimum_size = Vector2(84, 40)
		speed_row.add_child(b)
		speed_buttons[key] = b
		b.pressed.connect(_set_speed.bind(key))
	var sp2 := Control.new()
	sp2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	speed_row.add_child(sp2)
	_refresh_speed()

	var tips_row := HBoxContainer.new()
	box.add_child(tips_row)
	var tl := UiTheme.label("Mostrar dicas educativas", 17)
	tl.custom_minimum_size = Vector2(260, 0)
	tips_row.add_child(tl)
	var tips := CheckButton.new()
	tips.button_pressed = bool(Store.opt("tips", true))
	tips.focus_mode = Control.FOCUS_NONE
	tips.toggled.connect(_set_tips)
	tips_row.add_child(tips)

	var lang_row := HBoxContainer.new()
	box.add_child(lang_row)
	var ll := UiTheme.label("Idioma", 17)
	ll.custom_minimum_size = Vector2(260, 0)
	lang_row.add_child(ll)
	lang_row.add_child(UiTheme.label("Português (PT-BR)", 16, Color("#9fc0d8")))

	box.add_child(UiTheme.hsep(1, Color("#31536d")))

	var wipe_row := HBoxContainer.new()
	wipe_row.add_theme_constant_override("separation", 16)
	box.add_child(wipe_row)
	var wipe := UiTheme.button("Apagar progresso", "close", 16, Color("#8e3333"))
	wipe.custom_minimum_size = Vector2(230, 44)
	wipe_row.add_child(wipe)
	wipe_feedback = UiTheme.label("", 14, Color("#ffcf8a"))
	wipe_row.add_child(wipe_feedback)
	var confirm := ConfirmationDialog.new()
	confirm.title = "Apagar progresso"
	confirm.dialog_text = "Isso apaga recordes, receitas, itens e torres descobertas. Tem certeza?"
	confirm.ok_button_text = "APAGAR"
	confirm.cancel_button_text = "Cancelar"
	add_child(confirm)
	confirm.confirmed.connect(_wipe_progress)
	wipe.pressed.connect(_ask_wipe.bind(confirm))


func _slider_row(title: String, key: String) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	var l := UiTheme.label(title, 17)
	l.custom_minimum_size = Vector2(260, 0)
	row.add_child(l)
	var slider := HSlider.new()
	slider.min_value = 0
	slider.max_value = 100
	slider.step = 1
	slider.value = float(Store.opt(key, 0.7)) * 100.0
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	slider.custom_minimum_size = Vector2(280, 28)
	slider.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(slider)
	var val := UiTheme.label(str(int(slider.value)) + "%", 15, Color("#b8d6ea"))
	val.custom_minimum_size = Vector2(56, 0)
	val.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	row.add_child(val)
	slider.value_changed.connect(_on_slider.bind(key, val))
	return row


func _go_menu() -> void:
	Snd.play_sfx("click")
	get_parent().go("menu")


func _set_speed(key: int) -> void:
	Snd.play_sfx("click")
	Store.set_opt("speed", key)
	_refresh_speed()


func _set_tips(on: bool) -> void:
	Snd.play_sfx("click")
	Store.set_opt("tips", on)


func _ask_wipe(dialog: ConfirmationDialog) -> void:
	Snd.play_sfx("click")
	dialog.popup_centered(Vector2i(460, 170))


func _wipe_progress() -> void:
	Store.wipe()
	wipe_feedback.text = "Progresso apagado."
	Snd.play_sfx("sell")


func _on_slider(v: float, key: String, val: Label) -> void:
	val.text = str(int(v)) + "%"
	Store.set_opt(key, v / 100.0)
	Snd.apply_volumes()


func _refresh_speed() -> void:
	var current := int(Store.opt("speed", 1))
	for key in speed_buttons.keys():
		var b: Button = speed_buttons[key]
		var sel: bool = key == current
		b.add_theme_stylebox_override("normal", UiTheme.box(Color("#2f9e5f") if sel else Color("#1b618d"), 10, 2, Color("#b8f0cc") if sel else Color("#3d7ea8")))
