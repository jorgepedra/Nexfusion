extends Control
## Laboratory sandbox: drag ingredients into flasks, mix and discover recipes.

var flasks: Array = []
var inventory_tiles: Array = []
var recipe_box: VBoxContainer
var created_row: HBoxContainer
var backpack_row: HBoxContainer
var counter_label: Label
var banner: Label
var banner_t := 0.0
var banner_kind := 0
var heat := false
var heat_btn: Button
var bench: LabBench
var time := 0.0
var reaction_state := 0
var reaction_t := 0.0
var mix_count := 0
var assistant: Label
var hint_open := {}


func setup(_args: Dictionary) -> void:
	var bg := LabBackdrop.new()
	bg.dim = true
	bg.show_towers = false
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var top := Control.new()
	top.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(top)

	var back := UiTheme.button("Voltar", "back", 16, Color("#27506e"))
	back.position = Vector2(16, 16)
	back.size = Vector2(126, 42)
	add_child(back)
	back.pressed.connect(_go_menu)

	var title := UiTheme.label("LABORATÓRIO", 30, Color("#eaf6ff"))
	title.position = Vector2(300, 16)
	title.size = Vector2(680, 38)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_color_override("font_outline_color", Color(0.02, 0.05, 0.08, 0.9))
	title.add_theme_constant_override("outline_size", 8)
	add_child(title)

	counter_label = UiTheme.label("", 15, Color("#f4d36a"))
	counter_label.position = Vector2(1010, 26)
	counter_label.size = Vector2(250, 24)
	counter_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	add_child(counter_label)

	_build_inventory()
	_build_bench()
	_build_recipes()
	_build_actions()
	_refresh_all()


func _go_menu() -> void:
	Snd.play_sfx("click")
	get_parent().go("menu")


func _build_inventory() -> void:
	var panel := UiTheme.panel(Color(0.04, 0.12, 0.18, 0.96), 14, 2, Color("#4f7fa6"))
	panel.position = Vector2(16, 76)
	panel.size = Vector2(242, 626)
	add_child(panel)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 6)
	panel.add_child(col)
	var t := UiTheme.label("INVENTÁRIO", 18, Color("#eaf6ff"))
	col.add_child(t)
	var hint := UiTheme.label("Arraste para os frascos", 11, Color(0.65, 0.8, 0.9, 0.8))
	col.add_child(hint)
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	col.add_child(scroll)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 6)
	grid.add_theme_constant_override("v_separation", 6)
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(grid)
	for item_id in DB.ITEMS.keys():
		var tile := ItemTile.new()
		tile.lab = self
		tile.item_id = item_id
		tile.custom_minimum_size = Vector2(100, 82)
		tile.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		grid.add_child(tile)
		inventory_tiles.append(tile)


func _build_bench() -> void:
	bench = LabBench.new()
	bench.lab = self
	bench.position = Vector2(272, 86)
	bench.size = Vector2(692, 400)
	bench.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bench)
	var guide := UiTheme.panel(Color(0.05, 0.14, 0.2, 0.95), 9, 1, Color("#8fe6a8"))
	guide.position = Vector2(296, 88)
	guide.size = Vector2(660, 40)
	add_child(guide)
	assistant = UiTheme.label("", 12, Color("#c8ffd8"))
	assistant.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	assistant.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	guide.add_child(assistant)
	for i in 3:
		var f := Flask.new()
		f.lab = self
		f.index = i
		f.position = Vector2(296 + i * 208, 132)
		f.size = Vector2(180, 246)
		add_child(f)
		flasks.append(f)
	banner = UiTheme.label("", 16, Color("#ffe9a8"))
	banner.position = Vector2(300, 452)
	banner.size = Vector2(660, 28)
	banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	banner.add_theme_color_override("font_outline_color", Color(0.02, 0.05, 0.08, 0.95))
	banner.add_theme_constant_override("outline_size", 7)
	banner.visible = false
	banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(banner)


func _build_recipes() -> void:
	var panel := UiTheme.panel(Color(0.04, 0.12, 0.18, 0.96), 14, 2, Color("#4f7fa6"))
	panel.position = Vector2(976, 76)
	panel.size = Vector2(288, 626)
	add_child(panel)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 7)
	panel.add_child(col)
	var t := UiTheme.label("LIVRO DE RECEITAS", 16, Color("#eaf6ff"))
	col.add_child(t)
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	col.add_child(scroll)
	recipe_box = VBoxContainer.new()
	recipe_box.add_theme_constant_override("separation", 5)
	recipe_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(recipe_box)
	col.add_child(UiTheme.hsep(1, Color("#31536d")))
	var bp := UiTheme.label("MOCHILA · até 4 itens", 13, Color("#cfe9f7"))
	col.add_child(bp)
	backpack_row = HBoxContainer.new()
	backpack_row.add_theme_constant_override("separation", 6)
	col.add_child(backpack_row)
	var hint := UiTheme.label("Clique para equipar (máx. 4).", 10, Color(0.65, 0.8, 0.9, 0.8))
	col.add_child(hint)


func _build_actions() -> void:
	var mix := UiTheme.button("MISTURAR", "flask", 19, Color("#2f9e5f"))
	mix.position = Vector2(300, 496)
	mix.size = Vector2(250, 50)
	add_child(mix)
	mix.pressed.connect(_mix)

	var clear := UiTheme.button("LIMPAR", "close", 15, Color("#42596b"))
	clear.position = Vector2(560, 500)
	clear.size = Vector2(140, 42)
	add_child(clear)
	clear.pressed.connect(_clear_all)

	heat_btn = UiTheme.button("AQUECER", "heat", 15, Color("#1b618d"))
	heat_btn.position = Vector2(712, 500)
	heat_btn.size = Vector2(164, 42)
	add_child(heat_btn)
	heat_btn.pressed.connect(_toggle_heat)

	var created_title := UiTheme.label("ITENS CRIADOS · clique para equipar", 13, Color("#cfe9f7"))
	created_title.position = Vector2(300, 556)
	created_title.size = Vector2(660, 22)
	add_child(created_title)
	created_row = HBoxContainer.new()
	created_row.position = Vector2(300, 582)
	created_row.size = Vector2(660, 82)
	created_row.add_theme_constant_override("separation", 7)
	add_child(created_row)

	var hint := UiTheme.label("Misturas simbólicas e educativas. Nunca misture produtos de limpeza na vida real.", 12, Color(0.7, 0.83, 0.92, 0.8))
	hint.position = Vector2(300, 676)
	hint.size = Vector2(660, 22)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	add_child(hint)


func _process(delta: float) -> void:
	time += delta
	if banner_t > 0.0:
		banner_t -= delta
		banner.modulate.a = clampf(banner_t * 1.5, 0.0, 1.0)
		if banner_t <= 0.0:
			banner.visible = false
	if reaction_t > 0.0:
		reaction_t -= delta
		if reaction_t <= 0.0:
			reaction_state = 0
	for f in flasks:
		f.queue_redraw()
	bench.queue_redraw()


func _banner(text: String, kind := 0, seconds := 4.0) -> void:
	banner.text = text
	banner_kind = kind
	banner.add_theme_color_override("font_color", Color("#ffb86b") if kind == 2 else Color("#8ff0a8") if kind == 1 else Color("#ffe9a8"))
	banner.visible = true
	banner.modulate.a = 1.0
	banner_t = seconds


func add_to_flask(index: int, item_id: String) -> void:
	var f: Flask = flasks[index]
	if f.items.size() >= 2:
		_banner("Este frasco já tem 2 itens. Clique nele para esvaziar.", 0, 3.0)
		return
	var used := 0
	for other in flasks:
		for id in other.items:
			if id == item_id:
				used += 1
	if used >= Store.inventory_count(item_id):
		_banner("Você não tem mais " + DB.ITEMS[item_id].name + " no inventário.", 0, 3.0)
		Snd.play_sfx("error")
		return
	f.items.append(item_id)
	f.queue_redraw()
	_refresh_assistant()
	Snd.play_sfx("bubble", randf_range(0.9, 1.15))
	_banner(DB.ITEMS[item_id].name + " adicionado ao frasco " + str(index + 1) + ".", 0, 2.0)


func clear_flask(index: int) -> void:
	var f: Flask = flasks[index]
	if f.items.is_empty():
		return
	f.items.clear()
	f.queue_redraw()
	_refresh_assistant()
	Snd.play_sfx("bubble")
	_banner("Frasco " + str(index + 1) + " esvaziado. Os itens voltaram ao inventário.", 0, 2.0)


func _clear_all() -> void:
	for i in 3:
		flasks[i].items.clear()
		flasks[i].queue_redraw()
	reaction_state = 0
	_refresh_assistant()
	Snd.play_sfx("bubble")
	_banner("Bancada limpa.", 0, 2.0)


func _toggle_heat() -> void:
	heat = not heat
	Snd.play_sfx("click")
	_banner("Bico de Bunsen " + ("ligado. Algumas reações precisam de calor." if heat else "desligado."), 0, 3.0)
	_refresh_heat_button()
	_refresh_assistant()


func _refresh_heat_button() -> void:
	if heat_btn == null:
		return
	heat_btn.text = "   AQUECER: ON" if heat else "   AQUECER"
	heat_btn.add_theme_stylebox_override("normal", UiTheme.box(Color("#c9772f") if heat else Color("#1b618d"), 10, 2, Color("#ffd08a") if heat else Color("#3d7ea8")))
	heat_btn.add_theme_stylebox_override("hover", UiTheme.box(Color("#e08a3a") if heat else Color("#2377a8"), 10, 2, Color.WHITE))
	heat_btn.add_theme_stylebox_override("pressed", UiTheme.box(Color("#a85f25") if heat else Color("#124a6c"), 10, 2, Color.WHITE))


func _mix() -> void:
	mix_count += 1
	var items: Array = []
	for f in flasks:
		for id in f.items:
			items.append(id)
	if items.size() < 2:
		_banner("Adicione pelo menos 2 itens aos frascos para misturar.", 0, 3.5)
		Snd.play_sfx("error")
		return
	if items.size() > 2:
		_unstable("A bancada da demo mistura pares de itens. Use apenas 2 por vez.")
		return
	var a: String = items[0]
	var b: String = items[1]
	var recipe := DB.recipe_available(a, b)
	if recipe.is_empty():
		_unstable(_unsafe_note())
		return
	if bool(recipe.heat) != heat:
		reaction_state = 2
		reaction_t = 1.2
		Snd.play_sfx("error")
		_banner("Essa reação " + ("precisa do BICO DE BUNSEN ligado." if recipe.heat else "não pode ser aquecida. Desligue o bico."), 2, 4.0)
		return
	if not Store.consume_ingredients(items):
		_banner("Ingredientes insuficientes no inventário.", 2, 3.0)
		Snd.play_sfx("error")
		return
	for f in flasks:
		f.items.clear()
		f.queue_redraw()
	reaction_state = 1
	reaction_t = 1.5
	var result: String = recipe.result
	var is_new := Store.discover(result)
	if not is_new:
		Store.add_created(result)
	var item: Dictionary = DB.CREATED[result]
	Snd.play_sfx("discover")
	if is_new:
		_banner("Nova reação descoberta: " + item.name + "! " + str(recipe.note), 1, 6.0)
	else:
		_banner("Reação repetida: +1 " + item.name + ". " + str(recipe.note), 1, 5.0)
	if is_new:
		_show_recipe_popup(item)
	_refresh_all()


func _show_recipe_popup(item: Dictionary) -> void:
	var ov := Control.new()
	ov.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ov.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(ov)
	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.04, 0.07, 0.55)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ov.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ov.add_child(center)
	var panel := UiTheme.panel(Color(0.04, 0.14, 0.2, 0.99), 16, 2, Color("#8fe6a8"))
	panel.custom_minimum_size = Vector2(470, 0)
	center.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	panel.add_child(v)
	var t := UiTheme.label("NOVA REAÇÃO DESCOBERTA!", 22, Color("#8ff0a8"))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(t)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	v.add_child(row)
	var icon := UIcon.new()
	icon.kind = str(item.icon)
	icon.tint = Color(item.color)
	icon.custom_minimum_size = Vector2(56, 56)
	row.add_child(icon)
	var name_l := UiTheme.label(str(item.name), 20, Color("#eaf6ff"))
	name_l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(name_l)
	var d := UiTheme.label(str(item.desc), 14, Color("#cfe9f7"))
	d.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(d)
	var sci := UiTheme.label(str(item.science), 12, Color("#9fc0d8"))
	sci.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(sci)
	var info := UiTheme.label("Já está na Mochila? Clique no item criado para equipar até 4 habilidades.", 12, Color("#f4d36a"))
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(info)
	var ok := UiTheme.button("Continuar", "check", 16, Color("#2f9e5f"))
	v.add_child(ok)
	ok.pressed.connect(_close_popup.bind(ov))


func _close_popup(ov: Control) -> void:
	Snd.play_sfx("click")
	ov.queue_free()


func _unsafe_note() -> String:
	var notes := [
		"Mistura instável! Em um laboratório real, combinar substâncias desconhecidas pode liberar gases tóxicos ou calor.",
		"Mistura instável! Nunca misture produtos de limpeza: algumas combinações formam gases perigosos.",
		"Mistura instável! Use óculos de proteção e nunca cheire diretamente um frasco.",
		"Mistura instável! A química exige saber o que está sendo misturado antes de começar.",
	]
	return notes[mix_count % notes.size()]


func _unstable(text: String) -> void:
	reaction_state = 2
	reaction_t = 1.4
	Snd.play_sfx("error")
	_banner(text + " Nada foi criado e os itens voltaram.", 2, 6.0)


func toggle_equip(item_id: String) -> void:
	if item_id in Store.backpack():
		Store.unequip(item_id)
		Snd.play_sfx("sell")
		_banner(DB.CREATED[item_id].name + " removido da mochila.", 0, 2.5)
	elif Store.equip(item_id):
		Snd.play_sfx("upgrade")
		_banner(DB.CREATED[item_id].name + " equipado! Ele aparece na barra de habilidades da partida.", 1, 3.5)
	else:
		_banner("A mochila já tem 4 itens. Remova um para equipar outro.", 2, 3.0)
		Snd.play_sfx("error")
	_refresh_all()


func _refresh_all() -> void:
	counter_label.text = "Reações descobertas: " + str(Store.data.recipes.size()) + " / " + str(DB.RECIPES.size())
	for tile in inventory_tiles:
		tile.queue_redraw()
	for f in flasks:
		f.update_tooltip()
		f.queue_redraw()
	_refresh_heat_button()
	_refresh_assistant()
	_rebuild_recipes()
	_rebuild_created()
	_rebuild_backpack()


func _rebuild_recipes() -> void:
	for c in recipe_box.get_children():
		c.queue_free()
	for r in DB.RECIPES:
		var item: Dictionary = DB.CREATED[r.result]
		var known := Store.has_recipe(r.result)
		var row := PanelContainer.new()
		row.add_theme_stylebox_override("panel", UiTheme.box(Color(0.05, 0.13, 0.2, 0.95), 8, 1, Color("#33506a")))
		recipe_box.add_child(row)
		var h := HBoxContainer.new()
		h.add_theme_constant_override("separation", 8)
		row.add_child(h)
		var ic := UIcon.new()
		ic.kind = str(item.icon) if known else "question"
		ic.tint = Color(item.color) if known else Color(0.4, 0.48, 0.55)
		ic.custom_minimum_size = Vector2(30, 30)
		h.add_child(ic)
		var v := VBoxContainer.new()
		v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h.add_child(v)
		var name_l := UiTheme.label(str(item.name) if known else "???", 13, Color("#eaf6ff") if known else Color("#6f8798"))
		v.add_child(name_l)
		var desc := UiTheme.label(str(item.desc) if known else "Reação ainda não descoberta.", 10, Color(0.68, 0.82, 0.9, 0.8))
		desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		v.add_child(desc)
		if not known:
			var hint_row := HBoxContainer.new()
			hint_row.add_theme_constant_override("separation", 4)
			v.add_child(hint_row)
			var result_id := String(r.result)
			var hint_btn := UiTheme.button("Dica [?]", "", 10, Color("#3a4e5e"))
			hint_btn.custom_minimum_size = Vector2(78, 24)
			hint_btn.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
			hint_btn.add_theme_font_size_override("font_size", 10)
			hint_row.add_child(hint_btn)
			var hint_text := UiTheme.label(str(r.get("hint", "")), 10, Color("#ffd08a"))
			hint_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			hint_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			hint_text.visible = bool(hint_open.get(result_id, false))
			v.add_child(hint_text)
			hint_btn.pressed.connect(func() -> void:
				hint_open[result_id] = not bool(hint_open.get(result_id, false))
				Snd.play_sfx("click")
				_rebuild_recipes())


func _refresh_assistant() -> void:
	if assistant == null:
		return
	var items: Array = []
	for f in flasks:
		for id in f.items:
			items.append(id)
	var text := ""
	if items.is_empty():
		text = "Assistente da bancada: adicione 2 ingredientes aos frascos e clique em MISTURAR."
	elif items.size() == 1:
		text = "Você adicionou " + DB.ITEMS[items[0]].name + ". Coloque mais 1 ingrediente compatível e clique em MISTURAR."
	else:
		var a := String(items[0])
		var b := String(items[1])
		var recipe := DB.recipe_available(a, b)
		if recipe.is_empty():
			text = "Esses dois ingredientes não formam um item conhecido. Consulte as pistas do livro de receitas."
		elif bool(recipe.heat) and not heat:
			text = "Quase lá! Essa mistura sólida precisa de calor. Clique em AQUECER antes de misturar!"
		elif not bool(recipe.heat) and heat:
			text = "Essa reação não precisa de calor. Desligue o AQUECER para misturar."
		else:
			text = "Combinação estável detectada! Clique em MISTURAR para sintetizar " + str(DB.CREATED[recipe.result].name) + "."
	assistant.text = text


func _rebuild_created() -> void:
	for c in created_row.get_children():
		c.queue_free()
	var found_any := false
	for id in DB.CREATED.keys():
		if not Store.has_recipe(id):
			continue
		found_any = true
		var chip := CreatedChip.new()
		chip.lab = self
		chip.item_id = id
		chip.custom_minimum_size = Vector2(76, 76)
		created_row.add_child(chip)
	if not found_any:
		var l := UiTheme.label("Nenhum item criado ainda. Misture dois ingredientes na bancada!", 12, Color(0.7, 0.83, 0.92, 0.8))
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size = Vector2(640, 40)
		created_row.add_child(l)


func _rebuild_backpack() -> void:
	for c in backpack_row.get_children():
		c.queue_free()
	var equipped := Store.backpack()
	for i in 4:
		var slot := BackpackSlot.new()
		slot.lab = self
		slot.slot_index = i
		slot.item_id = equipped[i] if i < equipped.size() else ""
		slot.custom_minimum_size = Vector2(58, 58)
		backpack_row.add_child(slot)


class ItemTile extends Button:
	var lab = null
	var item_id := ""

	func _ready() -> void:
		focus_mode = Control.FOCUS_NONE
		flat = true
		for st in ["normal", "hover", "pressed", "focus"]:
			add_theme_stylebox_override(st, StyleBoxEmpty.new())
		mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
		mouse_entered.connect(queue_redraw)
		mouse_exited.connect(queue_redraw)

	func _get_drag_data(_at: Vector2):
		if lab == null or Store.inventory_count(item_id) <= 0:
			return null
		var preview := PanelContainer.new()
		preview.add_theme_stylebox_override("panel", UiTheme.box(Color(0.06, 0.17, 0.25, 0.96), 8, 2, Color("#8fd8ff")))
		var l := UiTheme.label(DB.ITEMS[item_id].name, 14, Color.WHITE)
		preview.add_child(l)
		set_drag_preview(preview)
		return {"item": item_id}

	func _draw() -> void:
		var count := Store.inventory_count(item_id)
		var col := Color(DB.ITEMS[item_id].color)
		var bg := Color(0.05, 0.14, 0.21, 0.96)
		if count <= 0:
			bg = Color(0.05, 0.09, 0.13, 0.9)
		if is_hovered() and count > 0:
			bg = Color(0.08, 0.21, 0.3, 0.98)
		draw_style_box(UiTheme.box(bg, 9, 2, Color(0.32, 0.52, 0.68) if count > 0 else Color(0.24, 0.32, 0.38)), Rect2(Vector2.ZERO, size))
		var icon_col := col if count > 0 else Color(0.35, 0.42, 0.48)
		Art.draw_icon(self, "flask", Vector2(24, 26), 26.0, icon_col)
		var font := ThemeDB.fallback_font
		draw_multiline_string(font, Vector2(6, 52), str(DB.ITEMS[item_id].name), HORIZONTAL_ALIGNMENT_LEFT, size.x - 12, 10, 2, Color("#eaf6ff") if count > 0 else Color(0.5, 0.6, 0.68))
		draw_string(font, Vector2(size.x - 34, 20), "x" + str(count), HORIZONTAL_ALIGNMENT_RIGHT, 28, 11, Color("#f4d36a") if count > 0 else Color("#ff8a8a"))
		if count <= 0:
			draw_rect(Rect2(3, 3, size.x - 6, size.y - 6), Color(0.02, 0.04, 0.07, 0.45))


class Flask extends Control:
	var lab = null
	var index := 0
	var items: Array = []

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_STOP
		mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND

	func update_tooltip() -> void:
		var names: Array = []
		for id in items:
			names.append(DB.ITEMS[id].name)
		tooltip_text = "Frasco " + str(index + 1) + "\n" + (", ".join(names) if not names.is_empty() else "vazio") + "\nClique para esvaziar."

	func _can_drop_data(_pos: Vector2, data) -> bool:
		return typeof(data) == TYPE_DICTIONARY and data.has("item")

	func _drop_data(_pos: Vector2, data) -> void:
		if lab != null:
			lab.add_to_flask(index, str(data["item"]))

	func _gui_input(event: InputEvent) -> void:
		if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
			if not items.is_empty():
				lab.clear_flask(index)

	func _draw() -> void:
		if lab == null:
			return
		var fill := Color(0, 0, 0, 0)
		if items.size() == 1:
			fill = Color(DB.ITEMS[items[0]].color)
			fill.a = 0.7
		elif items.size() >= 2:
			var c1 := Color(DB.ITEMS[items[0]].color)
			var c2 := Color(DB.ITEMS[items[1]].color)
			fill = c1.lerp(c2, 0.5)
			fill.a = 0.78
		var center := Vector2(size.x * 0.5, size.y * 0.58)
		if lab.reaction_state == 1 and lab.reaction_t > 0.0:
			fill = Color(0.65, 1.0, 0.7, 0.8)
		# stand
		Art._ellipse(self, Vector2(center.x, center.y + 58), Vector2(62, 13), Color("#6d7f90"))
		draw_rect(Rect2(center + Vector2(-58, 58), Vector2(116, 10)), Color("#6d7f90"))
		draw_rect(Rect2(center + Vector2(-46, 68), Vector2(92, 8)), Color("#4d5d6b"))
		Art.draw_flask(self, center, 116.0, fill, float(lab.time) + index * 0.7, true)
		draw_style_box(UiTheme.box(Color(0.02, 0.06, 0.09, 0.6), 6), Rect2(12, size.y - 42, size.x - 24, 36))
		draw_string(ThemeDB.fallback_font, Vector2(0, size.y - 24), "FRASCO " + str(index + 1), HORIZONTAL_ALIGNMENT_CENTER, size.x, 11, Color(0.85, 0.95, 1, 0.9))
		draw_string(ThemeDB.fallback_font, Vector2(0, size.y - 9), str(items.size()) + "/2 itens · clique para esvaziar", HORIZONTAL_ALIGNMENT_CENTER, size.x, 9, Color(0.65, 0.8, 0.9, 0.8))
		if lab.reaction_state == 2 and lab.reaction_t > 0.0:
			for i in 5:
				var a: float = float(lab.time) * 1.2 + i
				draw_circle(center + Vector2(sin(a) * 40, -76 - fmod(float(lab.time) * 26 + i * 14, 54)), 8 + i, Color(0.6, 0.62, 0.65, 0.18))
		if items.size() == 2:
			draw_circle(center + Vector2(-12, 36), 7, Color(DB.ITEMS[items[0]].color))
			draw_circle(center + Vector2(12, 30), 7, Color(DB.ITEMS[items[1]].color))


class LabBench extends Control:
	var lab = null

	func _draw() -> void:
		if lab == null:
			return
		# back shelf
		draw_rect(Rect2(30, 18, 630, 12), Color("#8fa3b5"))
		for i in 5:
			Art.draw_flask(self, Vector2(70 + i * 120, 40), 46.0, [Color("#8fe6a8"), Color("#ffd36e"), Color("#9fd0ff"), Color("#ff9d6e"), Color("#c9f2ff")][i], lab.time + i, true)
		# counter
		draw_rect(Rect2(0, 252, size.x, 22), Color("#c7d5e0"))
		draw_rect(Rect2(0, 274, size.x, 58), Color("#8fa3b5"))
		draw_rect(Rect2(0, 332, size.x, 10), Color("#697d8e"))
		for i in 6:
			draw_line(Vector2(20 + i * 120, 274), Vector2(20 + i * 120, 332), Color("#7c90a1"), 2)
		# cabinets
		draw_rect(Rect2(12, 352, size.x - 24, 42), Color("#5f7384"))
		for i in 4:
			draw_rect(Rect2(28 + i * 156, 360, 140, 26), Color("#71879a"))
			draw_circle(Vector2(98 + i * 156, 373), 4, Color("#d7e4ee"))
		# bunsen burner (middle flask)
		var bx := 322.0
		draw_rect(Rect2(bx - 30, 250, 60, 8), Color("#3e4a54"))
		draw_rect(Rect2(bx - 8, 196, 16, 56), Color("#9aa7b3"))
		draw_rect(Rect2(bx - 12, 188, 24, 10), Color("#6d7f90"))
		if lab.heat:
			for i in 3:
				var h: float = 44.0 + sin(float(lab.time) * 9.0 + i) * 8.0
				var col := Color("#63c8ff") if i == 0 else Color("#ffd36e")
				draw_colored_polygon(PackedVector2Array([
					Vector2(bx - 8 + i * 4, 192), Vector2(bx, 192 - h), Vector2(bx + 8 - i * 4, 192)]), col)
			draw_circle(Vector2(bx, 250), 26, Color(1.0, 0.8, 0.4, 0.12))
		else:
			draw_line(Vector2(bx, 192), Vector2(bx, 186), Color("#6d7f90"), 3)
		# hazard sign
		draw_rect(Rect2(596, 150, 74, 48), Color("#d8c35a"))
		draw_rect(Rect2(596, 150, 74, 48), Color("#8a7a2e"), false, 2)
		var font := ThemeDB.fallback_font
		draw_string(font, Vector2(602, 168), "ATENÇÃO", HORIZONTAL_ALIGNMENT_CENTER, 62, 10, Color("#3a3413"))
		draw_string(font, Vector2(602, 188), "ÓCULOS", HORIZONTAL_ALIGNMENT_CENTER, 62, 10, Color("#3a3413"))
		# reaction glow
		if lab.reaction_state == 1 and lab.reaction_t > 0.0:
			for i in 3:
				draw_circle(Vector2(114 + i * 208, 200), 60 + sin(lab.time * 6 + i) * 8, Color(0.6, 1.0, 0.7, 0.06))
		elif lab.reaction_state == 2 and lab.reaction_t > 0.0:
			draw_rect(Rect2(0, 0, size.x, 250), Color(0.35, 0.36, 0.4, 0.12))


class CreatedChip extends Button:
	var lab = null
	var item_id := ""

	func _ready() -> void:
		focus_mode = Control.FOCUS_NONE
		flat = true
		for st in ["normal", "hover", "pressed", "focus"]:
			add_theme_stylebox_override(st, StyleBoxEmpty.new())
		mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
		tooltip_text = DB.CREATED[item_id].name + "\n" + str(DB.CREATED[item_id].desc)
		pressed.connect(func(): lab.toggle_equip(item_id))

	func _draw() -> void:
		var item: Dictionary = DB.CREATED[item_id]
		var equipped := item_id in Store.backpack()
		var bg := Color(0.09, 0.22, 0.3, 0.98) if equipped else Color(0.05, 0.14, 0.21, 0.96)
		var border := Color("#9b6bff")
		if equipped:
			border = Color("#8ff0a8")
		if is_hovered():
			bg = Color(0.1, 0.26, 0.36, 0.99)
		draw_style_box(UiTheme.box(bg, 9, 2, border), Rect2(Vector2.ZERO, size))
		Art.draw_icon(self, str(item.icon), Vector2(size.x * 0.5, 28), 26.0, Color(item.color))
		var font := ThemeDB.fallback_font
		draw_multiline_string(font, Vector2(4, 50), str(item.name), HORIZONTAL_ALIGNMENT_CENTER, size.x - 8, 9, 2, Color("#eaf6ff"))
		draw_string(font, Vector2(4, size.y - 5), "x" + str(int(Store.data.created.get(item_id, 1))), HORIZONTAL_ALIGNMENT_LEFT, 30, 9, Color("#f4d36a"))
		if equipped:
			Art.draw_icon(self, "check", Vector2(size.x - 13, size.y - 12), 13.0, Color("#8ff0a8"))


class BackpackSlot extends Button:
	var lab = null
	var slot_index := 0
	var item_id := ""

	func _ready() -> void:
		focus_mode = Control.FOCUS_NONE
		flat = true
		for st in ["normal", "hover", "pressed", "focus"]:
			add_theme_stylebox_override(st, StyleBoxEmpty.new())
		mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
		if item_id != "":
			tooltip_text = DB.CREATED[item_id].name + "\nClique para remover da mochila."
			pressed.connect(func(): lab.toggle_equip(item_id))

	func _draw() -> void:
		var bg := Color(0.05, 0.13, 0.19, 0.96)
		var border := Color(0.32, 0.45, 0.55)
		if item_id != "":
			bg = Color(0.09, 0.2, 0.29, 0.98)
			border = Color("#9b6bff")
		draw_style_box(UiTheme.box(bg, 9, 2, border), Rect2(Vector2.ZERO, size))
		draw_string(ThemeDB.fallback_font, Vector2(4, 12), str(slot_index + 1), HORIZONTAL_ALIGNMENT_LEFT, 18, 10, Color(0.7, 0.85, 0.95, 0.8))
		if item_id != "":
			var item: Dictionary = DB.CREATED[item_id]
			Art.draw_icon(self, str(item.icon), Vector2(size.x * 0.5, size.y * 0.55), 24.0, Color(item.color))
		else:
			Art.draw_icon(self, "plus", Vector2(size.x * 0.5, size.y * 0.55), 16.0, Color(0.42, 0.52, 0.6))
