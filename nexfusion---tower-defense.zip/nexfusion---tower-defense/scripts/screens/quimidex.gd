extends Control
## Quimidex: educational encyclopedia for enemies, towers and reactions.

var tab := "enemies"
var grid: GridContainer
var tab_buttons := {}
var counter: Label
var detail: Control
var time := 0.0


func setup(_args: Dictionary) -> void:
	var bg := LabBackdrop.new()
	bg.dim = true
	bg.show_towers = false
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var back := UiTheme.button("Voltar", "back", 16, Color("#27506e"))
	back.position = Vector2(16, 16)
	back.size = Vector2(126, 42)
	add_child(back)
	back.pressed.connect(_go_menu)

	var title := UiTheme.label("QUIMIDEX", 30, Color("#eaf6ff"))
	title.position = Vector2(160, 14)
	title.size = Vector2(220, 40)
	add_child(title)

	tab_buttons["enemies"] = UiTheme.button("INIMIGOS", "", 16, Color("#1b618d"))
	tab_buttons["towers"] = UiTheme.button("TORRES", "", 16, Color("#1b618d"))
	tab_buttons["reactions"] = UiTheme.button("REAÇÕES", "", 16, Color("#1b618d"))
	var x := 420.0
	for key in ["enemies", "towers", "reactions"]:
		var b: Button = tab_buttons[key]
		b.position = Vector2(x, 16)
		b.size = Vector2(160, 40)
		add_child(b)
		b.pressed.connect(_set_tab.bind(key))
		x += 168.0

	counter = UiTheme.label("", 14, Color("#f4d36a"))
	counter.position = Vector2(996, 26)
	counter.size = Vector2(260, 24)
	counter.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	add_child(counter)

	var scroll := ScrollContainer.new()
	scroll.position = Vector2(20, 74)
	scroll.size = Vector2(1240, 594)
	add_child(scroll)
	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 10)
	margin.add_theme_constant_override("margin_right", 10)
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(margin)
	grid = GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)
	margin.add_child(grid)

	var hint := UiTheme.label("Itens ainda não encontrados aparecem como silhueta. Jogue e experimente no Laboratório para completar o Quimidex.", 12, Color(0.7, 0.83, 0.92, 0.8))
	hint.position = Vector2(20, 678)
	hint.size = Vector2(1240, 22)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(hint)

	_set_tab("enemies")


func _process(delta: float) -> void:
	time += delta


func _go_menu() -> void:
	Snd.play_sfx("click")
	get_parent().go("menu")


func _set_tab(key: String) -> void:
	tab = key
	Snd.play_sfx("click")
	for k in tab_buttons.keys():
		var b: Button = tab_buttons[k]
		var sel: bool = k == key
		b.add_theme_stylebox_override("normal", UiTheme.box(Color("#2f9e5f") if sel else Color("#1b618d"), 10, 2, Color("#b8f0cc") if sel else Color("#3d7ea8")))
		b.add_theme_stylebox_override("hover", UiTheme.box(Color("#37b06c") if sel else Color("#2377a8"), 10, 2, Color.WHITE))
	_rebuild_grid()


func _rebuild_grid() -> void:
	for c in grid.get_children():
		c.queue_free()
	var ids: Array = []
	var unlocked := 0
	if tab == "enemies":
		ids = DB.ENEMIES.keys()
		for id in ids:
			if id in Store.data.seen_enemies:
				unlocked += 1
	elif tab == "towers":
		ids = DB.TOWER_ORDER
		for id in ids:
			if id in Store.data.seen_towers:
				unlocked += 1
	else:
		ids = DB.CREATED.keys()
		for id in ids:
			if Store.has_recipe(id):
				unlocked += 1
	counter.text = "Descobertos: " + str(unlocked) + " / " + str(ids.size())
	for id in ids:
		var card := CodexCard.new()
		card.codex = self
		card.kind = tab
		card.entry_id = str(id)
		card.unlocked = (id in Store.data.seen_enemies) if tab == "enemies" else ((id in Store.data.seen_towers) if tab == "towers" else Store.has_recipe(str(id)))
		card.custom_minimum_size = Vector2(294, 186)
		grid.add_child(card)


func show_detail(kind: String, entry_id: String) -> void:
	Snd.play_sfx("click")
	if detail != null and is_instance_valid(detail):
		detail.queue_free()
	detail = Control.new()
	detail.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	detail.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(detail)
	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.04, 0.07, 0.72)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	dim.gui_input.connect(_on_dim_input)
	detail.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	detail.add_child(center)
	var panel := UiTheme.panel(Color(0.04, 0.12, 0.18, 0.99), 18, 2, Color("#5f93b8"))
	panel.custom_minimum_size = Vector2(780, 0)
	center.add_child(panel)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 18)
	panel.add_child(row)

	var art := DetailArt.new()
	art.kind = kind
	art.entry_id = entry_id
	art.custom_minimum_size = Vector2(250, 280)
	art.size = Vector2(250, 280)
	row.add_child(art)

	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 7)
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(col)

	var name_l := UiTheme.label(_entry_name(kind, entry_id), 27, Color("#eaf6ff"))
	name_l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	col.add_child(name_l)
	var formula := UiTheme.label(_entry_formula(kind, entry_id), 14, Color("#9fc0d8"))
	col.add_child(formula)
	col.add_child(_badge_row(kind, entry_id))

	if kind == "enemies":
		col.add_child(_section("POR QUE É PERIGOSO", str(DB.ENEMIES[entry_id].why)))
		col.add_child(_section("COMO SE NEUTRALIZA", str(DB.ENEMIES[entry_id].how)))
		col.add_child(_section("CURIOSIDADE", str(DB.ENEMIES[entry_id].curious)))
		col.add_child(_weakness_row(entry_id))
	elif kind == "towers":
		var d: Dictionary = DB.TOWERS[entry_id]
		col.add_child(_section("POR QUE ISSO PROTEGE", str(d.why)))
		col.add_child(_section("CURIOSIDADE", str(d.curious)))
		col.add_child(_section("COMO ATACA", str(d.desc) + " Preço: " + str(int(d.price)) + " CP."))
		var ua := ""
		var ub := ""
		for up in d.paths.A:
			ua += (", " if ua != "" else "") + str(up.name)
		for up in d.paths.B:
			ub += (", " if ub != "" else "") + str(up.name)
		col.add_child(_section("CAMINHO A", ua))
		col.add_child(_section("CAMINHO B", ub))
	else:
		var it: Dictionary = DB.CREATED[entry_id]
		col.add_child(_section("O QUE FAZ", str(it.desc)))
		col.add_child(_section("CIÊNCIA POR TRÁS", str(it.science)))
		col.add_child(_section("RECARGA", str(int(it.cooldown)) + " segundos. Equipe na Mochila do Laboratório."))
		var pr := ""
		for h in it.protects:
			pr += (", " if pr != "" else "") + DB.hazard_label(str(h))
		col.add_child(_section("NEUTRALIZA", pr))

	var close := UiTheme.button("Fechar", "check", 15, Color("#27506e"))
	close.custom_minimum_size = Vector2(0, 38)
	col.add_child(close)
	close.pressed.connect(_close_detail)


func _entry_name(kind: String, id: String) -> String:
	if kind == "enemies":
		return str(DB.ENEMIES[id].name)
	if kind == "towers":
		return str(DB.TOWERS[id].name)
	return str(DB.CREATED[id].name)


func _entry_formula(kind: String, id: String) -> String:
	if kind == "enemies":
		return str(DB.ENEMIES[id].formula)
	if kind == "towers":
		return str(DB.TOWERS[id].formula)
	return "Habilidade de Laboratório · " + DB.CREATED[id].name


func _badge_row(kind: String, id: String) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	if kind == "enemies":
		var layer: Dictionary = DB.enemy_layer(id, 0)
		var hz: Dictionary = DB.HAZARDS.get(str(layer.hazard), {"name": "Perigo", "color": "#ffffff", "icon": "gas"})
		row.add_child(_chip(str(hz.name), Color(hz.color), str(hz.icon)))
		if "boss" in DB.ENEMIES[id].props:
			row.add_child(_chip("CHEFE", Color("#ff8a6a"), "star"))
		row.add_child(_chip(str(DB.ENEMIES[id].layers.size()) + " camada(s)", Color("#9fc0d8"), "flask"))
	elif kind == "towers":
		var d: Dictionary = DB.TOWERS[id]
		for h in d.protects:
			var hz2: Dictionary = DB.HAZARDS.get(str(h), {"name": str(h), "color": "#ffffff", "icon": "gas"})
			row.add_child(_chip(str(hz2.name), Color(hz2.color), str(hz2.icon)))
	else:
		var it: Dictionary = DB.CREATED[id]
		row.add_child(_chip("Recarga " + str(int(it.cooldown)) + "s", Color("#9b6bff"), str(it.icon)))
	return row


func _chip(text: String, col: Color, icon: String) -> Control:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UiTheme.box(Color(col.r * 0.2, col.g * 0.2, col.b * 0.2, 0.85), 8, 1, Color(col.r, col.g, col.b, 0.7)))
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 5)
	p.add_child(h)
	var ic := UIcon.new()
	ic.kind = icon
	ic.tint = col
	ic.custom_minimum_size = Vector2(16, 16)
	h.add_child(ic)
	var l := UiTheme.label(text, 11, Color(col.r, col.g, col.b).lightened(0.55))
	h.add_child(l)
	return p


func _section(title: String, body: String) -> Control:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 1)
	var t := UiTheme.label(title, 10, Color("#8fe6ff"))
	v.add_child(t)
	var b := UiTheme.label(body, 13, Color("#cfe9f7"))
	b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	b.custom_minimum_size = Vector2(470, 0)
	v.add_child(b)
	return v


func _weakness_row(enemy_id: String) -> Control:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 4)
	var t := UiTheme.label("FRAQUEZAS", 10, Color("#8fe6a8"))
	v.add_child(t)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	v.add_child(row)
	var weak: Array = DB.tower_weakness_icons(enemy_id, 0)
	for w in weak:
		var p := PanelContainer.new()
		p.add_theme_stylebox_override("panel", UiTheme.box(Color(0.07, 0.16, 0.22, 0.95), 8, 1, Color(w.color)))
		var h := HBoxContainer.new()
		h.add_theme_constant_override("separation", 6)
		p.add_child(h)
		var mini := MiniTower.new()
		mini.tower_id = str(w.id)
		mini.custom_minimum_size = Vector2(34, 34)
		h.add_child(mini)
		var l := UiTheme.label(str(w.name), 11, Color("#eaf6ff"))
		h.add_child(l)
		row.add_child(p)
	return v


func _close_detail() -> void:
	Snd.play_sfx("click")
	if detail != null and is_instance_valid(detail):
		detail.queue_free()


func _on_dim_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_close_detail()


class CodexCard extends Button:
	var codex = null
	var kind := "enemies"
	var entry_id := ""
	var unlocked := false
	var t := 0.0

	func _ready() -> void:
		focus_mode = Control.FOCUS_NONE
		flat = true
		for st in ["normal", "hover", "pressed", "focus"]:
			add_theme_stylebox_override(st, StyleBoxEmpty.new())
		mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
		mouse_entered.connect(queue_redraw)
		mouse_exited.connect(queue_redraw)
		pressed.connect(func(): codex.show_detail(kind, entry_id))
		set_process(true)

	func _process(delta: float) -> void:
		t += delta
		if unlocked:
			queue_redraw()

	func _draw() -> void:
		var bg := Color(0.05, 0.13, 0.2, 0.96)
		var border := Color("#3d6b8e")
		if unlocked:
			if kind == "enemies":
				border = Color(DB.HAZARDS.get(str(DB.enemy_layer(entry_id, 0).hazard), {"color": "#3d6b8e"}).color)
			elif kind == "towers":
				border = Color(DB.CATEGORIES[DB.TOWERS[entry_id].cat].color)
			else:
				border = Color("#9b6bff")
		if is_hovered():
			bg = Color(0.08, 0.19, 0.27, 0.99)
		draw_style_box(UiTheme.box(bg, 12, 2, border if unlocked else Color(0.25, 0.32, 0.38)), Rect2(Vector2.ZERO, size))
		var font := ThemeDB.fallback_font
		if not unlocked:
			Art._ellipse(self, Vector2(size.x * 0.5, 72), Vector2(46, 40), Color(0.12, 0.17, 0.22, 0.9))
			Art.draw_icon(self, "question", Vector2(size.x * 0.5, 68), 44.0, Color(0.38, 0.47, 0.55))
			draw_string(font, Vector2(0, 146), "???", HORIZONTAL_ALIGNMENT_CENTER, size.x, 18, Color(0.45, 0.55, 0.63))
			draw_string(font, Vector2(0, 170), "Ainda não descoberto", HORIZONTAL_ALIGNMENT_CENTER, size.x, 11, Color(0.4, 0.5, 0.58))
			return
		if kind == "enemies":
			var def: Dictionary = DB.ENEMIES[entry_id]
			var layer: Dictionary = DB.enemy_layer(entry_id, 0)
			Art.draw_enemy(self, def, layer, Vector2(size.x * 0.5, 66), 30.0 * float(def.scale), t, "walk", true)
			draw_string(font, Vector2(10, 138), str(def.name), HORIZONTAL_ALIGNMENT_LEFT, size.x - 20, 16, Color("#eaf6ff"))
			draw_string(font, Vector2(10, 156), str(def.formula) + "  ·  " + DB.hazard_label(str(layer.hazard)), HORIZONTAL_ALIGNMENT_LEFT, size.x - 20, 11, Color("#9fc0d8"))
			draw_string(font, Vector2(10, 174), str(def.layers.size()) + " camada(s)", HORIZONTAL_ALIGNMENT_LEFT, size.x - 20, 10, Color(0.6, 0.75, 0.85, 0.8))
		elif kind == "towers":
			var d: Dictionary = DB.TOWERS[entry_id]
			Art.draw_tower(self, entry_id, Vector2(size.x * 0.5, 68), 30.0, t, 0.0, false)
			draw_string(font, Vector2(10, 138), str(d.name), HORIZONTAL_ALIGNMENT_LEFT, size.x - 20, 16, Color("#eaf6ff"))
			draw_string(font, Vector2(10, 156), str(d.formula) + "  ·  " + str(int(d.price)) + " CP", HORIZONTAL_ALIGNMENT_LEFT, size.x - 20, 11, Color("#9fc0d8"))
			draw_string(font, Vector2(10, 174), "Protege: " + DB.tower_protects_text(entry_id), HORIZONTAL_ALIGNMENT_LEFT, size.x - 20, 10, Color(0.6, 0.75, 0.85, 0.8))
		else:
			var it: Dictionary = DB.CREATED[entry_id]
			Art.draw_icon(self, str(it.icon), Vector2(size.x * 0.5, 66), 64.0, Color(it.color))
			draw_string(font, Vector2(10, 138), str(it.name), HORIZONTAL_ALIGNMENT_LEFT, size.x - 20, 16, Color("#eaf6ff"))
			draw_string(font, Vector2(10, 156), "Habilidade · recarga " + str(int(it.cooldown)) + "s", HORIZONTAL_ALIGNMENT_LEFT, size.x - 20, 11, Color("#9fc0d8"))
			draw_string(font, Vector2(10, 174), "Clique para ver a ficha", HORIZONTAL_ALIGNMENT_LEFT, size.x - 20, 10, Color(0.6, 0.75, 0.85, 0.8))


class DetailArt extends Control:
	var kind := "enemies"
	var entry_id := ""
	var t := 0.0

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		set_process(true)

	func _process(delta: float) -> void:
		t += delta
		queue_redraw()

	func _draw() -> void:
		var c := Vector2(size.x * 0.5, size.y * 0.5)
		if kind == "enemies":
			var hz: Dictionary = DB.HAZARDS.get(str(DB.enemy_layer(entry_id, 0).hazard), {"color": "#ffffff"})
			var col := Color(hz.color)
			draw_circle(c, 105, Color(col.r, col.g, col.b, 0.08 + 0.03 * sin(t * 2.0)))
			draw_arc(c, 110, 0, TAU, 60, Color(col.r, col.g, col.b, 0.35), 2.0)
			Art.draw_enemy(self, DB.ENEMIES[entry_id], DB.enemy_layer(entry_id, 0), c, 62.0 * float(DB.ENEMIES[entry_id].scale), t, "walk", true)
		elif kind == "towers":
			draw_circle(c + Vector2(0, 22), 95, Color(0.2, 0.4, 0.55, 0.2))
			Art.draw_tower(self, entry_id, c + Vector2(0, 18), 58.0, t, 0.0, false)
		else:
			var it: Dictionary = DB.CREATED[entry_id]
			var col := Color(it.color)
			draw_circle(c, 90, Color(col.r, col.g, col.b, 0.1))
			draw_arc(c, 94, 0, TAU, 50, Color(col.r, col.g, col.b, 0.4), 2.0)
			Art.draw_icon(self, str(it.icon), c, 110.0, col)


class MiniTower extends Control:
	var tower_id := ""

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func _draw() -> void:
		if tower_id == "":
			return
		Art.draw_tower(self, tower_id, size * 0.5, 16.0, 0.0, 0.0, false)
