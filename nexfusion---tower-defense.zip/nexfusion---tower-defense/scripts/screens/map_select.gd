extends Control
## Map selection and difficulty modal.

var selected_map := 0
var selected_diff := "normal"
var modal: Control
var diff_buttons := {}
var diff_desc: Label
var modal_title: Label
var card_panels: Array = []


func setup(_args: Dictionary) -> void:
	var bg := LabBackdrop.new()
	bg.dim = true
	bg.show_towers = false
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 32)
	margin.add_theme_constant_override("margin_top", 18)
	margin.add_theme_constant_override("margin_bottom", 20)
	add_child(margin)

	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 14)
	margin.add_child(col)

	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 16)
	col.add_child(header)

	var back := UiTheme.button("Voltar", "back", 17, Color("#27506e"))
	back.custom_minimum_size = Vector2(132, 42)
	header.add_child(back)
	back.pressed.connect(_go_menu)

	var title := UiTheme.label("SELECIONE O CENÁRIO", 30, Color("#eaf6ff"))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)

	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(132, 42)
	header.add_child(spacer)

	var cards := HBoxContainer.new()
	cards.add_theme_constant_override("separation", 18)
	cards.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(cards)

	for i in DB.MAPS.size():
		cards.add_child(_make_card(i))

	var foot := UiTheme.label("Clique em um cenário para escolher a dificuldade. Seu recorde é salvo automaticamente.", 14, Color(0.78, 0.88, 0.96, 0.75))
	foot.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(foot)

	_build_modal()


func _make_card(map_id: int) -> Control:
	var m: Dictionary = DB.MAPS[map_id]
	var card := PanelContainer.new()
	card.add_theme_stylebox_override("panel", UiTheme.box(Color(0.05, 0.12, 0.19, 0.94), 16, 2, Color("#3d6b8e")))
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	card.mouse_filter = Control.MOUSE_FILTER_STOP
	card.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	var inner := VBoxContainer.new()
	inner.add_theme_constant_override("separation", 8)
	card.add_child(inner)
	inner.mouse_filter = Control.MOUSE_FILTER_IGNORE

	var thumb := MapThumb.new()
	thumb.map_id = map_id
	thumb.custom_minimum_size = Vector2(0, 158)
	thumb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	inner.add_child(thumb)

	var name_l := UiTheme.label(m.name, 21, Color("#eaf6ff"))
	name_l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	name_l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	inner.add_child(name_l)

	var stars := StarRow.new()
	stars.count = int(m.stars)
	stars.custom_minimum_size = Vector2(0, 22)
	stars.mouse_filter = Control.MOUSE_FILTER_IGNORE
	inner.add_child(stars)

	var desc := UiTheme.label(m.desc, 14, Color("#a9c7dd"))
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.custom_minimum_size = Vector2(0, 62)
	desc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	inner.add_child(desc)

	var record := UiTheme.label("Recorde: " + ("Round " + str(Store.best(map_id)) if Store.best(map_id) > 0 else "sem recorde"), 14, Color("#f4c744"))
	record.mouse_filter = Control.MOUSE_FILTER_IGNORE
	inner.add_child(record)

	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	inner.add_child(spacer)

	var go_l := UiTheme.label("JOGAR  ▸", 17, Color("#8fe6ff"))
	go_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	go_l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	inner.add_child(go_l)

	card.gui_input.connect(_on_card_input.bind(map_id))
	card.mouse_entered.connect(_hover_card.bind(card, true))
	card.mouse_exited.connect(_hover_card.bind(card, false))
	card_panels.append(card)
	return card


func _build_modal() -> void:
	modal = Control.new()
	modal.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	modal.mouse_filter = Control.MOUSE_FILTER_STOP
	modal.visible = false
	add_child(modal)

	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.04, 0.08, 0.66)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	modal.add_child(dim)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	modal.add_child(center)

	var panel := UiTheme.panel(Color("#0e2537"), 18, 2, Color("#5f93b8"))
	panel.custom_minimum_size = Vector2(560, 0)
	center.add_child(panel)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 12)
	panel.add_child(box)

	modal_title = UiTheme.label("DIFICULDADE", 26, Color("#eaf6ff"))
	modal_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(modal_title)

	diff_desc = UiTheme.label("", 15, Color("#b8d6ea"))
	diff_desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	diff_desc.custom_minimum_size = Vector2(0, 42)
	diff_desc.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(diff_desc)

	var list := VBoxContainer.new()
	list.add_theme_constant_override("separation", 8)
	box.add_child(list)
	for key in ["facil", "normal", "dificil"]:
		var d: Dictionary = DB.DIFFICULTIES[key]
		var b := UiTheme.button(d.label + "   ·   " + d.desc, "", 17, Color("#1b618d"))
		b.custom_minimum_size = Vector2(0, 54)
		list.add_child(b)
		diff_buttons[key] = b
		b.pressed.connect(_select_diff.bind(key))

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)

	var cancel := UiTheme.button("Voltar", "back", 17, Color("#3a4e5e"))
	cancel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(cancel)
	cancel.pressed.connect(_close_modal)

	var play := UiTheme.button("Jogar", "play", 19, Color("#2f9e5f"))
	play.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(play)
	play.pressed.connect(_start)


func _go_menu() -> void:
	Snd.play_sfx("click")
	get_parent().go("menu")


func _on_card_input(event: InputEvent, map_id: int) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_open_map(map_id)


func _hover_card(card: PanelContainer, on: bool) -> void:
	if on:
		card.add_theme_stylebox_override("panel", UiTheme.box(Color(0.08, 0.18, 0.27, 0.96), 16, 2, Color("#8fd8ff")))
	else:
		card.add_theme_stylebox_override("panel", UiTheme.box(Color(0.05, 0.12, 0.19, 0.94), 16, 2, Color("#3d6b8e")))


func _close_modal() -> void:
	Snd.play_sfx("click")
	modal.visible = false


func _open_map(map_id: int) -> void:
	selected_map = map_id
	selected_diff = "normal"
	modal_title.text = DB.MAPS[map_id].name.to_upper() + " · DIFICULDADE"
	modal.visible = true
	_refresh_diff()
	Snd.play_sfx("click")


func _select_diff(key: String) -> void:
	Snd.play_sfx("click")
	selected_diff = key
	_refresh_diff()


func _refresh_diff() -> void:
	for key in diff_buttons.keys():
		var b: Button = diff_buttons[key]
		var sel: bool = key == selected_diff
		b.add_theme_stylebox_override("normal", UiTheme.box(Color("#2f9e5f") if sel else Color("#1b618d"), 10, 2, Color("#b8f0cc") if sel else Color("#3d7ea8")))
		b.add_theme_stylebox_override("hover", UiTheme.box(Color("#37b06c") if sel else Color("#2377a8"), 10, 2, Color.WHITE))
	diff_desc.text = DB.DIFFICULTIES[selected_diff].desc + "\nO recorde é por cenário e vale para todas as dificuldades."


func _start() -> void:
	Snd.play_sfx("click")
	get_parent().go("battle", {"map_id": selected_map, "diff": selected_diff})


class MapThumb extends Control:
	var map_id := 0
	var t := 0.0

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		set_process(true)

	func _process(delta: float) -> void:
		t += delta
		queue_redraw()

	func _draw() -> void:
		var m: Dictionary = DB.MAPS[map_id]
		var sc := minf(size.x / 960.0, size.y / 720.0)
		var origin := (size - Vector2(960, 720) * sc) * 0.5
		var bg_col := Color("#dbeaf2") if map_id == 0 else (Color("#16211d") if map_id == 1 else Color("#2b2220"))
		draw_rect(Rect2(Vector2.ZERO, size), bg_col)
		for gy in 9:
			for gx in 12:
				var c := bg_col.lightened(0.05) if (gx + gy) % 2 == 0 else bg_col.darkened(0.04)
				draw_rect(Rect2(Vector2(gx * 80, gy * 80) * sc + origin, Vector2(78, 78) * sc), c)
		for r in m.blocked:
			draw_rect(Rect2(r.position * sc + origin, r.size * sc), Color(0.15, 0.2, 0.26, 0.55))
		for circle in m.blocked_circles:
			draw_circle(Vector2(circle[0], circle[1]) * sc + origin, float(circle[2]) * sc, Color(0.15, 0.2, 0.26, 0.55))
		for path in m.paths:
			var pts := PackedVector2Array()
			for p in path:
				pts.append(p * sc + origin)
			draw_polyline(pts, Color("#2b3542"), maxf(10.0, 30.0 * sc))
			draw_polyline(pts, Color("#7c8b99") if map_id == 0 else Color("#55605e") if map_id == 1 else Color("#6b5a4e"), maxf(6.0, 20.0 * sc))
			draw_polyline(pts, Color(1, 1, 1, 0.22), maxf(1.0, 3.0 * sc))
		var base_pos: Vector2 = m.base * sc + origin
		Art.draw_icon(self, "base", base_pos, 26.0 * sc + 6.0, Color("#7dfa9a"))
		draw_circle(base_pos, 13.0 * sc + 3.0, Color(0.4, 1.0, 0.6, 0.15 + 0.1 * sin(t * 3.0)))
		var entry: Vector2 = m.paths[0][0] * sc + origin
		draw_circle(entry + Vector2(8, 0), 5.0, Color("#ffcf5e"))
		if map_id == 1:
			var rp := Vector2(480, 356) * sc + origin
			draw_arc(rp, 48.0 * sc, 0, TAU, 32, Color(0.55, 1.0, 0.4, 0.5 + 0.2 * sin(t * 2.0)), 3.0)
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.05, 0.1, 0.15, 0.18))
		draw_rect(Rect2(Vector2.ZERO, size), Color("#3d6b8e"), false, 1.0)


class StarRow extends Control:
	var count := 1

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func _draw() -> void:
		var s := 18.0
		var start := Vector2(2, size.y * 0.5)
		for i in 3:
			var col := Color("#f4c744") if i < count else Color(0.4, 0.48, 0.56, 0.6)
			Art.draw_icon(self, "star", start + Vector2(i * (s + 6), 0), s, col)
