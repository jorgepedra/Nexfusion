extends Control
## The match. Towers, enemies and projectiles are real nodes (.tscn); damage is
## resolved by the controller, while movement and range detection run natively.

const ARENA_W := 960.0
const ARENA_H := 720.0
const SHOP_X := 966.0
const TOWER_SCENE := preload("res://scenes/entities/tower.tscn")
const ENEMY_SCENE := preload("res://scenes/entities/enemy.tscn")
const PROJECTILE_SCENE := preload("res://scenes/entities/projectile.tscn")
const MAP_SCENE := preload("res://scenes/maps/map_base.tscn")
const ARENA_SHADER := preload("res://shaders/arena_fx.gdshader")
const TUTORIAL_SCRIPT := preload("res://scripts/ui/tutorial_overlay.gd")

var map_id := 0
var diff := "normal"
var map: Dictionary
var max_rounds := 40

var cp := 650
var integrity := 100.0
var round_num := 0
var speed := 1
var paused := false
var running := false
var over := false
var auto_start := false

var towers: Array = []
var enemies: Array = []
var projectiles: Array = []
var puddles: Array = []
var buffs: Array = []
var spawn_queue: Array = []
var wave_time := 0.0
var auto_timer := 0.0

var build_id := ""
var is_dragging := false
var selected: TowerUnit = null
var build_valid := false
var mouse_pos := Vector2(480, 360)
var aim_index := -1
var ability_cd: Array = [0.0, 0.0, 0.0, 0.0]
var backpack: Array = []
var ghost: TowerUnit = null
var tutorial = null

var board: Control
var map_node: MapBase
var arena_fx: ColorRect
var arena_mat: ShaderMaterial
var effects_layer: Node2D
var float_layer: Control
var shop_grid: GridContainer
var shop_tiles: Array = []
var ability_buttons: Array = []
var ability_bar: HBoxContainer
var lbl_integrity: Label
var lbl_cp: Label
var lbl_round: Label
var hud_integrity: PanelContainer
var hud_integrity_pos := Vector2.ZERO
var integrity_flash := 0.0
var cp_flash := 0.0
var boss_panel: PanelContainer
var boss_label: Label
var boss_pb: ProgressBar
var play_btn: Button
var play_icon: UIcon
var play_speed_label: Label
var auto_btn: Button
var tip_label: Label
var tip_timer := 0.0
var pause_panel: PanelContainer
var tower_panel: PanelContainer
var tower_box: VBoxContainer
var panel_cards: Array = []
var panel_target_btn: Button
var panel_sell: Button
var panel_kills: Label
var panel_name: Label
var end_overlay: Control
var shop_hint: Label
var tip_panel: Panel
var tip_rt: RichTextLabel
var tip_key := ""
var unlocked_count := 0

var counts := {"radiacao": 0, "acido": 0, "gas": 0, "outros": 0}
var leak_stats := {}
var last_tip := {}
var last_ineff := {}
var game_time := 0.0


func setup(args: Dictionary) -> void:
	map_id = int(args.get("map_id", 0))
	diff = str(args.get("diff", "normal"))
	map = DB.MAPS[map_id]
	max_rounds = int(DB.DIFFICULTIES[diff].rounds)
	cp = int(DB.DIFFICULTIES[diff].cp)
	speed = int(Store.opt("speed", 1))
	if speed < 1 or speed > 3:
		speed = 1
	backpack = Store.backpack()
	_build_ui()
	_tip("Compre torres e clique no mapa para posicioná-las. Pressione ▶ para iniciar o Round 1.", 8.0)
	_refresh_hud()
	if bool(args.get("tutorial", false)) or not bool(Store.data.get("tutorial_seen", false)):
		_start_tutorial()

# --- interface --------------------------------------------------------------

func _build_ui() -> void:
	board = Control.new()
	board.position = Vector2.ZERO
	board.size = Vector2(ARENA_W, ARENA_H)
	board.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(board)

	map_node = MAP_SCENE.instantiate()
	board.add_child(map_node)
	map_node.setup(map_id)

	effects_layer = Node2D.new()
	effects_layer.z_index = 20
	board.add_child(effects_layer)

	float_layer = Control.new()
	float_layer.size = Vector2(ARENA_W, ARENA_H)
	float_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	float_layer.z_index = 30
	board.add_child(float_layer)

	arena_mat = ShaderMaterial.new()
	arena_mat.shader = ARENA_SHADER
	arena_fx = ColorRect.new()
	arena_fx.size = Vector2(ARENA_W, ARENA_H)
	arena_fx.mouse_filter = Control.MOUSE_FILTER_IGNORE
	arena_fx.material = arena_mat
	arena_fx.z_index = 40
	board.add_child(arena_fx)

	var shop := UiTheme.panel(Color(0.04, 0.11, 0.17, 0.98), 14, 2, Color("#4f7fa6"))
	shop.position = Vector2(SHOP_X, 8)
	shop.size = Vector2(306, 704)
	shop.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(shop)
	var shop_box := VBoxContainer.new()
	shop_box.add_theme_constant_override("separation", 8)
	shop.add_child(shop_box)

	var title_row := HBoxContainer.new()
	shop_box.add_child(title_row)
	var title := UiTheme.label("TORRES", 22, Color("#eaf6ff"))
	title_row.add_child(title)
	var spr := Control.new()
	spr.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_row.add_child(spr)
	shop_hint = UiTheme.label("", 11, Color(0.65, 0.8, 0.9, 0.8))
	shop_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	shop_box.add_child(shop_hint)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	shop_box.add_child(scroll)
	shop_grid = GridContainer.new()
	shop_grid.columns = 2
	shop_grid.add_theme_constant_override("h_separation", 6)
	shop_grid.add_theme_constant_override("v_separation", 6)
	shop_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(shop_grid)

	_build_top_hud()
	_build_abilities()

	play_btn = Button.new()
	play_btn.focus_mode = Control.FOCUS_NONE
	play_btn.position = Vector2(1180, 596)
	play_btn.size = Vector2(80, 80)
	play_btn.add_theme_stylebox_override("normal", UiTheme.box(Color("#2f9e5f"), 40, 3, Color("#8ff0a8")))
	play_btn.add_theme_stylebox_override("hover", UiTheme.box(Color("#38b972"), 40, 3, Color("#d6ffe2")))
	play_btn.add_theme_stylebox_override("pressed", UiTheme.box(Color("#226f44"), 40, 3, Color("#8ff0a8")))
	add_child(play_btn)
	play_btn.pressed.connect(_play_or_speed)
	play_icon = UIcon.new()
	play_icon.kind = "play"
	play_icon.tint = Color.WHITE
	play_icon.position = Vector2(23, 22)
	play_icon.size = Vector2(36, 36)
	play_icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	play_btn.add_child(play_icon)
	play_speed_label = UiTheme.label("", 13, Color("#eaffee"))
	play_speed_label.position = Vector2(0, 60)
	play_speed_label.size = Vector2(80, 16)
	play_speed_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	play_speed_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	play_btn.add_child(play_speed_label)

	auto_btn = Button.new()
	auto_btn.text = "AUTO"
	auto_btn.focus_mode = Control.FOCUS_NONE
	auto_btn.position = Vector2(1094, 646)
	auto_btn.size = Vector2(78, 34)
	auto_btn.add_theme_font_size_override("font_size", 12)
	add_child(auto_btn)
	auto_btn.pressed.connect(_toggle_auto)
	_refresh_auto_button()

	tip_label = UiTheme.label("", 14, Color("#ffe9a8"))
	tip_label.position = Vector2(292, 662)
	tip_label.size = Vector2(600, 40)
	tip_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tip_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tip_label.add_theme_color_override("font_outline_color", Color(0.02, 0.05, 0.08, 0.95))
	tip_label.add_theme_constant_override("outline_size", 6)
	tip_label.visible = false
	tip_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(tip_label)

	_build_tower_panel()
	_build_pause_panel()
	_rebuild_shop()
	_build_tooltip()


func _build_top_hud() -> void:
	hud_integrity = UiTheme.panel(Color(0.03, 0.09, 0.14, 0.86), 10, 2, Color(0.35, 0.55, 0.68, 0.8))
	hud_integrity.position = Vector2(14, 10)
	hud_integrity.size = Vector2(178, 44)
	add_child(hud_integrity)
	hud_integrity_pos = hud_integrity.position
	var ih := HBoxContainer.new()
	ih.add_theme_constant_override("separation", 8)
	hud_integrity.add_child(ih)
	var hi := UIcon.new()
	hi.kind = "heart"
	hi.tint = Color("#ff8a8a")
	hi.custom_minimum_size = Vector2(24, 24)
	ih.add_child(hi)
	lbl_integrity = UiTheme.label("100", 21, Color("#ffe3e3"))
	ih.add_child(lbl_integrity)

	var cp_panel := UiTheme.panel(Color(0.03, 0.09, 0.14, 0.86), 10, 2, Color(0.35, 0.55, 0.68, 0.8))
	cp_panel.position = Vector2(200, 10)
	cp_panel.size = Vector2(178, 44)
	add_child(cp_panel)
	var ch := HBoxContainer.new()
	ch.add_theme_constant_override("separation", 8)
	cp_panel.add_child(ch)
	var ci := UIcon.new()
	ci.kind = "coin"
	ci.tint = Color("#f4d36a")
	ci.custom_minimum_size = Vector2(24, 24)
	ch.add_child(ci)
	lbl_cp = UiTheme.label(str(cp), 21, Color("#fff4cf"))
	ch.add_child(lbl_cp)

	lbl_round = UiTheme.label("Round 0 / 40", 21, Color("#eaf6ff"))
	lbl_round.position = Vector2(380, 12)
	lbl_round.size = Vector2(200, 32)
	lbl_round.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl_round.add_theme_color_override("font_outline_color", Color(0.02, 0.05, 0.08, 0.95))
	lbl_round.add_theme_constant_override("outline_size", 7)
	add_child(lbl_round)

	boss_panel = UiTheme.panel(Color(0.06, 0.04, 0.05, 0.9), 8, 1, Color(0.75, 0.42, 0.35, 0.9))
	boss_panel.position = Vector2(330, 46)
	boss_panel.size = Vector2(300, 44)
	boss_panel.visible = false
	add_child(boss_panel)
	var boss_box := VBoxContainer.new()
	boss_box.add_theme_constant_override("separation", 2)
	boss_panel.add_child(boss_box)
	boss_label = UiTheme.label("", 11, Color("#ffd2c2"))
	boss_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	boss_box.add_child(boss_label)
	boss_pb = ProgressBar.new()
	boss_pb.custom_minimum_size = Vector2(0, 10)
	boss_pb.show_percentage = false
	boss_pb.max_value = 100.0
	boss_pb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	boss_box.add_child(boss_pb)
	var boss_fill := StyleBoxFlat.new()
	boss_fill.bg_color = Color("#ff7a5a")
	boss_fill.corner_radius_top_left = 4
	boss_fill.corner_radius_top_right = 4
	boss_fill.corner_radius_bottom_left = 4
	boss_fill.corner_radius_bottom_right = 4
	boss_pb.add_theme_stylebox_override("fill", boss_fill)
	var boss_bg := StyleBoxFlat.new()
	boss_bg.bg_color = Color(0.09, 0.11, 0.14, 0.95)
	boss_bg.corner_radius_top_left = 4
	boss_bg.corner_radius_top_right = 4
	boss_bg.corner_radius_bottom_left = 4
	boss_bg.corner_radius_bottom_right = 4
	boss_pb.add_theme_stylebox_override("background", boss_bg)

	var gear := UiTheme.icon_button("gear", 25, Color("#d6ecff"), Color(0.03, 0.09, 0.14, 0.8))
	gear.position = Vector2(856, 10)
	add_child(gear)
	gear.pressed.connect(_open_pause_menu)
	var pause_btn := UiTheme.icon_button("pause", 24, Color("#d6ecff"), Color(0.03, 0.09, 0.14, 0.8))
	pause_btn.position = Vector2(902, 10)
	add_child(pause_btn)
	pause_btn.pressed.connect(_toggle_pause)


func _build_abilities() -> void:
	var wrap := VBoxContainer.new()
	wrap.position = Vector2(14, 636)
	add_child(wrap)
	var lbl := UiTheme.label("ITENS  [1-4]", 10, Color(0.7, 0.82, 0.92, 0.8))
	wrap.add_child(lbl)
	ability_bar = HBoxContainer.new()
	ability_bar.add_theme_constant_override("separation", 7)
	wrap.add_child(ability_bar)
	for i in 4:
		var btn := AbilityButton.new()
		btn.hotkey = i + 1
		btn.empty = i >= backpack.size()
		if not btn.empty:
			btn.item_id = backpack[i]
			btn.cooldown_total = float(DB.CREATED[backpack[i]].cooldown)
		ability_bar.add_child(btn)
		ability_buttons.append(btn)
		btn.pressed.connect(_ability_pressed.bind(i))
		btn.refresh()


func _build_tower_panel() -> void:
	tower_panel = UiTheme.panel(Color(0.035, 0.1, 0.16, 0.98), 14, 2, Color("#5f93b8"))
	tower_panel.z_index = 60
	tower_panel.position = Vector2(12, 70)
	tower_panel.size = Vector2(300, 548)
	tower_panel.visible = false
	tower_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(tower_panel)
	tower_box = VBoxContainer.new()
	tower_box.add_theme_constant_override("separation", 6)
	tower_panel.add_child(tower_box)


func _build_pause_panel() -> void:
	pause_panel = UiTheme.panel(Color(0.04, 0.11, 0.17, 0.98), 14, 2, Color("#5f93b8"))
	pause_panel.position = Vector2(714, 66)
	pause_panel.size = Vector2(232, 236)
	pause_panel.visible = false
	add_child(pause_panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 7)
	pause_panel.add_child(box)
	var t := UiTheme.label("PAUSADO", 20, Color("#eaf6ff"))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(t)
	var cont := UiTheme.button("Continuar", "play", 15, Color("#2f9e5f"))
	box.add_child(cont)
	cont.pressed.connect(_toggle_pause)
	var opt := UiTheme.button("Opções", "gear", 15, Color("#27506e"))
	box.add_child(opt)
	opt.pressed.connect(func() -> void: get_parent().go("options"))
	var restart := UiTheme.button("Reiniciar", "auto", 15, Color("#27506e"))
	box.add_child(restart)
	restart.pressed.connect(_restart)
	var back := UiTheme.button("Voltar ao menu", "back", 15, Color("#3a4e5e"))
	box.add_child(back)
	back.pressed.connect(func() -> void: get_parent().go("menu"))


func _start_tutorial() -> void:
	if tutorial != null:
		return
	tutorial = TUTORIAL_SCRIPT.new()
	tutorial.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(tutorial)
	tutorial.setup(self)


func _rebuild_shop() -> void:
	for c in shop_grid.get_children():
		c.queue_free()
	shop_tiles.clear()
	unlocked_count = 0
	for id in DB.TOWER_ORDER:
		var d: Dictionary = DB.TOWERS[id]
		if int(d.unlock) > maxi(1, round_num):
			continue
		unlocked_count += 1
		var tile := ShopTile.new()
		tile.tower_id = id
		tile.hotkey = d.hotkey
		tile.battle = self
		tile.affordable = cp >= int(d.price)
		tile.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		shop_grid.add_child(tile)
		shop_tiles.append(tile)
		tile.refresh()
	var next_id := ""
	for id in DB.TOWER_ORDER:
		if int(DB.TOWERS[id].unlock) > maxi(1, round_num):
			next_id = id
			break
	if next_id != "":
		shop_hint.text = "Próxima torre: " + DB.TOWERS[next_id].name + " (Round " + str(int(DB.TOWERS[next_id].unlock)) + ")"
	else:
		shop_hint.text = "Todas as torres liberadas."


func _refresh_shop_states() -> void:
	for tile in shop_tiles:
		var d: Dictionary = DB.TOWERS[tile.tower_id]
		tile.affordable = cp >= int(d.price)
		tile.selected = build_id == tile.tower_id
		tile.refresh()


func _rebuild_tower_panel() -> void:
	if selected == null or not is_instance_valid(selected):
		tower_panel.visible = false
		return
	for c in tower_box.get_children():
		c.queue_free()
	panel_cards.clear()
	var t := selected
	var d: Dictionary = DB.TOWERS[t.id]
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 8)
	tower_box.add_child(head)
	var preview := TextureRect.new()
	preview.texture = Sprites.get_tower(t.id)
	preview.custom_minimum_size = Vector2(64, 64)
	preview.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	preview.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	preview.mouse_filter = Control.MOUSE_FILTER_IGNORE
	head.add_child(preview)
	var hb := VBoxContainer.new()
	hb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(hb)
	panel_name = UiTheme.label(d.name + " (" + d.formula + ")", 18, Color("#eaf6ff"))
	panel_name.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hb.add_child(panel_name)
	var prot := UiTheme.label("Protege: " + DB.tower_protects_text(t.id), 11, Color("#9fc0d8"))
	prot.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hb.add_child(prot)
	panel_kills = UiTheme.label("Neutralizados: " + str(t.kills), 12, Color("#8fe6a8"))
	hb.add_child(panel_kills)

	panel_target_btn = UiTheme.button("Alvo: " + DB.PRIORITY_LABELS[t.target_priority] + "  [TAB]", "", 14, Color("#27506e"))
	panel_target_btn.custom_minimum_size = Vector2(0, 34)
	panel_target_btn.add_theme_font_size_override("font_size", 14)
	tower_box.add_child(panel_target_btn)
	panel_target_btn.pressed.connect(_cycle_priority)

	for path in ["A", "B"]:
		var lbl := UiTheme.label("CAMINHO " + path, 12, Color("#9fc0d8"))
		tower_box.add_child(lbl)
		var card := UpgradeCard.new()
		card.tower_id = t.id
		card.path = path
		tower_box.add_child(card)
		panel_cards.append(card)
		card.pressed.connect(_buy_upgrade.bind(path))

	panel_sell = UiTheme.button("", "sell", 14, Color("#8e3333"))
	panel_sell.custom_minimum_size = Vector2(0, 36)
	tower_box.add_child(panel_sell)
	panel_sell.pressed.connect(_sell_selected)

	_refresh_tower_panel_states()
	tower_panel.position = Vector2(12, 70)
	tower_panel.size = Vector2(306, 556)
	tower_panel.visible = true


func _refresh_tower_panel_states() -> void:
	if selected == null or not is_instance_valid(selected):
		return
	var t := selected
	panel_kills.text = "Neutralizados: " + str(t.kills)
	panel_target_btn.text = "Alvo: " + DB.PRIORITY_LABELS[t.target_priority] + "  [TAB]"
	panel_sell.text = "Vender  +" + str(t.sell_value()) + " CP  [Del]"
	for card in panel_cards:
		var path: String = card.path
		var lvl := t.level_a if path == "A" else t.level_b
		var is_max := lvl >= 4
		var locked := not is_max and not DB.can_upgrade(t.level_a, t.level_b, path)
		card.current_level = lvl
		card.level_index = mini(lvl, 3)
		card.is_max = is_max
		card.locked = locked
		card.locked_reason = DB.upgrade_locked_reason(t.level_a, t.level_b, path)
		if not is_max:
			var up: Dictionary = DB.TOWERS[t.id].paths[path][lvl]
			card.title = up.name
			card.desc = up.desc
			card.cost = int(up.cost)
			card.affordable = cp >= card.cost
		else:
			card.title = DB.TOWERS[t.id].paths[path][3].name
			card.desc = ""
			card.cost = 0
			card.affordable = true
		card.refresh()


# --- loop -------------------------------------------------------------------

func _process(delta: float) -> void:
	game_time += delta
	if tip_timer > 0.0:
		tip_timer -= delta
		tip_label.modulate.a = clampf(tip_timer * 2.0, 0.0, 1.0)
		if tip_timer <= 0.0:
			tip_label.visible = false
	if cp_flash > 0.0:
		cp_flash -= delta
		lbl_cp.scale = Vector2.ONE * (1.0 + cp_flash * 0.12)
	if integrity_flash > 0.0:
		integrity_flash -= delta
		hud_integrity.position = hud_integrity_pos + Vector2(sin(game_time * 70.0) * 4.0, 0)
	else:
		hud_integrity.position = hud_integrity_pos
	if paused or over:
		_refresh_hud()
		return
	_step(delta * speed)
	_refresh_hud()


func _step(dt: float) -> void:
	if auto_timer > 0.0 and not running:
		auto_timer -= dt
		if auto_timer <= 0.0:
			_start_round()
	if running:
		wave_time += dt
		while not spawn_queue.is_empty() and float(spawn_queue[0]["t"]) <= wave_time:
			var s: Dictionary = spawn_queue.pop_front()
			_spawn(str(s["id"]), int(s["path"]))
	_update_buffs(dt)
	_update_towers(dt)
	_update_enemies(dt)
	_update_projectiles(dt)
	_update_puddles(dt)
	for i in 4:
		if ability_cd[i] > 0.0:
			ability_cd[i] = maxf(0.0, ability_cd[i] - dt)
	if running and spawn_queue.is_empty() and _live_enemies() == 0 and not over:
		_end_round()


func _update_buffs(dt: float) -> void:
	var keep: Array = []
	for bf in buffs:
		bf.time -= dt
		if bf.time > 0.0:
			keep.append(bf)
	buffs = keep


func _update_towers(dt: float) -> void:
	var i := towers.size() - 1
	while i >= 0:
		var t = towers[i]
		if not is_instance_valid(t) or t.is_queued_for_deletion():
			towers.remove_at(i)
			i -= 1
			continue
		t.display_range = effective_range(t)
		t.set_range_radius(t.display_range)
		if "purify" in t.stats.flags:
			t.purify_cd -= dt
			if t.purify_cd <= 0.0:
				t.purify_cd = 10.0
				for e in t.enemies_in_range.duplicate():
					if _valid(e) and t.global_position.distance_to(e.pos) <= t.display_range:
						hit_enemy(e, float(t.stats.damage) * 1.4, t.id, t)
				_burst(t.global_position, 12, Color(0.6, 0.85, 0.5), "mist", t.display_range * 0.6)
		t.tick(dt)
		i -= 1


func _update_enemies(dt: float) -> void:
	var i := enemies.size() - 1
	while i >= 0:
		var e = enemies[i]
		if not is_instance_valid(e) or e.is_queued_for_deletion():
			enemies.remove_at(i)
			i -= 1
			continue
		if not e.alive:
			enemies.remove_at(i)
			e.queue_free()
			i -= 1
			continue
		var res: String = e.advance(dt)
		if res == "leak" and not e.is_dying:
			_leak(e)
			enemies.remove_at(i)
			e.queue_free()
			i -= 1
			continue
		if e.is_dying and not e.alive:
			enemies.remove_at(i)
			e.queue_free()
			i -= 1
			continue
		if not e.is_dying:
			e.effect_t += dt
			if e.effect_t >= 0.25:
				e.effect_t = 0.0
				_enemy_aura(e)
		i -= 1


func _update_projectiles(dt: float) -> void:
	var i := projectiles.size() - 1
	while i >= 0:
		var p = projectiles[i]
		if not is_instance_valid(p) or p.is_queued_for_deletion():
			projectiles.remove_at(i)
			i -= 1
			continue
		if p.tick(dt):
			var consumed: bool = _impact(p)
			if consumed:
				projectiles.remove_at(i)
				p.queue_free()
		i -= 1


func _update_puddles(dt: float) -> void:
	var i := puddles.size() - 1
	while i >= 0:
		var p: Dictionary = puddles[i]
		var node = p.get("node")
		if node == null or not is_instance_valid(node):
			puddles.remove_at(i)
			i -= 1
			continue
		p.life -= dt
		if p.life <= 0.0:
			puddles.remove_at(i)
			node.queue_free()
			i -= 1
			continue
		p.tick -= dt
		if p.tick <= 0.0 and String(p.tower_id) != "":
			p.tick = 0.5
			for e in enemies.duplicate():
				if _valid(e) and e.pos.distance_to(p.pos) <= float(p.radius):
					hit_enemy(e, float(p.damage), String(p.tower_id), p.tower)
		i -= 1


# --- combat -----------------------------------------------------------------

func _valid(e) -> bool:
	return e != null and is_instance_valid(e) and not e.is_queued_for_deletion() and e.alive and not e.is_dying


func compare_priority(a: EnemyUnit, b: EnemyUnit, pri: String) -> bool:
	match pri:
		"ultimo":
			return a.progress < b.progress
		"forte":
			return a.max_hp > b.max_hp
		"rapido":
			return a.speed > b.speed
		_:
			return a.progress > b.progress


func play_shoot(t: TowerUnit) -> void:
	Snd.play_sfx("shoot_" + t.id, randf_range(0.93, 1.07))


func fire_at(t: TowerUnit, e: EnemyUnit) -> void:
	if not _valid(e):
		return
	var def: Dictionary = DB.TOWERS[t.id]
	var p: ProjectileUnit = PROJECTILE_SCENE.instantiate()
	map_node.projectiles_container.add_child(p)
	p.battle = self
	p.configure(t.muzzle.global_position, e, t, t.id, str(def.proj), Color(def.proj_color))
	p.damage = float(t.stats.damage) * damage_mult(t)
	p.pierce = int(t.stats.pierce)
	p.splash = float(t.stats.splash)
	p.stun = float(t.stats.stun)
	p.slow_factor = float(t.stats.slow_factor)
	p.slow_time = float(t.stats.slow_time)
	p.kickback = 18.0 if "knockback" in t.stats.flags else 0.0
	projectiles.append(p)
	if "puddle" in t.stats.flags and t.puddle_cd <= 0.0:
		t.puddle_cd = 4.0
		_spawn_puddle(e.pos, maxf(48.0, float(t.stats.splash) * 0.85), Color(def.proj_color), t.id, t, float(t.stats.damage) * 0.32, 5.0)


func _impact(p: ProjectileUnit) -> bool:
	if not is_instance_valid(p):
		return true
	var tgt = p.target
	var hit_pos: Vector2 = p.global_position
	if _valid(tgt):
		hit_pos = tgt.pos
	if p.splash > 0.0:
		# The primary target always takes full damage; the others take 85%.
		if _valid(tgt):
			hit_enemy(tgt, p.damage, p.tower_id, p.tower, p.stun, p.slow_factor, p.slow_time, p.kickback)
		for e in enemies.duplicate():
			if e == tgt:
				continue
			if _valid(e) and e.pos.distance_to(hit_pos) <= p.splash:
				hit_enemy(e, p.damage * 0.85, p.tower_id, p.tower, p.stun, p.slow_factor, p.slow_time, p.kickback)
		_burst(hit_pos, 10, p.color, _effect_kind(p.kind), p.splash * 0.5)
		return true
	if _valid(tgt):
		hit_enemy(tgt, p.damage, p.tower_id, p.tower, p.stun, p.slow_factor, p.slow_time, p.kickback)
		_burst(tgt.pos, 5, p.color, _effect_kind(p.kind), 26.0)
		if p.pierce > 0:
			var next: EnemyUnit = _next_pierce_target(p, tgt)
			if next != null:
				p.pierced.append(tgt)
				p.pierce -= 1
				p.damage *= 0.9
				p.target = next
				p.life = maxf(p.life, 0.9)
				p.global_position = tgt.pos
				return false
		return true
	# Target died mid-flight: the shot still hits a nearby enemy at impact point.
	var near := _enemy_at(hit_pos, 30.0)
	if near != null:
		hit_enemy(near, p.damage, p.tower_id, p.tower, p.stun, p.slow_factor, p.slow_time, p.kickback)
		_burst(near.pos, 5, p.color, _effect_kind(p.kind), 26.0)
	return true


func _next_pierce_target(p: ProjectileUnit, current) -> EnemyUnit:
	var best: EnemyUnit = null
	var bd := 9999.0
	for e in enemies:
		if not _valid(e) or e == current:
			continue
		if e in p.pierced:
			continue
		var d: float = p.global_position.distance_to(e.pos)
		if d <= 200.0 and d < bd:
			best = e
			bd = d
	return best


func _effect_kind(proj: String) -> String:
	match proj:
		"foam":
			return "foam"
		"cloud":
			return "mist"
		"snow":
			return "spark"
		_:
			return "dust"


func hit_enemy(e: EnemyUnit, amount: float, tower_id: String, tower: TowerUnit = null, stun := 0.0, slow_factor := 1.0, slow_time := 0.0, kickback := 0.0, force := false) -> void:
	if not _valid(e):
		return
	if tower_id == "water" and "reativo_agua" in e.props:
		e.hp = minf(e.max_hp, e.hp + e.max_hp * 0.18)
		e.heal_flash = 0.6
		_float(e.pos + Vector2(0, -26), "ÁGUA PIORA!", Color("#ff8a6a"), 15)
		_tip_once(e.id, "Água reage com sódio metálico! Use ÓLEO MINERAL ou AREIA para isolar.")
		Snd.play_sfx("error")
		return
	var eff := 1.0
	if not force:
		var layer: Dictionary = DB.enemy_layer(e.id, e.layer_index)
		eff = DB.effectiveness(tower_id, e.id, layer)
		if eff <= 0.0:
			_show_ineffective(e)
			return
	var dmg := amount * eff * DB.resist(e.id)
	if tower != null and is_instance_valid(tower):
		if "boss" in e.props:
			dmg *= 1.0 + float(tower.stats.bonus_boss)
		if "emissor" in e.props:
			dmg *= 1.0 + float(tower.stats.bonus_emissor)
	if eff < 0.7:
		_show_ineffective(e)
	e.apply_slow(slow_factor, slow_time)
	if stun > 0.0:
		e.stun_time = maxf(e.stun_time, stun)
	if kickback > 0.0:
		e.progress = maxf(0.0, e.progress - kickback)
	var killed: bool = e.hit(dmg)
	if not killed:
		return
	if e.transition_layer():
		cp += e.reward
		cp_flash = 0.4
		_float(e.pos + Vector2(0, -24), "+" + str(e.reward), Color("#ffe66e"), 14)
		_burst(e.pos, 10, Color(DB.HAZARDS.get(e.hazard, {"color": "#ffffff"}).color), "foam", 34.0)
		Snd.play_sfx("pop_" + e.hazard)
		if Store.opt("tips", true):
			_tip("Camada neutralizada! O inimigo ficou menos perigoso.", 3.0)
	else:
		_neutralize(e, tower_id, tower)


func _neutralize(e: EnemyUnit, tower_id: String, tower: TowerUnit) -> void:
	if not _valid(e):
		return
	e.is_dying = true
	e.die_t = 0.0
	e.burst_death()
	cp += e.reward
	cp_flash = 0.4
	_float(e.pos + Vector2(0, -30), "+" + str(e.reward), Color("#ffe66e"), 16)
	_burst(e.pos, 16, Color(DB.HAZARDS.get(e.hazard, {"color": "#ffffff"}).color), _hazard_particle(e.hazard), 40.0)
	_burst(e.pos, 6, Color(0.55, 1.0, 0.65), "spark", 28.0)
	Snd.play_sfx("pop_" + e.hazard)
	Store.mark_enemy(e.id)
	if tower != null and is_instance_valid(tower):
		tower.kills += 1
		if selected == tower:
			_refresh_tower_panel_states()
	_count_hazard(e.hazard)
	if "instavel" in e.props and not (tower_id in e.weak):
		for t in towers:
			if is_instance_valid(t) and t.global_position.distance_to(e.pos) < 92.0 and not _is_shielded(t):
				t.set_disabled(2.0)
		_burst(e.pos, 18, Color("#ff9a4a"), "spark", 100.0)
		_tip("Explosivo instável! A neutralização errada paralisou torres próximas.", 4.0)
		Snd.play_sfx("pop_explosivo")
	if "incendiario" in e.props and not (tower_id in ["water", "sand"]):
		var nearest: TowerUnit = null
		var best := 9999.0
		for t in towers:
			if not is_instance_valid(t):
				continue
			var d: float = t.global_position.distance_to(e.pos)
			if d < best:
				best = d
				nearest = t
		if nearest != null and best < 130.0:
			nearest.set_disabled(1.5)
			_tip("Fósforo branco incendiou uma torre! Resfrie com ÁGUA ou abafe com AREIA.", 4.0)
	if e.is_boss():
		_float(e.pos + Vector2(0, -56), "CHEFE NEUTRALIZADO!", Color("#8ff0a8"), 22)
	if selected != null:
		_refresh_tower_panel_states()
	_refresh_shop_states()


func _count_hazard(hazard: String) -> void:
	match hazard:
		"radiacao":
			counts["radiacao"] = int(counts["radiacao"]) + 1
		"acido", "base":
			counts["acido"] = int(counts["acido"]) + 1
		"gas", "inflamavel", "explosivo", "oxidante":
			counts["gas"] = int(counts["gas"]) + 1
		_:
			counts["outros"] = int(counts["outros"]) + 1


func _hazard_particle(hazard: String) -> String:
	match hazard:
		"gas", "oxidante":
			return "mist"
		"acido", "base":
			return "foam"
		"radiacao", "explosivo", "inflamavel":
			return "spark"
		_:
			return "dust"


func _show_ineffective(e: EnemyUnit) -> void:
	if not _valid(e):
		return
	var now := Time.get_ticks_msec()
	if int(last_ineff.get(e.id, -99999)) < now - 1400:
		last_ineff[e.id] = now
		_float(e.pos + Vector2(0, -34), "INEFICAZ!", Color("#ff6b6b"), 17)
		_tip_once(e.id, str(DB.ENEMIES[e.id].hint))


func _tip_once(enemy_id: String, text: String) -> void:
	if not Store.opt("tips", true):
		return
	var now := Time.get_ticks_msec()
	if int(last_tip.get(enemy_id, -999999)) > now - 30000:
		return
	last_tip[enemy_id] = now
	_tip(text, 6.0)


func _tip(text: String, seconds := 4.0) -> void:
	if not Store.opt("tips", true):
		return
	tip_label.text = text
	tip_label.visible = true
	tip_label.modulate.a = 1.0
	tip_timer = seconds


func _enemy_aura(e: EnemyUnit) -> void:
	for t in towers:
		if not is_instance_valid(t):
			continue
		var d: float = e.pos.distance_to(t.global_position)
		if "emissor" in e.props and d < 132.0:
			if not _is_shielded(t):
				t.emitter_timer = 0.45
		if "corrosivo" in e.props and d < 66.0 and t.corrosion_cd <= 0.0:
			if not _is_shielded(t) and not ("anti_corrosive" in t.stats.flags):
				t.corrosion_cd = 4.0
				t.set_disabled(3.0)
				_burst(t.global_position + Vector2(0, -12), 6, Color(0.65, 1.0, 0.3), "foam", 18.0)


func _leak(e: EnemyUnit) -> void:
	integrity = maxf(0.0, integrity - float(e.leak))
	leak_stats[e.id] = int(leak_stats.get(e.id, 0)) + e.leak
	integrity_flash = 0.7
	_float(Vector2(map.base.x - 20, map.base.y - 40), "-" + str(e.leak), Color("#ff7a7a"), 24)
	_burst(Vector2(map.base), 14, Color("#ff6b6b"), "smoke", 50.0)
	Snd.play_sfx("leak")
	e.alive = false
	_tip("A base perdeu integridade! Neutralize antes que cheguem ao fim do caminho.", 4.0)
	if integrity <= 0.0:
		_defeat()


func _is_shielded(t: TowerUnit) -> bool:
	for other in towers:
		if other == t or not is_instance_valid(other):
			continue
		if "shield_aura" in other.stats.flags and other.global_position.distance_to(t.global_position) < 112.0:
			return true
	return false


func effective_range(t: TowerUnit) -> float:
	var r: float = float(t.stats.range)
	if t.emitter_timer > 0.0 and not _is_shielded(t):
		r *= 0.8
	for bf in buffs:
		if bf.kind == "range" and (bf.protects == "" or bf.protects in t.stats.protects):
			r *= 1.0 + float(bf.value)
	return r


func damage_mult(t: TowerUnit) -> float:
	var m := 1.0
	for bf in buffs:
		if bf.kind == "damage" and (bf.protects == "" or bf.protects in t.stats.protects):
			m += float(bf.value)
	return m


func rate_mult(t: TowerUnit) -> float:
	var m := 1.0
	for bf in buffs:
		if bf.kind == "rate":
			m += float(bf.value)
	return m


func _live_enemies() -> int:
	var n := 0
	for e in enemies:
		if _valid(e):
			n += 1
	return n


func _spawn(id: String, path_idx: int) -> void:
	var path: Path2D = map_node.path_at(path_idx)
	if path == null:
		return
	var e: EnemyUnit = ENEMY_SCENE.instantiate()
	path.add_child(e)
	e.battle = self
	var hp_mult := (1.0 + 0.16 * float(round_num - 1)) * float(DB.DIFFICULTIES[diff].hp)
	var speed_mult := (1.0 + 0.006 * float(round_num)) * float(DB.DIFFICULTIES[diff].speed)
	e.setup(id, hp_mult, speed_mult)
	e.tree_exiting.connect(_on_enemy_exiting.bind(e))
	enemies.append(e)
	Store.mark_enemy(id)
	if e.is_boss():
		Snd.play_sfx("boss")
		_float(Vector2(480, 150), "CHEFE: " + str(DB.ENEMIES[id].name).to_upper(), Color("#ff9a6a"), 24)


func _on_enemy_exiting(e) -> void:
	for t in towers:
		if is_instance_valid(t):
			t.forget_enemy(e)


func _start_round() -> void:
	if running or over or round_num >= max_rounds:
		return
	if paused:
		_toggle_pause()
	var before := unlocked_count
	round_num += 1
	spawn_queue = DB.build_wave(map_id, round_num, diff)
	spawn_queue.sort_custom(_sort_time)
	wave_time = 0.0
	running = true
	auto_timer = 0.0
	_rebuild_shop()
	if unlocked_count > before:
		_tip("Novas torres disponíveis na loja!", 5.0)
		Snd.play_sfx("discover")
	if tutorial != null:
		tutorial.notify("round")


func _sort_time(a: Dictionary, b: Dictionary) -> bool:
	return float(a["t"]) < float(b["t"])


func _end_round() -> void:
	running = false
	var bonus := 100 + round_num * 5
	cp += bonus
	cp_flash = 0.6
	Store.record_round(map_id, round_num)
	_float(Vector2(480, 330), "ROUND " + str(round_num) + " CONCLUÍDO  +" + str(bonus) + " CP", Color("#8ff0a8"), 26)
	Snd.play_sfx("upgrade")
	_tip("Round " + str(round_num) + " concluído! Bônus de " + str(bonus) + " CP.", 4.0)
	_refresh_shop_states()
	if round_num >= max_rounds:
		_victory()
	elif auto_start:
		auto_timer = 2.2


func _victory() -> void:
	if over:
		return
	over = true
	running = false
	Store.record_round(map_id, round_num)
	Snd.play_sfx("win")
	var stars := 3
	if integrity < 70.0:
		stars = 2
	if integrity < 35.0:
		stars = 1
	_show_end(true, stars)


func _defeat() -> void:
	if over:
		return
	over = true
	running = false
	Store.record_round(map_id, round_num)
	Snd.play_sfx("lose")
	_show_end(false, 0)


func _show_end(win: bool, stars: int) -> void:
	end_overlay = Control.new()
	end_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	end_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(end_overlay)
	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.04, 0.06, 0.72)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	end_overlay.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	end_overlay.add_child(center)
	var panel := UiTheme.panel(Color(0.04, 0.12, 0.18, 0.98), 18, 2, Color("#5f93b8"))
	panel.custom_minimum_size = Vector2(640, 0)
	center.add_child(panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 12)
	panel.add_child(box)

	var t := UiTheme.label("BASE PROTEGIDA!" if win else "BASE CONTAMINADA", 36 if win else 32, Color("#8ff0a8") if win else Color("#ff8a6a"))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(t)

	if win:
		var star_row := HBoxContainer.new()
		star_row.alignment = BoxContainer.ALIGNMENT_CENTER
		star_row.add_theme_constant_override("separation", 10)
		box.add_child(star_row)
		for i in 3:
			var ic := UIcon.new()
			ic.kind = "star"
			ic.tint = Color("#f4c744") if i < stars else Color(0.35, 0.42, 0.5, 0.8)
			ic.custom_minimum_size = Vector2(40, 40)
			star_row.add_child(ic)
		var summary := UiTheme.label("Você neutralizou " + str(counts.radiacao) + " ameaças radioativas, " + str(counts.acido) + " ácidos e " + str(counts.gas) + " gases tóxicos.", 16, Color("#cfe9f7"))
		summary.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		summary.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		box.add_child(summary)
		var integrity_l := UiTheme.label("Integridade final da base: " + str(int(integrity)) + " / 100", 15, Color("#9fc0d8"))
		integrity_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		box.add_child(integrity_l)
	else:
		var worst := ""
		var worst_dmg := 0
		for k in leak_stats.keys():
			if int(leak_stats[k]) > worst_dmg:
				worst_dmg = int(leak_stats[k])
				worst = str(k)
		var info := "Você caiu no Round " + str(round_num) + " de " + str(max_rounds) + "."
		if worst != "":
			info += "\nA maior ameaça foi: " + DB.ENEMIES[worst].name + " (" + DB.ENEMIES[worst].formula + ")."
			info += "\n" + str(DB.ENEMIES[worst].hint)
		var ill := UiTheme.label(info, 16, Color("#ffd2c2"))
		ill.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		ill.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		box.add_child(ill)
		var dica := UiTheme.label("Dica: combine proteções diferentes. Cada perigo tem um neutralizador próprio.", 14, Color("#9fc0d8"))
		dica.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		dica.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		box.add_child(dica)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	box.add_child(row)
	if win and map_id < DB.MAPS.size() - 1:
		var nextb := UiTheme.button("Próximo mapa", "play", 16, Color("#2f9e5f"))
		nextb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(nextb)
		nextb.pressed.connect(_next_map)
	var retry := UiTheme.button("Jogar de novo" if win else "Tentar de novo", "auto", 16, Color("#1b618d"))
	retry.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(retry)
	retry.pressed.connect(_restart)
	var menu := UiTheme.button("Menu", "back", 16, Color("#3a4e5e"))
	menu.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(menu)
	menu.pressed.connect(func() -> void: get_parent().go("menu"))


func _next_map() -> void:
	get_parent().go("battle", {"map_id": mini(map_id + 1, DB.MAPS.size() - 1), "diff": diff})


func _restart() -> void:
	get_parent().go("battle", {"map_id": map_id, "diff": diff})


func _play_or_speed() -> void:
	Snd.play_sfx("click")
	if over:
		return
	if paused:
		_toggle_pause()
		return
	if not running:
		_start_round()
	else:
		speed = speed % 3 + 1
	_refresh_play_button()


func _toggle_auto() -> void:
	auto_start = not auto_start
	Snd.play_sfx("click")
	_refresh_auto_button()


func _refresh_auto_button() -> void:
	var on := auto_start
	var b := UiTheme.box(Color("#2f9e5f") if on else Color("#1c3547"), 8, 2, Color("#8ff0a8") if on else Color("#3d6b8e"))
	auto_btn.add_theme_stylebox_override("normal", b)
	auto_btn.add_theme_stylebox_override("hover", b)
	auto_btn.add_theme_stylebox_override("pressed", b)
	auto_btn.add_theme_color_override("font_color", Color("#eaffee") if on else Color("#8fa6b6"))


func _refresh_play_button() -> void:
	if running:
		play_icon.kind = "fast"
		play_speed_label.text = str(speed) + "x"
	else:
		play_icon.kind = "play"
		play_speed_label.text = "PLAY"


func _toggle_pause() -> void:
	paused = not paused
	pause_panel.visible = paused
	Snd.play_sfx("click")


func _open_pause_menu() -> void:
	paused = true
	pause_panel.visible = true
	Snd.play_sfx("click")


# --- building ---------------------------------------------------------------

func begin_placement(id: String, from_drag := false) -> void:
	if over:
		return
	var price := int(DB.TOWERS[id].price)
	if cp < price:
		_tip("CP insuficiente para " + DB.TOWERS[id].name + ". Neutralize inimigos para ganhar mais.", 4.0)
		Snd.play_sfx("error")
		return
	if build_id != id:
		_free_ghost()
	build_id = id
	is_dragging = from_drag
	aim_index = -1
	_deselect()
	mouse_pos = board.get_local_mouse_position()
	_make_ghost()
	_update_ghost(mouse_pos)
	Snd.play_sfx("click")
	_refresh_shop_states()
	shop_hint.text = "Arraste para a arena ou clique em um espaço livre. ESC / botão direito cancela."


func _make_ghost() -> void:
	_free_ghost()
	ghost = TOWER_SCENE.instantiate()
	board.add_child(ghost)
	ghost.battle = self
	ghost.z_index = 50
	ghost.setup(build_id, mouse_pos, true)


func _free_ghost() -> void:
	if ghost != null and is_instance_valid(ghost):
		ghost.queue_free()
	ghost = null


func _update_ghost(p: Vector2) -> void:
	mouse_pos = p
	if ghost == null or not is_instance_valid(ghost):
		return
	ghost.position = p
	build_valid = _is_valid_pos(p)
	ghost.ghost_invalid = not build_valid
	ghost.display_range = float(DB.TOWERS[build_id].range)


func _try_place(p: Vector2, shift: bool) -> bool:
	if build_id == "":
		return false
	mouse_pos = p
	build_valid = _is_valid_pos(p)
	if not build_valid:
		_tip("Posição inválida: " + _invalid_reason(p), 3.5)
		Snd.play_sfx("error")
		return false
	var id := build_id
	var price := int(DB.TOWERS[id].price)
	if cp < price:
		cancel_build()
		_tip("CP insuficiente para construir.", 3.0)
		Snd.play_sfx("error")
		return false
	cp -= price
	cp_flash = 0.35
	var t: TowerUnit = TOWER_SCENE.instantiate()
	map_node.towers_container.add_child(t)
	t.battle = self
	t.setup(id, p)
	towers.append(t)
	Store.mark_tower(id)
	_burst(p, 12, Color("#cfd8e6"), "dust", 40.0)
	_float(p + Vector2(0, -30), "-" + str(price), Color("#ffcf8a"), 15)
	Snd.play_sfx("place")
	if tutorial != null:
		tutorial.notify("place")
	if not shift or cp < price:
		cancel_build()
	else:
		_make_ghost()
		_update_ghost(p)
	_refresh_shop_states()
	return true


func _invalid_reason(p: Vector2) -> String:
	if p.x < 28.0 or p.x > 932.0 or p.y < 70.0 or p.y > 696.0:
		return "fora da área construível."
	for path in map.paths:
		var pts: Array = path
		for i in range(pts.size() - 1):
			var closest: Vector2 = Geometry2D.get_closest_point_to_segment(p, pts[i], pts[i + 1])
			if closest.distance_to(p) < 44.0:
				return "muito perto do caminho!"
	if p.distance_to(Vector2(map.base)) < 72.0:
		return "perto demais da Base."
	for r in map.blocked:
		if Rect2(r.position - Vector2(6, 6), r.size + Vector2(12, 12)).has_point(p):
			return "espaço bloqueado por equipamento!"
	for circle in map.blocked_circles:
		if p.distance_to(Vector2(circle[0], circle[1])) < float(circle[2]) + 26.0:
			return "espaço bloqueado pelo reator!"
	if _tower_overlap(p):
		return "já existe uma torre neste ponto."
	return ""


func _is_valid_pos(p: Vector2) -> bool:
	return _invalid_reason(p) == ""


func _tower_overlap(p: Vector2) -> bool:
	var space := get_world_2d().direct_space_state
	var q := PhysicsPointQueryParameters2D.new()
	q.position = p
	q.collision_mask = 2
	q.collide_with_areas = true
	q.collide_with_bodies = false
	var hits := space.intersect_point(q, 1)
	return not hits.is_empty()


func cancel_build() -> void:
	build_id = ""
	is_dragging = false
	_free_ghost()
	_refresh_shop_states()


func cancel_modes() -> void:
	cancel_build()
	aim_index = -1
	_deselect()


func _deselect() -> void:
	if selected != null and is_instance_valid(selected):
		selected.is_selected = false
	selected = null
	if tower_panel != null:
		tower_panel.visible = false


func select_tower(t: TowerUnit) -> void:
	if over or build_id != "" or aim_index >= 0:
		return
	if selected == t:
		return
	_deselect()
	selected = t
	t.is_selected = true
	_rebuild_tower_panel()
	Snd.play_sfx("click")


func _buy_upgrade(path: String) -> void:
	if selected == null or not is_instance_valid(selected):
		return
	var t := selected
	if not DB.can_upgrade(t.level_a, t.level_b, path):
		_tip(DB.upgrade_locked_reason(t.level_a, t.level_b, path), 3.0)
		Snd.play_sfx("error")
		return
	var cost := t.next_cost(path)
	if cp < cost:
		_tip("CP insuficiente para este upgrade (" + str(cost) + " CP).", 3.0)
		Snd.play_sfx("error")
		return
	cp -= cost
	t.spent += cost
	if path == "A":
		t.level_a += 1
	else:
		t.level_b += 1
	t.refresh()
	Snd.play_sfx("upgrade")
	_burst(t.global_position, 12, Color("#8ff0a8"), "spark", 36.0)
	_float(t.global_position + Vector2(0, -32), "-" + str(cost), Color("#ffcf8a"), 14)
	_refresh_shop_states()
	_refresh_tower_panel_states()


func _sell_selected() -> void:
	if selected == null or not is_instance_valid(selected):
		return
	var t := selected
	var val := t.sell_value()
	cp += val
	_burst(t.global_position, 10, Color("#cfd8e6"), "dust", 34.0)
	_float(t.global_position + Vector2(0, -28), "+" + str(val), Color("#ffe66e"), 15)
	towers.erase(t)
	t.queue_free()
	_deselect()
	Snd.play_sfx("sell")
	_refresh_shop_states()


func _cycle_priority() -> void:
	if selected == null or not is_instance_valid(selected):
		return
	var i := DB.PRIORITIES.find(selected.target_priority)
	selected.target_priority = DB.PRIORITIES[(i + 1) % DB.PRIORITIES.size()]
	Snd.play_sfx("click")
	_refresh_tower_panel_states()


# --- laboratory items -------------------------------------------------------

func _ability_pressed(i: int) -> void:
	if over:
		return
	if i >= backpack.size():
		_tip("Crie itens no LABORATÓRIO e equipe-os na Mochila (até 4 itens).", 4.0)
		Snd.play_sfx("error")
		return
	if ability_cd[i] > 0.0:
		_tip("Item recarregando: " + str(int(ceil(ability_cd[i]))) + " s.", 2.0)
		Snd.play_sfx("error")
		return
	var item: Dictionary = DB.CREATED[backpack[i]]
	if item.effect == "buff":
		_apply_buff_item(item)
		ability_cd[i] = float(item.cooldown)
		Snd.play_sfx("ability")
		_tip(item.name + " ativado: " + item.desc, 4.0)
	elif item.effect == "area":
		aim_index = i
		cancel_build()
		_deselect()
		_tip("Clique no mapa para usar " + item.name + ".", 4.0)
		Snd.play_sfx("click")


func _apply_buff_item(item: Dictionary) -> void:
	if item.has("buff_damage"):
		buffs.append({"kind": "damage", "protects": item.get("buff_protect", ""), "value": item.buff_damage, "time": item.buff_time})
	if item.has("buff_range"):
		buffs.append({"kind": "range", "protects": item.get("buff_protect", ""), "value": item.buff_range, "time": item.buff_time})
	if item.has("buff_rate"):
		buffs.append({"kind": "rate", "protects": "", "value": item.buff_rate, "time": item.buff_time})
	_burst(Vector2(480, 360), 20, Color("#9be6ff"), "spark", 200.0)


func _cast_ability(index: int, pos: Vector2) -> void:
	var item: Dictionary = DB.CREATED[backpack[index]]
	var radius: float = float(item.get("radius", 100))
	for e in enemies.duplicate():
		if not _valid(e):
			continue
		if e.pos.distance_to(pos) > radius:
			continue
		var layer: Dictionary = DB.enemy_layer(e.id, e.layer_index)
		if layer.hazard in item.protects:
			hit_enemy(e, float(item.damage), "ability", null, 0.0, 1.0, 0.0, 0.0, true)
			if item.has("slow_factor"):
				e.apply_slow(float(item.slow_factor), float(item.slow_time))
	_burst(pos, 26, Color(item.get("color", "#9be6ff")), "foam", radius * 0.8)
	_spawn_puddle(pos, radius * 0.7, Color(item.get("color", "#9be6ff")), "", null, 0.0, 3.0)
	ability_cd[index] = float(item.cooldown)
	aim_index = -1
	Snd.play_sfx("ability")
	_float(pos + Vector2(0, -30), String(item.name).to_upper(), Color("#9be6ff"), 18)


func _spawn_puddle(pos: Vector2, radius: float, col: Color, tower_id: String, tower, damage: float, life: float) -> void:
	var sprite := Sprite2D.new()
	sprite.texture = Sprites.get_effect("puddle")
	sprite.position = pos
	sprite.modulate = Color(col.r, col.g, col.b, 0.8)
	var sc := radius / 56.0
	sprite.scale = Vector2(sc, sc)
	sprite.z_index = 5
	effects_layer.add_child(sprite)
	var tw := sprite.create_tween()
	tw.tween_property(sprite, "modulate:a", 0.0, life)
	tw.tween_callback(sprite.queue_free)
	puddles.append({
		"node": sprite, "pos": pos, "radius": radius, "color": col,
		"tower_id": tower_id, "tower": tower, "damage": damage,
		"life": life, "tick": 0.0,
	})


# --- effects ----------------------------------------------------------------

func _burst(pos: Vector2, n: int, color: Color, kind: String, spread: float) -> void:
	var p := CPUParticles2D.new()
	p.position = pos
	p.amount = maxi(4, n)
	p.one_shot = true
	p.explosiveness = 0.9
	p.lifetime = 0.65
	p.direction = Vector2(1, 0)
	p.spread = 180.0
	p.initial_velocity_min = 18.0
	p.initial_velocity_max = maxf(40.0, spread)
	p.gravity = Vector2(0, 26)
	p.scale_amount_min = 0.25
	p.scale_amount_max = 0.9
	p.damping_min = 10.0
	p.damping_max = 40.0
	p.color = color
	match kind:
		"mist":
			p.scale_amount_min = 0.8
			p.scale_amount_max = 2.2
			p.initial_velocity_max = maxf(30.0, spread * 0.5)
			p.color = Color(color.r, color.g, color.b, 0.4)
		"foam":
			p.scale_amount_min = 0.35
			p.scale_amount_max = 1.2
		"spark":
			p.gravity = Vector2(0, 80)
	p.texture = Sprites.get_effect("dot")
	p.emitting = true
	p.z_index = 22
	p.finished.connect(p.queue_free)
	effects_layer.add_child(p)


func _float(pos: Vector2, text: String, color: Color, fsize := 16) -> void:
	var l := UiTheme.label(text, fsize, color)
	l.position = pos - Vector2(90, 0)
	l.size = Vector2(180, fsize + 10)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_color_override("font_outline_color", Color(0.02, 0.04, 0.06, 0.92))
	l.add_theme_constant_override("outline_size", 6)
	float_layer.add_child(l)
	var tw := l.create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "position:y", l.position.y - 36.0, 1.1)
	tw.tween_property(l, "modulate:a", 0.0, 1.1)
	tw.chain().tween_callback(l.queue_free)


# --- hover info -------------------------------------------------------------

func _build_tooltip() -> void:
	tip_panel = Panel.new()
	tip_panel.add_theme_stylebox_override("panel", UiTheme.box(Color(0.025, 0.075, 0.11, 0.97), 10, 2, Color(0.42, 0.66, 0.82)))
	tip_panel.size = Vector2(334, 96)
	tip_panel.visible = false
	tip_panel.z_index = 300
	tip_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(tip_panel)
	tip_rt = RichTextLabel.new()
	tip_rt.bbcode_enabled = true
	tip_rt.fit_content = false
	tip_rt.scroll_active = false
	tip_rt.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tip_rt.position = Vector2(12, 8)
	tip_rt.size = Vector2(310, 72)
	tip_rt.add_theme_font_size_override("normal_font_size", 13)
	tip_rt.add_theme_font_size_override("bold_font_size", 13)
	tip_rt.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tip_panel.add_child(tip_rt)


func _ui_under_mouse() -> bool:
	var c := get_viewport().gui_get_hovered_control()
	if c == null or c == self or c == get_parent():
		return false
	return true


func _tile_at(screen_pos: Vector2) -> ShopTile:
	for tile in shop_tiles:
		if is_instance_valid(tile) and tile.get_global_rect().has_point(screen_pos):
			return tile
	return null


func _tower_at(p: Vector2) -> TowerUnit:
	var best: TowerUnit = null
	var bd := 9999.0
	for t in towers:
		if not is_instance_valid(t) or t.is_ghost:
			continue
		var d: float = t.global_position.distance_to(p)
		if d <= 30.0 and d < bd:
			best = t
			bd = d
	return best


func _enemy_at(p: Vector2, radius := 0.0) -> EnemyUnit:
	var best = null
	var bd := 9999.0
	for e in enemies:
		if not _valid(e):
			continue
		var r: float = radius if radius > 0.0 else (44.0 if e.is_boss() else 26.0 * float(DB.ENEMIES[e.id].scale))
		var d: float = e.global_position.distance_to(p)
		if d <= r and d < bd:
			best = e
			bd = d
	return best


func _tower_names(ids: Array) -> String:
	var parts: Array = []
	for id in ids:
		if DB.TOWERS.has(id):
			parts.append(str(DB.TOWERS[id].name) + " (" + str(DB.TOWERS[id].formula) + ")")
	return ", ".join(parts)


func _props_text(props: Array) -> String:
	var out: Array = []
	if "emissor" in props:
		out.append("Emissor: enfraquece o alcance das torres próximas.")
	if "corrosivo" in props:
		out.append("Corrosivo: desativa torres por 3 s ao passar perto.")
	if "instavel" in props:
		out.append("Instável: neutralizar com a torre errada explode e paralisa torres.")
	if "incendiario" in props:
		out.append("Incendiário: incendeia a torre mais próxima.")
	if "denso" in props:
		out.append("Denso: recebe 25% menos dano de qualquer torre.")
	if "reativo_agua" in props:
		out.append("Reativo à água: Água cura este inimigo.")
	if "gasoso" in props:
		out.append("Gasoso: só torres com proteção de gás causam dano.")
	return "\n".join(out)


func _update_hover(screen_pos: Vector2) -> void:
	if tutorial != null and tutorial.blocks(screen_pos):
		_hide_tip()
		return
	var tile := _tile_at(screen_pos)
	if tile != null:
		_show_tower_tip(tile.tower_id, null)
		return
	if _ui_under_mouse():
		_hide_tip()
		return
	if screen_pos.x < 0.0 or screen_pos.y < 0.0 or screen_pos.x >= ARENA_W or screen_pos.y >= ARENA_H:
		_hide_tip()
		return
	var local := board.get_global_transform().affine_inverse() * screen_pos
	var t := _tower_at(local)
	if t != null:
		_show_tower_tip(t.id, t)
		return
	var e := _enemy_at(local)
	if e != null:
		_show_enemy_tip(e)
		return
	_hide_tip()


func _show_tower_tip(id: String, t: TowerUnit) -> void:
	var key := "t:" + id + ":" + ((str(t.level_a) + str(t.level_b)) if t != null else "shop")
	if key == tip_key and tip_panel.visible:
		_reposition_tip()
		return
	tip_key = key
	var d: Dictionary = DB.TOWERS[id]
	var stats: Dictionary = t.stats if t != null else DB.tower_stats(id, 0, 0)
	var lines: Array = []
	lines.append("[color=#b6f24a][b]" + str(d.name) + "  (" + str(d.formula) + ")[/b][/color]")
	if t != null:
		lines.append("[color=#9fc0d8]Nível A" + str(t.level_a) + " · B" + str(t.level_b) + " · " + str(t.kills) + " neutralizados[/color]")
	lines.append("Dano [b]" + str(snappedf(float(stats.damage), 0.1)) + "[/b] · Alcance [b]" + str(int(round(float(stats.range)))) + "[/b] · Cadência [b]" + str(snappedf(float(stats.rate), 0.05)) + "/s[/b] · Alvos [b]" + str(int(stats.targets)) + "[/b]")
	lines.append("[color=#8ff0a8][b]Neutraliza:[/b] " + DB.tower_protects_text(id) + "[/color]")
	if int(stats.pierce) > 0:
		lines.append("[color=#9be6ff][b]Perfurante:[/b] atravessa " + str(int(stats.pierce)) + " inimigo(s) extra(s), com 90% de dano em cada.[/color]")
	lines.append("[color=#ffd27a]Outros perigos: só 10% de dano (INEFICAZ).[/color]")
	if t != null:
		lines.append("[color=#cfe2f0]Clique na torre para abrir upgrades (A/B), alvo e venda.[/color]")
	else:
		lines.append("[color=#cfe2f0]" + str(d.desc) + "\nPreço " + str(int(d.price)) + " CP · arraste para a arena ou clique e depois clique no espaço.[/color]")
	_show_tip("\n".join(lines))


func _show_enemy_tip(e: EnemyUnit) -> void:
	var key := "e:" + e.id + ":" + str(e.layer_index)
	if key == tip_key and tip_panel.visible:
		_reposition_tip()
		return
	tip_key = key
	var hz: Dictionary = DB.HAZARDS.get(e.hazard, {"name": e.hazard, "color": "#ffffff"})
	var lines: Array = []
	lines.append("[color=#ffb0a0][b]" + str(e.display_name) + "[/b][/color]")
	if e.layer_count > 1:
		lines.append("[color=#9fc0d8]Camada " + str(e.layer_index + 1) + " de " + str(e.layer_count) + " · " + str(DB.ENEMIES[e.id].name) + "[/color]")
	lines.append("Perigo: [color=" + str(hz.color) + "][b]" + str(hz.name) + "[/b][/color]")
	lines.append("Vida [b]" + str(int(ceil(e.hp))) + "/" + str(int(round(e.max_hp))) + "[/b] · Velocidade [b]" + str(int(round(e.speed))) + "[/b]")
	var names := _tower_names(e.weak)
	if names == "":
		lines.append("[color=#ffd27a][b]Sem fraqueza registrada.[/b][/color]")
	else:
		lines.append("[color=#8ff0a8][b]Fraquezas:[/b] " + names + "[/color]")
	lines.append("[color=#ffd27a]Outras torres: 10% de dano (INEFICAZ).[/color]")
	var props := _props_text(e.props)
	if props != "":
		lines.append("[color=#9fc0d8]" + props + "[/color]")
	_show_tip("\n".join(lines))


func _show_tip(bb: String) -> void:
	tip_rt.text = bb
	tip_rt.size = Vector2(310, 40)
	var h := tip_rt.get_content_height()
	if h < 24.0:
		h = 22.0 * float(bb.count("\n") + 1)
	h += 6.0
	tip_rt.size = Vector2(310, h)
	tip_panel.size = Vector2(334, h + 18)
	tip_panel.visible = true
	_reposition_tip()


func _reposition_tip() -> void:
	var pos := get_global_mouse_position() + Vector2(18, 18)
	pos.x = clampf(pos.x, 6.0, 1280.0 - tip_panel.size.x - 6.0)
	pos.y = clampf(pos.y, 6.0, 720.0 - tip_panel.size.y - 6.0)
	tip_panel.position = pos


func _hide_tip() -> void:
	tip_key = ""
	if tip_panel != null:
		tip_panel.visible = false


# --- HUD / input ------------------------------------------------------------

func _refresh_hud() -> void:
	if lbl_integrity == null:
		return
	lbl_integrity.text = str(int(ceil(integrity)))
	lbl_integrity.add_theme_color_override("font_color", Color("#ffe3e3") if integrity > 35.0 else Color("#ff9a9a"))
	lbl_cp.text = str(cp)
	lbl_round.text = "Round " + str(round_num) + " / " + str(max_rounds)
	_refresh_play_button()
	for i in ability_buttons.size():
		var btn: AbilityButton = ability_buttons[i]
		btn.cooldown_left = ability_cd[i]
		btn.aiming = aim_index == i
		btn.empty = i >= backpack.size()
		if not btn.empty:
			btn.item_id = backpack[i]
		btn.refresh()
	if tip_timer <= 0.0:
		tip_label.visible = false
	var danger := clampf((55.0 - integrity) / 55.0, 0.0, 1.0)
	if arena_mat != null:
		arena_mat.set_shader_parameter("danger", danger)
	if map_node != null:
		map_node.set_danger(danger)
	var boss = null
	for e in enemies:
		if _valid(e) and e.is_boss():
			boss = e
			break
	if boss == null:
		boss_panel.visible = false
	else:
		boss_panel.visible = true
		boss_label.text = str(DB.ENEMIES[boss.id].name).to_upper() + " · " + boss.display_name
		boss_pb.value = boss.hp_fraction() * 100.0


func _event_pos(event: InputEventMouse) -> Vector2:
	return board.get_global_transform().affine_inverse() * event.position


func _input(event: InputEvent) -> void:
	if over or map_node == null:
		return
	if event is InputEventMouseMotion:
		if build_id != "":
			_update_ghost(_event_pos(event))
			_hide_tip()
		elif aim_index >= 0:
			mouse_pos = _event_pos(event)
			_hide_tip()
		else:
			_update_hover(event.position)
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		var local := _event_pos(event)
		var inside := Rect2(Vector2.ZERO, Vector2(ARENA_W, ARENA_H)).has_point(local)
		if event.pressed:
			if tutorial != null and tutorial.blocks(event.position):
				return
			_hide_tip()
			if build_id != "" and not is_dragging and inside:
				_try_place(local, event.shift_pressed)
				get_viewport().set_input_as_handled()
			elif aim_index >= 0 and inside:
				_cast_ability(aim_index, local)
				get_viewport().set_input_as_handled()
			elif inside and not _ui_under_mouse():
				var picked := _tower_at(local)
				if picked != null:
					select_tower(picked)
					get_viewport().set_input_as_handled()
				else:
					_deselect()
		else:
			if build_id != "":
				if is_dragging:
					if inside:
						_try_place(local, false)
					else:
						is_dragging = false
						shop_hint.text = "Clique em um espaço livre da arena para construir."
				else:
					is_dragging = false


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		var k: int = event.keycode
		if over:
			return
		if k == KEY_SPACE:
			_play_or_speed()
			get_viewport().set_input_as_handled()
		elif k == KEY_ESCAPE:
			if build_id != "" or aim_index >= 0 or selected != null:
				cancel_modes()
			else:
				_toggle_pause()
		elif k == KEY_TAB:
			if selected != null:
				_cycle_priority()
		elif k == KEY_DELETE or k == KEY_BACKSPACE:
			_sell_selected()
		elif k >= KEY_1 and k <= KEY_4:
			_ability_pressed(k - KEY_1)
		else:
			for id in DB.TOWER_ORDER:
				if DB.TOWERS[id].hotkey == OS.get_keycode_string(k).to_upper() and int(DB.TOWERS[id].unlock) <= maxi(1, round_num):
					begin_placement(id, false)
					break
