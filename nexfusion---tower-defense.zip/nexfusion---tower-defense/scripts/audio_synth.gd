extends Node
## Sound effects and ambience synthesized in code (no audio files, no music).
## Every shot, neutralization, alarm and lab bubble is generated once and cached.

const RATE := 22050
const SFX_VOICES := 12
const SFX_LENGTH := 1.0

var voices: Array = []
var voice_index := 0
var cache: Dictionary = {}


func _ready() -> void:
	_make_buses()
	for i in SFX_VOICES:
		var p := AudioStreamPlayer.new()
		p.bus = "SFX"
		add_child(p)
		voices.append(p)
	apply_volumes()


func _make_buses() -> void:
	if AudioServer.get_bus_index("SFX") == -1:
		AudioServer.add_bus()
		var idx := AudioServer.bus_count - 1
		AudioServer.set_bus_name(idx, "SFX")
		AudioServer.set_bus_send(idx, "Master")


func apply_volumes() -> void:
	var s: float = float(Store.opt("sfx", 0.8))
	var idx := AudioServer.get_bus_index("SFX")
	if idx >= 0:
		AudioServer.set_bus_volume_db(idx, linear_to_db(clampf(s, 0.0001, 1.0)))


func play_sfx(name: String, pitch: float = 1.0) -> void:
	var key := "s_" + name
	if not cache.has(key):
		cache[key] = _make_sfx(name)
	var p: AudioStreamPlayer = voices[voice_index % voices.size()]
	voice_index += 1
	p.stream = cache[key]
	p.pitch_scale = pitch
	p.play()


func _make_sfx(name: String) -> AudioStreamWAV:
	var buf := PackedFloat32Array()
	buf.resize(int(SFX_LENGTH * RATE))
	match name:
		"click":
			_add_note(buf, 0.0, 0.055, 1500.0, 0.16, "sine")
			_add_note(buf, 0.0, 0.03, 2400.0, 0.06, "square")
		"place":
			_add_note(buf, 0.0, 0.09, 300.0, 0.2, "sine")
			_add_note(buf, 0.06, 0.12, 460.0, 0.16, "triangle")
			_add_noise(buf, 0.0, 0.06, 0.05, 0.0, 0.2)
		"sell":
			_add_note(buf, 0.0, 0.1, 700.0, 0.15, "square")
			_add_note(buf, 0.07, 0.13, 380.0, 0.13, "square")
		"upgrade":
			for i in 3:
				_add_note(buf, i * 0.075, 0.11, _midi([72, 76, 79][i]), 0.16, "triangle")
		"leak":
			_add_note(buf, 0.0, 0.25, 240.0, 0.22, "saw")
			_add_note(buf, 0.08, 0.25, 120.0, 0.2, "sine")
			_add_noise(buf, 0.0, 0.2, 0.1, 0.0, 0.3)
		"win":
			for i in 5:
				_add_note(buf, i * 0.12, 0.22, _midi([60, 64, 67, 72, 76][i]), 0.18, "triangle")
		"lose":
			for i in 4:
				_add_note(buf, i * 0.18, 0.3, _midi([60, 56, 53, 48][i]), 0.16, "sine")
		"bubble":
			_add_note(buf, 0.0, 0.07, 520.0, 0.1, "sine")
			_add_note(buf, 0.05, 0.06, 780.0, 0.08, "sine")
			_add_noise(buf, 0.0, 0.12, 0.03, 0.0, 0.3)
		"discover":
			for i in 4:
				_add_note(buf, i * 0.08, 0.16, _midi([67, 71, 74, 79][i]), 0.18, "triangle")
			_add_note(buf, 0.32, 0.2, _midi(83), 0.14, "sine")
		"error":
			_add_note(buf, 0.0, 0.14, 180.0, 0.16, "square")
			_add_note(buf, 0.11, 0.18, 150.0, 0.14, "square")
		"mix":
			_add_noise(buf, 0.0, 0.26, 0.08, 0.0, 0.18)
			_add_note(buf, 0.05, 0.2, 420.0, 0.09, "sine")
		"ability":
			_add_note(buf, 0.0, 0.2, 620.0, 0.15, "triangle")
			_add_note(buf, 0.09, 0.24, _midi(79), 0.13, "sine")
		"geiger":
			for i in 5:
				_add_noise(buf, i * 0.035 + randf() * 0.02, 0.02, 0.16, 0.0, 0.8)
		"boss":
			_add_note(buf, 0.0, 0.5, 70.0, 0.25, "saw")
			_add_note(buf, 0.0, 0.4, 105.0, 0.12, "square")
		"siren":
			# containment alarm: two rising sweeps with a metallic edge
			for k in 2:
				var base := 320.0 + k * 40.0
				var start := k * 0.45
				for i in 8:
					_add_note(buf, start + i * 0.055, 0.07, base * (1.0 + i * 0.09), 0.12, "saw")
					_add_note(buf, start + i * 0.055, 0.06, base * 1.5 * (1.0 + i * 0.07), 0.06, "square")
			_add_noise(buf, 0.0, 0.2, 0.07, 0.0, 0.4)
			_add_noise(buf, 0.45, 0.2, 0.07, 0.0, 0.4)
		"alarm":
			_add_note(buf, 0.0, 0.3, 520.0, 0.18, "square")
			_add_note(buf, 0.0, 0.3, 780.0, 0.1, "saw")
			_add_noise(buf, 0.0, 0.12, 0.09, 0.0, 0.5)
		"spawn":
			_add_note(buf, 0.0, 0.1, 900.0, 0.09, "sine")
			_add_note(buf, 0.04, 0.12, 1300.0, 0.06, "triangle")
		"confirm":
			_add_note(buf, 0.0, 0.1, _midi(76), 0.14, "triangle")
			_add_note(buf, 0.07, 0.14, _midi(83), 0.12, "sine")
		_:
			# tower shots and neutralization pops
			var base := 600.0
			var wave := "triangle"
			var noise := 0.04
			match name:
				"shoot_lead", "shoot_sand", "shoot_edta":
					base = 240.0
					wave = "square"
					noise = 0.03
				"shoot_bicarb", "shoot_vinegar", "shoot_thio", "shoot_oil":
					base = 520.0
					wave = "sine"
					noise = 0.06
				"shoot_charcoal":
					base = 180.0
					wave = "saw"
					noise = 0.09
				"shoot_water", "shoot_co2":
					base = 700.0
					wave = "sine"
					noise = 0.07
				"shoot_dryice":
					base = 900.0
					wave = "triangle"
					noise = 0.09
				"pop_radiacao":
					base = 420.0
					noise = 0.05
				"pop_acido":
					base = 620.0
					noise = 0.1
				"pop_base":
					base = 480.0
					noise = 0.08
				"pop_gas":
					base = 300.0
					noise = 0.12
				"pop_explosivo":
					base = 120.0
					noise = 0.16
				"pop_metal":
					base = 360.0
					noise = 0.06
				"pop_inflamavel":
					base = 260.0
					noise = 0.1
				"pop_oxidante":
					base = 760.0
					noise = 0.07
				"pop_criogenico":
					base = 1100.0
					noise = 0.05
				"pop_reativo_agua":
					base = 200.0
					noise = 0.12
			_add_note(buf, 0.0, 0.12, base, 0.13, wave)
			_add_note(buf, 0.02, 0.1, base * 1.5, 0.08, "sine")
			_add_noise(buf, 0.0, 0.08, noise, 0.0, 0.4)
	return _to_wav(buf, false)


func _midi(note: int) -> float:
	return 440.0 * pow(2.0, (note - 69) / 12.0)


func _add_note(buf: PackedFloat32Array, start: float, dur: float, freq: float, amp: float, wave: String) -> void:
	var s0 := int(start * RATE)
	var n := int(dur * RATE)
	var count := buf.size()
	if s0 >= count:
		return
	for i in n:
		var idx := s0 + i
		if idx >= count:
			break
		var t := float(i) / RATE
		var env := minf(1.0, t / 0.012) * exp(-t * (2.2 / maxf(dur, 0.05)))
		var phase := fmod(freq * t, 1.0)
		var v := 0.0
		match wave:
			"square":
				v = 1.0 if phase < 0.5 else -1.0
			"saw":
				v = phase * 2.0 - 1.0
			"triangle":
				v = 1.0 - absf(phase * 4.0 - 2.0)
			_:
				v = sin(phase * TAU)
		buf[idx] += v * amp * env


func _add_noise(buf: PackedFloat32Array, start: float, dur: float, amp: float, _unused: float, bright: float) -> void:
	var s0 := int(start * RATE)
	var n := int(dur * RATE)
	var count := buf.size()
	var rng := RandomNumberGenerator.new()
	rng.seed = int(start * 10007.0) + 17
	var prev := 0.0
	for i in n:
		var idx := s0 + i
		if idx >= count:
			break
		var t := float(i) / RATE
		var env := exp(-t * (3.0 / maxf(dur, 0.03)))
		var raw := rng.randf_range(-1.0, 1.0)
		prev = lerpf(prev, raw, bright)
		buf[idx] += prev * amp * env


func _to_wav(buf: PackedFloat32Array, looped: bool) -> AudioStreamWAV:
	var peak := 0.0001
	for v in buf:
		peak = maxf(peak, absf(v))
	var gain := 0.82 / peak
	var bytes := PackedByteArray()
	bytes.resize(buf.size() * 2)
	for i in buf.size():
		var v := clampf(buf[i] * gain, -1.0, 1.0)
		bytes.encode_s16(i * 2, int(v * 32000.0))
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = RATE
	wav.stereo = false
	wav.data = bytes
	if looped:
		wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
		wav.loop_begin = 0
		wav.loop_end = buf.size()
	return wav
