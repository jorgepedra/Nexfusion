extends Control
## Root screen manager. The game opens on the menu with a short fade-in.

const SCREENS := {
	"menu": "res://scripts/screens/main_menu.gd",
	"maps": "res://scripts/screens/map_select.gd",
	"battle": "res://scripts/screens/battle.gd",
	"lab": "res://scripts/screens/lab.gd",
	"quimidex": "res://scripts/screens/quimidex.gd",
	"options": "res://scripts/screens/options.gd",
}

var current: Control
var busy := false


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	theme = UiTheme.make()
	var args := OS.get_cmdline_user_args()
	var start_screen := "menu"
	var shot := ""
	if not Sprites.is_ready:
		await Sprites.baked
	for a in args:
		if a.begins_with("--screen="):
			start_screen = a.split("=")[1]
		elif a.begins_with("--shot="):
			shot = a.split("=", true, 1)[1]
	go(start_screen)
	if shot != "":
		_take_shot(shot, args)
	else:
		_fade_in()


func _fade_in() -> void:
	var curtain := ColorRect.new()
	curtain.color = Color(0.008, 0.024, 0.04, 1.0)
	curtain.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	curtain.mouse_filter = Control.MOUSE_FILTER_IGNORE
	curtain.z_index = 200
	add_child(curtain)
	var tw := curtain.create_tween()
	tw.tween_property(curtain, "color:a", 0.0, 0.9)
	tw.tween_callback(curtain.queue_free)


func go(screen: String, args: Dictionary = {}) -> void:
	if busy:
		return
	busy = true
	if current != null and is_instance_valid(current):
		current.queue_free()
	var path: String = SCREENS.get(screen, SCREENS["menu"])
	var node: Control = null
	if path.ends_with(".tscn"):
		var packed: PackedScene = load(path)
		if packed != null:
			node = packed.instantiate()
	else:
		var scr = load(path)
		if scr != null:
			node = scr.new()
	if node == null:
		push_warning("Screen missing: " + path)
		node = Control.new()
	node.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	node.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(node)
	current = node
	if node.has_method("setup"):
		node.setup(args)
	busy = false


func _take_shot(path: String, args: Array) -> void:
	var frames := 45
	var wait_screen := ""
	for a in args:
		if a.begins_with("--wait="):
			wait_screen = a.split("=")[1]
	if wait_screen != "":
		await get_tree().create_timer(float(wait_screen)).timeout
	for i in frames:
		await get_tree().process_frame
	await RenderingServer.frame_post_draw
	var img := get_viewport().get_texture().get_image()
	if img != null:
		img.save_png(path)
		print("SHOT_SAVED " + path)
	get_tree().quit()
