extends Node
## Pre-renders every sprite once into ImageTexture so the GPU draws them.
## Nothing is drawn with _draw() during a match: Sprite2D/TextureRect read
## straight from video memory.

const BOARD := Vector2i(960, 720)
const TOWER_SIZE := Vector2i(64, 64)
const ENEMY_SIZE := Vector2i(64, 64)
const BOSS_SIZE := Vector2i(128, 128)
const PROJ_SIZE := Vector2i(32, 32)
const HAZARD_SIZE := Vector2i(24, 24)

var _towers := {}
var _enemies := {}
var _projectiles := {}
var _hazards := {}
var _maps := {}
var _misc := {}
var _failed := 0
var is_ready := false

signal baked


class SpriteCanvas extends Node2D:
	var fn: Callable

	func _draw() -> void:
		if fn.is_valid():
			fn.call(self)


func _ready() -> void:
	if DisplayServer.get_name() == "headless":
		is_ready = true
		return
	await _build_towers()
	await _build_enemies()
	await _build_projectiles()
	await _build_hazards()
	await _build_misc()
	await _build_maps()
	if _failed > 0:
		push_warning("SpriteFactory: %d sprites used the fallback texture." % _failed)
	is_ready = true
	baked.emit()


func _render(size: Vector2i, fn: Callable) -> ImageTexture:
	# The headless dummy renderer has no textures to read back: use a plain image.
	if DisplayServer.get_name() == "headless":
		return _fallback(size)
	var vp := SubViewport.new()
	vp.size = size
	vp.transparent_bg = true
	vp.disable_3d = true
	vp.render_target_update_mode = SubViewport.UPDATE_ONCE
	var canvas := SpriteCanvas.new()
	canvas.fn = fn
	vp.add_child(canvas)
	add_child(vp)
	await RenderingServer.frame_post_draw
	var tex: ImageTexture = null
	var vtex := vp.get_texture()
	if vtex != null:
		var img := vtex.get_image()
		if img != null and not img.is_empty():
			tex = ImageTexture.create_from_image(img)
	vp.queue_free()
	if tex == null:
		_failed += 1
		tex = _fallback(size)
	return tex


func _fallback(size: Vector2i) -> ImageTexture:
	var img := Image.create(size.x, size.y, false, Image.FORMAT_RGBA8)
	img.fill(Color(0.55, 0.62, 0.7, 0.95))
	var edge := Color(0.16, 0.2, 0.27, 1.0)
	img.fill_rect(Rect2i(0, 0, size.x, 2), edge)
	img.fill_rect(Rect2i(0, size.y - 2, size.x, 2), edge)
	img.fill_rect(Rect2i(0, 0, 2, size.y), edge)
	img.fill_rect(Rect2i(size.x - 2, 0, 2, size.y), edge)
	return ImageTexture.create_from_image(img)


# --- public API -------------------------------------------------------------

func get_tower(id: String, disabled: bool = false) -> Texture2D:
	return _towers.get(id + ("_off" if disabled else ""), _fallback(TOWER_SIZE))


func get_enemy(id: String, layer: int = 0) -> Texture2D:
	return _enemies.get(id + "_" + str(layer), _fallback(ENEMY_SIZE))


func get_projectile(kind: String, color: Color) -> Texture2D:
	return _projectiles.get(kind + "_" + color.to_html(false), _fallback(PROJ_SIZE))


func get_hazard(hazard: String) -> Texture2D:
	return _hazards.get(hazard, _fallback(HAZARD_SIZE))


func get_map(map_id: int) -> Texture2D:
	return _maps.get(map_id, _fallback(BOARD))


func get_effect(name: String) -> Texture2D:
	return _misc.get(name, _fallback(Vector2i(32, 32)))


func get_misc(name: String) -> Texture2D:
	return _misc.get(name, _fallback(Vector2i(32, 32)))


# --- generation -------------------------------------------------------------

func _build_towers() -> void:
	for id in DB.TOWER_ORDER:
		var center := Vector2(32, 34)
		var tower_id := String(id)
		_towers[tower_id] = await _render(TOWER_SIZE, func(ci: CanvasItem) -> void:
			Art.draw_tower(ci, tower_id, center, 23.0, 0.0, 0.0, false))
		_towers[tower_id + "_off"] = await _render(TOWER_SIZE, func(ci: CanvasItem) -> void:
			Art.draw_tower(ci, tower_id, center, 23.0, 0.0, 0.0, true))


func _build_enemies() -> void:
	for id in DB.ENEMIES.keys():
		var def: Dictionary = DB.ENEMIES[id]
		var boss: bool = "boss" in def.props
		var size := BOSS_SIZE if boss else ENEMY_SIZE
		var center := Vector2(64, 66) if boss else Vector2(32, 36)
		var s := 42.0 if boss else 21.0 * float(def.scale)
		var layers: Array = def.layers
		for i in layers.size():
			var layer: Dictionary = DB.enemy_layer(id, i)
			var key := String(id) + "_" + str(i)
			var layer_data := layer
			var def_data := def
			_enemies[key] = await _render(size, func(ci: CanvasItem) -> void:
				Art.draw_enemy(ci, def_data, layer_data, center, s, 0.0, "walk", false))


func _build_projectiles() -> void:
	for id in DB.TOWER_ORDER:
		var def: Dictionary = DB.TOWERS[id]
		var kind := str(def.proj)
		var color := Color(def.proj_color)
		var key := kind + "_" + color.to_html(false)
		if _projectiles.has(key):
			continue
		_projectiles[key] = await _render(PROJ_SIZE, func(ci: CanvasItem) -> void:
			Art.draw_projectile(ci, kind, Vector2(16, 16), 0.0, color, 0.0))


func _build_hazards() -> void:
	for h in DB.HAZARDS.keys():
		var hazard := String(h)
		_hazards[hazard] = await _render(HAZARD_SIZE, func(ci: CanvasItem) -> void:
			Art.draw_hazard_icon(ci, hazard, Vector2(12, 12), 9.5))


func _build_misc() -> void:
	_misc["pad"] = await _render(TOWER_SIZE, func(ci: CanvasItem) -> void:
		Art._ellipse(ci, Vector2(32, 46), Vector2(19, 7), Color(0.16, 0.22, 0.33, 0.9))
		Art._ellipse(ci, Vector2(32, 44), Vector2(17, 5.5), Color(0.3, 0.4, 0.55, 0.9)))
	_misc["base"] = await _render(Vector2i(112, 112), func(ci: CanvasItem) -> void:
		Art.draw_base(ci, Vector2(56, 52), 44.0, 0.0, 100.0))
	_misc["dot"] = await _render(Vector2i(16, 16), func(ci: CanvasItem) -> void:
		ci.draw_circle(Vector2(8, 8), 7.0, Color(1, 1, 1, 1))
		ci.draw_circle(Vector2(8, 8), 4.0, Color(1, 1, 1, 0.85)))
	_misc["puddle"] = await _render(Vector2i(128, 64), func(ci: CanvasItem) -> void:
		Art._ellipse(ci, Vector2(64, 32), Vector2(62, 30), Color(1, 1, 1, 0.26))
		Art._ellipse(ci, Vector2(64, 32), Vector2(50, 22), Color(1, 1, 1, 0.22))
		ci.draw_arc(Vector2(64, 32), 60, 0, TAU, 40, Color(1, 1, 1, 0.55), 2.0))
	_misc["entrance"] = await _render(Vector2i(120, 34), func(ci: CanvasItem) -> void:
		var pts := PackedVector2Array([Vector2(4, 3), Vector2(26, 17), Vector2(4, 31)])
		ci.draw_colored_polygon(pts, Color("#ffcf5e"))
		ci.draw_string(ThemeDB.fallback_font, Vector2(32, 22), "ENTRADA", HORIZONTAL_ALIGNMENT_LEFT, 84, 11, Color(0.12, 0.16, 0.2, 0.85)))
	_misc["flask_green"] = await _render(Vector2i(96, 96), func(ci: CanvasItem) -> void:
		Art.draw_flask(ci, Vector2(48, 46), 72.0, Color(0.56, 0.9, 0.66, 0.85), 0.0, true))
	_misc["flask_blue"] = await _render(Vector2i(96, 96), func(ci: CanvasItem) -> void:
		Art.draw_flask(ci, Vector2(48, 46), 72.0, Color(0.5, 0.75, 1.0, 0.85), 0.0, true))
	_misc["flask_amber"] = await _render(Vector2i(96, 96), func(ci: CanvasItem) -> void:
		Art.draw_flask(ci, Vector2(48, 46), 72.0, Color(1.0, 0.82, 0.4, 0.85), 0.0, true))


func _build_maps() -> void:
	for i in DB.MAPS.size():
		var map_id := i
		_maps[map_id] = await _render(BOARD, func(ci: CanvasItem) -> void:
			_draw_map(ci, map_id))


# --- static scenario art (ground + obstacles, baked once) --------------------

func _draw_map(ci: CanvasItem, map_id: int) -> void:
	var m: Dictionary = DB.MAPS[map_id]
	var theme: String = m.theme
	var view := Vector2(BOARD)
	var base_col := Color("#e6eff5")
	var tile := 48.0
	if theme == "nuclear":
		base_col = Color("#1d2823")
		tile = 54.0
	elif theme == "industrial":
		base_col = Color("#2f2823")
		tile = 52.0
	ci.draw_rect(Rect2(Vector2.ZERO, view), base_col)
	var cols := int(view.x / tile) + 1
	var rows := int(view.y / tile) + 1
	for y in rows:
		for x in cols:
			var alt := (x + y) % 2 == 0
			var col := base_col.lightened(0.04) if alt else base_col.darkened(0.03)
			ci.draw_rect(Rect2(Vector2(x * tile, y * tile), Vector2(tile - 1, tile - 1)), col)
	if theme == "school":
		for i in 3:
			var r := Rect2(360 + i * 140, 84, 100, 46)
			ci.draw_rect(r, Color("#a8d8ee"))
			ci.draw_rect(r, Color("#7fb4cf"), false, 3)
			ci.draw_line(r.position + Vector2(50, 0), r.position + Vector2(50, 46), Color("#7fb4cf"), 2)
			ci.draw_circle(r.position + Vector2(24, 18), 9, Color(1, 1, 1, 0.28))
		for i in 4:
			var lx := 130.0 + i * 230.0
			ci.draw_line(Vector2(lx, 0), Vector2(lx, 18), Color("#8fa3b5"), 3)
			ci.draw_rect(Rect2(lx - 26, 18, 52, 9), Color("#dff3ff"))
			ci.draw_circle(Vector2(lx, 26), 34, Color(1, 1, 0.9, 0.09))
		ci.draw_line(Vector2(44, 96), Vector2(44, 250), Color("#7d94a8"), 6)
		ci.draw_line(Vector2(44, 96), Vector2(100, 96), Color("#7d94a8"), 6)
		ci.draw_circle(Vector2(100, 106), 11, Color("#a9bdcb"))
		ci.draw_string(ThemeDB.fallback_font, Vector2(24, 284), "CHUVEIRO", HORIZONTAL_ALIGNMENT_LEFT, 120, 10, Color(0.3, 0.42, 0.5, 0.8))
	elif theme == "nuclear":
		for i in 4:
			var y := 40.0 + i * 170.0
			ci.draw_line(Vector2(0, y), Vector2(view.x, y), Color("#2c3a33"), 10)
			ci.draw_line(Vector2(0, y - 2), Vector2(view.x, y - 2), Color(0.5, 0.9, 0.4, 0.18), 2)
		for i in 6:
			var p := Vector2(90 + i * 160, 660 - (i % 2) * 600)
			ci.draw_arc(p, 22, 0, TAU, 24, Color(0.55, 1.0, 0.45, 0.14), 3)
		ci.draw_rect(Rect2(0, 0, view.x, view.y), Color(0.02, 0.08, 0.04, 0.25))
	elif theme == "industrial":
		for i in 5:
			var y := 70.0 + i * 140.0
			ci.draw_line(Vector2(0, y), Vector2(view.x, y + 12), Color("#4a3a2e"), 12)
			ci.draw_line(Vector2(0, y - 3), Vector2(view.x, y + 9), Color("#8f6b4a"), 3)
		for i in 8:
			var px := fmod(i * 211.0, view.x)
			var py := 660 - fmod(i * 70.0, 300)
			ci.draw_circle(Vector2(px, py), 14 + (i % 3) * 6, Color(0.6, 0.6, 0.6, 0.05))
	ci.draw_rect(Rect2(0, 0, view.x, view.y), Color(0.02, 0.05, 0.09, 0.12))
	_draw_decor(ci, m)


func _draw_decor(ci: CanvasItem, m: Dictionary) -> void:
	var theme: String = m.theme
	for i in m.blocked.size():
		var r: Rect2 = m.blocked[i]
		if theme == "school":
			ci.draw_rect(Rect2(r.position + Vector2(4, 6), r.size), Color(0.05, 0.1, 0.15, 0.25))
			ci.draw_rect(r, Color("#9a6f4a"))
			ci.draw_rect(Rect2(r.position + Vector2(0, 8), Vector2(r.size.x, r.size.y - 8)), Color("#c79a68"))
			ci.draw_rect(Rect2(r.position, Vector2(r.size.x, 10)), Color("#e0b98a"))
			for k in 2:
				var fill := Color("#8fe6a8") if k == 0 else Color("#ffd36e")
				Art.draw_flask(ci, r.position + Vector2(28 + k * 52, 30), 26.0, fill, float(i + k) * 0.7, false)
			ci.draw_rect(Rect2(r.position + Vector2(6, r.size.y - 8), Vector2(r.size.x - 12, 8)), Color("#7a543a"))
		elif theme == "nuclear":
			ci.draw_rect(Rect2(r.position + Vector2(5, 6), r.size), Color(0.02, 0.05, 0.03, 0.4))
			ci.draw_rect(r, Color("#38463f"))
			ci.draw_rect(Rect2(r.position + Vector2(4, 4), r.size - Vector2(8, 8)), Color("#2a3630"))
			ci.draw_rect(Rect2(r.position + Vector2(10, 12), Vector2(r.size.x - 20, 26)), Color("#13261a"))
			ci.draw_string(ThemeDB.fallback_font, r.position + Vector2(16, 31), "REATOR", HORIZONTAL_ALIGNMENT_LEFT, r.size.x - 20, 11, Color(0.6, 1.0, 0.5, 0.85))
			for k in 3:
				ci.draw_circle(r.position + Vector2(16 + k * 18, r.size.y - 14), 3.5, Color(0.6, 1.0, 0.4, 0.7))
			_draw_trefoil(ci, r.position + r.size * Vector2(0.5, 0.65), 14.0)
		else:
			ci.draw_rect(Rect2(r.position + Vector2(5, 6), r.size), Color(0.05, 0.03, 0.02, 0.35))
			ci.draw_rect(r, Color("#5a4436"))
			ci.draw_rect(Rect2(r.position, Vector2(r.size.x, 18)), Color("#7a5c48"))
			for k in 3:
				ci.draw_line(r.position + Vector2(0, 24 + k * 22), r.position + Vector2(r.size.x, 24 + k * 22), Color("#3f3028"), 3)
			ci.draw_circle(r.position + r.size * Vector2(0.5, 0.52), minf(r.size.x, r.size.y) * 0.22, Color("#b85c3a"))
			ci.draw_arc(r.position + r.size * Vector2(0.5, 0.52), minf(r.size.x, r.size.y) * 0.26, 0, TAU, 22, Color("#e0a070"), 3)
	for circle in m.blocked_circles:
		var c := Vector2(circle[0], circle[1])
		var rad: float = circle[2]
		ci.draw_circle(c, rad + 8, Color("#2a3630"))
		ci.draw_circle(c, rad, Color("#1d2823"))
		ci.draw_arc(c, rad - 4, 0, TAU, 40, Color(0.6, 1.0, 0.45, 0.4), 5)
		ci.draw_arc(c, rad + 14, 0, TAU, 40, Color(0.6, 1.0, 0.45, 0.12), 2)
		_draw_trefoil(ci, c, 18.0)


func _draw_trefoil(ci: CanvasItem, c: Vector2, r: float) -> void:
	for i in 3:
		var a := -PI / 2.0 + i * TAU / 3.0
		ci.draw_circle(c + Vector2(cos(a), sin(a)) * r * 0.6, r * 0.3, Color(0.75, 1.0, 0.5, 0.5))
	ci.draw_circle(c, r * 0.22, Color(0.75, 1.0, 0.5, 0.5))
