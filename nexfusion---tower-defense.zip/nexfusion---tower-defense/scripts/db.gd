extends Node
## All static game data for Nexfusion Tower Defense (educational demo).
## Content is simplified science: no synthesis instructions or real quantities.

const HAZARDS := {
	"radiacao": {"name": "Radiação", "color": "#9be15d", "icon": "radiation"},
	"acido": {"name": "Ácido", "color": "#e8e24a", "icon": "acid"},
	"base": {"name": "Base cáustica", "color": "#7ee0c3", "icon": "acid"},
	"gas": {"name": "Gás tóxico", "color": "#b6e05a", "icon": "gas"},
	"explosivo": {"name": "Explosivo", "color": "#ff8a4a", "icon": "boom"},
	"inflamavel": {"name": "Inflamável", "color": "#ffab45", "icon": "flame"},
	"metal": {"name": "Metal pesado", "color": "#b8c2d6", "icon": "metal"},
	"oxidante": {"name": "Oxidante", "color": "#63d3ff", "icon": "oxid"},
	"reativo_agua": {"name": "Reativo à água", "color": "#c9d4e6", "icon": "water"},
	"criogenico": {"name": "Criogênico", "color": "#9be6ff", "icon": "snow"},
}

const CATEGORIES := {
	"rad": {"name": "Radiação e metais", "color": "#5fd36a"},
	"chem": {"name": "Neutralizadores químicos", "color": "#f4c744"},
	"gas": {"name": "Gases e fogo", "color": "#4fb3ff"},
	"lab": {"name": "Itens de Laboratório", "color": "#9b6bff"},
}

const PRIORITIES := ["primeiro", "ultimo", "forte", "rapido"]
const PRIORITY_LABELS := {
	"primeiro": "Primeiro",
	"ultimo": "Último",
	"forte": "Mais forte",
	"rapido": "Mais rápido",
}

const DIFFICULTIES := {
	"facil": {"label": "FÁCIL", "rounds": 30, "cp": 800, "hp": 0.85, "speed": 0.9, "desc": "30 rounds · 800 CP · inimigos mais lentos"},
	"normal": {"label": "NORMAL", "rounds": 40, "cp": 650, "hp": 1.0, "speed": 1.0, "desc": "40 rounds · 650 CP"},
	"dificil": {"label": "DIFÍCIL", "rounds": 40, "cp": 500, "hp": 1.25, "speed": 1.12, "desc": "40 rounds · 500 CP · inimigos mais rápidos e fortes"},
}

var ENEMIES := {
	"uranio": {
		"name": "Urânio", "formula": "U", "shape": "canister", "color": "#8ed24b",
		"hazard": "radiacao", "props": ["emissor"], "weak": ["lead"], "scale": 1.0,
		"from": 1, "maps": [0, 1],
		"layers": [{"name": "Urânio radioativo", "hp": 18, "speed": 42, "reward": 10, "leak": 1}],
		"why": "O urânio emite radiação ionizante, que atravessa a matéria e pode danificar células e equipamentos.",
		"how": "O chumbo é muito denso e absorve boa parte da radiação. Por isso é usado como blindagem protetora.",
		"curious": "A radiação não é 'sujeira': é energia que se espalha. Blindar é bloquear essa energia.",
		"hint": "Radiação exige blindagem densa: use CHUMBO (Pb).",
	},
	"cesio": {
		"name": "Césio-137", "formula": "Cs-137", "shape": "canister", "color": "#ffe14d",
		"hazard": "radiacao", "props": ["emissor"], "weak": ["lead", "sand"], "scale": 1.08,
		"from": 8, "maps": [1, 2],
		"layers": [{"name": "Césio-137", "hp": 36, "speed": 38, "reward": 17, "leak": 3}],
		"why": "O césio-137 é um isótopo radioativo que emite radiação intensa por muitos anos.",
		"how": "Blindagens densas de chumbo, concreto e areia reduzem a exposição à radiação.",
		"curious": "Radioisótopos têm 'meia-vida': o tempo para metade da radiação diminuir.",
		"hint": "Césio-137 pede blindagem dupla: CHUMBO (Pb) ou areia espessa.",
	},
	"cloro": {
		"name": "Cloro gasoso", "formula": "Cl₂", "shape": "cloud", "color": "#c6e34a",
		"hazard": "gas", "props": ["gasoso"], "weak": ["charcoal", "thio"], "scale": 1.0,
		"from": 4, "maps": [0, 1, 2],
		"layers": [{"name": "Cloro gasoso", "hp": 20, "speed": 50, "reward": 11, "leak": 2}],
		"why": "O cloro gasoso irrita e lesiona as vias respiratórias; em ambientes fechados é muito perigoso.",
		"how": "O carvão ativado adsorve moléculas de gás em seus poros. O tiossulfato também neutraliza oxidantes como o cloro.",
		"curious": "Carvão ativado tem poros microscópicos: 1 grama pode ter centenas de metros quadrados de área.",
		"hint": "Gás cloro não se segura com areia: use CARVÃO ATIVADO ou TIOSSULFATO.",
	},
	"amonia": {
		"name": "Amônia", "formula": "NH₃", "shape": "cloud", "color": "#e6eef8",
		"hazard": "gas", "props": ["gasoso"], "weak": ["water", "charcoal"], "scale": 0.98,
		"from": 2, "maps": [0, 1, 2],
		"layers": [{"name": "Amônia", "hp": 17, "speed": 54, "reward": 10, "leak": 2}],
		"why": "A amônia é um gás irritante; em alta concentração prejudica os pulmões e os olhos.",
		"how": "A água dissolve a amônia e o carvão ativado absorve boa parte do gás.",
		"curious": "A amônia é muito solúvel em água — dissolver é uma forma de conter o vapor.",
		"hint": "Amônia se dissolve em ÁGUA e é absorvida por CARVÃO ATIVADO.",
	},
	"sulfurico": {
		"name": "Ácido sulfúrico", "formula": "H₂SO₄", "shape": "bottle", "color": "#e3e24f",
		"hazard": "acido", "props": ["corrosivo"], "weak": ["bicarb"], "scale": 1.02,
		"from": 3, "maps": [0, 1, 2],
		"layers": [
			{"name": "Ácido concentrado", "hp": 27, "speed": 38, "reward": 10, "leak": 2},
			{"name": "Ácido diluído", "hp": 15, "speed": 46, "reward": 5, "leak": 1, "color": "#c8d24a"},
			{"name": "Água levemente ácida", "hp": 8, "speed": 54, "reward": 3, "leak": 1, "color": "#9fd6c0"}],
		"why": "O ácido sulfúrico concentrado é altamente corrosivo e desidrata os tecidos.",
		"how": "O bicarbonato de sódio reage com ácidos formando gás carbônico, água e um sal — a acidez cai.",
		"curious": "O ácido 'enfraquece' ao ser neutralizado: a reação consome os íons de hidrogênio.",
		"hint": "Ácidos só perdem força com BICARBONATO (NaHCO₃), que forma espuma e sal.",
	},
	"cloridrico": {
		"name": "Ácido clorídrico", "formula": "HCl", "shape": "bottle", "color": "#d9e86a",
		"hazard": "acido", "props": ["corrosivo"], "weak": ["bicarb"], "scale": 0.96,
		"from": 6, "maps": [0, 2],
		"layers": [
			{"name": "Ácido clorídrico", "hp": 22, "speed": 42, "reward": 9, "leak": 2},
			{"name": "Solução ácida fraca", "hp": 11, "speed": 50, "reward": 4, "leak": 1, "color": "#a8d4b8"}],
		"why": "O ácido clorídrico é corrosivo e libera vapores irritantes.",
		"how": "O bicarbonato neutraliza o ácido formando cloreto de sódio, água e gás carbônico.",
		"curious": "Um indicador de pH muda de cor quando a acidez diminui — ciência visível!",
		"hint": "Ácido clorídrico também é neutralizado por BICARBONATO.",
	},
	"soda": {
		"name": "Soda cáustica", "formula": "NaOH", "shape": "chunk", "color": "#dff4ef",
		"hazard": "base", "props": ["corrosivo"], "weak": ["vinegar"], "scale": 1.0,
		"from": 9, "maps": [0, 1, 2],
		"layers": [{"name": "Soda cáustica", "hp": 24, "speed": 42, "reward": 12, "leak": 2}],
		"why": "Bases fortes como a soda cáustica dissolvem gorduras e queimam a pele.",
		"how": "Um ácido fraco como o vinagre neutraliza a base, formando sal e água.",
		"curious": "Bases também são corrosivas — 'cáustico' não é só ácido.",
		"hint": "Bases pedem neutralização com ácido fraco: use VINAGRE (CH₃COOH).",
	},
	"sodio": {
		"name": "Sódio metálico", "formula": "Na", "shape": "droplet", "color": "#c8d2e2",
		"hazard": "reativo_agua", "props": ["reativo_agua"], "weak": ["oil", "sand"], "scale": 1.0,
		"from": 11, "maps": [0, 1],
		"layers": [{"name": "Sódio metálico", "hp": 26, "speed": 46, "reward": 13, "leak": 2}],
		"why": "O sódio metálico reage violentamente com água, liberando calor e hidrogênio inflamável.",
		"how": "Óleo mineral e areia seca isolam o sódio da umidade, impedindo o contato com a água.",
		"curious": "Metais alcalinos são guardados sob óleo justamente para evitar o contato com a umidade do ar.",
		"hint": "Água PIORA o sódio metálico. Isole com ÓLEO MINERAL ou AREIA.",
	},
	"mercurio": {
		"name": "Mercúrio", "formula": "Hg", "shape": "droplet", "color": "#b9c4d6",
		"hazard": "metal", "props": ["denso"], "weak": ["edta"], "scale": 1.05,
		"from": 12, "maps": [1, 2],
		"layers": [{"name": "Mercúrio", "hp": 62, "speed": 28, "reward": 21, "leak": 3}],
		"why": "O mercúrio é um metal pesado que se acumula no corpo e no ambiente; seus vapores são tóxicos.",
		"how": "Quelantes como o EDTA 'agarram' íons metálicos, formando complexos que podem ser removidos.",
		"curious": "O mercúrio é líquido à temperatura ambiente — o único metal assim na natureza comum.",
		"hint": "Mercúrio exige QUELANTE (EDTA), que captura metais pesados.",
	},
	"co": {
		"name": "Monóxido de carbono", "formula": "CO", "shape": "cloud", "color": "#b8c2cc",
		"hazard": "gas", "props": ["gasoso"], "weak": ["charcoal", "water"], "scale": 0.92,
		"from": 7, "maps": [0, 1, 2],
		"layers": [{"name": "Monóxido de carbono", "hp": 15, "speed": 66, "reward": 10, "leak": 2}],
		"why": "O CO é inodoro e se liga à hemoglobina, impedindo o transporte de oxigênio no sangue.",
		"how": "Carvão ativado adsorve o CO; a ventilação e a água também ajudam a dispersar o gás.",
		"curious": "Como não tem cheiro, o CO é detectado por sensores, não pelo olfato.",
		"hint": "O CO é rápido e invisível: use CARVÃO ATIVADO com filtro largo.",
	},
	"metano": {
		"name": "Metano", "formula": "CH₄", "shape": "cloud", "color": "#bfe4d6",
		"hazard": "inflamavel", "props": ["gasoso"], "weak": ["co2", "sand"], "scale": 0.96,
		"from": 10, "maps": [0, 1, 2],
		"layers": [{"name": "Metano", "hp": 21, "speed": 56, "reward": 11, "leak": 2}],
		"why": "O metano é inflamável: misturado ao ar, pode formar uma atmosfera explosiva.",
		"how": "O CO₂ do extintor desloca o oxigênio e abafa a chama; areia e isolamento também contêm o fogo.",
		"curious": "O metano é o principal componente do gás natural.",
		"hint": "Contra inflamáveis, abafe o oxigênio com EXTINTOR DE CO₂.",
	},
	"nitro": {
		"name": "Nitroglicerina", "formula": "C₃H₅N₃O₉", "shape": "vial", "color": "#ffb45e",
		"hazard": "explosivo", "props": ["instavel"], "weak": ["dryice", "co2"], "scale": 1.0,
		"from": 14, "maps": [0, 2],
		"layers": [{"name": "Nitroglicerina", "hp": 28, "speed": 46, "reward": 14, "leak": 3}],
		"why": "A nitroglicerina é um líquido explosivo muito sensível a choque e calor.",
		"how": "O resfriamento com gelo seco reduz a energia do sistema e estabiliza a reação.",
		"curious": "Explosivos liberam gás e calor muito rápido; controlar a temperatura é essencial.",
		"hint": "Explosivos precisam de resfriamento: GELO SECO ou EXTINTOR DE CO₂.",
	},
	"agua_sanitaria": {
		"name": "Água sanitária + amônia", "formula": "NaClO + NH₃", "shape": "cloud", "color": "#d7f07a",
		"hazard": "gas", "props": ["gasoso", "oxidante"], "weak": ["charcoal", "thio"], "scale": 1.08,
		"from": 16, "maps": [0, 2],
		"layers": [{"name": "Nuvem de cloramina", "hp": 38, "speed": 42, "reward": 18, "leak": 3}],
		"why": "Misturar água sanitária com amônia libera cloraminas, gases tóxicos para os pulmões.",
		"how": "Carvão ativado e tiossulfato reduzem gases oxidantes e irritantes. Nunca misture produtos de limpeza.",
		"curious": "Esta é a reação que o laboratório do jogo usa para ensinar segurança doméstica.",
		"hint": "Nunca misture produtos de limpeza. Use CARVÃO + TIOSSULFATO contra essa nuvem.",
	},
	"fosforo": {
		"name": "Fósforo branco", "formula": "P₄", "shape": "chunk", "color": "#fff2c4",
		"hazard": "inflamavel", "props": ["incendiario"], "weak": ["water", "sand"], "scale": 1.0,
		"from": 18, "maps": [0, 2],
		"layers": [{"name": "Fósforo branco", "hp": 32, "speed": 44, "reward": 15, "leak": 3}],
		"why": "O fósforo branco inflama em contato com o ar e queima a altas temperaturas.",
		"how": "Água resfria e areia abafa, cortando o contato com o oxigênio do ar.",
		"curious": "O fósforo branco precisa ser guardado submerso em água para não inflamar.",
		"hint": "Fósforo branco queima: resfrie com ÁGUA e abafe com AREIA.",
	},
	"reator": {
		"name": "Reator em Fusão", "formula": "Chefe", "shape": "boss_reactor", "color": "#9ff06a",
		"hazard": "radiacao", "props": ["emissor", "boss"], "weak": ["lead"], "scale": 1.9,
		"from": 99, "maps": [1],
		"layers": [
			{"name": "Fase 1 · Radiação", "hp": 620, "speed": 24, "reward": 120, "leak": 50, "weak": ["lead"]},
			{"name": "Fase 2 · Calor", "hp": 520, "speed": 28, "reward": 90, "leak": 50, "hazard": "explosivo", "weak": ["dryice", "co2"], "color": "#ffb45e"},
			{"name": "Fase 3 · Metais", "hp": 460, "speed": 32, "reward": 90, "leak": 50, "hazard": "metal", "weak": ["edta"], "color": "#b8c2d6"}],
		"why": "Um reator danificado libera radiação e calor; as fases misturam perigos diferentes.",
		"how": "Cada fase exige uma proteção: chumbo contra radiação, gelo seco contra calor, quelante contra metais.",
		"curious": "Um reator real tem várias barreiras de contenção — defesa em camadas, como no jogo.",
		"hint": "O chefe muda de perigo: alterne CHUMBO, GELO SECO e QUELANTE.",
	},
	"nuvem": {
		"name": "Nuvem Química", "formula": "Chefe", "shape": "boss_cloud", "color": "#b6e05a",
		"hazard": "gas", "props": ["boss"], "weak": ["charcoal"], "scale": 1.9,
		"from": 99, "maps": [2],
		"layers": [
			{"name": "Fase 1 · Gás", "hp": 560, "speed": 26, "reward": 120, "leak": 50, "weak": ["charcoal", "thio"]},
			{"name": "Fase 2 · Ácido", "hp": 480, "speed": 30, "reward": 90, "leak": 50, "hazard": "acido", "weak": ["bicarb"], "color": "#e3e24f"},
			{"name": "Fase 3 · Oxidante", "hp": 430, "speed": 34, "reward": 90, "leak": 50, "hazard": "oxidante", "weak": ["thio"], "color": "#63d3ff"}],
		"why": "Essa nuvem muda de composição: gás tóxico, depois ácido e por fim um oxidante.",
		"how": "Cada composição pede um neutralizador diferente: carvão, bicarbonato e tiossulfato.",
		"curious": "Nuvens industriais podem ter camadas de gases diferentes ao mesmo tempo.",
		"hint": "A Nuvem Química muda de perigo: prepare CARVÃO, BICARBONATO e TIOSSULFATO.",
	},
}

var TOWER_ORDER := ["lead", "bicarb", "water", "charcoal", "vinegar", "sand", "co2", "thio", "oil", "edta", "dryice"]
var TOWERS := {}
var RECIPES := []
var ITEMS := {}
var CREATED := {}

var MAPS := [
	{
		"id": 0, "name": "Laboratório Escolar", "stars": 1, "theme": "school",
		"desc": "Bancadas, azulejos e um caminho em S entre os frascos. Foco: ácidos e gases simples.",
		"paths": [[Vector2(0, 170), Vector2(690, 170), Vector2(690, 340), Vector2(210, 340), Vector2(210, 540), Vector2(890, 540)]],
		"base": Vector2(914, 540),
		"blocked": [Rect2(46, 380, 112, 82), Rect2(760, 58, 148, 74), Rect2(430, 58, 120, 72), Rect2(804, 230, 110, 78), Rect2(52, 60, 120, 86)],
		"blocked_circles": [],
		"boss": "",
	},
	{
		"id": 1, "name": "Usina Nuclear Abandonada", "stars": 2, "theme": "nuclear",
		"desc": "Espiral ao redor de um reator antigo, com tubos brilhantes e contador Geiger. Foco: radiação.",
		"paths": [[Vector2(0, 660), Vector2(840, 660), Vector2(840, 120), Vector2(140, 120), Vector2(140, 540), Vector2(710, 540), Vector2(710, 270), Vector2(330, 270), Vector2(330, 420), Vector2(480, 420), Vector2(480, 348)]],
		"base": Vector2(480, 340),
		"blocked": [Rect2(58, 62, 96, 96), Rect2(792, 520, 120, 80), Rect2(560, 60, 90, 90), Rect2(782, 300, 90, 70)],
		"blocked_circles": [[480, 356, 64]],
		"boss": "reator",
	},
	{
		"id": 2, "name": "Complexo Industrial Químico", "stars": 3, "theme": "industrial",
		"desc": "Dois caminhos que se cruzam entre tanques e tubulações. Foco: gases, ácidos e explosivos.",
		"paths": [
			[Vector2(0, 120), Vector2(600, 120), Vector2(600, 600), Vector2(905, 600)],
			[Vector2(0, 320), Vector2(740, 320), Vector2(740, 600), Vector2(905, 600)]],
		"base": Vector2(914, 600),
		"blocked": [Rect2(62, 430, 118, 118), Rect2(788, 150, 120, 110), Rect2(430, 428, 112, 96), Rect2(60, 190, 96, 80)],
		"blocked_circles": [],
		"boss": "nuvem",
	},
]


func _ready() -> void:
	_build_towers()
	_build_recipes()


func _u(name: String, cost: int, desc: String, mods: Dictionary) -> Dictionary:
	return {"name": name, "cost": cost, "desc": desc, "mods": mods}


func _tower(d: Dictionary) -> void:
	TOWERS[d.id] = d


func _build_towers() -> void:
	_tower({
		"id": "lead", "name": "Chumbo", "formula": "Pb", "price": 350, "cat": "rad",
		"color": "#9aa9bd", "shape": "lead", "hotkey": "Q", "unlock": 1,
		"damage": 14.0, "range": 132.0, "rate": 1.1, "proj": "capsule",
		"protects": ["radiacao"], "proj_color": "#dbe4f2",
		"desc": "Lança cápsulas densas que selam a fonte de radiação.",
		"why": "O chumbo é denso e absorve radiação ionizante, funcionando como blindagem.",
		"curious": "Aventais de chumbo são usados em radiologia para proteger o corpo.",
		"paths": {
			"A": [
				_u("Cápsula perfurante", 220, "+70% de dano e a cápsula perfura 1 inimigo extra.", {"dmg": 0.7, "pierce": 1}),
				_u("Chumbo duplo", 380, "Atinge 2 inimigos ao mesmo tempo.", {"targets": 1, "dmg": 0.2}),
				_u("Câmara de contenção", 650, "Prende o inimigo por 1,5 s.", {"stun": 1.5, "dmg": 0.3}),
				_u("Sarcófago de chumbo", 1600, "Dano enorme em radiação e chefes.", {"dmg": 1.6, "bonus_boss": 1.5, "splash": 42.0})],
			"B": [
				_u("Alcance +15%", 180, "A cápsula alcança mais longe.", {"range": 0.15}),
				_u("Mira de detector Geiger", 300, "+50% de dano contra Emissores.", {"bonus_emissor": 0.5, "range": 0.1}),
				_u("Torre de chumbo alta", 520, "Alcance muito maior.", {"range": 0.3}),
				_u("Escudo anti-radiação", 1400, "Torres próximas ficam imunes ao enfraquecimento de Emissores.", {"flags": ["shield_aura"], "range": 0.1})]},
	})
	_tower({
		"id": "bicarb", "name": "Bicarbonato", "formula": "NaHCO₃", "price": 200, "cat": "chem",
		"color": "#f2f7ff", "shape": "bicarb", "hotkey": "W", "unlock": 1,
		"damage": 8.0, "range": 120.0, "rate": 1.4, "proj": "foam",
		"protects": ["acido"], "proj_color": "#ffffff",
		"desc": "Joga espuma que borbulha e neutraliza ácidos.",
		"why": "O bicarbonato reage com ácidos formando água, sal e gás carbônico — a acidez cai.",
		"curious": "É o mesmo princípio do fermento químico em bolos.",
		"paths": {
			"A": [
				_u("Espuma concentrada", 150, "+60% de dano.", {"dmg": 0.6}),
				_u("Jato duplo", 260, "Atinge 2 inimigos.", {"targets": 1}),
				_u("Chuva de bicarbonato", 480, "Dano em área ao redor do alvo.", {"splash": 56.0, "dmg": 0.4}),
				_u("Mar de espuma", 1200, "Área enorme que neutraliza ácidos concentrados.", {"splash": 112.0, "dmg": 0.9, "slow_factor": 0.65, "slow_time": 2.0})],
			"B": [
				_u("Atira mais rápido", 140, "+35% de cadência.", {"rate": 0.35}),
				_u("Espuma pegajosa", 280, "Deixa o inimigo mais lento.", {"slow_factor": 0.6, "slow_time": 2.5}),
				_u("Proteção da torre", 420, "Imune a inimigos Corrosivos.", {"flags": ["anti_corrosive"]}),
				_u("Espuma protetora", 1100, "Deixa uma poça que neutraliza ácidos que passarem.", {"flags": ["puddle"], "splash": 42.0, "dmg": 0.3})]},
	})
	_tower({
		"id": "charcoal", "name": "Carvão ativado", "formula": "C", "price": 300, "cat": "gas",
		"color": "#3a3d48", "shape": "charcoal", "hotkey": "E", "unlock": 2,
		"damage": 7.0, "range": 112.0, "rate": 1.0, "proj": "cloud",
		"protects": ["gas", "oxidante"], "proj_color": "#6b6f80",
		"desc": "Solta uma nuvem de carvão que absorve gases tóxicos.",
		"why": "O carvão ativado tem poros microscópicos que adsorvem moléculas de gás.",
		"curious": "Um único grama de carvão ativado pode ter centenas de metros quadrados de superfície.",
		"paths": {
			"A": [
				_u("Poros extras", 180, "+50% de absorção (dano).", {"dmg": 0.5}),
				_u("Nuvem grande", 300, "+20% de alcance.", {"range": 0.2}),
				_u("Filtro duplo", 460, "Absorve 2 gases por vez.", {"targets": 1, "dmg": 0.2}),
				_u("Purificador", 1250, "Limpa todos os gases no alcance a cada 10 s.", {"flags": ["purify"], "dmg": 0.4})],
			"B": [
				_u("Ventilador", 160, "+40% de cadência.", {"rate": 0.4}),
				_u("Mistura com quelante", 380, "Também reduz metais pesados.", {"add_protect": "metal", "dmg": 0.2}),
				_u("Filtro de ar", 480, "+35% de alcance.", {"range": 0.35}),
				_u("Ventilação industrial", 1150, "Empurra gases para trás no caminho.", {"flags": ["knockback"], "dmg": 0.4})]},
	})
	_tower({
		"id": "vinegar", "name": "Vinagre", "formula": "CH₃COOH", "price": 200, "cat": "chem",
		"color": "#c9a45c", "shape": "vinegar", "hotkey": "R", "unlock": 3,
		"damage": 6.0, "range": 110.0, "rate": 1.5, "proj": "drop",
		"protects": ["base"], "proj_color": "#e8c98a",
		"desc": "Borrife ácido fraco para neutralizar bases cáusticas.",
		"why": "O ácido acético do vinagre neutraliza bases, formando sal e água.",
		"curious": "O vinagre é um ácido fraco, seguro o bastante para usar na cozinha.",
		"paths": {
			"A": [
				_u("Ácido mais forte", 160, "+60% de dano.", {"dmg": 0.6}),
				_u("Spray duplo", 280, "Atinge 2 alvos.", {"targets": 1}),
				_u("Névoa ácida", 480, "Dano em área.", {"splash": 50.0, "dmg": 0.4}),
				_u("Banho neutralizante", 1150, "Área enorme de neutralização.", {"splash": 96.0, "dmg": 1.0})],
			"B": [
				_u("Dose maior", 150, "+30% de cadência.", {"rate": 0.3}),
				_u("Viscosidade", 280, "Deixa o inimigo mais lento.", {"slow_factor": 0.6, "slow_time": 2.0}),
				_u("Frasco reforçado", 420, "Resiste a Corrosivo e ganha alcance.", {"flags": ["anti_corrosive"], "range": 0.1}),
				_u("Poça reativa", 1050, "Deixa uma poça neutralizante no chão.", {"flags": ["puddle"], "dmg": 0.3})]},
	})
	_tower({
		"id": "water", "name": "Água", "formula": "H₂O", "price": 150, "cat": "gas",
		"color": "#4fb3e8", "shape": "water", "hotkey": "T", "unlock": 1,
		"damage": 5.0, "range": 116.0, "rate": 1.6, "proj": "drop",
		"protects": ["gas", "inflamavel"], "proj_color": "#7fd4ff",
		"desc": "Dilui e resfria: ajuda contra amônia e fogo.",
		"why": "A água dissolve muitos gases e absorve calor, reduzindo a temperatura.",
		"curious": "A água tem alto calor específico: precisa de muita energia para esquentar.",
		"paths": {
			"A": [
				_u("Jato pressurizado", 140, "+70% de dano.", {"dmg": 0.7}),
				_u("Dois bicos", 250, "Atinge 2 alvos.", {"targets": 1}),
				_u("Aspersão", 440, "Dano em área.", {"splash": 60.0, "dmg": 0.5}),
				_u("Diluição total", 1100, "Área enorme e inimigos mais lentos.", {"splash": 118.0, "dmg": 1.1, "slow_factor": 0.7, "slow_time": 2.0})],
			"B": [
				_u("Bomba rápida", 130, "+40% de cadência.", {"rate": 0.4}),
				_u("Água gelada", 260, "Resfria e atrasa os inimigos.", {"slow_factor": 0.55, "slow_time": 2.5}),
				_u("Mangueira longa", 400, "+30% de alcance.", {"range": 0.3}),
				_u("Poça refrescante", 1000, "Deixa uma poça que resfria quem passar.", {"flags": ["puddle"], "dmg": 0.3, "slow_factor": 0.8, "slow_time": 1.5})]},
	})
	_tower({
		"id": "sand", "name": "Areia / Vermiculita", "formula": "SiO₂", "price": 250, "cat": "rad",
		"color": "#d9b26a", "shape": "sand", "hotkey": "U", "unlock": 4,
		"damage": 9.0, "range": 102.0, "rate": 1.2, "proj": "drop",
		"protects": ["metal", "reativo_agua"], "proj_color": "#e6c890",
		"desc": "Contém metais reativos e derramamentos, sem usar água.",
		"why": "Areia e vermiculita absorvem líquidos e isolam materiais reativos da umidade.",
		"curious": "Vermiculita é um mineral expandido usado em jardinagem e em contenção de derramamentos.",
		"paths": {
			"A": [
				_u("Grão grosso", 160, "+60% de dano.", {"dmg": 0.6}),
				_u("Dois saquinhos", 280, "Atinge 2 alvos.", {"targets": 1}),
				_u("Monte de areia", 460, "Dano em área.", {"splash": 52.0, "dmg": 0.4}),
				_u("Barreira de contenção", 1200, "Área grande e desacelera.", {"splash": 100.0, "dmg": 1.1, "slow_factor": 0.72, "slow_time": 1.5})],
			"B": [
				_u("Fluxo rápido", 150, "+35% de cadência.", {"rate": 0.35}),
				_u("Areia pesada", 280, "Desacelera os inimigos.", {"slow_factor": 0.6, "slow_time": 2.0}),
				_u("Alcance maior", 440, "+30% de alcance.", {"range": 0.3}),
				_u("Vermiculita", 1050, "Contém também inflamáveis.", {"dmg": 0.4, "add_protect": "inflamavel"})]},
	})
	_tower({
		"id": "co2", "name": "Extintor de CO₂", "formula": "CO₂", "price": 400, "cat": "gas",
		"color": "#e05252", "shape": "co2", "hotkey": "Y", "unlock": 5,
		"damage": 12.0, "range": 126.0, "rate": 0.9, "proj": "snow",
		"protects": ["inflamavel", "explosivo"], "proj_color": "#d8f4ff",
		"desc": "Abafa o fogo deslocando o oxigênio e resfria explosivos.",
		"why": "O CO₂ é mais denso que o ar e abafa a chama, além de resfriar o material.",
		"curious": "Extintores de CO₂ não deixam resíduos, por isso são usados em laboratórios e painéis elétricos.",
		"paths": {
			"A": [
				_u("Carga extra", 220, "+60% de dano.", {"dmg": 0.6}),
				_u("Dois difusores", 360, "Atinge 2 alvos.", {"targets": 1}),
				_u("Nevasca de CO₂", 620, "Dano em área e desacelera.", {"splash": 58.0, "dmg": 0.5, "slow_factor": 0.7, "slow_time": 1.5}),
				_u("Supressão total", 1500, "Área grande com atordoamento curto.", {"splash": 108.0, "dmg": 1.1, "stun": 0.8})],
			"B": [
				_u("Válvula rápida", 200, "+35% de cadência.", {"rate": 0.35}),
				_u("Resfriamento", 340, "Desacelera fortemente.", {"slow_factor": 0.5, "slow_time": 3.0}),
				_u("Mangueira estendida", 520, "+30% de alcance.", {"range": 0.3}),
				_u("Isolamento térmico", 1300, "Protege torres próximas de explosões e corrosão.", {"flags": ["shield_aura"], "range": 0.1, "dmg": 0.2})]},
	})
	_tower({
		"id": "thio", "name": "Tiossulfato de sódio", "formula": "Na₂S₂O₃", "price": 400, "cat": "chem",
		"color": "#cfe7ef", "shape": "thio", "hotkey": "O", "unlock": 7,
		"damage": 11.0, "range": 120.0, "rate": 1.2, "proj": "drop",
		"protects": ["oxidante", "gas"], "proj_color": "#dff6ff",
		"desc": "Reduz oxidantes como cloro e água sanitária.",
		"why": "O tiossulfato é um redutor: ele 'consome' oxidantes fortes, tornando-os menos agressivos.",
		"curious": "É usado em laboratórios para neutralizar excesso de iodo e de cloro.",
		"paths": {
			"A": [
				_u("Cristais ativos", 220, "+60% de dano.", {"dmg": 0.6}),
				_u("Dose dupla", 360, "Atinge 2 alvos.", {"targets": 1}),
				_u("Reação em área", 580, "Dano em área.", {"splash": 56.0, "dmg": 0.5}),
				_u("Redução completa", 1400, "Área grande contra oxidantes.", {"splash": 102.0, "dmg": 1.0})],
			"B": [
				_u("Dissolução rápida", 200, "+35% de cadência.", {"rate": 0.35}),
				_u("Solução espessa", 340, "Desacelera o inimigo.", {"slow_factor": 0.62, "slow_time": 2.0}),
				_u("Aspersor longo", 520, "+30% de alcance.", {"range": 0.3}),
				_u("Banho neutralizador", 1250, "Deixa uma poça neutralizante.", {"flags": ["puddle"], "dmg": 0.35})]},
	})
	_tower({
		"id": "oil", "name": "Óleo mineral", "formula": "CₙH₂ₙ₊₂", "price": 300, "cat": "chem",
		"color": "#e0b45a", "shape": "oil", "hotkey": "P", "unlock": 9,
		"damage": 8.0, "range": 106.0, "rate": 1.3, "proj": "drop",
		"protects": ["reativo_agua"], "proj_color": "#f0cd7a",
		"desc": "Isola metais alcalinos da umidade do ar.",
		"why": "O óleo mineral cria uma película que impede o contato do metal com a água.",
		"curious": "Metais como o sódio são estocados sob óleo para não reagir com a umidade.",
		"paths": {
			"A": [
				_u("Óleo espesso", 170, "+60% de dano.", {"dmg": 0.6}),
				_u("Dois fios", 290, "Atinge 2 alvos.", {"targets": 1}),
				_u("Película isolante", 470, "Envolve e desacelera.", {"slow_factor": 0.65, "slow_time": 2.0, "dmg": 0.2}),
				_u("Encapsulamento", 1150, "Prende o inimigo por 1,5 s.", {"stun": 1.5, "dmg": 0.5})],
			"B": [
				_u("Gota rápida", 160, "+40% de cadência.", {"rate": 0.4}),
				_u("Camada dupla", 300, "+30% de dano e alcance.", {"range": 0.15, "dmg": 0.3}),
				_u("Mangueira longa", 440, "+30% de alcance.", {"range": 0.3}),
				_u("Isolamento total", 1050, "Deixa uma película no chão.", {"flags": ["puddle"], "dmg": 0.3})]},
	})
	_tower({
		"id": "edta", "name": "Quelante (EDTA)", "formula": "EDTA", "price": 450, "cat": "rad",
		"color": "#b48cff", "shape": "edta", "hotkey": "I", "unlock": 11,
		"damage": 18.0, "range": 136.0, "rate": 0.8, "proj": "drop",
		"protects": ["metal"], "proj_color": "#d4bcff",
		"desc": "Captura íons de metais pesados em complexos estáveis.",
		"why": "O EDTA envolve íons metálicos formando complexos, retirando-os do meio.",
		"curious": "Quelação também é usada na medicina para remover metais pesados do corpo.",
		"paths": {
			"A": [
				_u("Quelação forte", 250, "+70% de dano.", {"dmg": 0.7}),
				_u("Dose dupla", 420, "Atinge 2 alvos; a agulha perfura 1 inimigo extra.", {"targets": 1, "pierce": 1}),
				_u("Complexo estável", 700, "Prende metais por 1,2 s.", {"stun": 1.2}),
				_u("Quelante total", 1650, "Dano enorme e área.", {"dmg": 1.4, "splash": 46.0})],
			"B": [
				_u("Aplicação rápida", 240, "+40% de cadência.", {"rate": 0.4}),
				_u("Fixação prolongada", 400, "Deixa metais mais lentos.", {"slow_factor": 0.55, "slow_time": 2.5}),
				_u("Seringa longa", 620, "+35% de alcance.", {"range": 0.35}),
				_u("Captura em massa", 1500, "Poça de quelação no chão.", {"flags": ["puddle"], "dmg": 0.4})]},
	})
	_tower({
		"id": "dryice", "name": "Gelo seco", "formula": "CO₂ sólido", "price": 500, "cat": "gas",
		"color": "#bfeeff", "shape": "dryice", "hotkey": "A", "unlock": 13,
		"damage": 20.0, "range": 132.0, "rate": 0.85, "proj": "snow",
		"protects": ["explosivo", "criogenico", "inflamavel"], "proj_color": "#e6fbff",
		"desc": "Resfria explosivos e calor, estabilizando reações.",
		"why": "O gelo seco sublima a -78 °C e remove calor rapidamente, reduzindo a energia da reação.",
		"curious": "A sublimação é a passagem direta do sólido para o gás, sem derreter.",
		"paths": {
			"A": [
				_u("Granulação fina", 280, "+70% de dano.", {"dmg": 0.7}),
				_u("Dois jatos", 460, "Atinge 2 alvos.", {"targets": 1}),
				_u("Neblina congelante", 760, "Área com forte desaceleração.", {"splash": 62.0, "dmg": 0.4, "slow_factor": 0.6, "slow_time": 2.0}),
				_u("Criogenia absoluta", 1800, "Área enorme e atordoamento.", {"splash": 112.0, "dmg": 1.2, "stun": 1.2})],
			"B": [
				_u("Válvula turbo", 260, "+40% de cadência.", {"rate": 0.4}),
				_u("Gelo profundo", 440, "Desaceleração muito forte.", {"slow_factor": 0.45, "slow_time": 3.0}),
				_u("Armazenamento maior", 680, "+30% de alcance.", {"range": 0.3}),
				_u("Isolamento criogênico", 1600, "Protege torres próximas de explosões e corrosão.", {"flags": ["shield_aura"], "range": 0.1, "dmg": 0.2})]},
	})


func _build_recipes() -> void:
	ITEMS = {
		"agua": {"name": "Água", "formula": "H₂O", "color": "#7fd4ff", "icon": "water"},
		"bicarbonato": {"name": "Bicarbonato", "formula": "NaHCO₃", "color": "#f4f9ff", "icon": "flask"},
		"vinagre": {"name": "Vinagre", "formula": "CH₃COOH", "color": "#e8c98a", "icon": "flask"},
		"carvao": {"name": "Carvão ativado", "formula": "C", "color": "#5a5f73", "icon": "flask"},
		"sal": {"name": "Sal", "formula": "NaCl", "color": "#eef4ff", "icon": "flask"},
		"chumbo": {"name": "Chumbo", "formula": "Pb", "color": "#9aa9bd", "icon": "metal"},
		"concreto": {"name": "Concreto", "formula": "mistura", "color": "#b7c0c9", "icon": "flask"},
		"gelo_seco": {"name": "Gelo seco", "formula": "CO₂", "color": "#c9f2ff", "icon": "snow"},
		"silica": {"name": "Sílica", "formula": "SiO₂", "color": "#e0cba0", "icon": "flask"},
		"tiossulfato": {"name": "Tiossulfato", "formula": "Na₂S₂O₃", "color": "#dff6ff", "icon": "flask"},
		"quelante": {"name": "Quelante", "formula": "EDTA", "color": "#c8aaff", "icon": "flask"},
		"filtro": {"name": "Filtro", "formula": "malha", "color": "#8fa3b5", "icon": "flask"},
	}
	CREATED = {
		"espuma_co2": {"name": "Espuma de CO₂", "icon": "gas", "color": "#eafcff", "cooldown": 45.0,
			"effect": "area", "damage": 55.0, "radius": 112.0, "protects": ["acido", "inflamavel"],
			"slow_factor": 0.6, "slow_time": 3.0,
			"desc": "Poça de espuma que neutraliza ácidos e abafa fogo na área.",
			"science": "Bicarbonato + vinagre geram CO₂: a espuma abafa o oxigênio e dilui o ácido."},
		"filtro_gas": {"name": "Filtro de Gás", "icon": "gas", "color": "#bfe05a", "cooldown": 60.0,
			"effect": "buff", "buff_protect": "gas", "buff_range": 0.5, "buff_time": 20.0,
			"desc": "Aumenta em 50% o alcance das torres de gás por 20 s.",
			"science": "Carvão com malha fina adsorve mais gás, como um filtro de ar industrial."},
		"blindagem": {"name": "Blindagem Reforçada", "icon": "radiation", "color": "#9be15d", "cooldown": 70.0,
			"effect": "buff", "buff_protect": "radiacao", "buff_damage": 0.5, "buff_time": 20.0,
			"desc": "+50% de dano das torres de radiação por 20 s.",
			"science": "Concreto e chumbo juntos formam uma barreira densa contra radiação."},
		"solucao_salina": {"name": "Solução Salina", "icon": "water", "color": "#9fd0ff", "cooldown": 55.0,
			"effect": "buff", "buff_rate": 0.5, "buff_time": 15.0,
			"desc": "+50% de cadência de todas as torres por 15 s.",
			"science": "Soluções salinas absorvem calor e ajudam a resfriar equipamentos."},
		"filtro_combinado": {"name": "Filtro Combinado", "icon": "metal", "color": "#b48cff", "cooldown": 70.0,
			"effect": "area", "damage": 70.0, "radius": 104.0, "protects": ["metal"],
			"desc": "Quelação em área: remove metais pesados.",
			"science": "EDTA captura íons metálicos; o carvão ajuda a reter os complexos."},
		"nevoa_fria": {"name": "Névoa Fria", "icon": "snow", "color": "#c9f2ff", "cooldown": 60.0,
			"effect": "area", "damage": 20.0, "radius": 150.0, "protects": ["explosivo", "inflamavel"],
			"slow_factor": 0.4, "slow_time": 5.0,
			"desc": "Névoa que deixa todos os inimigos da área bem lentos.",
			"science": "Gelo seco resfria sem derreter: sublima e leva embora o calor."},
		"absorvente": {"name": "Absorvente Universal", "icon": "gas", "color": "#d9b26a", "cooldown": 65.0,
			"effect": "area", "damage": 45.0, "radius": 132.0, "protects": ["metal", "reativo_agua", "acido", "base"],
			"desc": "Absorve derramamentos de vários tipos.",
			"science": "Sílica e carvão têm enorme área interna e absorvem líquidos e vapores."},
		"neutralizador": {"name": "Solução Neutralizadora", "icon": "oxid", "color": "#9fe6ff", "cooldown": 50.0,
			"effect": "area", "damage": 85.0, "radius": 108.0, "protects": ["oxidante", "gas"],
			"desc": "Remove oxidantes e gases em área.",
			"science": "O tiossulfato reduz oxidantes; a água dissolve e dispersa os produtos."},
	}
	RECIPES = [
		{"a": "bicarbonato", "b": "vinagre", "result": "espuma_co2", "heat": false,
			"note": "A mistura borbulha porque libera gás carbônico.",
			"hint": "Pista: Misture um fermento de cozinha (Bicarbonato) com um ácido doméstico (Vinagre)."},
		{"a": "carvao", "b": "filtro", "result": "filtro_gas", "heat": false,
			"note": "A malha do filtro espalha o carvão e aumenta a adsorção.",
			"hint": "Pista: Combine Carvão ativado com uma malha de Filtro."},
		{"a": "chumbo", "b": "concreto", "result": "blindagem", "heat": true,
			"note": "O calor 'sinteriza' a mistura simbolicamente, criando uma blindagem densa.",
			"hint": "Pista: Junte um metal pesado denso (Chumbo) + Concreto e LIGUE O AQUECIMENTO."},
		{"a": "agua", "b": "sal", "result": "solucao_salina", "heat": false,
			"note": "O sal dissolve na água e forma uma solução condutora e refrescante.",
			"hint": "Pista: Dissolva Sal comum em Água."},
		{"a": "quelante", "b": "carvao", "result": "filtro_combinado", "heat": false,
			"note": "O quelante captura metais; o carvão segura os complexos.",
			"hint": "Pista: Misture Quelante (EDTA) com Carvão ativado."},
		{"a": "gelo_seco", "b": "agua", "result": "nevoa_fria", "heat": false,
			"note": "O gelo seco sublima e forma uma névoa fria e densa.",
			"hint": "Pista: Gelo seco em contato com Água sublima rapidamente."},
		{"a": "silica", "b": "carvao", "result": "absorvente", "heat": false,
			"note": "Sílica absorve líquidos e o carvão absorve vapores.",
			"hint": "Pista: Combine Sílica com Carvão ativado."},
		{"a": "tiossulfato", "b": "agua", "result": "neutralizador", "heat": false,
			"note": "A solução de tiossulfato reduz oxidantes em contato.",
			"hint": "Pista: Dissolva Tiossulfato em Água."},
	]


func enemy_layer(enemy_id: String, index: int) -> Dictionary:
	var e: Dictionary = ENEMIES[enemy_id]
	var layers: Array = e.layers
	var i := clampi(index, 0, layers.size() - 1)
	var l: Dictionary = layers[i].duplicate()
	l["hazard"] = l.get("hazard", e.hazard)
	l["color"] = l.get("color", e.color)
	l["shape"] = l.get("shape", e.shape)
	l["weak"] = l.get("weak", e.weak)
	l["props"] = e.props
	l["layer_index"] = i
	l["layer_count"] = layers.size()
	return l


func enemy_display_name(enemy_id: String, index: int) -> String:
	var e: Dictionary = ENEMIES[enemy_id]
	var layer: Dictionary = e.layers[clampi(index, 0, e.layers.size() - 1)]
	return layer.get("name", e.name)


func resist(enemy_id: String) -> float:
	var e: Dictionary = ENEMIES[enemy_id]
	return 1.0 - (0.25 if "denso" in e.props else 0.0)


func effectiveness(tower_id: String, enemy_id: String, layer: Dictionary) -> float:
	var td: Dictionary = TOWERS[tower_id]
	var ed: Dictionary = ENEMIES[enemy_id]
	var weak: Array = layer.get("weak", ed.weak)
	if tower_id in weak:
		return 1.0
	var hazard: String = layer.get("hazard", ed.hazard)
	if "gasoso" in ed.props and not ("gas" in td.protects):
		return 0.0
	if hazard in td.protects:
		return 0.85
	return 0.1


func tower_stats(id: String, level_a: int, level_b: int) -> Dictionary:
	var d: Dictionary = TOWERS[id]
	var st := {
		"damage": float(d.damage), "range": float(d.range), "rate": float(d.rate),
		"targets": 1, "splash": 0.0, "slow_factor": 1.0, "slow_time": 0.0, "stun": 0.0,
		"pierce": 0,
		"flags": [], "protects": (d.protects as Array).duplicate(),
		"bonus_emissor": 0.0, "bonus_boss": 0.0, "dmg_mult": 1.0, "range_mult": 1.0, "rate_mult": 1.0,
	}
	for path in ["A", "B"]:
		var lvl := level_a if path == "A" else level_b
		for i in lvl:
			var up: Dictionary = d.paths[path][i]
			var m: Dictionary = up.mods
			for f in m.get("flags", []):
				st.flags.append(f)
			for key in m.keys():
				match key:
					"dmg": st.dmg_mult += float(m[key])
					"range": st.range_mult += float(m[key])
					"rate": st.rate_mult += float(m[key])
					"targets": st.targets += int(m[key])
					"pierce": st.pierce += int(m[key])
					"splash": st.splash = maxf(st.splash, float(m[key]))
					"slow_factor": st.slow_factor = minf(st.slow_factor, float(m[key]))
					"slow_time": st.slow_time = maxf(st.slow_time, float(m[key]))
					"stun": st.stun = maxf(st.stun, float(m[key]))
					"bonus_emissor": st.bonus_emissor += float(m[key])
					"bonus_boss": st.bonus_boss += float(m[key])
					"add_protect": st.protects.append(str(m[key]))
	st.damage = float(d.damage) * st.dmg_mult
	st.range = float(d.range) * st.range_mult
	st.rate = float(d.rate) * st.rate_mult
	return st


func upgrade_cost(id: String, path: String, level: int) -> int:
	if level >= 4:
		return 0
	return int(TOWERS[id].paths[path][level].cost)


func can_upgrade(level_a: int, level_b: int, path: String) -> bool:
	if path == "A":
		if level_a >= 4:
			return false
		if level_b >= 3 and level_a >= 2:
			return false
		return true
	else:
		if level_b >= 4:
			return false
		if level_a >= 3 and level_b >= 2:
			return false
		return true


func upgrade_locked_reason(level_a: int, level_b: int, path: String) -> String:
	if path == "A" and level_b >= 3 and level_a >= 2:
		return "Máx. nível 2 (caminho B em 3+)"
	if path == "B" and level_a >= 3 and level_b >= 2:
		return "Máx. nível 2 (caminho A em 3+)"
	return ""


func build_wave(map_id: int, round_num: int, diff: String) -> Array:
	var d: Dictionary = DIFFICULTIES[diff]
	var loop_rounds: int = d.rounds
	var boss_id: String = MAPS[map_id].boss
	var out: Array = []
	var rng := RandomNumberGenerator.new()
	rng.seed = 9871 * (map_id + 3) + round_num * 137
	var is_boss := boss_id != "" and (round_num == 20 or round_num == loop_rounds)
	if is_boss:
		out.append({"id": boss_id, "t": 0.0, "path": 0})
		var escorts := 5 + int(round_num / 4)
		for i in escorts:
			var pool_b: Array = _pool(map_id, round_num)
			var pick: String = pool_b[rng.randi_range(0, pool_b.size() - 1)]
			out.append({"id": pick, "t": 3.0 + i * 1.6, "path": 0})
		return out
	var pool: Array = _pool(map_id, round_num)
	if pool.is_empty():
		pool = ["uranio"]
	var count := 5 + int(round_num * 0.85)
	var types := 1 + mini(3, int(round_num / 7.0))
	var chosen: Array = [pool[pool.size() - 1]]
	for i in types - 1:
		chosen.append(pool[rng.randi_range(0, pool.size() - 1)])
	var t := 0.0
	var idx := 0
	for i in count:
		var id: String = chosen[idx % chosen.size()]
		var path_idx := 0
		if MAPS[map_id].paths.size() > 1:
			path_idx = i % 2
		out.append({"id": id, "t": t, "path": path_idx})
		t += 0.62
		if (i + 1) % 5 == 0:
			t += 0.9
		if (i + 1) % 8 == 0:
			idx += 1
	# a small second wave of a different type halfway through
	if round_num >= 8:
		var extra: String = chosen[0] if chosen.size() == 1 else chosen[1]
		for i in 3:
			out.append({"id": extra, "t": t + 1.0 + i * 0.8, "path": 0})
	return out


func _pool(map_id: int, round_num: int) -> Array:
	var pool: Array = []
	for id in ENEMIES.keys():
		var e: Dictionary = ENEMIES[id]
		if map_id in e.maps and int(e.from) <= round_num and not ("boss" in e.props):
			pool.append(id)
	return pool


func hazard_label(h: String) -> String:
	return HAZARDS.get(h, {"name": h}).name


func tower_protects_text(id: String) -> String:
	var parts: Array = []
	for h in TOWERS[id].protects:
		parts.append(HAZARDS.get(h, {"name": h}).name)
	return ", ".join(parts)


func tower_weakness_icons(enemy_id: String, layer_index: int) -> Array:
	var layer := enemy_layer(enemy_id, layer_index)
	var weak: Array = layer.get("weak", [])
	var out: Array = []
	for t in weak:
		out.append({"id": t, "name": TOWERS[t].name, "formula": TOWERS[t].formula, "color": TOWERS[t].color})
	return out


func recipe_for(a: String, b: String, heat: bool) -> Dictionary:
	for r in RECIPES:
		if r.a == a and r.b == b and r.heat == heat:
			return r
		if r.a == b and r.b == a and r.heat == heat:
			return r
	return {}


func recipe_available(a: String, b: String) -> Dictionary:
	for r in RECIPES:
		if (r.a == a and r.b == b) or (r.a == b and r.b == a):
			return r
	return {}


func get_created(id: String) -> Dictionary:
	return CREATED.get(id, {})
