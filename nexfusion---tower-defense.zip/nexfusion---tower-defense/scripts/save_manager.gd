extends Node
## Persistent progress for Nexfusion Tower Defense (user://nexfusion_save.json).

const SAVE_PATH := "user://nexfusion_save.json"

var data: Dictionary = {}


func _ready() -> void:
	data = _defaults()
	load_game()


func _defaults() -> Dictionary:
	return {
		"records": {},
		"seen_enemies": ["uranio", "amonia", "sulfurico"],
		"seen_towers": ["lead", "bicarb", "water"],
		"recipes": [],
		"inventory": {
			"agua": 3, "bicarbonato": 3, "vinagre": 2, "carvao": 2, "sal": 2,
			"chumbo": 2, "concreto": 2, "gelo_seco": 1, "silica": 1,
			"tiossulfato": 1, "quelante": 1, "filtro": 1,
		},
		"created": {},
		"backpack": [],
		"tutorial_seen": false,
		"options": {"sfx": 0.8, "speed": 1, "tips": true, "lang": "pt"},
	}


func load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var txt := f.get_as_text()
	f.close()
	var parsed = JSON.parse_string(txt)
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	var d := _defaults()
	for key in parsed.keys():
		if key == "options" and typeof(parsed[key]) == TYPE_DICTIONARY:
			for ok in parsed[key].keys():
				# only known keys survive: "music" from old saves is dropped
				if d.options.has(ok):
					d.options[ok] = parsed[key][ok]
		elif key in d:
			d[key] = parsed[key]
	data = d


func save_game() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify(data, "\t"))
	f.close()


func opt(key: String, fallback = null):
	return data.options.get(key, fallback)


func set_opt(key: String, value) -> void:
	data.options[key] = value
	save_game()


func best(map_id: int) -> int:
	return int(data.records.get(str(map_id), 0))


func record_round(map_id: int, round_num: int) -> void:
	var key := str(map_id)
	if round_num > int(data.records.get(key, 0)):
		data.records[key] = round_num
		save_game()


func mark_enemy(id: String) -> void:
	if not (id in data.seen_enemies):
		data.seen_enemies.append(id)
		save_game()


func mark_tower(id: String) -> void:
	if not (id in data.seen_towers):
		data.seen_towers.append(id)
		save_game()


func has_recipe(result_id: String) -> bool:
	return result_id in data.recipes


func discover(result_id: String) -> bool:
	if result_id in data.recipes:
		return false
	data.recipes.append(result_id)
	data.created[result_id] = int(data.created.get(result_id, 0)) + 1
	save_game()
	return true


func add_created(result_id: String) -> void:
	data.created[result_id] = int(data.created.get(result_id, 0)) + 1
	save_game()


func inventory_count(id: String) -> int:
	return int(data.inventory.get(id, 0))


func add_item(id: String, n: int = 1) -> void:
	data.inventory[id] = inventory_count(id) + n
	save_game()


func has_ingredients(ids: Array) -> bool:
	var need := {}
	for id in ids:
		need[id] = int(need.get(id, 0)) + 1
	for id in need.keys():
		if inventory_count(id) < int(need[id]):
			return false
	return true


func consume_ingredients(ids: Array) -> bool:
	if not has_ingredients(ids):
		return false
	for id in ids:
		data.inventory[id] = inventory_count(id) - 1
	save_game()
	return true


func backpack() -> Array:
	var b: Array = data.backpack
	var out: Array = []
	for id in b:
		if id in data.created:
			out.append(id)
	return out


func equip(item_id: String) -> bool:
	if not (item_id in data.created):
		return false
	if item_id in data.backpack:
		return false
	if data.backpack.size() >= 4:
		return false
	data.backpack.append(item_id)
	save_game()
	return true


func unequip(item_id: String) -> void:
	data.backpack.erase(item_id)
	save_game()


func wipe() -> void:
	data = _defaults()
	save_game()
