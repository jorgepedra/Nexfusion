class_name ShopTile
extends Button
## Store card with hybrid interaction: press-and-drag or click-then-click.
## The press starts the battle placement immediately, so dragging out of the
## card keeps working (a plain "pressed" signal lost the drag).

var tower_id := ""
var affordable := true
var selected := false
var hotkey := ""
var battle = null


func _ready() -> void:
	focus_mode = Control.FOCUS_NONE
	custom_minimum_size = Vector2(126, 104)
	mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	flat = true
	add_theme_stylebox_override("normal", StyleBoxEmpty.new())
	add_theme_stylebox_override("hover", StyleBoxEmpty.new())
	add_theme_stylebox_override("pressed", StyleBoxEmpty.new())
	add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	mouse_entered.connect(queue_redraw)
	mouse_exited.connect(queue_redraw)


func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		if battle != null and affordable:
			battle.begin_placement(tower_id, true)
			accept_event()


func refresh() -> void:
	queue_redraw()


func _draw() -> void:
	var d: Dictionary = DB.TOWERS.get(tower_id, {})
	if d.is_empty():
		return
	var cat: Dictionary = DB.CATEGORIES[d.cat]
	var border := Color(cat.color)
	var bg := Color(0.05, 0.15, 0.23, 0.95)
	if selected:
		border = Color("#b8f0cc")
		bg = Color(0.09, 0.24, 0.3, 0.98)
	if not affordable:
		bg = Color(0.05, 0.1, 0.14, 0.95)
		border = Color(0.25, 0.32, 0.38, 0.9)
	if is_hovered() and affordable:
		bg = Color(0.09, 0.22, 0.32, 0.98)
	draw_style_box(UiTheme.box(bg, 11, 2, border), Rect2(Vector2.ZERO, size))
	if not selected:
		draw_rect(Rect2(0, 0, 5, size.y), Color(cat.color))
	draw_texture_rect(Sprites.get_tower(tower_id), Rect2(size.x * 0.5 - 26, size.y * 0.44 - 26, 52, 52), false)
	if not affordable:
		draw_rect(Rect2(Vector2(3, 3), size - Vector2(6, 6)), Color(0.02, 0.05, 0.08, 0.6))
	var font := ThemeDB.fallback_font
	var price_col := Color("#f4e6a0") if affordable else Color("#ff6b6b")
	draw_string(font, Vector2(31, size.y - 12), str(int(d.price)), HORIZONTAL_ALIGNMENT_LEFT, 80, 17, price_col)
	Art.draw_icon(self, "coin", Vector2(20, size.y - 18), 15.0, price_col)
	draw_string(font, Vector2(9, 20), str(hotkey), HORIZONTAL_ALIGNMENT_LEFT, 30, 13, Color(0.85, 0.95, 1, 0.9))
	if not affordable:
		Art.draw_icon(self, "lock", Vector2(size.x - 17, 18), 15.0, Color(1, 1, 1, 0.55))
	if selected:
		Art.draw_icon(self, "check", Vector2(size.x - 17, 18), 16.0, Color("#8ff0a8"))
