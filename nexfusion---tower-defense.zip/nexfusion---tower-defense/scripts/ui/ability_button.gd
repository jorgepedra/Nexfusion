class_name AbilityButton
extends Button
## Active laboratory item slot with cooldown ring.

var item_id := ""
var hotkey := 1
var cooldown_left := 0.0
var cooldown_total := 1.0
var aiming := false
var empty := true


func _ready() -> void:
	focus_mode = Control.FOCUS_NONE
	custom_minimum_size = Vector2(58, 58)
	flat = true
	for state in ["normal", "hover", "pressed", "focus"]:
		add_theme_stylebox_override(state, StyleBoxEmpty.new())
	mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	mouse_entered.connect(queue_redraw)
	mouse_exited.connect(queue_redraw)


func refresh() -> void:
	queue_redraw()


func _draw() -> void:
	var font := ThemeDB.fallback_font
	var bg := Color(0.05, 0.14, 0.21, 0.96)
	var border := Color("#9b6bff")
	if empty:
		bg = Color(0.05, 0.1, 0.15, 0.9)
		border = Color(0.35, 0.42, 0.5, 0.8)
	if aiming:
		border = Color("#b8f0cc")
	if is_hovered() and not empty:
		bg = Color(0.09, 0.2, 0.3, 0.98)
	draw_style_box(UiTheme.box(bg, 9, 2, border), Rect2(Vector2.ZERO, size))
	draw_string(font, Vector2(6, 15), str(hotkey), HORIZONTAL_ALIGNMENT_LEFT, 24, 12, Color(0.85, 0.95, 1, 0.9))
	if empty:
		Art.draw_icon(self, "plus", size * 0.5 + Vector2(2, 4), 18.0, Color(0.55, 0.65, 0.75, 0.7))
	else:
		var item: Dictionary = DB.CREATED.get(item_id, {})
		var col := Color(item.get("color", "#9b6bff"))
		Art.draw_icon(self, item.get("icon", "flask"), size * 0.5 + Vector2(2, 4), 26.0, col)
		if cooldown_left > 0.0:
			var frac := clampf(cooldown_left / maxf(0.1, cooldown_total), 0.0, 1.0)
			draw_rect(Rect2(3, 3, size.x - 6, (size.y - 6) * frac), Color(0.02, 0.04, 0.07, 0.68))
			draw_string(font, Vector2(0, size.y * 0.62), str(int(ceil(cooldown_left))), HORIZONTAL_ALIGNMENT_CENTER, size.x, 17, Color.WHITE)
		elif aiming:
			draw_arc(size * 0.5, size.x * 0.4, 0, TAU, 24, Color("#8ff0a8"), 2.0)
	if not empty and cooldown_left > 0.0:
		draw_arc(size * 0.5, size.x * 0.42, -PI / 2, -PI / 2 + TAU * (1.0 - cooldown_left / maxf(0.1, cooldown_total)), 26, Color("#8fe6ff"), 2.0)
