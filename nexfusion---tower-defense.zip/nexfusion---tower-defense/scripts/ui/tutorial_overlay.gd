class_name TutorialOverlay
extends Control
## Step-by-step guided overlay shown on the first match (and from the menu).
## It leaves the arena and the store clickable so the player learns by doing.

const STEPS := [
	{
		"text": "Bem-vindo à NEXFUSION! Impeça que substâncias perigosas cheguem à Base (canto direito). Cada inimigo tem uma fraqueza química real.",
		"arrow": "▶", "arrow_pos": Vector2(842, 300), "auto": false,
	},
	{
		"text": "Arraste a torre CHUMBO (Pb) ou BICARBONATO da loja à direita e solte-a em um espaço livre ao lado do caminho.",
		"arrow": "◀", "arrow_pos": Vector2(1156, 300), "auto": true,
	},
	{
		"text": "Excelente! Agora clique no botão verde PLAY (ou aperte ESPAÇO) para iniciar a primeira onda.",
		"arrow": "◀", "arrow_pos": Vector2(1150, 636), "auto": true,
	},
	{
		"text": "Fique atento à química: Chumbo bloqueia Radiação e Bicarbonato neutraliza Ácidos. Se usar a torre errada, aparecerá 'INEFICAZ!' e uma dica educativa.",
		"arrow": "▼", "arrow_pos": Vector2(470, 150), "auto": false,
	},
	{
		"text": "Clique em qualquer torre já colocada na arena para abrir os Caminhos de Upgrade (A e B), alterar a prioridade de alvo ou vendê-la.",
		"arrow": "◀", "arrow_pos": Vector2(310, 200), "auto": false,
	},
]

var battle = null
var step := 0
var panel: PanelContainer
var title: Label
var body: Label
var counter: Label
var arrow: Label
var next_btn: Button
var skip_btn: Button


func setup(b) -> void:
	battle = b
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_build()
	_show_step(0)


func _build() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.03, 0.05, 0.35)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(dim)

	arrow = UiTheme.label("▶", 44, Color("#b6f24a"))
	arrow.add_theme_color_override("font_outline_color", Color(0.02, 0.05, 0.08, 0.95))
	arrow.add_theme_constant_override("outline_size", 8)
	arrow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(arrow)

	panel = UiTheme.panel(Color(0.035, 0.11, 0.16, 0.98), 14, 2, Color("#8fd8ff"))
	panel.position = Vector2(292, 540)
	panel.size = Vector2(578, 112)
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(panel)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 4)
	panel.add_child(box)

	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 10)
	box.add_child(head)
	title = UiTheme.label("TUTORIAL", 16, Color("#b6f24a"))
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title)
	counter = UiTheme.label("", 12, Color("#9fc0d8"))
	head.add_child(counter)

	body = UiTheme.label("", 13, Color("#eaf6ff"))
	body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	body.custom_minimum_size = Vector2(540, 40)
	box.add_child(body)

	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", 8)
	box.add_child(actions)
	next_btn = UiTheme.button("Entendi", "check", 14, Color("#2f9e5f"))
	next_btn.custom_minimum_size = Vector2(140, 34)
	actions.add_child(next_btn)
	next_btn.pressed.connect(_advance)
	skip_btn = UiTheme.button("Pular Tutorial", "close", 13, Color("#42596b"))
	skip_btn.custom_minimum_size = Vector2(150, 34)
	skip_btn.mouse_filter = Control.MOUSE_FILTER_STOP
	actions.add_child(skip_btn)
	skip_btn.pressed.connect(finish)


func _show_step(i: int) -> void:
	step = i
	if i < 0 or i >= STEPS.size():
		finish()
		return
	var data: Dictionary = STEPS[i]
	body.text = str(data.text)
	counter.text = str(i + 1) + " / " + str(STEPS.size())
	arrow.text = str(data.arrow)
	arrow.position = Vector2(data.arrow_pos)
	if bool(data.auto):
		next_btn.text = "Aguardando..."
		next_btn.disabled = true
	else:
		next_btn.disabled = false
		next_btn.text = "Concluir" if i == STEPS.size() - 1 else "Entendi"
	arrow.modulate.a = 1.0
	var tw := arrow.create_tween()
	tw.set_loops(4)
	tw.tween_property(arrow, "modulate:a", 0.25, 0.45)
	tw.tween_property(arrow, "modulate:a", 1.0, 0.45)


func _advance() -> void:
	Snd.play_sfx("click")
	_show_step(step + 1)


func notify(kind: String) -> void:
	if kind == "place" and step == 1:
		_show_step(2)
	elif kind == "round" and step == 2:
		_show_step(3)


func blocks(pos: Vector2) -> bool:
	if panel != null and panel.visible and panel.get_global_rect().has_point(pos):
		return true
	if skip_btn != null and skip_btn.get_global_rect().has_point(pos):
		return true
	return false


func finish() -> void:
	Snd.play_sfx("confirm")
	Store.data["tutorial_seen"] = true
	Store.save_game()
	if battle != null and is_instance_valid(battle):
		battle.tutorial = null
	queue_free()
