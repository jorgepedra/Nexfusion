class_name LabBackdrop
extends Control
## Animated laboratory background used behind menus.

var t := 0.0
var dim := true
var show_towers := true
var mode := "school"


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_process(true)


func _process(delta: float) -> void:
	t += delta
	queue_redraw()


func _draw() -> void:
	Art.draw_lab_background(self, size, t, dim)
	if show_towers:
		var base_y := size.y - 96.0
		var xs := [size.x * 0.13, size.x * 0.87, size.x * 0.75]
		var ids := ["lead", "bicarb", "charcoal"]
		for i in 3:
			Art.draw_waving_tower(self, ids[i], Vector2(xs[i], base_y), 62.0, t, i * 1.7)
	# rising bubbles
	for i in 22:
		var bx := fmod(i * 137.7, size.x)
		var by := size.y - fmod(t * (18.0 + i % 7 * 6.0) + i * 61.0, size.y)
		var r := 2.0 + (i % 4)
		draw_circle(Vector2(bx, by), r, Color(0.75, 0.95, 1.0, 0.22))
		draw_arc(Vector2(bx, by), r, 0, TAU, 10, Color(0.9, 1, 1, 0.18), 1.0)
	# soft vignette
	var v := 0.35
	for i in 6:
		var inset := i * 18.0
		draw_rect(Rect2(inset, inset, size.x - inset * 2, size.y - inset * 2), Color(0.02, 0.05, 0.09, v * 0.12), false, 22.0)
