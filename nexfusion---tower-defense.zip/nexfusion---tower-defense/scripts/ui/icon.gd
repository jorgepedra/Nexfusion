class_name UIcon
extends Control
## Small vector icon widget used everywhere in the interface.

var kind := "flask":
	set(v):
		kind = v
		queue_redraw()
var tint := Color.WHITE:
	set(v):
		tint = v
		queue_redraw()


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	resized.connect(queue_redraw)


func _draw() -> void:
	var s := minf(size.x, size.y)
	if s <= 0:
		s = 22.0
	Art.draw_icon(self, kind, size * 0.5, s, tint)
