class_name UpgradeCard
extends Button
## Custom-drawn upgrade path card with level dots, price and lock state.

var tower_id := ""
var path := "A"
var level_index := 0
var current_level := 0
var affordable := true
var locked := false
var locked_reason := ""
var is_max := false
var title := ""
var desc := ""
var cost := 0


func _ready() -> void:
	focus_mode = Control.FOCUS_NONE
	custom_minimum_size = Vector2(0, 88)
	mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	flat = true
	for state in ["normal", "hover", "pressed", "focus"]:
		add_theme_stylebox_override(state, StyleBoxEmpty.new())
	mouse_entered.connect(queue_redraw)
	mouse_exited.connect(queue_redraw)


func refresh() -> void:
	queue_redraw()


func _draw() -> void:
	if tower_id == "":
		return
	var d: Dictionary = DB.TOWERS[tower_id]
	var ups: Array = d.paths[path]
	var accent := Color("#5fd36a") if path == "A" else Color("#63c3ff")
	var bg := Color(0.04, 0.12, 0.19, 0.96)
	if locked or is_max:
		bg = Color(0.05, 0.09, 0.12, 0.92)
	if not affordable and not is_max:
		bg = Color(0.13, 0.08, 0.09, 0.94)
	if is_hovered() and not locked and not is_max:
		bg = Color(0.08, 0.2, 0.28, 0.98)
	draw_style_box(UiTheme.box(bg, 9, 2, accent if not (locked or is_max) else Color(0.3, 0.38, 0.44)), Rect2(Vector2.ZERO, size))
	var font := ThemeDB.fallback_font
	draw_rect(Rect2(Vector2(8, 9), Vector2(20, 18)), accent)
	draw_string(font, Vector2(15, 23), path, HORIZONTAL_ALIGNMENT_LEFT, 16, 13, Color("#0a1a12"))
	var up_name := title if title != "" else str(ups[mini(level_index, 3)].name)
	draw_string(font, Vector2(36, 23), up_name, HORIZONTAL_ALIGNMENT_LEFT, size.x - 86, 14, Color("#eaf6ff"))
	if is_max:
		draw_string(font, Vector2(size.x - 62, 23), "MÁX", HORIZONTAL_ALIGNMENT_RIGHT, 50, 13, Color("#8fe6a8"))
	elif locked:
		draw_string(font, Vector2(size.x - 76, 23), "NÍVEL 2", HORIZONTAL_ALIGNMENT_RIGHT, 66, 12, Color("#ffb86b"))
	else:
		var pc := Color("#f4e6a0") if affordable else Color("#ff6b6b")
		draw_string(font, Vector2(size.x - 74, 23), str(cost) + " CP", HORIZONTAL_ALIGNMENT_RIGHT, 66, 13, pc)
	for i in 4:
		var c := Vector2(14 + i * 13, 38)
		if i < current_level:
			draw_circle(c, 4.0, accent)
		elif i == level_index and not is_max and not locked:
			draw_circle(c, 4.0, Color(accent.r, accent.g, accent.b, 0.35))
			draw_arc(c, 4.5, 0, TAU, 12, accent, 1.4)
		else:
			draw_circle(c, 3.4, Color(0.35, 0.45, 0.52, 0.65))
	if is_max:
		draw_string(font, Vector2(70, 42), "Caminho completo", HORIZONTAL_ALIGNMENT_LEFT, size.x - 78, 12, Color("#8fe6a8"))
	elif locked:
		Art.draw_icon(self, "lock", Vector2(size.x - 22, 40), 12.0, Color("#ffb86b"))
		draw_string(font, Vector2(70, 42), locked_reason, HORIZONTAL_ALIGNMENT_LEFT, size.x - 78, 11, Color("#ffb86b"))
	else:
		var up_desc := desc if desc != "" else str(ups[mini(level_index, 3)].desc)
		draw_multiline_string(font, Vector2(10, 58), up_desc, HORIZONTAL_ALIGNMENT_LEFT, size.x - 18, 11, 2, Color("#a9c7dd"))
	if current_level >= 1:
		draw_string(font, Vector2(10, 78), "Nível " + str(current_level) + "/4", HORIZONTAL_ALIGNMENT_LEFT, 100, 10, Color(0.7, 0.85, 0.95, 0.7))
