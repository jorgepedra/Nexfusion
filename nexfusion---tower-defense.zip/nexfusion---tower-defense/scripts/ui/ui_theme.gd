class_name UiTheme
extends Object
## Builds the laboratory UI theme and common widgets in code.

const BLUE := Color("#1f86c7")
const BLUE_DEEP := Color("#0d2b45")
const PANEL := Color("#102a42")
const PANEL_2 := Color("#163a58")
const LINE := Color("#4f7fa6")
const TEXT := Color("#eaf6ff")
const MUTED := Color("#9fc0d8")
const GREEN := Color("#2fbf71")
const YELLOW := Color("#f4c744")
const PURPLE := Color("#9b6bff")
const RED := Color("#e05252")


static func box(color: Color, radius: int = 10, border: int = 0, border_col: Color = LINE) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = color
	sb.corner_radius_top_left = radius
	sb.corner_radius_top_right = radius
	sb.corner_radius_bottom_left = radius
	sb.corner_radius_bottom_right = radius
	sb.set_border_width_all(border)
	sb.border_color = border_col
	sb.content_margin_left = 12
	sb.content_margin_right = 12
	sb.content_margin_top = 6
	sb.content_margin_bottom = 6
	return sb


static func make() -> Theme:
	var t := Theme.new()
	t.default_font_size = 17

	t.set_stylebox("normal", "Button", box(Color("#186a9e"), 10, 2, Color("#3aa3d8")))
	var hover := box(Color("#2494cf"), 10, 2, Color("#8fd8ff"))
	var pressed := box(Color("#0f4f78"), 10, 2, Color("#8fd8ff"))
	t.set_stylebox("hover", "Button", hover)
	t.set_stylebox("pressed", "Button", pressed)
	t.set_stylebox("disabled", "Button", box(Color("#26404f"), 10, 2, Color("#3c5a6b")))
	t.set_color("font_color", "Button", TEXT)
	t.set_color("font_hover_color", "Button", Color.WHITE)
	t.set_color("font_pressed_color", "Button", Color("#d6f2ff"))
	t.set_color("font_disabled_color", "Button", Color("#8298a6"))
	t.set_font_size("font_size", "Button", 19)

	t.set_stylebox("panel", "PanelContainer", box(PANEL, 14, 2, LINE))
	t.set_stylebox("panel", "Panel", box(PANEL, 14, 2, LINE))
	t.set_color("font_color", "Label", TEXT)
	t.set_color("font_color", "RichTextLabel", TEXT)
	t.set_stylebox("normal", "LineEdit", box(Color("#0a1f30"), 8, 1, LINE))
	t.set_color("font_color", "LineEdit", TEXT)
	t.set_stylebox("grabber_area", "VScrollBar", box(Color("#2b4b66"), 5))
	t.set_stylebox("grabber_area_highlight", "VScrollBar", box(Color("#3d6b8e"), 5))
	t.set_stylebox("scroll", "VScrollBar", box(Color("#0b2033"), 5))
	t.set_color("default_color", "RichTextLabel", TEXT)
	return t


static func label(text: String, size: int = 17, color: Color = TEXT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


static func wrapped(text: String) -> Label:
	var l := label(text, 15, MUTED)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l


static func button(text: String, icon: String = "", size: int = 19, color: Color = BLUE) -> Button:
	var b := Button.new()
	b.text = text if icon == "" else "   " + text
	b.add_theme_font_size_override("font_size", size)
	b.custom_minimum_size = Vector2(0, 46)
	b.focus_mode = Control.FOCUS_NONE
	var sb := box(color, 10, 2, color.lightened(0.35))
	b.add_theme_stylebox_override("normal", sb)
	b.add_theme_stylebox_override("hover", box(color.lightened(0.16), 10, 2, Color.WHITE))
	b.add_theme_stylebox_override("pressed", box(color.darkened(0.25), 10, 2, Color.WHITE))
	if icon != "":
		var ic := UIcon.new()
		ic.kind = icon
		ic.tint = Color.WHITE
		ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
		ic.size = Vector2(22, 22)
		ic.position = Vector2(16, 12)
		b.add_child(ic)
	return b


static func icon_button(kind: String, size: float = 22.0, color: Color = TEXT, bg: Color = Color(0, 0, 0, 0)) -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(44, 44)
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_stylebox_override("normal", box(bg, 10, 0))
	b.add_theme_stylebox_override("hover", box(Color(1, 1, 1, 0.12), 10, 0))
	b.add_theme_stylebox_override("pressed", box(Color(1, 1, 1, 0.2), 10, 0))
	var ic := UIcon.new()
	ic.kind = kind
	ic.tint = color
	ic.set_anchors_preset(Control.PRESET_FULL_RECT)
	ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(ic)
	return b


static func panel(color: Color = PANEL, radius: int = 14, border: int = 2, border_col: Color = LINE) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", box(color, radius, border, border_col))
	return p


static func hsep(h: int = 1, col: Color = LINE) -> Control:
	var c := ColorRect.new()
	c.color = Color(col.r, col.g, col.b, 0.5)
	c.custom_minimum_size = Vector2(0, h)
	return c


static func format_cp(v: int) -> String:
	return str(v)
