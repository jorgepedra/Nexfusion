extends Node
## Harness temporário de verificação (headless). Executa o jogo real e valida
## combate, divisão do slime, parry de granada, level up, hordas e save.

var falhas: int = 0
var _jogo: Node2D
var _player: Player
var _spawn: SpawnManager
var _hud: HUD


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	await get_tree().process_frame
	await _rodar()
	print("=== RESULTADO: %d falha(s) ===" % falhas)
	get_tree().quit(1 if falhas > 0 else 0)


func _ok(cond: bool, nome: String) -> void:
	if cond:
		print("[OK] ", nome)
	else:
		falhas += 1
		printerr("[FALHA] ", nome)


func _rodar() -> void:
	_jogo = load("res://scenes/jogo.tscn").instantiate() as Node2D
	add_child(_jogo)
	await get_tree().process_frame
	await get_tree().process_frame

	_player = _jogo.get_node_or_null("Mundo/Player") as Player
	_spawn = _jogo.get_node_or_null("SpawnManager") as SpawnManager
	_hud = _jogo.get_node_or_null("HUD") as HUD
	_ok(_player != null, "jogador instanciado")
	_ok(_spawn != null and _spawn._catalogo.size() >= 9, "catálogo de inimigos carregado (%d)" % (_spawn._catalogo.size() if _spawn != null else 0))
	_ok(_hud != null, "HUD instanciado")
	_ok(GlobalManager.partida_ativa and GlobalManager.horda_atual == 1, "partida iniciada na horda 1")
	_ok(_player.vida == _player.vida_maxima and _player.dash_cargas == 3, "vida e cargas de dash iniciais")

	# ---------- tiro e dano
	var dados_h: DadosInimigo = load("res://resources/inimigos/hidrogenio.tres") as DadosInimigo
	var alvo: Enemy = _spawn._instanciar(dados_h, _player.global_position + Vector2(200, 0))
	_ok(alvo != null, "inimigo básico spawnado")
	var vida_antes: float = alvo.vida
	_player.arma_pivot.rotation = 0.0
	_player._disparar(Vector2.RIGHT, 12.0, GlobalManager.arma_atual(), false)
	await get_tree().create_timer(0.35, true, false, true).timeout
	var ainda_vivo: bool = is_instance_valid(alvo) and not alvo.morto
	_ok((not ainda_vivo) or alvo.vida < vida_antes, "projétil causa dano/elimina inimigo")

	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		if is_instance_valid(n):
			n.queue_free()
	await get_tree().process_frame

	# ---------- moeda / ricochete (marksman)
	var moeda: MoedaAr = load("res://scenes/moeda_ar.tscn").instantiate() as MoedaAr
	_jogo.get_node("Mundo").add_child(moeda)
	moeda.configurar(_player.global_position, Vector2.RIGHT)
	await get_tree().create_timer(0.5, true, false, true).timeout
	var alvo_r: Enemy = _spawn._instanciar(dados_h, _player.global_position + Vector2(520, -60))
	var direcao_moeda: Vector2 = (moeda.global_position - _player.muzzle.global_position).normalized()
	_player._disparar(direcao_moeda, 20.0, GlobalManager.arma_atual(), false)
	await get_tree().create_timer(0.8, true, false, true).timeout
	_ok(not is_instance_valid(moeda), "tiro acerta a moeda no ar")
	_ok((not is_instance_valid(alvo_r)) or alvo_r.morto or alvo_r.vida < alvo_r.vida_max, "ricochete redireciona ao inimigo mais próximo")
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		if is_instance_valid(n):
			n.queue_free()
	await get_tree().process_frame

	# ---------- slime divisor 1 -> 2 -> 4
	var dados_s: DadosInimigo = load("res://resources/inimigos/slime_quimico.tres") as DadosInimigo
	var grande: EnemySlime = load("res://scenes/slime.tscn").instantiate() as EnemySlime
	_jogo.get_node("Mundo").add_child(grande)
	grande.configurar(dados_s, 3)
	grande.global_position = Vector2(300, 300)
	await get_tree().process_frame
	grande.receber_dano(99999.0)
	await get_tree().process_frame
	await get_tree().create_timer(0.25, true, false, true).timeout
	# conta apenas os slimes médios (o spawner comum também está ativo na arena)
	var medios: Array[Node] = []
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		if n is EnemySlime and (n as EnemySlime).estagio == 1:
			medios.append(n)
	_ok(medios.size() == 2, "slime grande divide em 2 médios (obtido %d)" % medios.size())
	for m: Node in medios:
		(m as Enemy).receber_dano(99999.0)
	await get_tree().process_frame
	var pequenos: int = 0
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		if n is EnemySlime and (n as EnemySlime).estagio == 2:
			pequenos += 1
	_ok(pequenos == 4, "slimes médios dividem em 4 pequenos (obtido %d)" % pequenos)
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		if is_instance_valid(n):
			n.queue_free()
	await get_tree().process_frame

	# ---------- granada rebatida
	var g: GranadaInimiga = load("res://scenes/granada_inimiga.tscn").instantiate() as GranadaInimiga
	_jogo.get_node("Mundo").add_child(g)
	g.configurar(_player.global_position, _player.global_position + Vector2(100, 0), 80.0, 15.0, null)
	var dano_antes: float = g.dano
	g.rebater(Vector2.RIGHT)
	_ok(g.refletida and g.dano > dano_antes, "parry rebate granada e multiplica o dano")
	await get_tree().create_timer(0.1, true, false, true).timeout

	# ---------- estilo / rank
	GlobalManager.registrar_estilo("TESTE", 200.0)
	_ok(GlobalManager.rank_estilo != "D" and GlobalManager.multiplicador_estilo > 1.0, "rank de estilo sobe (%s x%.2f)" % [GlobalManager.rank_estilo, GlobalManager.multiplicador_estilo])
	GlobalManager.registrar_abate(10)
	GlobalManager.registrar_abate(10)
	_ok(GlobalManager.combo_contagem >= 2, "combo registra abates consecutivos")
	GlobalManager.sofrer_dano_penalidade()
	_ok(GlobalManager.combo_contagem == 0, "dano encerra o combo e penaliza o estilo")

	# ---------- level up / cartas
	var nivel_antes: int = GlobalManager.nivel_run
	GlobalManager.adicionar_xp(GlobalManager.xp_necessario)
	await get_tree().process_frame
	_ok(GlobalManager.nivel_run == nivel_antes + 1, "XP sobe de nível")
	_ok(get_tree().paused and _hud._ov.visible, "overlay de level up abre e pausa a partida")
	_ok(_hud._ov._oferecidas.size() == 3, "três cartas são oferecidas")
	var dano_bonus_antes: float = _player.bonus_dano + _player.bonus_cadencia
	_hud._ov._ao_clicar(_hud._ov._oferecidas[0])
	await get_tree().process_frame
	_ok(not get_tree().paused and not _hud._ov.visible, "carta aplicada e partida retomada")
	var dano_bonus_depois: float = _player.bonus_dano + _player.bonus_cadencia + float(_player.projeteis_extra) + _player.critico_extra + _player.aura_dano + _player.velocidade + _player.cura_extra + _player.magnetismo_extra + float(_player.perfuracao_extra) + float(_player.cadeia_extra) + float(_player.ricochete_extra) + _player.area_explosao_extra + _player.dash_bonus + _player.vida_maxima
	_ok(dano_bonus_depois != dano_bonus_antes, "efeito da carta altera o jogador")

	# ---------- hordas e chefe
	var horda_antes: int = GlobalManager.horda_atual
	GlobalManager.concluir_horda()
	_ok(GlobalManager.horda_atual == horda_antes + 1, "horda avança ao limpar a arena")
	_spawn._iniciar_horda(10)
	await get_tree().create_timer(2.0, true, false, true).timeout
	var achou_chefe: bool = false
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		if n is Boss:
			achou_chefe = true
	_ok(achou_chefe, "chefe surge na horda 10")
	_ok(AudioManager._musica_atual == "chefe", "tema de chefe entra na batalha")
	_ok(AudioManager._bgm_cache.has("chefe"), "tema de chefe sintetizado/carregado")
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		if is_instance_valid(n):
			n.queue_free()
	await get_tree().process_frame

	# ---------- salto de horda (Shift+P)
	_spawn._iniciar_horda(3)
	var vivo_salto: Enemy = _spawn._instanciar(dados_h, _player.global_position + Vector2(300, 0))
	await get_tree().process_frame
	var ev_salto: InputEventKey = InputEventKey.new()
	ev_salto.physical_keycode = KEY_P
	ev_salto.shift_pressed = true
	ev_salto.pressed = true
	var horda_salto_antes: int = GlobalManager.horda_atual
	_jogo._unhandled_input(ev_salto)
	_ok(GlobalManager.horda_atual == horda_salto_antes + 1, "Shift+P avança uma horda")
	await get_tree().process_frame
	_ok(not is_instance_valid(vivo_salto) or vivo_salto.morto, "salto limpa os inimigos da arena")
	_spawn._iniciar_horda(31)
	_ok(not _spawn.pular_horda(), "salto não passa da horda 31")
	_spawn._iniciar_horda(4)

	# ---------- chefe final (horda 31)
	_ok(GlobalManager.HORDA_MAXIMA == 31, "horda máxima é a 31 (chefe final)")
	_ok(not _hud._pausa.has_signal("pular_horda_solicitado"), "menu de pausa não oferece pular horda")
	var dados_final: DadosInimigo = load("res://resources/inimigos/elemento_supremo.tres") as DadosInimigo
	_ok(dados_final != null and dados_final.ordem_chefe == 4, "catálogo tem o chefe final (ordem 4)")
	_ok(_spawn._eh_horda_chefe(31), "horda 31 é marcada como horda de chefe")
	var chefe_final: ChefeFinal = load("res://scenes/chefe_final.tscn").instantiate() as ChefeFinal
	_jogo.get_node("Mundo").add_child(chefe_final)
	chefe_final.configurar(dados_final, 31)
	chefe_final.global_position = Vector2(1200, -260)
	await get_tree().process_frame
	_ok(chefe_final._chegando, "chefe final começa em cutscene de chegada")
	var vida_chegada: float = chefe_final.vida
	chefe_final.receber_dano(500.0)
	_ok(is_equal_approx(chefe_final.vida, vida_chegada), "chefe final é intocável durante a chegada")
	chefe_final._chegando = false
	chefe_final.receber_dano(200.0)
	_ok(chefe_final.vida < vida_chegada, "camada de proteção deixa passar dano reduzido")
	chefe_final._ataque_guardioes()
	await get_tree().create_timer(0.35, true, false, true).timeout
	_ok(chefe_final._guardioes.size() > 0, "guardiões protegem a vida do chefe")
	var vida_protegida: float = chefe_final.vida
	chefe_final.receber_dano(400.0)
	_ok(is_equal_approx(chefe_final.vida, vida_protegida), "com guardiões vivos o chefe não toma dano")
	for guardiao: Enemy in chefe_final._guardioes:
		if is_instance_valid(guardiao):
			guardiao.receber_dano(99999.0)
	await get_tree().create_timer(0.35, true, false, true).timeout
	chefe_final.receber_dano(400.0)
	_ok(chefe_final.vida < vida_protegida, "matar os guardiões destrava o dano")
	var velocidade_base_final: float = chefe_final.velocidade
	chefe_final._entrar_furia()
	_ok(chefe_final._furia and is_equal_approx(chefe_final.velocidade, velocidade_base_final * 1.75), "fúria acelera o chefe final em 1.75x")
	chefe_final.queue_free()
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		if is_instance_valid(n):
			n.queue_free()
	await get_tree().process_frame

	# ---------- fluxo real da horda 31 (sem vitória precoce)
	_spawn._iniciar_horda(31)
	await get_tree().create_timer(2.3, true, false, true).timeout
	var chefe_h31: ChefeFinal = null
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		if n is ChefeFinal:
			chefe_h31 = n as ChefeFinal
	_ok(chefe_h31 != null, "horda 31 invoca o chefe final")
	_ok(GlobalManager.partida_ativa and not _jogo._finalizada, "horda 31 não termina antes do chefe morrer")
	if chefe_h31 != null:
		chefe_h31.queue_free()
	_spawn._iniciar_horda(4)
	await get_tree().process_frame

	# ---------- pause
	await get_tree().process_frame
	_hud.alternar_pausa()
	_ok(get_tree().paused and _hud._pausa.visible, "ESC pausa a partida")
	_hud.alternar_pausa()
	_ok(not get_tree().paused, "pausa é retomada")

	# ---------- save
	var moedas_originais: int = GlobalManager.moedas
	GlobalManager.moedas = 1234
	GlobalManager.salvar()
	GlobalManager.moedas = 0
	GlobalManager.carregar()
	_ok(GlobalManager.moedas == 1234, "save/load preserva moedas")
	GlobalManager.moedas = moedas_originais
	GlobalManager.salvar()

	# ---------- morte / tela final
	_player.invulneravel = 0.0
	_player.receber_dano(99999.0)
	await get_tree().create_timer(2.0, true, false, true).timeout
	_ok(_hud._tela_morte.visible, "tela de estatísticas abre após a morte")
	_ok(not GlobalManager.partida_ativa and GlobalManager.ultimo_resultado.has("rank"), "resultado final registrado")
	GlobalManager.ultimo_resultado.clear()
