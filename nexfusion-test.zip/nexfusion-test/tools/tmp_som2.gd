extends Node
## Sonda temporária: música do chefe em segundo plano e uso no jogo.


func _ready() -> void:
	await get_tree().process_frame
	var am: Node = get_node("/root/AudioManager")
	print("[t] thread iniciada=", am._thread_chefe != null and am._thread_chefe.is_started())
	await get_tree().create_timer(2.5).timeout
	var t0: int = Time.get_ticks_msec()
	var stream: AudioStreamWAV = am.call("_sintetizar_musica", "chefe") as AudioStreamWAV
	print("[t] demanda=", Time.get_ticks_msec() - t0, "ms  amostras=", stream.data.size() / 2, "  loop=", stream.loop_mode == AudioStreamWAV.LOOP_FORWARD)
	var t1: int = Time.get_ticks_msec()
	var de_novo: AudioStreamWAV = am.call("_sintetizar_musica", "chefe") as AudioStreamWAV
	print("[t] cache=", Time.get_ticks_msec() - t1, "ms  mesmo=", de_novo == stream)
	am.call("tocar_bgm", "chefe")
	print("[t] tema atual=", am._musica_atual, " tocando=", am._musica_a.playing or am._musica_b.playing)
	get_tree().quit(0)
