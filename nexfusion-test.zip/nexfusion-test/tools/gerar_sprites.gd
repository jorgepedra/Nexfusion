extends SceneTree
## Gerador de pixel art (executado por tools/gerar_art.sh).
## Desenha todos os sprites por código e grava PNGs em res://sprites/.
## Paleta limitada, contorno automático e escala inteira = look pixel art coeso.

const OUTLINE: Color = Color("11121c")
const SPRITES_DIR: String = "res://sprites"

var _img: Image
var _w: int = 0
var _h: int = 0


func _initialize() -> void:
	for d: String in ["player", "guns", "NPC", "map", "HUD", "enemies", "bosses", "props"]:
		DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(SPRITES_DIR.path_join(d)))

	_gerar_player()
	_gerar_armas()
	_gerar_inimigos()
	_gerar_chefes()
	_gerar_props()
	_gerar_tiles()
	_gerar_hud()
	print("[art] sprites gerados em ", SPRITES_DIR)
	quit()


# ---------------------------------------------------------------- infra
func _novo(w: int, h: int) -> void:
	_w = w
	_h = h
	_img = Image.create_empty(w, h, false, Image.FORMAT_RGBA8)
	_img.fill(Color(0, 0, 0, 0))


func _px(x: int, y: int, c: Color) -> void:
	if x < 0 or y < 0 or x >= _w or y >= _h:
		return
	if c.a <= 0.0:
		return
	_img.set_pixel(x, y, c)


func _rect(x: int, y: int, w: int, h: int, c: Color) -> void:
	for iy: int in range(y, y + h):
		for ix: int in range(x, x + w):
			_px(ix, iy, c)


func _ellipse(cx: float, cy: float, rx: float, ry: float, c: Color) -> void:
	for iy: int in range(int(cy - ry - 1.0), int(cy + ry + 2.0)):
		for ix: int in range(int(cx - rx - 1.0), int(cx + rx + 2.0)):
			var dx: float = (float(ix) - cx) / maxf(rx, 0.001)
			var dy: float = (float(iy) - cy) / maxf(ry, 0.001)
			if dx * dx + dy * dy <= 1.0:
				_px(ix, iy, c)


func _linha(x0: int, y0: int, x1: int, y1: int, c: Color) -> void:
	var dx: int = absi(x1 - x0)
	var dy: int = -absi(y1 - y0)
	var sx: int = 1 if x0 < x1 else -1
	var sy: int = 1 if y0 < y1 else -1
	var err: int = dx + dy
	var x: int = x0
	var y: int = y0
	while true:
		_px(x, y, c)
		if x == x1 and y == y1:
			break
		var e2: int = 2 * err
		if e2 >= dy:
			err += dy
			x += sx
		if e2 <= dx:
			err += dx
			y += sy


func _contorno(c: Color = OUTLINE) -> void:
	var base: Image = _img.duplicate()
	for y: int in range(_h):
		for x: int in range(_w):
			if base.get_pixel(x, y).a > 0.0:
				continue
			var vizinho: bool = false
			for o: Vector2i in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
				var nx: int = x + o.x
				var ny: int = y + o.y
				if nx < 0 or ny < 0 or nx >= _w or ny >= _h:
					continue
				if base.get_pixel(nx, ny).a > 0.0:
					vizinho = true
					break
			if vizinho:
				_px(x, y, c)


func _salvar(caminho: String) -> void:
	var full: String = ProjectSettings.globalize_path(SPRITES_DIR.path_join(caminho))
	var err: int = _img.save_png(full)
	if err != OK:
		printerr("[art] falha ao salvar ", caminho, " err=", err)


func _escurecer(c: Color, f: float = 0.62) -> Color:
	return Color(c.r * f, c.g * f, c.b * f, 1.0)


func _clarear(c: Color, f: float = 0.35) -> Color:
	return Color(lerpf(c.r, 1.0, f), lerpf(c.g, 1.0, f), lerpf(c.b, 1.0, f), 1.0)


# ---------------------------------------------------------------- player
func _gerar_player() -> void:
	var casaco: Color = Color("2b8f95")
	var casaco_escuro: Color = Color("1c666d")
	var visor: Color = Color("9df5ff")
	var pele: Color = Color("d9a37a")
	var bota: Color = Color("242b3d")
	var luva: Color = Color("16202e")

	_novo(16, 16)
	# botas
	_rect(3, 12, 4, 3, bota)
	_rect(9, 12, 4, 3, bota)
	_rect(3, 14, 4, 1, _escurecer(bota, 0.7))
	_rect(9, 14, 4, 1, _escurecer(bota, 0.7))
	# pernas
	_rect(4, 9, 3, 4, casaco_escuro)
	_rect(9, 9, 3, 4, casaco_escuro)
	# tronco
	_rect(3, 5, 10, 5, casaco)
	_rect(3, 5, 10, 1, _clarear(casaco, 0.2))
	_rect(3, 8, 10, 2, casaco_escuro)
	_rect(7, 6, 2, 3, Color("f2c14e"))  # fivela/reator
	# braços
	_rect(1, 6, 2, 4, casaco_escuro)
	_rect(13, 6, 2, 4, casaco_escuro)
	_rect(1, 9, 2, 2, luva)
	_rect(13, 9, 2, 2, luva)
	# cabeça / capacete
	_rect(4, 1, 8, 4, pele)
	_rect(5, 0, 6, 1, Color("3a3f52"))
	_rect(4, 1, 8, 1, Color("3a3f52"))
	_rect(4, 3, 8, 2, visor)
	_rect(4, 3, 8, 1, _clarear(visor, 0.5))
	_rect(11, 3, 1, 2, Color("5fd8ea"))
	# pescoço
	_rect(7, 4, 2, 1, _escurecer(pele, 0.75))
	_contorno()
	_salvar("player/player.png")


# ---------------------------------------------------------------- armas
func _gerar_armas() -> void:
	_arma("tungstenio", Color("8d97ab"), Color("c6cfe0"), "revolver")
	_arma("helio", Color("3fc7c0"), Color("a8f5ef"), "shotgun")
	_arma("ferro", Color("9a5f3c"), Color("d08a5a"), "cannon")
	_arma("litio", Color("8a5cf0"), Color("c9b0ff"), "smg")
	_arma("neonio", Color("ff7a59"), Color("ffc3ad"), "rod")
	_arma("mercurio", Color("b9c3cf"), Color("f0f4f8"), "blob")


func _arma(nome: String, cor: Color, brilho: Color, forma: String) -> void:
	_novo(14, 8)
	match forma:
		"revolver":
			_rect(1, 2, 9, 4, cor)
			_rect(1, 1, 3, 1, cor)
			_rect(6, 3, 4, 2, brilho)
			_rect(9, 2, 5, 2, _escurecer(cor, 0.8))
			_rect(1, 5, 3, 2, _escurecer(cor, 0.6))
			_px(9, 3, Color("fff6cf"))
		"shotgun":
			_rect(1, 2, 6, 4, cor)
			_rect(4, 1, 8, 2, _escurecer(cor, 0.85))
			_rect(4, 5, 8, 1, _escurecer(cor, 0.85))
			_rect(12, 2, 1, 4, brilho)
			_rect(1, 4, 2, 3, _escurecer(cor, 0.6))
		"cannon":
			_rect(0, 1, 6, 6, cor)
			_rect(4, 2, 6, 4, _escurecer(cor, 0.85))
			_rect(9, 1, 4, 6, brilho)
			_rect(11, 2, 3, 4, _escurecer(cor, 0.7))
			_rect(0, 3, 2, 4, _escurecer(cor, 0.55))
			_px(2, 4, Color("ffb45e"))
		"smg":
			_rect(1, 2, 8, 3, cor)
			_rect(8, 3, 5, 2, brilho)
			_rect(2, 5, 2, 3, _escurecer(cor, 0.65))
			_rect(5, 5, 2, 1, _escurecer(cor, 0.65))
			_px(12, 3, Color("fff2a8"))
		"rod":
			_rect(1, 2, 9, 4, cor)
			_rect(3, 3, 9, 2, brilho)
			_rect(11, 2, 2, 4, Color("fff6d5"))
			_px(1, 4, _escurecer(cor, 0.5))
		"blob":
			_ellipse(6.0, 4.0, 5.5, 3.2, cor)
			_ellipse(9.0, 3.5, 4.0, 2.2, brilho)
			_rect(12, 3, 2, 2, _escurecer(cor, 0.6))
			_px(3, 2, Color("ffffff"))
	_contorno()
	_salvar("guns/arma_%s.png" % nome)


# ---------------------------------------------------------------- inimigos
func _gerar_inimigos() -> void:
	_hidrogenio()
	_carbono()
	_ferro_enemy()
	_slime()
	_granadeiro()


func _hidrogenio() -> void:
	var corpo: Color = Color("c9d8ff")
	var gas: Color = Color("6c8cff")
	_novo(14, 14)
	_ellipse(7.0, 7.5, 5.0, 4.6, gas)
	_ellipse(7.0, 7.0, 3.6, 3.2, corpo)
	_ellipse(7.0, 6.4, 2.2, 1.6, _clarear(corpo, 0.5))
	_rect(4, 7, 2, 2, Color("1b2550"))
	_rect(8, 7, 2, 2, Color("1b2550"))
	_rect(3, 10, 8, 1, _escurecer(gas, 0.7))
	_px(2, 4, Color("ffffff"))
	_contorno()
	_salvar("enemies/hidrogenio.png")


func _carbono() -> void:
	var corpo: Color = Color("3d4557")
	var nucleo: Color = Color("ff9c3f")
	_novo(14, 14)
	_ellipse(7.0, 7.0, 4.2, 4.6, corpo)
	_ellipse(7.0, 7.0, 2.0, 2.2, nucleo)
	_ellipse(7.0, 7.0, 1.0, 1.1, Color("fff1c9"))
	for i: int in range(4):
		var ox: int = 1 if i % 2 == 0 else 11
		var oy: int = 3 + i * 2
		_linha(7, 7, ox, oy, _escurecer(corpo, 0.8))
		_px(ox, oy, nucleo)
	_contorno()
	_salvar("enemies/carbono.png")


func _ferro_enemy() -> void:
	var placa: Color = Color("7d848f")
	var placa2: Color = Color("b9c0c9")
	var ferrugem: Color = Color("a35a34")
	_novo(18, 18)
	_rect(3, 3, 12, 12, placa)
	_rect(4, 2, 10, 2, placa2)
	_rect(4, 4, 4, 4, placa2)
	_rect(10, 10, 4, 4, ferrugem)
	_rect(3, 3, 12, 1, _clarear(placa, 0.3))
	_rect(5, 6, 3, 2, Color("ffcf5c"))
	_rect(10, 6, 3, 2, Color("ffcf5c"))
	_rect(4, 14, 3, 2, Color("4a4f5c"))
	_rect(11, 14, 3, 2, Color("4a4f5c"))
	_contorno()
	_salvar("enemies/ferro.png")


func _slime() -> void:
	var corpo: Color = Color("6ee06a")
	var corpo2: Color = Color("3faa4a")
	var brilho: Color = Color("b7ffa1")
	_novo(20, 20)
	_ellipse(10.0, 13.0, 8.5, 6.0, corpo2)
	_ellipse(10.0, 12.0, 7.6, 5.6, corpo)
	_ellipse(7.5, 9.5, 3.6, 2.6, brilho)
	_rect(6, 12, 2, 3, Color("123018"))
	_rect(12, 12, 2, 3, Color("123018"))
	_px(7, 12, Color("ffffff"))
	_px(13, 12, Color("ffffff"))
	_rect(9, 16, 3, 1, Color("123018"))
	# bolhas internas
	_px(14, 8, brilho)
	_px(16, 11, brilho)
	_px(4, 14, brilho)
	_contorno()
	_salvar("enemies/slime.png")


func _granadeiro() -> void:
	var corpo: Color = Color("c8a23c")
	var corpo2: Color = Color("8a6b1f")
	var metal: Color = Color("4c5262")
	_novo(16, 16)
	# mochila de granadas
	_rect(2, 5, 3, 5, corpo2)
	_px(3, 4, Color("e0574a"))
	_px(3, 5, metal)
	# corpo
	_ellipse(8.5, 9.0, 5.2, 4.8, corpo)
	_ellipse(8.5, 7.5, 4.0, 3.4, _clarear(corpo, 0.18))
	# viseira
	_rect(5, 6, 7, 2, Color("2a3145"))
	_rect(6, 6, 2, 1, Color("8ef0ff"))
	# braço arremessador
	_rect(12, 8, 3, 3, corpo2)
	_rect(14, 7, 2, 2, metal)
	# pernas
	_rect(5, 13, 3, 2, metal)
	_rect(10, 13, 3, 2, metal)
	# antena/pavio
	_linha(8, 4, 6, 1, metal)
	_px(5, 1, Color("ff7a3c"))
	_contorno()
	_salvar("enemies/granadeiro.png")


# ---------------------------------------------------------------- chefes
func _gerar_chefes() -> void:
	_cloro()
	_mercurio_boss()
	_uranio()
	_elemento_supremo()


func _elemento_supremo() -> void:
	var casco: Color = Color("1c2a44")
	var casco2: Color = Color("2f4c72")
	var nucleo: Color = Color("9df5ff")
	var nucleo2: Color = Color("3fa8d8")
	var eletron: Color = Color("c8ffe8")
	_novo(40, 40)
	_ellipse(20.0, 20.0, 18.0, 18.0, casco)
	_ellipse(20.0, 19.5, 15.5, 15.5, casco2)
	# anéis de contenção
	for i: int in range(3):
		var y: int = 11 + i * 6
		_rect(7, y, 26, 1, _escurecer(casco, 0.55))
	# órbitas dos elementos
	_linha(4, 20, 36, 20, Color("2b6f8f"))
	_linha(9, 11, 31, 29, Color("2b6f8f"))
	_linha(31, 11, 9, 29, Color("2b6f8f"))
	# núcleo
	_ellipse(20.0, 20.0, 8.5, 8.5, nucleo2)
	_ellipse(20.0, 20.0, 5.6, 5.6, nucleo)
	_ellipse(18.0, 18.0, 2.6, 2.2, Color("ffffff"))
	# elétrons orbitando
	for p: Vector2i in [Vector2i(4, 20), Vector2i(36, 20), Vector2i(9, 29), Vector2i(31, 11)]:
		_ellipse(float(p.x), float(p.y), 2.6, 2.6, eletron)
	# coroa / antenas
	_rect(18, 1, 4, 2, Color("7ff0ff"))
	_rect(19, 3, 2, 3, Color("7ff0ff"))
	_rect(2, 24, 3, 8, _escurecer(casco, 0.35))
	_rect(35, 24, 3, 8, _escurecer(casco, 0.35))
	_contorno()
	_salvar("bosses/elemento_supremo.png")


func _cloro() -> void:
	var gas: Color = Color("7be36b")
	var gas2: Color = Color("3f9c46")
	var mascara: Color = Color("d7e6c8")
	_novo(40, 40)
	for i: int in range(7):
		var ang: float = TAU * float(i) / 7.0
		_ellipse(20.0 + cos(ang) * 10.0, 22.0 + sin(ang) * 9.0, 7.0, 7.0, gas2)
	_ellipse(20.0, 21.0, 13.0, 12.0, gas2)
	_ellipse(20.0, 20.0, 11.5, 10.5, gas)
	_ellipse(15.0, 14.0, 5.0, 4.0, _clarear(gas, 0.35))
	# máscara de gás
	_rect(13, 17, 14, 10, mascara)
	_rect(13, 17, 14, 1, _clarear(mascara, 0.4))
	_rect(15, 19, 4, 3, Color("22303a"))
	_rect(21, 19, 4, 3, Color("22303a"))
	_ellipse(20.0, 25.0, 3.0, 2.5, Color("4a5b46"))
	_rect(14, 29, 12, 2, _escurecer(mascara, 0.5))
	# olhos brilhantes
	_px(16, 20, Color("ffe97a"))
	_px(22, 20, Color("ffe97a"))
	_contorno()
	_salvar("bosses/cloro.png")


func _mercurio_boss() -> void:
	var metal: Color = Color("aeb8c6")
	var metal2: Color = Color("6f7b8c")
	var brilho: Color = Color("eef4fb")
	_novo(40, 40)
	for i: int in range(8):
		var ang: float = TAU * float(i) / 8.0
		_ellipse(20.0 + cos(ang) * 12.0, 21.0 + sin(ang) * 11.0, 4.5, 4.5, metal2)
	_ellipse(20.0, 21.0, 13.0, 12.5, metal2)
	_ellipse(20.0, 20.0, 11.5, 11.0, metal)
	_ellipse(15.0, 15.0, 5.0, 4.0, brilho)
	_rect(15, 18, 4, 3, Color("2b3340"))
	_rect(22, 18, 4, 3, Color("2b3340"))
	_px(16, 19, Color("9df5ff"))
	_px(23, 19, Color("9df5ff"))
	_rect(15, 25, 11, 2, Color("2b3340"))
	for i: int in range(5):
		_px(14 + i * 3, 25, Color("1b2230"))
	_px(26, 9, brilho)
	_px(9, 30, brilho)
	_contorno()
	_salvar("bosses/mercurio.png")


func _uranio() -> void:
	var casco: Color = Color("3a4a3c")
	var nucleo: Color = Color("a6ff4a")
	var nucleo2: Color = Color("4fd12b")
	_novo(44, 44)
	_ellipse(22.0, 24.0, 14.0, 13.0, casco)
	_ellipse(22.0, 22.0, 12.0, 11.0, _clarear(casco, 0.12))
	_ellipse(22.0, 21.0, 6.5, 6.0, nucleo2)
	_ellipse(22.0, 20.0, 4.0, 3.6, nucleo)
	_ellipse(20.0, 18.0, 2.0, 1.6, Color("f4ffd9"))
	# costelas de contenção
	for i: int in range(4):
		var y: int = 13 + i * 5
		_rect(9, y, 26, 1, _escurecer(casco, 0.6))
	_rect(8, 26, 3, 6, _escurecer(casco, 0.4))
	_rect(33, 26, 3, 6, _escurecer(casco, 0.4))
	# braços pesados
	_rect(4, 16, 4, 12, _escurecer(casco, 0.3))
	_rect(36, 16, 4, 12, _escurecer(casco, 0.3))
	_rect(3, 28, 5, 4, nucleo2)
	_rect(36, 28, 5, 4, nucleo2)
	# olhos
	_rect(16, 16, 3, 2, nucleo)
	_rect(26, 16, 3, 2, nucleo)
	_px(13, 9, nucleo)
	_px(31, 11, nucleo)
	_contorno()
	_salvar("bosses/uranio.png")


# ---------------------------------------------------------------- props
func _gerar_props() -> void:
	_moeda()
	_eletron()
	_isotopo()
	_granada_sprite()
	_particula()


func _moeda() -> void:
	_novo(10, 10)
	_ellipse(5.0, 5.0, 4.2, 4.2, Color("b8811f"))
	_ellipse(5.0, 4.6, 3.4, 3.4, Color("ffcf4a"))
	_ellipse(4.0, 3.6, 1.8, 1.6, Color("fff3bc"))
	_rect(4, 3, 2, 4, Color("b8811f"))
	_rect(4, 2, 2, 1, Color("b8811f"))
	_rect(4, 7, 2, 1, Color("b8811f"))
	_contorno()
	_salvar("props/moeda.png")


func _eletron() -> void:
	_novo(7, 7)
	_ellipse(3.0, 3.0, 3.2, 3.2, Color("1d6fa8"))
	_ellipse(3.0, 3.0, 2.2, 2.2, Color("59d8ff"))
	_ellipse(2.4, 2.4, 1.2, 1.0, Color("e8fbff"))
	_salvar("props/eletron.png")


func _isotopo() -> void:
	_novo(9, 9)
	_ellipse(4.0, 4.0, 4.0, 4.0, Color("8c1f45"))
	_rect(3, 1, 3, 7, Color("ff5f92"))
	_rect(1, 3, 7, 3, Color("ff5f92"))
	_rect(3, 2, 2, 2, Color("ffd3e2"))
	_contorno()
	_salvar("props/isotopo.png")


func _granada_sprite() -> void:
	_novo(10, 10)
	_ellipse(5.0, 6.0, 4.2, 3.8, Color("2f3a2c"))
	_ellipse(4.0, 4.6, 2.0, 1.6, Color("6f8a5e"))
	_rect(4, 1, 2, 2, Color("8a8f99"))
	_rect(3, 0, 4, 1, Color("b9bec8"))
	_px(7, 2, Color("ff7a3c"))
	_contorno()
	_salvar("props/granada.png")


func _particula() -> void:
	_novo(4, 4)
	_rect(1, 0, 2, 4, Color("ffffff"))
	_rect(0, 1, 4, 2, Color("ffffff"))
	_salvar("props/particula.png")


# ---------------------------------------------------------------- tiles
func _gerar_tiles() -> void:
	_novo(32, 32)
	var base: Color = Color("141a26")
	var linha: Color = Color("1d2637")
	var ponto: Color = Color("243049")
	_img.fill(base)
	for i: int in range(32):
		_px(i, 0, linha)
		_px(0, i, linha)
	_px(8, 8, ponto)
	_px(9, 8, ponto)
	_px(22, 5, ponto)
	_px(5, 22, ponto)
	_px(24, 24, ponto)
	_px(25, 24, ponto)
	_px(26, 17, linha)
	_salvar("map/tile_arena.png")

	# tile de "grade" para zonas de perigo
	_novo(32, 32)
	_img.fill(Color("1a1220"))
	for i: int in range(0, 32, 4):
		for j: int in range(32):
			if (i + j) % 8 < 2:
				_px(i, j, Color("2a1c33"))
	_salvar("map/tile_perigo.png")


# ---------------------------------------------------------------- hud
func _gerar_hud() -> void:
	# ícone de dash (seta dupla)
	_novo(12, 12)
	var c: Color = Color("9df5ff")
	_linha(2, 2, 6, 6, c)
	_linha(6, 6, 2, 10, c)
	_linha(6, 2, 10, 6, c)
	_linha(10, 6, 6, 10, c)
	_salvar("HUD/icone_dash.png")

	# ícone de coração/isotopo de vida
	_novo(12, 12)
	var v: Color = Color("ff5f92")
	_ellipse(4.0, 4.5, 3.0, 2.8, v)
	_ellipse(8.0, 4.5, 3.0, 2.8, v)
	_ellipse(6.0, 7.0, 3.6, 3.4, v)
	_rect(3, 2, 2, 2, Color("ffd3e2"))
	_contorno()
	_salvar("HUD/icone_vida.png")

	# ícone de estilo (raio)
	_novo(12, 12)
	var raio: Color = Color("ffcf4a")
	_rect(6, 1, 4, 2, raio)
	_rect(4, 3, 4, 2, raio)
	_rect(5, 5, 4, 2, raio)
	_rect(3, 7, 4, 2, raio)
	_rect(4, 9, 3, 2, raio)
	_salvar("HUD/icone_estilo.png")
