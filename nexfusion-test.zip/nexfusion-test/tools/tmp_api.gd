extends SceneTree
const ARQUIVO: String = "res://PAPYRUS+has+gone+TOO+FAR_+EVEN+FURTHER+(Soundtrack) [eS1ZpBbQW_0].mp3"
func _initialize() -> void:
	var s: AudioStreamMP3 = load(ARQUIVO) as AudioStreamMP3
	var pb: AudioStreamPlayback = s.instantiate_playback()
	pb.start(0.0)
	var t0: int = Time.get_ticks_msec()
	var energia: float = 0.0
	for i: int in range(22050):
		var f: PackedVector2Array = pb.mix_audio(44100.0, AudioStreamWAV.FORMAT_16_BITS)
		if f.size() > 0:
			energia += absf(f[0].x) + absf(f[0].y)
	print("22050 chamadas em ", (Time.get_ticks_msec() - t0) / 1000.0, "s energia=", energia, " pos=", pb.get_playback_position())
	quit()
