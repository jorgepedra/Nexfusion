extends SceneTree
## Sonda temporária: custo de geração do tema do chefe.


func _initialize() -> void:
	var script: GDScript = load("res://scripts/audio_manager.gd") as GDScript
	var am: Node = script.new() as Node
	var t0: int = Time.get_ticks_msec()
	var w: AudioStreamWAV = am.call("_sintetizar_musica", "chefe") as AudioStreamWAV
	var ms: int = Time.get_ticks_msec() - t0
	var dados: PackedByteArray = w.data
	var n: int = dados.size() / 2
	var pico: float = 0.0
	var soma: float = 0.0
	for i: int in range(n):
		var s: float = float(dados.decode_s16(i * 2)) / 32768.0
		pico = maxf(pico, absf(s))
		soma += s * s
	print("geracao=", ms, "ms  amostras=", n, "  duracao=", float(n) / float(w.mix_rate), "s")
	print("pico=", pico, "  rms=", sqrt(soma / float(maxi(1, n))), "  loop=", w.loop_mode == AudioStreamWAV.LOOP_FORWARD, "  taxa=", w.mix_rate)
	quit()
