import fs from "node:fs";
import path from "node:path";
import { MPEGDecoder } from "mpg123-decoder";

const dir = path.resolve("../..");
const arquivo = fs.readdirSync(dir).find((f) => f.toLowerCase().includes("papyrus") && f.endsWith(".mp3"));
const buf = fs.readFileSync(path.join(dir, arquivo));
const dec = new MPEGDecoder();
await dec.ready;
const { channelData, samplesDecoded, sampleRate } = dec.decode(buf);
const SR = sampleRate;
const N = samplesDecoded;
const mono = new Float32Array(N);
for (let i = 0; i < N; i++) mono[i] = (channelData[0][i] + (channelData[1]?.[i] ?? channelData[0][i])) * 0.5;

const FFT = 1024;
const HOP = Math.round(SR * 0.01);
const frames = Math.floor((Math.min(N, SR * 70) - FFT) / HOP);
const re = new Float64Array(FFT);
const im = new Float64Array(FFT);
const jan = new Float64Array(FFT);
for (let i = 0; i < FFT; i++) jan[i] = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (FFT - 1));

function fft(re, im) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) { [re[i], re[j]] = [re[j], re[i]]; [im[i], im[j]] = [im[j], im[i]]; }
  }
  for (let len = 2; len <= n; len <<= 1) {
    const ang = (-2 * Math.PI) / len;
    const wr = Math.cos(ang), wi = Math.sin(ang);
    for (let i = 0; i < n; i += len) {
      let cr = 1, ci = 0;
      for (let k = 0; k < len / 2; k++) {
        const ur = re[i + k], ui = im[i + k];
        const vr = re[i + k + len / 2] * cr - im[i + k + len / 2] * ci;
        const vi = re[i + k + len / 2] * ci + im[i + k + len / 2] * cr;
        re[i + k] = ur + vr; im[i + k] = ui + vi;
        re[i + k + len / 2] = ur - vr; im[i + k + len / 2] = ui - vi;
        const ncr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = ncr;
      }
    }
  }
}

const bandas = [[30, 100], [120, 350], [350, 900], [3000, 8000]];
const E = bandas.map(() => new Float64Array(frames));
const binHz = SR / FFT;
for (let f = 0; f < frames; f++) {
  const off = f * HOP;
  for (let i = 0; i < FFT; i++) { re[i] = mono[off + i] * jan[i]; im[i] = 0; }
  fft(re, im);
  for (let k = 1; k < FFT / 2; k++) {
    const hz = k * binHz;
    const mag = Math.hypot(re[k], im[k]);
    for (let b = 0; b < bandas.length; b++) if (hz >= bandas[b][0] && hz < bandas[b][1]) { E[b][f] += mag; break; }
  }
}

const BPM = parseFloat(process.argv[2] ?? "129");
const beat = 60 / BPM;
const inicial = parseFloat(process.argv[3] ?? "0");

// picos de energia (ataques) por banda
function picos(banda, limiarRel) {
  const s = E[banda];
  const max = Math.max(...s);
  const limiar = max * limiarRel;
  const out = [];
  let ultimo = -99;
  for (let f = 2; f < frames - 1; f++) {
    if (s[f] > limiar && s[f] > s[f - 1] * 1.15 && s[f] >= s[f + 1]) {
      const t = f * 0.01;
      if (t - ultimo >= 0.09) { out.push(t); ultimo = t; }
    }
  }
  return out;
}

for (let b = 0; b < bandas.length; b++) {
  const ps = picos(b, 0.55);
  const hist = new Float64Array(16);
  for (const t of ps) {
    const pos = ((t - inicial) / beat) * 4;
    hist[((Math.round(pos) % 16) + 16) % 16] += 1;
  }
  const total = ps.length || 1;
  console.log(`${bandas[b][0]}-${bandas[b][1]}`.padEnd(12), "ataques:", ps.length, " histograma16:", Array.from(hist, (v) => (v / total).toFixed(2)).join(" "));
}

const kicks = picos(0, 0.6);
console.log("\nprimeiros 24 ataques graves (s):", kicks.slice(0, 24).map((t) => t.toFixed(2)).join(" "));
console.log("intervalos (ms):", kicks.slice(1, 25).map((t, i) => ((t - kicks[i]) * 1000).toFixed(0)).join(" "));
