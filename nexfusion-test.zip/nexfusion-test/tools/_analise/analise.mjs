import fs from "node:fs";
import path from "node:path";
import { MPEGDecoder } from "mpg123-decoder";

const dir = path.resolve("../..");
const arquivo = fs.readdirSync(dir).find((f) => f.toLowerCase().includes("papyrus") && f.endsWith(".mp3"));
const buf = fs.readFileSync(path.join(dir, arquivo));
const dec = new MPEGDecoder();
await dec.ready;
const { channelData, samplesDecoded, sampleRate } = dec.decode(buf);
const L = channelData[0];
const R = channelData[1] ?? channelData[0];
const SR = sampleRate;
const N = samplesDecoded;
console.log("arquivo:", arquivo);
console.log("duracao:", (N / SR).toFixed(2), "s  sr:", SR, "canais:", channelData.length);

const mono = new Float32Array(N);
for (let i = 0; i < N; i++) mono[i] = (L[i] + R[i]) * 0.5;

// ---------- STFT ----------
const FFT = 1024;
const HOP = Math.round(SR * 0.01);
const maxSeg = Math.min(N, SR * 100); // primeiros 100 s bastam para a batida
const frames = Math.floor((maxSeg - FFT) / HOP);
const re = new Float64Array(FFT);
const im = new Float64Array(FFT);
const janela = new Float64Array(FFT);
for (let i = 0; i < FFT; i++) janela[i] = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (FFT - 1));

function fft(re, im) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      [re[i], re[j]] = [re[j], re[i]];
      [im[i], im[j]] = [im[j], im[i]];
    }
  }
  for (let len = 2; len <= n; len <<= 1) {
    const ang = (-2 * Math.PI) / len;
    const wr = Math.cos(ang);
    const wi = Math.sin(ang);
    for (let i = 0; i < n; i += len) {
      let cr = 1;
      let ci = 0;
      for (let k = 0; k < len / 2; k++) {
        const ur = re[i + k];
        const ui = im[i + k];
        const vr = re[i + k + len / 2] * cr - im[i + k + len / 2] * ci;
        const vi = re[i + k + len / 2] * ci + im[i + k + len / 2] * cr;
        re[i + k] = ur + vr;
        im[i + k] = ui + vi;
        re[i + k + len / 2] = ur - vr;
        im[i + k + len / 2] = ui - vi;
        const ncr = cr * wr - ci * wi;
        ci = cr * wi + ci * wr;
        cr = ncr;
      }
    }
  }
}

const low = new Float64Array(frames);
const mid = new Float64Array(frames);
const high = new Float64Array(frames);
const total = new Float64Array(frames);
const chroma = new Float64Array(12);
const binHz = SR / FFT;
const hzNota = (midi) => 440 * Math.pow(2, (midi - 69) / 12);
const pcDeHz = (hz) => {
  const midi = Math.round(69 + 12 * Math.log2(hz / 440));
  return ((midi % 12) + 12) % 12;
};

for (let f = 0; f < frames; f++) {
  const off = f * HOP;
  for (let i = 0; i < FFT; i++) {
    re[i] = mono[off + i] * janela[i];
    im[i] = 0;
  }
  fft(re, im);
  let eL = 0, eM = 0, eH = 0, eT = 0;
  for (let k = 1; k < FFT / 2; k++) {
    const hz = k * binHz;
    const mag = Math.hypot(re[k], im[k]);
    eT += mag;
    if (hz >= 30 && hz < 160) eL += mag;
    else if (hz >= 200 && hz < 2000) eM += mag;
    else if (hz >= 4000 && hz < 12000) eH += mag;
    if (hz > 60 && hz < 2000 && mag > 1) chroma[pcDeHz(hz)] += mag;
  }
  low[f] = eL;
  mid[f] = eM;
  high[f] = eH;
  total[f] = eT;
}

// ---------- BPM ----------
const fluxo = new Float64Array(frames);
for (let f = 1; f < frames; f++) fluxo[f] = Math.max(0, total[f] - total[f - 1]) + Math.max(0, low[f] - low[f - 1]) * 1.2;

function autocorrBpm() {
  const minLag = Math.round(0.28 / 0.01);
  const maxLag = Math.round(1.1 / 0.01);
  const pontuacoes = [];
  for (let lag = minLag; lag <= maxLag; lag++) {
    let s = 0;
    let n = 0;
    for (let i = 0; i + lag < frames; i++) {
      s += fluxo[i] * fluxo[i + lag];
      n++;
    }
    pontuacoes.push({ lag, bpm: 60 / (lag * 0.01), v: s / n });
  }
  const media = pontuacoes.reduce((a, b) => a + b.v, 0) / pontuacoes.length;
  pontuacoes.sort((a, b) => b.v - a.v);
  return pontuacoes.filter((p) => p.v > media).slice(0, 12);
}

const candidatos = autocorrBpm();
console.log("\nBPM candidatos:");
for (const c of candidatos.slice(0, 8)) console.log(`  ${c.bpm.toFixed(2)}  peso ${c.v.toFixed(1)}`);

// escolhe o candidato na faixa típica de boss 130-190 com maior peso
const faixa = candidatos.filter((c) => c.bpm >= 125 && c.bpm <= 195);
const bpm = (faixa[0] ?? candidatos[0]).bpm;
console.log("\nBPM escolhido:", bpm.toFixed(2));

// ---------- fase do pulso ----------
const passo = 60 / bpm; // segundos por batida
const passoFrames = passo / 0.01;
let melhorFase = 0;
let melhorSoma = -1;
for (let ph = 0; ph < passoFrames; ph += 1) {
  let s = 0;
  for (let f = Math.round(ph); f < frames; f += Math.round(passoFrames)) s += fluxo[f];
  if (s > melhorSoma) {
    melhorSoma = s;
    melhorFase = ph;
  }
}
console.log("fase do pulso:", (melhorFase * 0.01).toFixed(3), "s");

// ---------- grade de 16avos ----------
function grade(sinal, rotulo) {
  const passo16 = passoFrames / 4;
  const acc = new Float64Array(16);
  const cnt = new Float64Array(16);
  for (let f = 0; f < frames; f++) {
    const rel = (f - melhorFase) / passo16;
    const idx = ((Math.round(rel) % 16) + 16) % 16;
    acc[idx] += sinal[f];
    cnt[idx]++;
  }
  const vals = Array.from(acc, (v, i) => (cnt[i] ? v / cnt[i] : 0));
  const max = Math.max(...vals);
  const norm = vals.map((v) => v / (max || 1));
  console.log(`${rotulo}:`, norm.map((v) => v.toFixed(2)).join(" "));
  return norm;
}

console.log("\ngrade de 16avos (x = 1/16):");
const gKick = grade(low, "grave ");
const gMid = grade(mid, "medio ");
const gHigh = grade(high, "agudo ");
const gAll = grade(fluxo, "fluxo ");

// ---------- tonalidade ----------
const perfis = {
  maior: [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88],
  menor: [6.33, 2.68, 3.52, 5.38, 2.6, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17],
};
const nomes = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
const somaChroma = chroma.reduce((a, b) => a + b, 0);
const chromaN = Array.from(chroma, (v) => v / somaChroma);
let melhor = { nome: "", modo: "", score: -1 };
for (let rot = 0; rot < 12; rot++) {
  for (const modo of ["maior", "menor"]) {
    const p = perfis[modo];
    let s = 0;
    for (let i = 0; i < 12; i++) s += chromaN[(i + rot) % 12] * p[i];
    if (s > melhor.score) melhor = { nome: nomes[rot], modo, score: s };
  }
}
console.log("\ntonalidade provavel:", melhor.nome, melhor.modo, `score ${melhor.score.toFixed(3)}`);
console.log("chroma:", chromaN.map((v) => v.toFixed(3)).join(" "));

// ---------- baixo por compasso ----------
const compassoFrames = passoFrames * 4;
const totalCompassos = Math.floor((frames - melhorFase) / compassoFrames);
const baixos = [];
const notasBaixo = [];
for (let c = 0; c < totalCompassos; c++) {
  const ini = Math.round(melhorFase + c * compassoFrames);
  const fim = Math.min(frames, Math.round(ini + compassoFrames));
  // energia por semitom no grave (36..59 => C2..B3)
  const acum = new Float64Array(24);
  for (let f = ini; f < fim; f += 4) {
    const off = f * HOP;
    for (let i = 0; i < FFT; i++) {
      re[i] = mono[off + i] * janela[i];
      im[i] = 0;
    }
    fft(re, im);
    for (let k = 2; k < FFT / 2; k++) {
      const hz = k * binHz;
      if (hz < 55 || hz > 240) continue;
      const midi = Math.round(69 + 12 * Math.log2(hz / 440));
      if (midi < 33 || midi > 56) continue;
      acum[midi - 33] += Math.hypot(re[k], im[k]);
    }
  }
  let best = 0;
  for (let i = 1; i < acum.length; i++) if (acum[i] > acum[best]) best = i;
  const midi = best + 33;
  const pc = ((midi % 12) + 12) % 12;
  baixos.push(nomes[pc] + (Math.floor(midi / 12) - 1));
  notasBaixo.push(midi);
}
console.log("\nbaixo por compasso:", baixos.join(" "));

// ---------- estrutura (RMS por 2 s) ----------
const bloco = Math.round(SR * 2);
const rms = [];
for (let i = 0; i + bloco <= N; i += bloco) {
  let s = 0;
  for (let j = i; j < i + bloco; j += 8) s += mono[j] * mono[j];
  rms.push(Math.sqrt(s / (bloco / 8)));
}
const rmsMax = Math.max(...rms);
console.log("\nenvolucao (2 s por bloco):", rms.map((v) => (v / rmsMax).toFixed(2)).join(" "));

// ---------- melodia: nota dominante por 8avo ----------
const passo8 = passoFrames * 2;
const total8 = Math.min(64, Math.floor((frames - melhorFase) / passo8));
const melodia = [];
for (let b = 0; b < total8; b++) {
  const ini = Math.round(melhorFase + b * passo8);
  const fim = Math.min(frames, Math.round(ini + passo8));
  const acum = new Float64Array(36);
  for (let f = ini; f < fim; f += 3) {
    const off = f * HOP;
    for (let i = 0; i < FFT; i++) {
      re[i] = mono[off + i] * janela[i];
      im[i] = 0;
    }
    fft(re, im);
    for (let k = 2; k < FFT / 2; k++) {
      const hz = k * binHz;
      if (hz < 240 || hz > 1400) continue;
      const midi = Math.round(69 + 12 * Math.log2(hz / 440));
      if (midi < 57 || midi > 88) continue;
      acum[midi - 57] += Math.hypot(re[k], im[k]);
    }
  }
  let best = 0;
  for (let i = 1; i < acum.length; i++) if (acum[i] > acum[best]) best = i;
  const midi = best + 57;
  melodia.push(nomes[((midi % 12) + 12) % 12] + (Math.floor(midi / 12) - 1));
}
console.log("\nmelodia por 8avo:", melodia.join(" "));
