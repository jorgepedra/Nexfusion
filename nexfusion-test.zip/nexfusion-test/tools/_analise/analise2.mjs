import fs from "node:fs";
import path from "node:path";
import { MPEGDecoder } from "mpg123-decoder";

const dir = path.resolve("../..");
const arquivo = fs.readdirSync(dir).find((f) => f.toLowerCase().includes("papyrus") && f.endsWith(".mp3"));
const buf = fs.readFileSync(path.join(dir, arquivo));
const dec = new MPEGDecoder();
await dec.ready;
const { channelData, samplesDecoded, sampleRate } = dec.decode(buf);
const SR = sampleRate;
const N = samplesDecoded;
const mono = new Float32Array(N);
for (let i = 0; i < N; i++) mono[i] = (channelData[0][i] + (channelData[1]?.[i] ?? channelData[0][i])) * 0.5;

const FFT = 2048;
const HOP = Math.round(SR * 0.005); // 5 ms
const limite = Math.min(N, SR * 80);
const frames = Math.floor((limite - FFT) / HOP);
const re = new Float64Array(FFT);
const im = new Float64Array(FFT);
const jan = new Float64Array(FFT);
for (let i = 0; i < FFT; i++) jan[i] = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (FFT - 1));

function fft(re, im) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      [re[i], re[j]] = [re[j], re[i]];
      [im[i], im[j]] = [im[j], im[i]];
    }
  }
  for (let len = 2; len <= n; len <<= 1) {
    const ang = (-2 * Math.PI) / len;
    const wr = Math.cos(ang), wi = Math.sin(ang);
    for (let i = 0; i < n; i += len) {
      let cr = 1, ci = 0;
      for (let k = 0; k < len / 2; k++) {
        const ur = re[i + k], ui = im[i + k];
        const vr = re[i + k + len / 2] * cr - im[i + k + len / 2] * ci;
        const vi = re[i + k + len / 2] * ci + im[i + k + len / 2] * cr;
        re[i + k] = ur + vr; im[i + k] = ui + vi;
        re[i + k + len / 2] = ur - vr; im[i + k + len / 2] = ui - vi;
        const ncr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = ncr;
      }
    }
  }
}

const bandas = [
  [25, 90], [90, 200], [200, 400], [400, 900], [900, 2000],
  [2000, 4000], [4000, 7000], [7000, 12000],
];
const energia = bandas.map(() => new Float64Array(frames));
const binHz = SR / FFT;
for (let f = 0; f < frames; f++) {
  const off = f * HOP;
  for (let i = 0; i < FFT; i++) { re[i] = mono[off + i] * jan[i]; im[i] = 0; }
  fft(re, im);
  for (let k = 1; k < FFT / 2; k++) {
    const hz = k * binHz;
    const mag = Math.hypot(re[k], im[k]);
    for (let b = 0; b < bandas.length; b++) {
      if (hz >= bandas[b][0] && hz < bandas[b][1]) { energia[b][f] += mag; break; }
    }
  }
}

const onsetsBanda = energia.map((e) => {
  const o = new Float64Array(frames);
  for (let f = 1; f < frames; f++) o[f] = Math.max(0, Math.log1p(e[f]) - Math.log1p(e[f - 1]));
  return o;
});
const fluxo = new Float64Array(frames);
for (let f = 0; f < frames; f++) for (const o of onsetsBanda) fluxo[f] += o[f];

function melhoresLags(sinal, minBpm, maxBpm) {
  const minLag = Math.round((60 / maxBpm) / 0.005);
  const maxLag = Math.round((60 / minBpm) / 0.005);
  const out = [];
  for (let lag = minLag; lag <= maxLag; lag++) {
    let s = 0, n = 0;
    for (let i = 0; i + lag < frames; i++) { s += sinal[i] * sinal[i + lag]; n++; }
    out.push({ lag, bpm: 60 / (lag * 0.005), v: s / n });
  }
  const media = out.reduce((a, b) => a + b.v, 0) / out.length;
  return out.filter((p) => p.v > media * 1.4).sort((a, b) => b.v - a.v);
}

const cand = melhoresLags(fluxo, 60, 240);
console.log("candidatos:", cand.slice(0, 14).map((c) => `${c.bpm.toFixed(1)}(${c.v.toFixed(0)})`).join(" "));

// pulso de kick isolado
const candKick = melhoresLags(onsetsBanda[0], 60, 240);
console.log("candidatos kick:", candKick.slice(0, 10).map((c) => `${c.bpm.toFixed(1)}(${c.v.toFixed(0)})`).join(" "));

const bpm = parseFloat(process.argv[2] ?? "130.43");
const passo = 60 / bpm;
const passoFrames = passo / 0.005;

// fase pela energia do kick (grave)
let faseKick = 0, somaKick = -1;
for (let ph = 0; ph < Math.round(passoFrames); ph++) {
  let s = 0;
  for (let f = ph; f < frames; f += Math.round(passoFrames)) s += onsetsBanda[0][f];
  if (s > somaKick) { somaKick = s; faseKick = ph; }
}
console.log("BPM analisado:", bpm, " fase kick:", (faseKick * 0.005).toFixed(3), "s");

function grade(sinal, passos, rotulo) {
  const acc = new Float64Array(passos);
  const cnt = new Float64Array(passos);
  for (let f = 0; f < frames; f++) {
    const rel = (f - faseKick) / (passoFrames / (passos / 4));
    const idx = ((Math.round(rel) % passos) + passos) % passos;
    acc[idx] += sinal[f]; cnt[idx]++;
  }
  const vals = Array.from(acc, (v, i) => (cnt[i] ? v / cnt[i] : 0));
  const max = Math.max(...vals);
  console.log(rotulo.padEnd(12), vals.map((v) => (v / (max || 1)).toFixed(2)).join(" "));
  return vals.map((v) => v / (max || 1));
}

console.log("\ngrade de 16avos (16 passos = 1 compasso 4/4):");
for (let passos of [8, 16, 32]) {
for (let b = 0; b < bandas.length; b++) {
  grade(onsetsBanda[b], 16, `${bandas[b][0]}-${bandas[b][1]}`);
}

}

// energia média por 16avo (não só onset) — mostra acentos
console.log("\nenergia média por 16avo:");
for (let b = 0; b < bandas.length; b++) {
  const e = energia[b];
  const acc = new Float64Array(16), cnt = new Float64Array(16);
  for (let f = 0; f < frames; f++) {
    const idx = ((Math.round((f - faseKick) / (passoFrames / 4)) % 16) + 16) % 16;
    acc[idx] += e[f]; cnt[idx]++;
  }
  const vals = Array.from(acc, (v, i) => v / cnt[i]);
  const max = Math.max(...vals);
  console.log(`${bandas[b][0]}-${bandas[b][1]}`.padEnd(12), vals.map((v) => (v / max).toFixed(2)).join(" "));
}
