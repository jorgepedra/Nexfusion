class_name ChefeFinal
extends Boss
## Chefe final (horda 31) — O ELEMENTO SUPREMO.
## Chega numa cutscene em que a arena inteira treme. Estágio 1 tem camada de
## proteção; no estágio 2 entra em FÚRIA (1.75x de velocidade) e combina até
## dois ataques simultâneos, levemente mais fracos.
## Ataques: mão gigante, vômito ácido com placas seguras, super laser varrendo
## a arena, chuva diagonal com gota sólida e invocação de guardiões.

const ARENA: Rect2 = Rect2(0.0, 0.0, 2400.0, 1500.0)
const DURACAO_QUEDA: float = 3.0
const ALTURA_FINAL: float = 430.0
const REDUCAO_ESTAGIO_1: float = 0.7
const VELOCIDADE_FURIA: float = 1.75
const ELEMENTOS: Array[String] = [
	"H", "He", "Li", "Be", "C", "N", "O", "F", "Ne", "Na", "Mg", "Al",
	"Si", "P", "S", "Cl", "K", "Ca", "Fe", "Cu", "Ag", "Hg", "U",
]

var _chegando: bool = true
var _queda_t: float = 0.0
var _inicio_x: float = 1200.0
var _inicio_y: float = -260.0
var _tremor_t: float = 0.0
var _aura: float = 0.0
var _cooldown: float = 3.4
var _em_andamento: int = 0
var _guardioes: Array[Enemy] = []
var _tinha_guardioes: bool = false
var _aviso_escudo: float = 0.0
var _proximo: int = 0
var _angulo_aura: float = 0.0


func _ready() -> void:
	super._ready()
	_padrao_timer = 99999.0
	_invocar_timer = 99999.0
	z_index = 7
	if corpo != null:
		corpo.modulate = Color(0.85, 0.95, 1.0)


func _physics_process(delta: float) -> void:
	if morto:
		return
	if _chegando:
		_arrivar(delta)
		return
	_aura += delta
	queue_redraw()
	_limpar_guardioes()
	_aviso_escudo = maxf(0.0, _aviso_escudo - delta)
	super._physics_process(delta)
	if morto or not GlobalManager.partida_ativa:
		return
	if _cooldown > 0.0:
		_cooldown -= delta
	if _cooldown <= 0.0 and _em_andamento == 0:
		_iniciar_rodada()


# ------------------------------------------------------------------ chegada
func _arrivar(delta: float) -> void:
	if _queda_t <= 0.0:
		_inicio_x = global_position.x
		_inicio_y = global_position.y
	_queda_t += delta
	_aura += delta
	var p: float = clampf(_queda_t / DURACAO_QUEDA, 0.0, 1.0)
	var curva: float = p * p
	global_position = Vector2(lerpf(_inicio_x, ARENA.get_center().x, p), lerpf(_inicio_y, ALTURA_FINAL, curva))
	if corpo != null:
		corpo.modulate = Color(0.8 + p * 0.6, 0.9 + p * 0.2, 1.0)
	_tremor_t -= delta
	if _tremor_t <= 0.0:
		_tremor_t = 0.2
		Efeitos.tremor(2.5 + p * 13.0)
		if p > 0.35:
			Efeitos.particulas(get_parent(), global_position + Vector2(0, 80), Color("8ff3ff"), 6, 200.0, 0.5, 3.0)
	queue_redraw()
	if p >= 1.0:
		_chegando = false
		Efeitos.tremor(28.0)
		Efeitos.anel(get_parent(), global_position, 460.0, Color(1.0, 0.4, 0.3, 0.9), 0.9, 9.0)
		Efeitos.anel(get_parent(), global_position, 260.0, Color(0.6, 0.95, 1.0, 0.8), 0.6, 6.0)
		Efeitos.particulas(get_parent(), global_position, Color("ffb347"), 56, 460.0, 0.9, 4.5)
		AudioManager.tocar_sfx("explosao", 0.0, 0.05)
		GlobalManager.chefe_aviso.emit("FASE 1 — CAMADA DE PROTEÇÃO", "ROMPA OS GUARDIÕES E O ESCUDO")


# ------------------------------------------------------------------ ataques
func _iniciar_rodada() -> void:
	var disponiveis: Array[String] = ["mao", "acido", "laser", "chuva", "guardioes"]
	if not _guardioes.is_empty():
		disponiveis.erase("guardioes")
	var qtd: int = 2 if _furia else 1
	var fator: float = 0.72 if qtd > 1 else 1.0
	for i: int in range(qtd):
		if disponiveis.is_empty():
			break
		_proximo = (_proximo + 1) % disponiveis.size()
		var nome: String = disponiveis[_proximo % disponiveis.size()]
		disponiveis.erase(nome)
		_em_andamento += 1
		_executar(nome, fator)
	_cooldown = 1.7 if _furia else 2.5


func _executar(nome: String, fator: float) -> void:
	match nome:
		"mao":
			await _ataque_mao(fator)
		"acido":
			await _ataque_acido(fator)
		"laser":
			await _ataque_laser(fator)
		"chuva":
			await _ataque_chuva(fator)
		"guardioes":
			await _ataque_guardioes()
	_em_andamento = maxi(0, _em_andamento - 1)


func _ataque_mao(fator: float) -> void:
	if morto or not is_inside_tree():
		return
	var mao: MaoChefe = MaoChefe.new()
	mao.chefe = self
	get_parent().add_child(mao)
	mao.configurar(posicao_jogador(), 26.0 * fator, 118.0)
	AudioManager.tocar_sfx("perigo", -3.0, 0.06)
	GlobalManager.chefe_aviso.emit("MÃO COLOSSAL", "SAIA DA MARCA NO CHÃO")
	await mao.terminou
	if is_instance_valid(mao):
		mao.queue_free()


func _ataque_acido(fator: float) -> void:
	if morto or not is_inside_tree():
		return
	var placa: PlacasAcido = PlacasAcido.new()
	placa.chefe = self
	get_parent().add_child(placa)
	placa.configurar(self, _posicoes_placas(4 if not _furia else 5), 9.0 * fator, ARENA)
	AudioManager.tocar_sfx("perigo", -3.0, 0.05)
	GlobalManager.chefe_aviso.emit("VÔMITO ÁCIDO", "SUBA NAS PLACAS FLUTUANTES")
	await placa.terminou
	if is_instance_valid(placa):
		placa.queue_free()


func _ataque_laser(fator: float) -> void:
	if morto or not is_inside_tree():
		return
	var alvo: Player = jogador_atual()
	if alvo == null:
		return
	var laser: LaserChefe = LaserChefe.new()
	laser.chefe = self
	get_parent().add_child(laser)
	laser.configurar(global_position, alvo.global_position, 32.0 * fator)
	AudioManager.tocar_sfx("perigo", -2.0, 0.05)
	GlobalManager.chefe_aviso.emit("SUPER LASER", "ATRAVESSE COM O DASH")
	await laser.terminou
	if is_instance_valid(laser):
		laser.queue_free()


func _ataque_chuva(fator: float) -> void:
	if morto or not is_inside_tree():
		return
	var chuva: ChuvaDiagonal = ChuvaDiagonal.new()
	chuva.chefe = self
	get_parent().add_child(chuva)
	chuva.configurar(self, ARENA, fator)
	AudioManager.tocar_sfx("perigo", -4.0, 0.05)
	GlobalManager.chefe_aviso.emit("CHUVA DIAGONAL", "CUIDADO COM A GOTA SÓLIDA")
	await chuva.terminou
	if is_instance_valid(chuva):
		chuva.queue_free()


func _ataque_guardioes() -> void:
	var sm: Node = get_tree().get_first_node_in_group("spawn_manager")
	if sm == null or not sm.has_method("invocar_guardioes"):
		return
	GlobalManager.chefe_aviso.emit("GUARDIÕES ELEMENTAIS", "MATE-OS PARA ROMPER A PROTEÇÃO")
	AudioManager.tocar_sfx("chefe", -5.0, 0.05)
	var lista: Array = sm.call("invocar_guardioes", global_position, 3 if not _furia else 2) as Array
	_limpar_guardioes()
	for n: Variant in lista:
		var e: Enemy = n as Enemy
		if e != null and is_instance_valid(e):
			_guardioes.append(e)
	_tinha_guardioes = not _guardioes.is_empty()
	if _tinha_guardioes:
		for i: int in range(_guardioes.size()):
			Efeitos.anel(get_parent(), _guardioes[i].global_position, 90.0, Color(0.7, 0.6, 1.0, 0.8), 0.5, 3.0)
	await get_tree().create_timer(0.25).timeout


# ------------------------------------------------------------------ dano
func receber_dano(valor: float, critico: bool = false) -> void:
	if morto or _chegando:
		return
	_limpar_guardioes()
	if not _guardioes.is_empty():
		if _aviso_escudo <= 0.0:
			_aviso_escudo = 0.45
			Efeitos.texto_flutuante(get_parent(), global_position, "ESCUDO", Color("9df5ff"), 13)
			Efeitos.anel(get_parent(), global_position, 150.0, Color(0.6, 0.9, 1.0, 0.5), 0.3, 2.0)
		return
	var fator: float = 1.0 if _furia else REDUCAO_ESTAGIO_1
	super.receber_dano(maxf(1.0, valor * fator), critico)


func _entrar_furia() -> void:
	if _furia:
		return
	_furia = true
	velocidade *= VELOCIDADE_FURIA
	_cooldown = 0.8
	Efeitos.tremor(22.0)
	AudioManager.tocar_sfx("chefe", -1.0, 0.05)
	GlobalManager.registrar_estilo("FÚRIA ELEMENTAL", 15.0, Color("ff5f5f"))
	GlobalManager.chefe_aviso.emit("MODO FÚRIA", "ELEMENTOS DESCONTROLADOS — 1.75x VELOCIDADE")
	for i: int in range(4):
		Efeitos.anel(get_parent(), global_position, 200.0 + float(i) * 70.0, Color(1.0, 0.3, 0.3, 0.7), 0.7 + float(i) * 0.12, 6.0)
	if corpo != null:
		var tw: Tween = create_tween().set_loops(10)
		tw.tween_property(corpo, "modulate", Color(1.7, 0.55, 0.5), 0.16)
		tw.tween_property(corpo, "modulate", Color.WHITE, 0.16)


func _limpar_guardioes() -> void:
	var antes: int = _guardioes.size()
	var vivos: Array[Enemy] = []
	for e: Enemy in _guardioes:
		if e != null and is_instance_valid(e) and not e.morto:
			vivos.append(e)
	_guardioes = vivos
	if antes > 0 and vivos.is_empty() and _tinha_guardioes and not morto:
		_tinha_guardioes = false
		GlobalManager.chefe_aviso.emit("PROTEÇÃO ROMPIDA", "O ELEMENTO SUPREMO ESTÁ VULNERÁVEL")
		Efeitos.tremor(12.0)
		AudioManager.tocar_sfx("horda", -4.0, 0.04)


func _morrer() -> void:
	if morto:
		return
	for e: Enemy in _guardioes:
		if e != null and is_instance_valid(e) and not e.morto:
			e.receber_dano(999999.0)
	_guardioes.clear()
	GlobalManager.chefe_aviso.emit("ELEMENTO SUPREMO NEUTRALIZADO", "ARENA ESTABILIZADA")
	super._morrer()


# ------------------------------------------------------------------ auxiliares
func jogador_atual() -> Player:
	if jogador != null and is_instance_valid(jogador):
		return jogador
	var lista: Array[Node] = get_tree().get_nodes_in_group("player")
	if lista.is_empty():
		return null
	return lista[0] as Player


func posicao_jogador() -> Vector2:
	var p: Player = jogador_atual()
	return p.global_position if p != null else global_position


func ferir_jogador(valor: float) -> void:
	var p: Player = jogador_atual()
	if p != null and p.vivo:
		p.receber_dano(valor)


func dano_area(centro: Vector2, raio_area: float, valor: float) -> void:
	var p: Player = jogador_atual()
	if p == null or not p.vivo:
		return
	if centro.distance_to(p.global_position) <= raio_area + 12.0:
		p.receber_dano(valor)


func projetil(origem: Vector2, dir: Vector2, valor: float, vel: float, tam: float) -> void:
	if _cena_projetil == null:
		return
	var proj: Projetil = _cena_projetil.instantiate() as Projetil
	if proj == null:
		return
	get_parent().add_child(proj)
	proj.global_position = origem
	proj.configurar({
		"amigavel": false,
		"direcao": dir,
		"dano": valor,
		"velocidade": vel,
		"cor": dados.cor if dados != null else Color("8ff3ff"),
		"tamanho": tam,
		"alcance": 1400.0,
	})


func _posicoes_placas(qtd: int) -> Array[Vector2]:
	var lista: Array[Vector2] = []
	var tentativas: int = 0
	while lista.size() < qtd and tentativas < 220:
		tentativas += 1
		var p: Vector2 = Vector2(
			randf_range(ARENA.position.x + 300.0, ARENA.end.x - 300.0),
			randf_range(ARENA.position.y + 300.0, ARENA.end.y - 300.0)
		)
		if p.distance_to(global_position) < 230.0:
			continue
		var valido: bool = true
		for q: Vector2 in lista:
			if p.distance_to(q) < 480.0:
				valido = false
				break
		if valido:
			lista.append(p)
	if lista.is_empty():
		lista.append(ARENA.get_center())
	return lista


# ------------------------------------------------------------------ visual
func _draw() -> void:
	var raio_orbita: float = 138.0 if _furia else 116.0
	var qtd: int = 12 if _furia else 8
	var vel: float = 1.9 if _furia else 0.9
	_angulo_aura = _aura * vel
	var cor_anel: Color = Color(1.0, 0.35, 0.3, 0.35) if _furia else Color(0.45, 0.9, 1.0, 0.32)
	draw_arc(Vector2.ZERO, raio_orbita + 16.0, 0.0, TAU, 56, cor_anel, 3.0, true)
	for i: int in range(qtd):
		var ang: float = _angulo_aura + TAU * float(i) / float(qtd)
		var orb: Vector2 = Vector2(cos(ang), sin(ang) * 0.55) * raio_orbita
		draw_circle(orb, 9.0, Color(0.55, 0.85, 1.0, 0.16))
		draw_arc(orb, 9.0, 0.0, TAU, 12, Color(0.7, 0.95, 1.0, 0.85), 1.5, true)
		var fonte: Font = ThemeDB.fallback_font
		if fonte != null:
			var simbolo: String = ELEMENTOS[(i * 3 + 1) % ELEMENTOS.size()]
			draw_string(fonte, orb + Vector2(-8.0, 4.0), simbolo, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 11, Color(0.88, 0.98, 1.0, 0.9))
