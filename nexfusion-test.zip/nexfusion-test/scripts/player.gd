class_name Player
extends CharacterBody2D
## Jogador: mobilidade (dash com i-frames), parry (Feedbacker),
## moedas de catalisador para ricochete, cura à queima-roupa e stats rogue-lite.

signal morreu
signal vida_alterada(atual: float, maxima: float)
signal cargas_alteradas(atual: int, maxima: int)

const VELOCIDADE_BASE: float = 240.0
const VELOCIDADE_DASH: float = 860.0
const DURACAO_DASH: float = 0.15
const IFRAMES_DASH: float = 0.24
const CARGAS_DASH_MAX: int = 3
const RECARGA_DASH: float = 1.05
const RAIO_PARRY: float = 92.0
const ALCANCE_PARRY: float = 0.18
const COOLDOWN_PARRY: float = 0.42
const ESCALA_SPRITE: float = 3.0

const CENA_PROJETIL: String = "res://scenes/projetil.tscn"
const CENA_MOEDA: String = "res://scenes/moeda_ar.tscn"

var vida: float = 100.0
var vida_maxima: float = 100.0
var vivo: bool = true
var controle_bloqueado: bool = false
var velocidade: float = VELOCIDADE_BASE
var limites: Rect2 = Rect2(0.0, 0.0, 2400.0, 1500.0)

# bônus de cartas rogue-lite
var bonus_dano: float = 1.0
var bonus_cadencia: float = 1.0
var projeteis_extra: int = 0
var perfuracao_extra: int = 0
var cadeia_extra: int = 0
var ricochete_extra: int = 0
var critico_extra: float = 0.0
var area_explosao_extra: float = 0.0
var aura_dano: float = 0.0
var magnetismo_extra: float = 0.0
var cura_extra: float = 0.0
var dash_bonus: float = 1.0

# estado
var dash_cargas: int = CARGAS_DASH_MAX
var raio_magnetismo: float = 165.0
var invulneravel: float = 0.0
var vida_recente: float = 0.0

var _dash_ativo: bool = false
var _dash_tempo: float = 0.0
var _direcao_dash: Vector2 = Vector2.RIGHT
var _recarga_dash: float = 0.0
var _cooldown_tiro: float = 0.0
var _cooldown_moeda: float = 0.0
var _cooldown_aparar: float = 0.0
var _bonus_precisao: float = 0.0
var _aura_timer: float = 0.0
var _shake: float = 0.0
var _tempo_afterimage: float = 0.0
var _textura_proj: Texture2D = null
var _cena_proj: PackedScene = null
var _cena_moeda: PackedScene = null

@onready var corpo: Sprite2D = $Corpo
@onready var arma_pivot: Node2D = $ArmaPivot
@onready var arma_sprite: Sprite2D = $ArmaPivot/Arma
@onready var muzzle: Marker2D = $ArmaPivot/Muzzle
@onready var camera: Camera2D = $Camera2D


func _ready() -> void:
	add_to_group("player")
	z_index = 10
	vida_maxima = 100.0 + GlobalManager.vida_maxima_bonus()
	vida = vida_maxima
	velocidade = VELOCIDADE_BASE * GlobalManager.multiplicador_velocidade()
	if ResourceLoader.exists("res://sprites/player/player.png"):
		corpo.texture = load("res://sprites/player/player.png") as Texture2D
	corpo.scale = Vector2.ONE * ESCALA_SPRITE
	_textura_proj = load("res://sprites/props/particula.png") as Texture2D if ResourceLoader.exists("res://sprites/props/particula.png") else null
	if ResourceLoader.exists(CENA_PROJETIL):
		_cena_proj = load(CENA_PROJETIL) as PackedScene
	if ResourceLoader.exists(CENA_MOEDA):
		_cena_moeda = load(CENA_MOEDA) as PackedScene
	if camera != null:
		camera.position_smoothing_enabled = true
		camera.position_smoothing_speed = 9.0
	_atualizar_arma_visual()
	GlobalManager.tela_tremeu.connect(_ao_tremer)
	emit_signal("vida_alterada", vida, vida_maxima)
	emit_signal("cargas_alteradas", dash_cargas, CARGAS_DASH_MAX)


func definir_limites(r: Rect2) -> void:
	limites = r
	if camera != null:
		camera.limit_left = int(r.position.x)
		camera.limit_top = int(r.position.y)
		camera.limit_right = int(r.end.x)
		camera.limit_bottom = int(r.end.y)


func _ao_tremer(forca: float) -> void:
	_shake = maxf(_shake, forca)


func _process(delta: float) -> void:
	if camera != null:
		if _shake > 0.05:
			camera.offset = Vector2(randf_range(-_shake, _shake), randf_range(-_shake, _shake))
			_shake = lerpf(_shake, 0.0, clampf(delta * 12.0, 0.0, 1.0))
		else:
			camera.offset = Vector2.ZERO
			_shake = 0.0


func _physics_process(delta: float) -> void:
	if not vivo:
		return
	_tick_timers(delta)
	_mover(delta)
	_mirar()
	_processar_acoes()
	_processar_aura(delta)


func _tick_timers(delta: float) -> void:
	invulneravel = maxf(0.0, invulneravel - delta)
	_cooldown_tiro = maxf(0.0, _cooldown_tiro - delta)
	_cooldown_moeda = maxf(0.0, _cooldown_moeda - delta)
	_cooldown_aparar = maxf(0.0, _cooldown_aparar - delta)
	_bonus_precisao = maxf(0.0, _bonus_precisao - delta)
	vida_recente = maxf(0.0, vida_recente - delta)
	if _dash_tempo > 0.0:
		_dash_tempo = maxf(0.0, _dash_tempo - delta)
		if _dash_tempo <= 0.0:
			_dash_ativo = false
	if not _dash_ativo and dash_cargas < CARGAS_DASH_MAX:
		_recarga_dash += delta
		var necessario: float = RECARGA_DASH * GlobalManager.multiplicador_recarga_dash() / maxf(0.2, dash_bonus)
		if _recarga_dash >= necessario:
			_recarga_dash = 0.0
			dash_cargas += 1
			cargas_alteradas.emit(dash_cargas, CARGAS_DASH_MAX)
	if invulneravel > 0.0:
		corpo.modulate.a = 0.55 if fmod(invulneravel, 0.12) > 0.06 else 1.0
	else:
		corpo.modulate.a = 1.0


func _mover(delta: float) -> void:
	var dir: Vector2 = Vector2(
		Input.get_action_strength("mover_direita") - Input.get_action_strength("mover_esquerda"),
		Input.get_action_strength("mover_baixo") - Input.get_action_strength("mover_cima")
	)
	if dir.length() > 1.0:
		dir = dir.normalized()
	if controle_bloqueado:
		dir = Vector2.ZERO
		_dash_ativo = false
	if _dash_ativo:
		velocity = _direcao_dash * VELOCIDADE_DASH
		_tempo_afterimage -= delta
		if _tempo_afterimage <= 0.0 and corpo.texture != null:
			_tempo_afterimage = 0.02
			Efeitos.afterimage(get_parent(), corpo.texture, global_position, 0.0, corpo.scale, Color(0.56, 0.95, 1.0, 0.45))
	else:
		velocity = dir * velocidade
	move_and_slide()
	global_position.x = clampf(global_position.x, limites.position.x + 22.0, limites.end.x - 22.0)
	global_position.y = clampf(global_position.y, limites.position.y + 22.0, limites.end.y - 22.0)


func _mirar() -> void:
	var mira: Vector2 = get_global_mouse_position()
	var dir: Vector2 = (mira - global_position)
	if dir.length() < 1.0:
		dir = Vector2.RIGHT
	arma_pivot.rotation = dir.angle()
	arma_sprite.flip_v = dir.x < 0.0
	corpo.flip_h = dir.x < 0.0


func _processar_acoes() -> void:
	if controle_bloqueado:
		return
	if Input.is_action_pressed("tiro_primario"):
		_tentar_atirar()
	if Input.is_action_just_pressed("dash_esquiva"):
		_tentar_dash()
	if Input.is_action_just_pressed("aparar_melee"):
		_tentar_aparar()
	if Input.is_action_just_pressed("tiro_carregado"):
		_lancar_moeda()


func _processar_aura(delta: float) -> void:
	if aura_dano <= 0.0:
		return
	_aura_timer -= delta
	if _aura_timer > 0.0:
		return
	_aura_timer = 0.45
	var afetados: int = 0
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		var e: Enemy = n as Enemy
		if e == null or not is_instance_valid(e) or e.morto:
			continue
		if global_position.distance_to(e.global_position) <= 84.0:
			e.receber_dano(aura_dano, false)
			afetados += 1
	if afetados > 0:
		Efeitos.anel(get_parent(), global_position, 84.0, Color(0.37, 0.88, 0.4, 0.5), 0.35, 2.0)


# ------------------------------------------------------------------ disparo
func _tentar_atirar() -> void:
	if _cooldown_tiro > 0.0:
		return
	var arma: DadosArma = GlobalManager.arma_atual()
	if arma == null:
		return
	var cadencia: float = maxf(0.4, arma.cadencia * bonus_cadencia)
	_cooldown_tiro = 1.0 / cadencia
	var mira: Vector2 = (get_global_mouse_position() - global_position)
	if mira.length() < 1.0:
		mira = Vector2.RIGHT
	var dir_base: Vector2 = mira.normalized()
	var qtd: int = arma.projeteis + projeteis_extra
	var crit_chance: float = arma.critico + critico_extra + (0.45 if _bonus_precisao > 0.0 else 0.0)
	var dano_base: float = arma.dano * GlobalManager.multiplicador_dano() * bonus_dano * (1.15 if _bonus_precisao > 0.0 else 1.0)
	for i: int in range(maxi(1, qtd)):
		var angulo: float = 0.0
		if qtd > 1:
			var passo: float = deg_to_rad(arma.dispersao) * 2.0 / float(qtd - 1)
			angulo = -deg_to_rad(arma.dispersao) + passo * float(i)
			angulo += randf_range(-0.015, 0.015)
		var dir: Vector2 = dir_base.rotated(angulo)
		var critico: bool = randf() < crit_chance
		_disparar(dir, dano_base * (2.0 if critico else 1.0), arma, critico)
	Efeitos.particulas(get_parent(), muzzle.global_position, arma.cor, 3, 90.0, 0.16, 2.0)
	AudioManager.tocar_sfx(arma.som, -8.0, 0.09)
	arma_sprite.position.x = -2.0
	var tw: Tween = arma_sprite.create_tween()
	tw.tween_property(arma_sprite, "position:x", 0.0, 0.09)
	GlobalManager.registrar_estilo("DISPARO", 0.8, arma.cor)


func _disparar(dir: Vector2, dano: float, arma: DadosArma, critico: bool) -> void:
	if _cena_proj == null:
		return
	var p: Projetil = _cena_proj.instantiate() as Projetil
	if p == null:
		return
	get_parent().add_child(p)
	p.global_position = muzzle.global_position
	p.configurar({
		"amigavel": true,
		"direcao": dir,
		"dano": dano,
		"velocidade": arma.velocidade_projetil,
		"cor": arma.cor,
		"tamanho": arma.tamanho_projetil,
		"perfuracao": arma.perfuracao + perfuracao_extra,
		"cadeia": arma.cadeia + cadeia_extra,
		"ricochetes": arma.ricochetes + ricochete_extra,
		"raio_explosao": arma.raio_explosao + area_explosao_extra,
		"critico": critico,
		"alcance": arma.alcance,
	})


# ------------------------------------------------------------------ dash
func _tentar_dash() -> void:
	if _dash_ativo or dash_cargas <= 0:
		return
	var dir: Vector2 = Vector2(
		Input.get_action_strength("mover_direita") - Input.get_action_strength("mover_esquerda"),
		Input.get_action_strength("mover_baixo") - Input.get_action_strength("mover_cima")
	)
	if dir.length() < 0.1:
		dir = (get_global_mouse_position() - global_position).normalized()
	_direcao_dash = dir.normalized()
	_dash_ativo = true
	_dash_tempo = DURACAO_DASH
	dash_cargas -= 1
	_recarga_dash = 0.0
	invulneravel = maxf(invulneravel, IFRAMES_DASH)
	_bonus_precisao = 0.35
	cargas_alteradas.emit(dash_cargas, CARGAS_DASH_MAX)
	AudioManager.tocar_sfx("dash", -6.0, 0.1)
	Efeitos.anel(get_parent(), global_position, 46.0, Color(0.56, 0.95, 1.0, 0.7), 0.28, 2.0)
	GlobalManager.registrar_estilo("DASH", 3.0, Color("8ff3ff"))


# ------------------------------------------------------------------ parry
func _tentar_aparar() -> void:
	if _cooldown_aparar > 0.0:
		return
	_cooldown_aparar = COOLDOWN_PARRY
	var mira: Vector2 = (get_global_mouse_position() - global_position)
	if mira.length() < 1.0:
		mira = Vector2.RIGHT
	var dir: Vector2 = mira.normalized()
	var afetados: int = 0
	for n: Node in get_tree().get_nodes_in_group("projeteis_inimigos"):
		var b: Projetil = n as Projetil
		if b == null or not is_instance_valid(b):
			continue
		var dv: Vector2 = b.global_position - global_position
		if dv.length() <= RAIO_PARRY and dv.normalized().dot(dir) > -0.15:
			b.refletir(dir)
			afetados += 1
	for n: Node in get_tree().get_nodes_in_group("granadas"):
		var g: GranadaInimiga = n as GranadaInimiga
		if g == null or not is_instance_valid(g):
			continue
		var dv2: Vector2 = g.global_position - global_position
		if dv2.length() <= RAIO_PARRY + 30.0:
			g.rebater(dir)
			afetados += 1
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		var e: Enemy = n as Enemy
		if e == null or not is_instance_valid(e) or e.morto:
			continue
		var dv3: Vector2 = e.global_position - global_position
		if dv3.length() <= 112.0 and dv3.normalized().dot(dir) > 0.1:
			e.receber_dano(18.0 * GlobalManager.multiplicador_dano() * bonus_dano, true)
			e.aplicar_knockback(dir * 260.0)
			afetados += 1
	if afetados > 0:
		curar(4.0 + cura_extra)
		GlobalManager.registrar_estilo("+PARRY", 22.0, Color("8ff3ff"))
		Efeitos.hitstop(70)
		Efeitos.tremor(6.0)
		AudioManager.tocar_sfx("parry", -2.0, 0.04)
	else:
		GlobalManager.registrar_estilo("APARO", 1.0, Color("8ff3ff"))
		AudioManager.tocar_sfx("perigo", -14.0, 0.1)
	Efeitos.anel(get_parent(), global_position + dir * 40.0, 62.0, Color(1.0, 1.0, 1.0, 0.85), 0.2, 4.0)


# ------------------------------------------------------------------ moeda (marksman)
func _lancar_moeda() -> void:
	if _cooldown_moeda > 0.0 or _cena_moeda == null:
		return
	_cooldown_moeda = 0.5
	var mira: Vector2 = (get_global_mouse_position() - global_position)
	if mira.length() < 1.0:
		mira = Vector2.RIGHT
	var moeda: MoedaAr = _cena_moeda.instantiate() as MoedaAr
	if moeda == null:
		return
	get_parent().add_child(moeda)
	moeda.configurar(global_position, mira.normalized())
	AudioManager.tocar_sfx("moeda", -8.0, 0.06)
	GlobalManager.registrar_estilo("CATALISADOR", 2.0, Color("ffcf4a"))


# ------------------------------------------------------------------ vida
func receber_dano(valor: float) -> void:
	if not vivo or invulneravel > 0.0:
		return
	vida = maxf(0.0, vida - valor)
	invulneravel = 0.55
	vida_recente = 0.0
	corpo.modulate = Color(1.0, 0.45, 0.45)
	var tw: Tween = corpo.create_tween()
	tw.tween_property(corpo, "modulate", Color.WHITE, 0.18)
	Efeitos.particulas(get_parent(), global_position, Color("ff5f5f"), 8, 150.0, 0.4)
	Efeitos.tremor(9.0)
	AudioManager.tocar_sfx("dano", -3.0, 0.08)
	GlobalManager.sofrer_dano_penalidade()
	vida_alterada.emit(vida, vida_maxima)
	if vida <= 0.0:
		_morrer()


func curar(valor: float) -> void:
	if not vivo or valor <= 0.0:
		return
	vida = minf(vida_maxima, vida + valor)
	vida_recente = 1.4
	vida_alterada.emit(vida, vida_maxima)


func _morrer() -> void:
	if not vivo:
		return
	vivo = false
	velocity = Vector2.ZERO
	set_physics_process(false)
	GlobalManager.registrar_estilo("MORTE", 0.0)
	Efeitos.particulas(get_parent(), global_position, Color("8ff3ff"), 26, 260.0, 0.8, 4.0)
	Efeitos.anel(get_parent(), global_position, 120.0, Color(1.0, 0.4, 0.4, 0.8), 0.5, 5.0)
	Efeitos.tremor(16.0)
	AudioManager.tocar_sfx("explosao", 0.0, 0.05)
	corpo.visible = false
	arma_pivot.visible = false
	morreu.emit()


func _atualizar_arma_visual() -> void:
	var arma: DadosArma = GlobalManager.arma_atual()
	if arma == null or arma_sprite == null:
		return
	arma_sprite.position = Vector2(15.0, 6.0)
	arma_sprite.scale = Vector2.ONE * 2.2
	arma_sprite.z_index = 11
	if arma.textura != "" and ResourceLoader.exists(arma.textura):
		arma_sprite.texture = load(arma.textura) as Texture2D
	if muzzle != null:
		muzzle.position = Vector2(30.0, 0.0)


func atualizar_arma() -> void:
	_atualizar_arma_visual()


# ------------------------------------------------------------------ cartas rogue-lite
func aplicar_carta(carta: CartaRoguelite) -> void:
	if carta == null:
		return
	match carta.atributo:
		"dano":
			bonus_dano += carta.valor
		"cadencia":
			bonus_cadencia += carta.valor
		"projeteis":
			projeteis_extra += int(carta.valor)
		"perfuracao":
			perfuracao_extra += int(carta.valor)
		"cadeia":
			cadeia_extra += int(carta.valor)
		"ricochete":
			ricochete_extra += int(carta.valor)
		"critico":
			critico_extra += carta.valor
		"area_explosao":
			area_explosao_extra += carta.valor
		"aura":
			aura_dano += carta.valor
		"magnetismo":
			magnetismo_extra += carta.valor
			raio_magnetismo = 165.0 + magnetismo_extra
		"cura":
			cura_extra += carta.valor
		"vida":
			vida_maxima += carta.valor
			vida = minf(vida_maxima, vida + carta.valor)
			vida_alterada.emit(vida, vida_maxima)
		"velocidade":
			velocidade += carta.valor
		"dash":
			dash_bonus += carta.valor
		_:
			bonus_dano += 0.05
	GlobalManager.registrar_carta(carta.id)
	Efeitos.anel(get_parent(), global_position, 70.0, Color(1.0, 0.82, 0.29, 0.7), 0.4, 3.0)
