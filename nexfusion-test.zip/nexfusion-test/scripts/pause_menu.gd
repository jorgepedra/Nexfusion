class_name MenuPausa
extends Control
## Menu de pausa (ESC) com resumo da build atual.

signal continuar_solicitado
signal menu_solicitado

var _resumo: VBoxContainer


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false
	var fundo: ColorRect = ColorRect.new()
	fundo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fundo.color = Color(0.02, 0.03, 0.05, 0.85)
	add_child(fundo)
	var centro: VBoxContainer = VBoxContainer.new()
	centro.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	centro.alignment = BoxContainer.ALIGNMENT_CENTER
	centro.add_theme_constant_override("separation", 12)
	add_child(centro)
	centro.add_child(UI.titulo("PAUSADO", 52, UI.COR_CIANO))
	var sub: Label = UI.rotulo("O experimento aguarda", 15, UI.COR_TEXTO_FRACO)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	centro.add_child(sub)
	_resumo = VBoxContainer.new()
	_resumo.add_theme_constant_override("separation", 2)
	centro.add_child(_resumo)
	centro.add_child(UI.separador(16.0))
	var linha: HBoxContainer = HBoxContainer.new()
	linha.alignment = BoxContainer.ALIGNMENT_CENTER
	linha.add_theme_constant_override("separation", 12)
	centro.add_child(linha)
	var b_continuar: Button = UI.botao("CONTINUAR", 20, UI.COR_CIANO)
	b_continuar.pressed.connect(func() -> void: continuar_solicitado.emit())
	linha.add_child(b_continuar)
	var b_menu: Button = UI.botao("SAIR PARA O MENU", 20, UI.COR_VERMELHO)
	b_menu.pressed.connect(func() -> void: menu_solicitado.emit())
	linha.add_child(b_menu)


func atualizar() -> void:
	for filho: Node in _resumo.get_children():
		filho.queue_free()
	var arma: DadosArma = GlobalManager.arma_atual()
	var texto: String = "Arma: %s  •  Nível %d  •  Horda %d" % [
		arma.nome if arma != null else "—",
		GlobalManager.nivel_run,
		GlobalManager.horda_atual,
	]
	var l: Label = UI.rotulo(texto, 15, UI.COR_TEXTO)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_resumo.add_child(l)
	if not GlobalManager.cartas_coletadas.is_empty():
		var lbl: Label = UI.rotulo("Catalisadores: %s" % ", ".join(GlobalManager.cartas_coletadas), 13, UI.COR_MAGENTA)
		lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		lbl.custom_minimum_size = Vector2(620, 0)
		_resumo.add_child(lbl)
