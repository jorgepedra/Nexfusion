extends Control
## Loja de melhorias permanentes. A lista é gerada por código a partir dos
## recursos ItemLoja (.tres) de res://resources/loja/.

const PASTA_ITENS: String = "res://resources/loja"

var _lista: VBoxContainer
var _label_moedas: Label
var _label_arma: Label
var _itens: Array[ItemLoja] = []


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var fundo: ColorRect = ColorRect.new()
	fundo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fundo.color = Color(0.03, 0.045, 0.07)
	add_child(fundo)
	_carregar()
	_construir()
	AudioManager.tocar_bgm("menu")


func _carregar() -> void:
	_itens.clear()
	var dir: DirAccess = DirAccess.open(PASTA_ITENS)
	if dir == null:
		push_warning("Loja: pasta de itens não encontrada")
		return
	dir.list_dir_begin()
	var arquivo: String = dir.get_next()
	while arquivo != "":
		if arquivo.ends_with(".tres"):
			var rec: Resource = load(PASTA_ITENS.path_join(arquivo))
			if rec is ItemLoja:
				_itens.append(rec as ItemLoja)
		arquivo = dir.get_next()
	dir.list_dir_end()
	_itens.sort_custom(func(a: ItemLoja, b: ItemLoja) -> bool: return a.ordem < b.ordem)


func _construir() -> void:
	var margem: MarginContainer = MarginContainer.new()
	margem.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margem.add_theme_constant_override("margin_left", 60)
	margem.add_theme_constant_override("margin_right", 60)
	margem.add_theme_constant_override("margin_top", 26)
	margem.add_theme_constant_override("margin_bottom", 26)
	add_child(margem)
	var principal: VBoxContainer = VBoxContainer.new()
	principal.add_theme_constant_override("separation", 12)
	margem.add_child(principal)

	var topo: HBoxContainer = HBoxContainer.new()
	principal.add_child(topo)
	var titulo: Label = UI.titulo("LABORATÓRIO", 40, UI.COR_CIANO)
	topo.add_child(titulo)
	var espaco: Control = Control.new()
	espaco.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	topo.add_child(espaco)
	_label_arma = UI.rotulo("EQUIPADA: %s" % _nome_equipada(), 14, UI.COR_TEXTO_FRACO)
	topo.add_child(_label_arma)
	_label_moedas = UI.rotulo("◈ %s" % UI.formatar(GlobalManager.moedas), 24, UI.COR_AMBAR)
	topo.add_child(_label_moedas)
	var b_voltar: Button = UI.botao("VOLTAR", 16, UI.COR_TEXTO_FRACO)
	b_voltar.custom_minimum_size = Vector2(130, 42)
	b_voltar.pressed.connect(func() -> void: get_tree().change_scene_to_file("res://scenes/menu.tscn"))
	topo.add_child(b_voltar)

	var sub: Label = UI.rotulo("Melhorias permanentes e arsenal elemental — o progresso é salvo entre tentativas.", 14, UI.COR_TEXTO_FRACO)
	principal.add_child(sub)

	var rolagem: ScrollContainer = ScrollContainer.new()
	rolagem.size_flags_vertical = Control.SIZE_EXPAND_FILL
	rolagem.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	principal.add_child(rolagem)
	_lista = VBoxContainer.new()
	_lista.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_lista.add_theme_constant_override("separation", 10)
	rolagem.add_child(_lista)
	_reconstruir_lista()


func _reconstruir_lista() -> void:
	for filho: Node in _lista.get_children():
		filho.queue_free()
	_lista.add_child(_secao("MELHORIAS PERMANENTES", UI.COR_CIANO))
	for item: ItemLoja in _itens:
		if item.tipo == "upgrade":
			_lista.add_child(_linha_upgrade(item))
	_lista.add_child(_secao("ARSENAL ELEMENTAL", UI.COR_MAGENTA))
	for item: ItemLoja in _itens:
		if item.tipo == "arma":
			_lista.add_child(_linha_arma(item))
	_atualizar_cabecalho()


func _atualizar_cabecalho() -> void:
	if _label_moedas != null:
		_label_moedas.text = "◈ %s" % UI.formatar(GlobalManager.moedas)
	if _label_arma != null:
		_label_arma.text = "EQUIPADA: %s" % _nome_equipada()


func _nome_equipada() -> String:
	var arma: DadosArma = GlobalManager.arma_atual()
	return arma.nome.to_upper() if arma != null else "—"


func _secao(texto: String, cor: Color) -> Control:
	var h: HBoxContainer = HBoxContainer.new()
	h.add_theme_constant_override("separation", 10)
	var l: Label = UI.rotulo(texto, 18, cor)
	h.add_child(l)
	var linha: HSeparator = HSeparator.new()
	linha.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	linha.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(linha)
	var topo: Control = Control.new()
	topo.custom_minimum_size = Vector2(0, 14)
	var v: VBoxContainer = VBoxContainer.new()
	v.add_child(topo)
	v.add_child(h)
	return v


func _linha_upgrade(item: ItemLoja) -> Control:
	var dados: Dictionary = GlobalManager.UPGRADES.get(item.alvo, {}) as Dictionary
	if dados.is_empty():
		return UI.rotulo("Upgrade desconhecido: %s" % item.alvo, 14, UI.COR_VERMELHO)
	var nivel: int = GlobalManager.nivel_upgrade(item.alvo)
	var maximo: int = int(dados["max"])
	var preco: int = GlobalManager.preco_upgrade(item.alvo)
	var cheio: bool = nivel >= maximo
	var linha: HBoxContainer = HBoxContainer.new()
	linha.add_theme_constant_override("separation", 14)
	var icone: Label = UI.rotulo(item.simbolo, 26, item.cor)
	icone.custom_minimum_size = Vector2(40, 40)
	icone.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	icone.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	linha.add_child(icone)
	var textos: VBoxContainer = VBoxContainer.new()
	textos.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	textos.add_child(UI.rotulo(item.titulo, 17, UI.COR_TEXTO))
	var nivel_label: Label = UI.rotulo("%s   ·   Nível %d/%d" % [String(dados["desc"]), nivel, maximo], 13, UI.COR_TEXTO_FRACO)
	textos.add_child(nivel_label)
	var marcadores: HBoxContainer = HBoxContainer.new()
	marcadores.add_theme_constant_override("separation", 4)
	for i: int in range(maximo):
		var bloco: ColorRect = ColorRect.new()
		bloco.custom_minimum_size = Vector2(18, 7)
		bloco.color = item.cor if i < nivel else Color(0.15, 0.2, 0.27)
		marcadores.add_child(bloco)
	textos.add_child(marcadores)
	linha.add_child(textos)
	var botao: Button = UI.botao("MÁXIMO" if cheio else "◈ %s" % UI.formatar(preco), 16, item.cor)
	botao.custom_minimum_size = Vector2(150, 44)
	botao.disabled = cheio or GlobalManager.moedas < preco
	if not cheio:
		botao.pressed.connect(_comprar_upgrade.bind(item.alvo))
	linha.add_child(botao)
	return _envolver(linha, item.cor)


func _linha_arma(item: ItemLoja) -> Control:
	var dados: DadosArma = GlobalManager.carregar_arma(item.alvo)
	if dados == null:
		return UI.rotulo("Arma desconhecida: %s" % item.alvo, 14, UI.COR_VERMELHO)
	var desbloqueada: bool = GlobalManager.arma_desbloqueada(item.alvo)
	var equipada: bool = GlobalManager.arma_equipada == item.alvo
	var linha: HBoxContainer = HBoxContainer.new()
	linha.add_theme_constant_override("separation", 14)
	var icone: Label = UI.rotulo(item.simbolo, 24, dados.cor)
	icone.custom_minimum_size = Vector2(40, 40)
	icone.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	icone.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	linha.add_child(icone)
	var textos: VBoxContainer = VBoxContainer.new()
	textos.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var nome: Label = UI.rotulo("%s  (%s)" % [dados.nome, dados.elemento], 17, UI.COR_TEXTO)
	textos.add_child(nome)
	var stats: Label = UI.rotulo(
		"%s   ·   Dano %.0f  ·  Cadência %.1f/s  ·  Projéteis %d" % [dados.descricao, dados.dano, dados.cadencia, dados.projeteis],
		13, UI.COR_TEXTO_FRACO)
	stats.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	stats.custom_minimum_size = Vector2(560, 0)
	textos.add_child(stats)
	linha.add_child(textos)
	if not desbloqueada:
		var botao: Button = UI.botao("◈ %s" % UI.formatar(dados.custo), 16, dados.cor)
		botao.custom_minimum_size = Vector2(150, 44)
		botao.disabled = GlobalManager.moedas < dados.custo
		botao.pressed.connect(_comprar_arma.bind(item.alvo))
		linha.add_child(botao)
	else:
		var btn_equipar: Button = UI.botao("EQUIPADO" if equipada else "EQUIPAR", 16, dados.cor)
		btn_equipar.custom_minimum_size = Vector2(150, 44)
		btn_equipar.disabled = equipada
		btn_equipar.pressed.connect(_equipar.bind(item.alvo))
		linha.add_child(btn_equipar)
	return _envolver(linha, dados.cor)


func _envolver(filho: Control, cor: Color) -> Control:
	var painel: PanelContainer = PanelContainer.new()
	painel.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.06, 0.09, 0.13, 0.95), cor.darkened(0.6), 4))
	painel.add_child(filho)
	return painel


func _comprar_upgrade(id: String) -> void:
	if GlobalManager.comprar_upgrade(id):
		AudioManager.tocar_sfx("moeda", -4.0, 0.05)
		_reconstruir_lista()
	else:
		AudioManager.tocar_sfx("perigo", -8.0, 0.05)


func _comprar_arma(id: String) -> void:
	if GlobalManager.comprar_arma(id):
		AudioManager.tocar_sfx("levelup", -6.0, 0.03)
		_reconstruir_lista()
	else:
		AudioManager.tocar_sfx("perigo", -8.0, 0.05)


func _equipar(id: String) -> void:
	if GlobalManager.equipar_arma(id):
		AudioManager.tocar_sfx("clique", -6.0, 0.03)
		_reconstruir_lista()
