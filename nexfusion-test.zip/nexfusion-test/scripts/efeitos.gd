class_name Efeitos
extends RefCounted
## Game feel: números de dano, partículas, anéis de choque, afterimages,
## raios elétricos, flash de tela e hit-stop global.

const TEXTO_PARTICULA: String = "res://sprites/props/particula.png"
var _cache_particula: Texture2D = null


class Anel extends Node2D:
	var raio_final: float = 40.0
	var cor: Color = Color.WHITE
	var duracao: float = 0.3
	var espessura: float = 3.0
	var _t: float = 0.0

	func _process(delta: float) -> void:
		_t += delta
		if _t >= duracao:
			queue_free()
			return
		queue_redraw()

	func _draw() -> void:
		var p: float = clampf(_t / duracao, 0.0, 1.0)
		var r: float = lerpf(6.0, raio_final, p)
		var a: float = 1.0 - p
		draw_arc(Vector2.ZERO, r, 0.0, TAU, 28, Color(cor.r, cor.g, cor.b, a * 0.9), espessura * (1.0 - p * 0.6), true)


class Raio extends Node2D:
	var destino: Vector2 = Vector2.ZERO
	var cor: Color = Color("8ff3ff")
	var duracao: float = 0.12
	var _t: float = 0.0
	var _pontos: PackedVector2Array = PackedVector2Array()

	func _ready() -> void:
		var passos: int = 5
		for i: int in range(passos + 1):
			var f: float = float(i) / float(passos)
			var p: Vector2 = destino * f
			if i > 0 and i < passos:
				p += Vector2(randf_range(-8.0, 8.0), randf_range(-8.0, 8.0))
			_pontos.append(p)

	func _process(delta: float) -> void:
		_t += delta
		if _t >= duracao:
			queue_free()
			return
		queue_redraw()

	func _draw() -> void:
		var a: float = 1.0 - _t / duracao
		for i: int in range(_pontos.size() - 1):
			draw_line(_pontos[i], _pontos[i + 1], Color(cor.r, cor.g, cor.b, a), 3.0, true)
			draw_line(_pontos[i], _pontos[i + 1], Color(1, 1, 1, a * 0.8), 1.0, true)


static func _textura_particula() -> Texture2D:
	if not ResourceLoader.exists(TEXTO_PARTICULA):
		return null
	return load(TEXTO_PARTICULA) as Texture2D


static func texto_flutuante(pai: Node, pos: Vector2, texto: String, cor: Color = Color.WHITE, tamanho: int = 14, critico: bool = false) -> void:
	if pai == null or not pai.is_inside_tree():
		return
	var l: Label = Label.new()
	l.text = texto
	l.add_theme_font_size_override("font_size", tamanho + (4 if critico else 0))
	l.add_theme_color_override("font_color", cor)
	l.add_theme_color_override("font_outline_color", Color(0.02, 0.02, 0.05, 0.95))
	l.add_theme_constant_override("outline_size", 5)
	l.z_index = 60
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pai.add_child(l)
	l.global_position = pos + Vector2(randf_range(-6.0, 6.0), -8.0)
	var tw: Tween = l.create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "global_position", l.global_position + Vector2(randf_range(-10.0, 10.0), -34.0), 0.55)
	tw.tween_property(l, "modulate:a", 0.0, 0.55).set_delay(0.12)
	tw.chain().tween_callback(l.queue_free)


static func particulas(pai: Node, pos: Vector2, cor: Color, quantidade: int = 10, velocidade: float = 140.0, vida: float = 0.45, tamanho: float = 3.0) -> void:
	if pai == null or not pai.is_inside_tree():
		return
	var tex: Texture2D = _textura_particula()
	for i: int in range(quantidade):
		var s: Sprite2D = Sprite2D.new()
		s.texture = tex
		s.modulate = cor
		s.z_index = 45
		var ang: float = randf() * TAU
		var vel: float = randf_range(velocidade * 0.35, velocidade)
		s.scale = Vector2.ONE * randf_range(tamanho * 0.5, tamanho)
		pai.add_child(s)
		s.global_position = pos
		var destino: Vector2 = pos + Vector2(cos(ang), sin(ang)) * vel * vida * 2.2
		var tw: Tween = s.create_tween()
		tw.set_parallel(true)
		tw.tween_property(s, "global_position", destino, vida)
		tw.tween_property(s, "scale", Vector2.ONE * 0.2, vida)
		tw.tween_property(s, "modulate:a", 0.0, vida).set_delay(vida * 0.35)
		tw.chain().tween_callback(s.queue_free)


static func anel(pai: Node, pos: Vector2, raio: float, cor: Color, duracao: float = 0.3, espessura: float = 3.0) -> void:
	if pai == null or not pai.is_inside_tree():
		return
	var a: Anel = Anel.new()
	a.raio_final = raio
	a.cor = cor
	a.duracao = duracao
	a.espessura = espessura
	a.z_index = 44
	pai.add_child(a)
	a.global_position = pos


static func raio(pai: Node, origem: Vector2, destino: Vector2, cor: Color = Color("8ff3ff")) -> void:
	if pai == null or not pai.is_inside_tree():
		return
	var r: Raio = Raio.new()
	r.destino = destino - origem
	r.cor = cor
	r.z_index = 46
	pai.add_child(r)
	r.global_position = origem


static func afterimage(pai: Node, textura: Texture2D, pos: Vector2, rotacao: float, escala: Vector2, cor: Color) -> void:
	if pai == null or textura == null or not pai.is_inside_tree():
		return
	var s: Sprite2D = Sprite2D.new()
	s.texture = textura
	s.global_position = pos
	s.rotation = rotacao
	s.scale = escala
	s.modulate = cor
	s.z_index = -1
	pai.add_child(s)
	var tw: Tween = s.create_tween()
	tw.set_parallel(true)
	tw.tween_property(s, "modulate:a", 0.0, 0.25)
	tw.tween_property(s, "scale", escala * 0.8, 0.25)
	tw.chain().tween_callback(s.queue_free)


static func hitstop(duracao_ms: int) -> void:
	var arvore: SceneTree = Engine.get_main_loop() as SceneTree
	if arvore == null:
		return
	Engine.time_scale = 0.06
	var timer: SceneTreeTimer = arvore.create_timer(float(duracao_ms) / 1000.0, true, false, true)
	timer.timeout.connect(func() -> void: Engine.time_scale = 1.0)


static func tremor(forca: float) -> void:
	GlobalManager.tela_tremeu.emit(forca)
