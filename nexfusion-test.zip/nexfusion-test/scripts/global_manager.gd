extends Node
## GlobalManager (Autoload)
## Estado da partida, economia, estilo/combo, meta-progressão e persistência.
## Toda a lógica de save/load passa por aqui (user://save.cfg via ConfigFile).

const ARQUIVO_SAVE: String = "user://save.cfg"
const HORDA_MAXIMA: int = 31
const TAMANHO_FASE: int = 10
const JANELA_COMBO: float = 1.5
const DECAIMENTO_ESTILO: float = 16.0
const PERDA_ESTILO_DANO: float = 45.0
const PENALIDADE_PONTOS_DANO: int = 35
const VERSAO_SAVE: int = 1

# ------------------------------------------------------------------ sinais
signal horda_alterada(horda: int)
signal horda_concluida(horda: int)
signal pontuacao_alterada(pontuacao: int)
signal moedas_alteradas(moedas: int)
signal combo_realizado(quantidade: int, nome: String)
signal combo_encerrado()
signal estilo_alterado(rank: String, multiplicador: float)
signal acao_estilo(texto: String, cor: Color)
signal xp_alterado(xp: int, necessario: int, nivel: int)
signal nivel_subiu(nivel: int)
signal partida_iniciada()
signal partida_encerrada(venceu: bool)
signal tela_tremeu(forca: float)
signal boss_derrotado(nome: String)
signal chefe_surgiu(nome: String, vida_maxima: float)
signal chefe_vida(vida: float, vida_maxima: float)
signal chefe_aviso(titulo: String, subtitulo: String)
signal dano_recebido()
signal vida_jogador(atual: float, maxima: float)

# ------------------------------------------------------------------ ranks
const RANKS := [
	{"nome": "D", "min": 0.0, "cor": Color("7c8798")},
	{"nome": "C", "min": 25.0, "cor": Color("68b7ff")},
	{"nome": "B", "min": 60.0, "cor": Color("5fe08a")},
	{"nome": "A", "min": 110.0, "cor": Color("e8d24a")},
	{"nome": "S", "min": 170.0, "cor": Color("ff9b3d")},
	{"nome": "SS", "min": 240.0, "cor": Color("ff5f5f")},
	{"nome": "SSS", "min": 320.0, "cor": Color("ff5fd2")},
	{"nome": "ULTRAQUÍMICO", "min": 430.0, "cor": Color("8ff3ff")},
]

const RANKS_FINAIS := [
	{"nome": "C", "min": 0, "mult": 1.0, "cor": Color("7c8798")},
	{"nome": "B", "min": 1200, "mult": 1.15, "cor": Color("5fe08a")},
	{"nome": "A", "min": 2400, "mult": 1.5, "cor": Color("e8d24a")},
	{"nome": "S", "min": 3800, "mult": 1.6, "cor": Color("ff9b3d")},
	{"nome": "S++", "min": 5400, "mult": 1.7, "cor": Color("8ff3ff")},
]

const UPGRADES := {
	"vida_maxima": {"nome": "Vida Máxima", "desc": "+20 HP por nível", "max": 5, "preco": 40, "crescimento": 1.55},
	"velocidade": {"nome": "Velocidade de Movimento", "desc": "+8% por nível", "max": 5, "preco": 35, "crescimento": 1.5},
	"dano": {"nome": "Dano Geral", "desc": "+10% por nível", "max": 5, "preco": 45, "crescimento": 1.55},
	"recarga_dash": {"nome": "Recarga de Dash", "desc": "+10% de recarga por nível", "max": 4, "preco": 30, "crescimento": 1.45},
}

const ARMAS_ELEMENTOS: Array[String] = ["tungstenio", "helio", "ferro", "litio", "neonio", "mercurio"]

# ------------------------------------------------------------------ estado permanente
var moedas: int = 0
var maior_horda_alcancada: int = 0
var total_abates: int = 0
var partidas_jogadas: int = 0
var niveis_upgrade: Dictionary = {}
var armas_desbloqueadas: Array[String] = ["tungstenio"]
var arma_equipada: String = "tungstenio"
var volume_musica: float = 0.75
var volume_sfx: float = 0.85
var tela_cheia: bool = false
var config_teclas: Dictionary = {}

# ------------------------------------------------------------------ estado da run
var partida_ativa: bool = false
var horda_atual: int = 1
var horda_inicial: int = 1
var pontuacao: int = 0
var moedas_partida: int = 0
var nivel_run: int = 1
var xp_run: int = 0
var xp_necessario: int = 14
var abates_run: int = 0
var tempo_run: float = 0.0
var estilo_pontos: float = 0.0
var estilo_maximo: float = 0.0
var rank_estilo: String = "D"
var multiplicador_estilo: float = 1.0
var combo_contagem: int = 0
var cartas_coletadas: Array[String] = []
var ultimo_resultado: Dictionary = {}
var horda_skip_alvo: int = 1

var _combo_tempo: float = 0.0
var _tempo_sem_estilo: float = 0.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	garantir_acoes_padrao()
	carregar()
	_aplicar_config_teclas()


func _process(delta: float) -> void:
	if not partida_ativa or get_tree().paused:
		return
	tempo_run += delta
	if _combo_tempo > 0.0:
		_combo_tempo -= delta
		if _combo_tempo <= 0.0 and combo_contagem > 0:
			combo_contagem = 0
			combo_encerrado.emit()
	_tempo_sem_estilo += delta
	if _tempo_sem_estilo > 0.9 and estilo_pontos > 0.0:
		estilo_pontos = maxf(0.0, estilo_pontos - DECAIMENTO_ESTILO * delta)
		_atualizar_rank()


# ------------------------------------------------------------------ partida
func iniciar_partida(horda_inicial_run: int = 1) -> void:
	var h: int = clampi(horda_inicial_run, 1, HORDA_MAXIMA)
	horda_inicial = h
	horda_atual = h
	partida_ativa = true
	pontuacao = 0
	moedas_partida = 0
	nivel_run = 1
	xp_run = 0
	xp_necessario = _xp_para_nivel(1)
	abates_run = 0
	tempo_run = 0.0
	estilo_pontos = 0.0
	estilo_maximo = 0.0
	rank_estilo = "D"
	multiplicador_estilo = 1.0
	combo_contagem = 0
	_combo_tempo = 0.0
	_tempo_sem_estilo = 0.0
	cartas_coletadas.clear()
	partidas_jogadas += 1
	partida_iniciada.emit()
	horda_alterada.emit(horda_atual)
	pontuacao_alterada.emit(pontuacao)
	xp_alterado.emit(xp_run, xp_necessario, nivel_run)
	estilo_alterado.emit(rank_estilo, multiplicador_estilo)


func concluir_horda() -> void:
	if not partida_ativa:
		return
	var concluida: int = horda_atual
	if maior_horda_alcancada < concluida:
		maior_horda_alcancada = concluida
	horda_concluida.emit(concluida)
	if horda_atual < HORDA_MAXIMA:
		horda_atual += 1
		horda_alterada.emit(horda_atual)
	salvar()


func finalizar_partida(venceu: bool) -> void:
	if not partida_ativa:
		return
	partida_ativa = false
	var rank: Dictionary = _calcular_rank_final()
	var missao: float = float(rank["mult"])
	var moedas_finais: int = int(round(float(moedas_partida) * missao))
	moedas += moedas_finais
	if maior_horda_alcancada < horda_atual:
		maior_horda_alcancada = horda_atual
	ultimo_resultado = {
		"venceu": venceu,
		"horda": horda_atual,
		"nivel": nivel_run,
		"pontuacao": pontuacao,
		"abates": abates_run,
		"tempo": tempo_run,
		"rank": String(rank["nome"]),
		"multiplicador": missao,
		"moedas_base": moedas_partida,
		"moedas_finais": moedas_finais,
		"estilo_maximo": estilo_maximo,
		"cartas": cartas_coletadas.duplicate(),
	}
	combo_contagem = 0
	salvar()
	moedas_alteradas.emit(moedas)
	partida_encerrada.emit(venceu)


func _calcular_rank_final() -> Dictionary:
	var valor: int = pontuacao + horda_atual * 120 + nivel_run * 50 + abates_run * 6 + int(estilo_maximo)
	var escolhido: Dictionary = RANKS_FINAIS[0]
	for r: Dictionary in RANKS_FINAIS:
		if valor >= int(r["min"]):
			escolhido = r
	return escolhido


func _xp_para_nivel(nivel: int) -> int:
	return 14 + int(pow(float(nivel), 1.42) * 9.0)


# ------------------------------------------------------------------ pontuação / estilo
func adicionar_pontos(base: int) -> void:
	if not partida_ativa:
		return
	var ganho: int = int(round(float(base) * multiplicador_estilo))
	pontuacao = maxi(0, pontuacao + ganho)
	pontuacao_alterada.emit(pontuacao)


func registrar_estilo(acao: String, valor: float = 8.0, cor: Color = Color("8ff3ff")) -> void:
	if not partida_ativa:
		return
	estilo_pontos = minf(estilo_pontos + valor, 900.0)
	estilo_maximo = maxf(estilo_maximo, estilo_pontos)
	_tempo_sem_estilo = 0.0
	acao_estilo.emit(acao, cor)
	_atualizar_rank()


func _atualizar_rank() -> void:
	var novo: String = "D"
	var mult: float = 1.0
	for i: int in range(RANKS.size()):
		var r: Dictionary = RANKS[i]
		if estilo_pontos >= float(r["min"]):
			novo = String(r["nome"])
			mult = 1.0 + float(i) * 0.28
	if novo != rank_estilo:
		rank_estilo = novo
		multiplicador_estilo = mult
		estilo_alterado.emit(rank_estilo, multiplicador_estilo)
	else:
		multiplicador_estilo = mult


func cor_rank(nome: String) -> Color:
	for r: Dictionary in RANKS:
		if String(r["nome"]) == nome:
			return r["cor"]
	return Color("7c8798")


func registrar_abate(pontos: int) -> void:
	if not partida_ativa:
		return
	abates_run += 1
	total_abates += 1
	combo_contagem += 1
	_combo_tempo = JANELA_COMBO
	if combo_contagem >= 2:
		combo_realizado.emit(combo_contagem, _nome_combo(combo_contagem))
	adicionar_pontos(pontos)
	registrar_estilo("ABATE", 5.0, Color("5fe08a"))


func _nome_combo(qtd: int) -> String:
	match qtd:
		2:
			return "DOUBLE KILL"
		3:
			return "TRIPLE KILL"
		4:
			return "MULTI KILL x4"
		_:
			return "MULTI KILL x%d" % qtd


func sofrer_dano_penalidade() -> void:
	if not partida_ativa:
		return
	pontuacao = maxi(0, pontuacao - PENALIDADE_PONTOS_DANO)
	pontuacao_alterada.emit(pontuacao)
	estilo_pontos = maxf(0.0, estilo_pontos - PERDA_ESTILO_DANO)
	_tempo_sem_estilo = 0.0
	combo_contagem = 0
	_combo_tempo = 0.0
	_atualizar_rank()
	dano_recebido.emit()


# ------------------------------------------------------------------ xp / moedas
func adicionar_xp(valor: int) -> void:
	if not partida_ativa:
		return
	xp_run += valor
	var subiu: bool = false
	while xp_run >= xp_necessario:
		xp_run -= xp_necessario
		nivel_run += 1
		xp_necessario = _xp_para_nivel(nivel_run)
		subiu = true
	xp_alterado.emit(xp_run, xp_necessario, nivel_run)
	if subiu:
		nivel_subiu.emit(nivel_run)


func registrar_carta(id: String) -> void:
	cartas_coletadas.append(id)


func adicionar_moedas_partida(valor: int) -> void:
	moedas_partida = maxi(0, moedas_partida + valor)
	moedas_alteradas.emit(moedas + moedas_partida)


# ------------------------------------------------------------------ upgrades permanentes
func nivel_upgrade(id: String) -> int:
	return int(niveis_upgrade.get(id, 0))


func preco_upgrade(id: String) -> int:
	if not UPGRADES.has(id):
		return 0
	var dados: Dictionary = UPGRADES[id]
	var nivel: int = nivel_upgrade(id)
	return int(round(float(dados["preco"]) * pow(float(dados["crescimento"]), float(nivel))))


func pode_comprar_upgrade(id: String) -> bool:
	if not UPGRADES.has(id):
		return false
	if nivel_upgrade(id) >= int(UPGRADES[id]["max"]):
		return false
	return moedas >= preco_upgrade(id)


func comprar_upgrade(id: String) -> bool:
	if not pode_comprar_upgrade(id):
		return false
	moedas -= preco_upgrade(id)
	niveis_upgrade[id] = nivel_upgrade(id) + 1
	salvar()
	moedas_alteradas.emit(moedas)
	return true


func vida_maxima_bonus() -> float:
	return float(nivel_upgrade("vida_maxima")) * 20.0


func multiplicador_velocidade() -> float:
	return 1.0 + float(nivel_upgrade("velocidade")) * 0.08


func multiplicador_dano() -> float:
	return 1.0 + float(nivel_upgrade("dano")) * 0.10


func multiplicador_recarga_dash() -> float:
	return maxf(0.5, 1.0 - float(nivel_upgrade("recarga_dash")) * 0.10)


# ------------------------------------------------------------------ arsenal
func arma_desbloqueada(id: String) -> bool:
	return armas_desbloqueadas.has(id)


func custo_arma(id: String) -> int:
	var dados: DadosArma = carregar_arma(id)
	if dados == null:
		return 0
	return dados.custo


func comprar_arma(id: String) -> bool:
	if arma_desbloqueada(id):
		return false
	var custo: int = custo_arma(id)
	if moedas < custo:
		return false
	moedas -= custo
	armas_desbloqueadas.append(id)
	arma_equipada = id
	salvar()
	moedas_alteradas.emit(moedas)
	return true


func equipar_arma(id: String) -> bool:
	if not arma_desbloqueada(id):
		return false
	arma_equipada = id
	salvar()
	return true


func carregar_arma(id: String) -> DadosArma:
	var caminho: String = "res://resources/armas/%s.tres" % id
	if not ResourceLoader.exists(caminho):
		return null
	var rec: Resource = load(caminho)
	if rec is DadosArma:
		return rec as DadosArma
	return null


func arma_atual() -> DadosArma:
	var dados: DadosArma = carregar_arma(arma_equipada)
	if dados == null:
		dados = carregar_arma("tungstenio")
	return dados


# ------------------------------------------------------------------ save / load
func salvar() -> void:
	var cfg: ConfigFile = ConfigFile.new()
	cfg.set_value("progresso", "moedas", moedas)
	cfg.set_value("progresso", "maior_horda", maior_horda_alcancada)
	cfg.set_value("progresso", "total_abates", total_abates)
	cfg.set_value("progresso", "partidas", partidas_jogadas)
	cfg.set_value("progresso", "versao", VERSAO_SAVE)
	for id: String in UPGRADES.keys():
		cfg.set_value("upgrades", id, nivel_upgrade(id))
	cfg.set_value("armas", "desbloqueadas", PackedStringArray(armas_desbloqueadas))
	cfg.set_value("armas", "equipada", arma_equipada)
	cfg.set_value("audio", "musica", volume_musica)
	cfg.set_value("audio", "sfx", volume_sfx)
	cfg.set_value("video", "tela_cheia", tela_cheia)
	cfg.set_value("input", "teclas", JSON.stringify(config_teclas))
	var err: int = cfg.save(ARQUIVO_SAVE)
	if err != OK:
		push_warning("GlobalManager: não foi possível salvar (%s)" % err)


func carregar() -> void:
	var cfg: ConfigFile = ConfigFile.new()
	if cfg.load(ARQUIVO_SAVE) != OK:
		_garantir_padroes()
		return
	moedas = int(cfg.get_value("progresso", "moedas", 0))
	maior_horda_alcancada = int(cfg.get_value("progresso", "maior_horda", 0))
	total_abates = int(cfg.get_value("progresso", "total_abates", 0))
	partidas_jogadas = int(cfg.get_value("progresso", "partidas", 0))
	for id: String in UPGRADES.keys():
		niveis_upgrade[id] = int(cfg.get_value("upgrades", id, 0))
	var desbloqueadas: PackedStringArray = cfg.get_value("armas", "desbloqueadas", PackedStringArray(["tungstenio"]))
	armas_desbloqueadas.clear()
	for a: String in desbloqueadas:
		if not armas_desbloqueadas.has(a):
			armas_desbloqueadas.append(a)
	if armas_desbloqueadas.is_empty():
		armas_desbloqueadas.append("tungstenio")
	if not armas_desbloqueadas.has("tungstenio"):
		armas_desbloqueadas.append("tungstenio")
	arma_equipada = String(cfg.get_value("armas", "equipada", "tungstenio"))
	if not armas_desbloqueadas.has(arma_equipada):
		arma_equipada = "tungstenio"
	volume_musica = clampf(float(cfg.get_value("audio", "musica", 0.75)), 0.0, 1.0)
	volume_sfx = clampf(float(cfg.get_value("audio", "sfx", 0.85)), 0.0, 1.0)
	tela_cheia = bool(cfg.get_value("video", "tela_cheia", false))
	var json_teclas: String = String(cfg.get_value("input", "teclas", "{}"))
	var parsed: Variant = JSON.parse_string(json_teclas)
	if parsed is Dictionary:
		config_teclas = parsed as Dictionary
	_garantir_padroes()
	_aplicar_tela()


func _garantir_padroes() -> void:
	for id: String in UPGRADES.keys():
		if not niveis_upgrade.has(id):
			niveis_upgrade[id] = 0


func resetar_progresso() -> void:
	moedas = 0
	maior_horda_alcancada = 0
	total_abates = 0
	partidas_jogadas = 0
	niveis_upgrade.clear()
	armas_desbloqueadas = ["tungstenio"]
	arma_equipada = "tungstenio"
	_garantir_padroes()
	salvar()
	moedas_alteradas.emit(moedas)


# ------------------------------------------------------------------ configurações
func definir_volume_musica(v: float) -> void:
	volume_musica = clampf(v, 0.0, 1.0)
	if AudioManager != null:
		AudioManager.definir_volume(AudioManager.BUS_MUSICA, volume_musica)
	salvar()


func definir_volume_sfx(v: float) -> void:
	volume_sfx = clampf(v, 0.0, 1.0)
	if AudioManager != null:
		AudioManager.definir_volume(AudioManager.BUS_SFX, volume_sfx)
	salvar()


func definir_tela_cheia(ativa: bool) -> void:
	tela_cheia = ativa
	_aplicar_tela()
	salvar()


func _aplicar_tela() -> void:
	if DisplayServer.get_name() == "headless":
		return
	var modo: DisplayServer.WindowMode = DisplayServer.WINDOW_MODE_FULLSCREEN if tela_cheia else DisplayServer.WINDOW_MODE_WINDOWED
	DisplayServer.window_set_mode(modo)


# ------------------------------------------------------------------ input
func garantir_acoes_padrao() -> void:
	var padroes: Dictionary = {
		"mover_esquerda": [KEY_A, KEY_LEFT],
		"mover_direita": [KEY_D, KEY_RIGHT],
		"mover_cima": [KEY_W, KEY_UP],
		"mover_baixo": [KEY_S, KEY_DOWN],
		"dash_esquiva": [KEY_SPACE, KEY_SHIFT],
		"aparar_melee": [KEY_F],
		"pausar": [KEY_ESCAPE],
	}
	for acao: String in padroes.keys():
		if not InputMap.has_action(acao):
			InputMap.add_action(acao)
		if InputMap.action_get_events(acao).is_empty():
			for tecla: int in padroes[acao]:
				var ev: InputEventKey = InputEventKey.new()
				ev.physical_keycode = tecla
				InputMap.action_add_event(acao, ev)
	for acao_mouse: String in ["tiro_primario", "tiro_carregado"]:
		if not InputMap.has_action(acao_mouse):
			InputMap.add_action(acao_mouse)


func remapear_acao(acao: String, evento: InputEvent) -> void:
	if not InputMap.has_action(acao):
		InputMap.add_action(acao)
	InputMap.action_erase_events(acao)
	InputMap.action_add_event(acao, evento)
	var entrada: Dictionary = {"tipo": "mouse" if evento is InputEventMouseButton else "tecla"}
	if evento is InputEventKey:
		var k: InputEventKey = evento as InputEventKey
		entrada["keycode"] = k.physical_keycode if k.physical_keycode != 0 else k.keycode
	elif evento is InputEventMouseButton:
		entrada["botao"] = (evento as InputEventMouseButton).button_index
	config_teclas[acao] = entrada
	salvar()


func _aplicar_config_teclas() -> void:
	for acao_v: Variant in config_teclas.keys():
		var acao: String = String(acao_v)
		var dado: Variant = config_teclas[acao_v]
		if not dado is Dictionary:
			continue
		var d: Dictionary = dado as Dictionary
		var ev: InputEvent = null
		if String(d.get("tipo", "tecla")) == "mouse":
			var mb: InputEventMouseButton = InputEventMouseButton.new()
			mb.button_index = int(d.get("botao", 1))
			ev = mb
		else:
			var k: InputEventKey = InputEventKey.new()
			k.physical_keycode = int(d.get("keycode", 0))
			ev = k
		if ev != null:
			if not InputMap.has_action(acao):
				InputMap.add_action(acao)
			InputMap.action_erase_events(acao)
			InputMap.action_add_event(acao, ev)


func nome_tecla(acao: String) -> String:
	var eventos: Array[InputEvent] = InputMap.action_get_events(acao)
	if eventos.is_empty():
		return "—"
	var ev: InputEvent = eventos[0]
	if ev is InputEventKey:
		var k: InputEventKey = ev as InputEventKey
		var code: int = k.physical_keycode if k.physical_keycode != 0 else k.keycode
		return OS.get_keycode_string(code)
	if ev is InputEventMouseButton:
		match (ev as InputEventMouseButton).button_index:
			MOUSE_BUTTON_LEFT:
				return "Botão Esq."
			MOUSE_BUTTON_RIGHT:
				return "Botão Dir."
			MOUSE_BUTTON_MIDDLE:
				return "Botão Meio"
			_:
				return "Botão %d" % (ev as InputEventMouseButton).button_index
	return "—"
