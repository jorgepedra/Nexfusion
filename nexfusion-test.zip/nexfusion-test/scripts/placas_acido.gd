class_name PlacasAcido
extends Node2D
## Ataque de "vômito" ácido: placas do chão flutuam e são a única área segura.
## Quem estiver fora delas durante o dilúvio leva dano periódico.

signal terminou

const EMERGIR: float = 1.1
const ATIVO: float = 3.4
const RECOLHER: float = 0.75
const INTERVALO_DANO: float = 0.5

var chefe: ChefeFinal = null
var dano: float = 9.0
var raio_placa: float = 108.0
var placas: Array[Vector2] = []
var arena: Rect2 = Rect2(0.0, 0.0, 2400.0, 1500.0)

var _t: float = 0.0
var _fase: String = "emergir"
var _tick: float = 0.0
var _acido: float = 0.0
var _pulso: float = 0.0


func configurar(chefe_ref: ChefeFinal, posicoes: Array[Vector2], valor: float, caixa: Rect2) -> void:
	chefe = chefe_ref
	placas = posicoes
	dano = valor
	arena = caixa
	global_position = Vector2.ZERO
	z_index = 18
	_tick = 0.45


func _chefe_vivo() -> bool:
	## O chefe pode morrer no meio do ataque: nesse caso o objeto é liberado.
	return chefe != null and is_instance_valid(chefe) and not chefe.morto


func _process(delta: float) -> void:
	if not _chefe_vivo():
		terminou.emit()
		queue_free()
		return
	_t += delta
	_pulso += delta
	match _fase:
		"emergir":
			_acido = clampf(_t / EMERGIR, 0.0, 1.0) * 0.85
			if _t >= EMERGIR:
				_fase = "ativo"
				_t = 0.0
				AudioManager.tocar_sfx("explosao", -6.0, 0.06)
				Efeitos.tremor(10.0)
				for p: Vector2 in placas:
					Efeitos.anel(get_parent(), p, raio_placa, Color(0.55, 1.0, 0.65, 0.8), 0.45, 3.0)
		"ativo":
			_acido = 1.0
			_processar_dano(delta)
			if _t >= ATIVO:
				_fase = "recolher"
				_t = 0.0
		_:
			_acido = clampf(1.0 - _t / RECOLHER, 0.0, 1.0)
			if _t >= RECOLHER:
				terminou.emit()
				queue_free()
				return
	queue_redraw()


func _processar_dano(delta: float) -> void:
	if not _chefe_vivo():
		return
	var p: Player = chefe.jogador_atual()
	if p == null or not p.vivo:
		return
	_tick -= delta
	if _tick > 0.0:
		return
	_tick = INTERVALO_DANO
	if _em_placa(p.global_position):
		return
	chefe.ferir_jogador(dano)
	Efeitos.particulas(get_parent(), p.global_position, Color("7dff5a"), 7, 130.0, 0.4, 2.5)


func _em_placa(pos: Vector2) -> bool:
	for p: Vector2 in placas:
		if p.distance_to(pos) <= raio_placa - 6.0:
			return true
	return false


func _draw() -> void:
	if _acido <= 0.01:
		return
	draw_rect(arena, Color(0.24, 0.72, 0.2, 0.16 * _acido))
	var onda: float = sin(_pulso * 3.0) * 0.5 + 0.5
	for p: Vector2 in placas:
		var sobe: float = clampf(_acido, 0.0, 1.0)
		draw_circle(p, raio_placa, Color(0.05, 0.16, 0.12, 0.75 * sobe))
		draw_circle(p, raio_placa * 0.94, Color(0.11, 0.3, 0.24, 0.85 * sobe))
		draw_circle(p, raio_placa * 0.78, Color(0.16, 0.42, 0.34, 0.9 * sobe))
		# marcas das placas
		for i: int in range(3):
			var r: float = raio_placa * (0.3 + float(i) * 0.22)
			draw_arc(p, r, 0.0, TAU, 32, Color(0.5, 1.0, 0.8, (0.45 - float(i) * 0.1) * sobe), 2.0, true)
		draw_arc(p, raio_placa, 0.0, TAU, 44, Color(0.6, 1.0, 0.75, (0.55 + onda * 0.35) * sobe), 4.0, true)
	# bolhas de ácido
	for i: int in range(18):
		var bx: float = arena.position.x + fmod(float(i) * 233.0 + _pulso * 42.0, arena.size.x)
		var by: float = arena.position.y + fmod(float(i) * 137.0 + _pulso * 30.0, arena.size.y)
		draw_circle(Vector2(bx, by), 5.0 + float(i % 3) * 2.0, Color(0.6, 1.0, 0.5, 0.18 * _acido))
