class_name LevelUpOverlay
extends Control
## Escolha de 3 cartas rogue-lite ao subir de nível. Pausa a árvore
## (processa sempre) e aplica a carta no jogador.

signal carta_selecionada(carta: CartaRoguelite)

const PASTA_CARTAS: String = "res://resources/cartas_roguelite"

var _cartas: Array[CartaRoguelite] = []
var _oferecidas: Array[CartaRoguelite] = []
var _container: HBoxContainer
var _titulo: Label


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false
	_carregar_cartas()
	var fundo: ColorRect = ColorRect.new()
	fundo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fundo.color = Color(0.02, 0.03, 0.05, 0.86)
	add_child(fundo)
	var centro: VBoxContainer = VBoxContainer.new()
	centro.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	centro.alignment = BoxContainer.ALIGNMENT_CENTER
	centro.add_theme_constant_override("separation", 18)
	add_child(centro)
	_titulo = UI.titulo("NÍVEL 2", 40, UI.COR_CIANO)
	centro.add_child(_titulo)
	var sub: Label = UI.rotulo("ESCOLHA UM CATALISADOR PARA ESTA TENTATIVA", 16, UI.COR_TEXTO_FRACO)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	centro.add_child(sub)
	var margem: MarginContainer = MarginContainer.new()
	margem.add_theme_constant_override("margin_left", 60)
	margem.add_theme_constant_override("margin_right", 60)
	centro.add_child(margem)
	_container = HBoxContainer.new()
	_container.alignment = BoxContainer.ALIGNMENT_CENTER
	_container.add_theme_constant_override("separation", 22)
	margem.add_child(_container)


func _carregar_cartas() -> void:
	_cartas.clear()
	var dir: DirAccess = DirAccess.open(PASTA_CARTAS)
	if dir == null:
		push_warning("LevelUpOverlay: pasta de cartas não encontrada")
		return
	dir.list_dir_begin()
	var arquivo: String = dir.get_next()
	while arquivo != "":
		if arquivo.ends_with(".tres"):
			var rec: Resource = load(PASTA_CARTAS.path_join(arquivo))
			if rec is CartaRoguelite:
				_cartas.append(rec as CartaRoguelite)
		arquivo = dir.get_next()
	dir.list_dir_end()


func abrir(nivel: int, _jogador: Player) -> void:
	visible = true
	_titulo.text = "NÍVEL %d" % nivel
	for filho: Node in _container.get_children():
		filho.queue_free()
	_oferecidas = _sortear(3)
	for i: int in range(_oferecidas.size()):
		_container.add_child(_criar_carta(_oferecidas[i], i))
	modulate.a = 0.0
	var tw: Tween = create_tween()
	tw.tween_property(self, "modulate:a", 1.0, 0.18)


func fechar() -> void:
	visible = false


func _sortear(qtd: int) -> Array[CartaRoguelite]:
	var disponiveis: Array[CartaRoguelite] = _cartas.duplicate()
	var escolhidas: Array[CartaRoguelite] = []
	while escolhidas.size() < qtd and not disponiveis.is_empty():
		var total: float = 0.0
		for c: CartaRoguelite in disponiveis:
			total += _peso(c)
		var sorteio: float = randf() * total
		var indice: int = 0
		for i: int in range(disponiveis.size()):
			sorteio -= _peso(disponiveis[i])
			if sorteio <= 0.0:
				indice = i
				break
		escolhidas.append(disponiveis[indice])
		disponiveis.remove_at(indice)
	return escolhidas


func _peso(c: CartaRoguelite) -> float:
	var base: float = c.peso
	match c.raridade:
		"raro":
			base *= 0.5
		"epico":
			base *= 0.24
		"isotopico":
			base *= 0.1
	return maxf(0.05, base)


func _criar_carta(carta: CartaRoguelite, indice: int) -> Control:
	var cor: Color = UI.cor_raridade(carta.raridade)
	var botao: Button = Button.new()
	botao.custom_minimum_size = Vector2(250, 310)
	botao.focus_mode = Control.FOCUS_NONE
	botao.add_theme_stylebox_override("normal", UI.estilo_painel(Color(0.06, 0.09, 0.14, 0.96), cor.darkened(0.35), 6))
	botao.add_theme_stylebox_override("hover", UI.estilo_painel(Color(0.1, 0.14, 0.21, 0.98), cor, 6))
	botao.add_theme_stylebox_override("pressed", UI.estilo_painel(Color(0.04, 0.06, 0.1, 1.0), cor, 6))
	botao.pressed.connect(_ao_clicar.bind(carta))
	var vb: VBoxContainer = VBoxContainer.new()
	vb.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vb.offset_left = 14
	vb.offset_right = -14
	vb.offset_top = 18
	vb.offset_bottom = -14
	vb.add_theme_constant_override("separation", 8)
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	botao.add_child(vb)
	var simbolo: Label = UI.rotulo(carta.simbolo, 54, cor)
	simbolo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	simbolo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(simbolo)
	var nome: Label = UI.rotulo(carta.nome, 19, UI.COR_TEXTO)
	nome.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	nome.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	nome.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(nome)
	var raridade: Label = UI.rotulo(String(carta.raridade).to_upper(), 12, cor)
	raridade.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	raridade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(raridade)
	var desc: Label = UI.rotulo(carta.descricao, 14, UI.COR_TEXTO_FRACO)
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	desc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(desc)
	var atalho: Label = UI.rotulo("[%d]" % (indice + 1), 12, UI.COR_TEXTO_FRACO)
	atalho.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	atalho.offset_top = -26
	atalho.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	atalho.mouse_filter = Control.MOUSE_FILTER_IGNORE
	botao.add_child(atalho)
	botao.modulate.a = 0.0
	botao.position = Vector2(0, 26)
	var tw: Tween = botao.create_tween()
	tw.set_parallel(true)
	tw.tween_property(botao, "modulate:a", 1.0, 0.22).set_delay(0.06 * float(indice))
	tw.tween_property(botao, "position:y", 0.0, 0.26).set_delay(0.06 * float(indice)).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	return botao


func _unhandled_input(evento: InputEvent) -> void:
	if not visible:
		return
	if evento is InputEventKey and evento.pressed and not evento.echo:
		var k: InputEventKey = evento as InputEventKey
		var numero: int = int(k.physical_keycode) - 49
		if numero >= 0 and numero < _oferecidas.size() and (k.physical_keycode >= KEY_1 and k.physical_keycode <= KEY_3):
			_ao_clicar(_oferecidas[numero])
			get_viewport().set_input_as_handled()


func _ao_clicar(carta: CartaRoguelite) -> void:
	if not visible:
		return
	carta_selecionada.emit(carta)
