extends Node2D
## Controla a arena: construção do cenário, jogador, spawner, HUD e fluxo
## de vitória/derrota. Ponto de entrada de jogo.tscn.

const CENA_PLAYER: String = "res://scenes/player.tscn"
const TAMANHO_ARENA: Vector2 = Vector2(2400.0, 1500.0)
const TILE_CHAO: String = "res://sprites/map/tile_arena.png"

var jogador: Player
var _finalizada: bool = false
var _aguardando: bool = false
var _salto_manual: bool = false

@onready var mundo: Node2D = $Mundo
@onready var hud: HUD = $HUD
@onready var spawn_manager: SpawnManager = $SpawnManager


class ArenaVisual extends Node2D:
	func _draw() -> void:
		var r: Rect2 = Rect2(Vector2.ZERO, Vector2(2400.0, 1500.0))
		# borda luminosa
		draw_rect(r, Color(0.17, 0.42, 0.55, 0.9), false, 4.0)
		draw_rect(r.grow(-10.0), Color(0.10, 0.24, 0.33, 0.55), false, 2.0)
		# cantos técnicos
		var cantos: Array[Vector2] = [r.position, Vector2(r.end.x, r.position.y), r.end, Vector2(r.position.x, r.end.y)]
		for c: Vector2 in cantos:
			var dir_x: float = 1.0 if c.x < r.get_center().x else -1.0
			var dir_y: float = 1.0 if c.y < r.get_center().y else -1.0
			for i: int in range(3):
				var off: float = 26.0 + float(i) * 14.0
				draw_line(c + Vector2(dir_x * off, dir_y * 12.0), c + Vector2(dir_x * off, dir_y * 62.0), Color(0.35, 0.75, 0.85, 0.28), 2.0)
				draw_line(c + Vector2(dir_x * 12.0, dir_y * off), c + Vector2(dir_x * 62.0, dir_y * off), Color(0.35, 0.75, 0.85, 0.28), 2.0)
		# círculo central de contenção química
		var centro: Vector2 = r.get_center()
		draw_arc(centro, 240.0, 0.0, TAU, 72, Color(0.18, 0.42, 0.5, 0.24), 3.0, true)
		draw_arc(centro, 120.0, 0.0, TAU, 48, Color(0.18, 0.42, 0.5, 0.18), 2.0, true)
		# faixas de perigo nas bordas
		var passo: float = 46.0
		var x: float = 0.0
		while x < r.size.x:
			draw_line(Vector2(x, 0.0), Vector2(x + 22.0, 0.0), Color(0.85, 0.65, 0.2, 0.35), 6.0)
			draw_line(Vector2(x, r.size.y), Vector2(x + 22.0, r.size.y), Color(0.85, 0.65, 0.2, 0.35), 6.0)
			x += passo
		var y: float = 0.0
		while y < r.size.y:
			draw_line(Vector2(0.0, y), Vector2(0.0, y + 22.0), Color(0.85, 0.65, 0.2, 0.35), 6.0)
			draw_line(Vector2(r.size.x, y), Vector2(r.size.x, y + 22.0), Color(0.85, 0.65, 0.2, 0.35), 6.0)
			y += passo


func _ready() -> void:
	randomize()
	GlobalManager.iniciar_partida(GlobalManager.horda_skip_alvo)
	_construir_arena()
	_criar_jogador()
	hud.configurar(jogador)
	_conectar_sinais()
	spawn_manager.iniciar(jogador, Rect2(Vector2.ZERO, TAMANHO_ARENA), mundo)
	AudioManager.tocar_bgm("jogo")
	hud.mostrar_banner("HORDA %d" % GlobalManager.horda_atual, UI.COR_CIANO, "SOBREVIVA")


func _construir_arena() -> void:
	var chao: TextureRect = TextureRect.new()
	if ResourceLoader.exists(TILE_CHAO):
		chao.texture = load(TILE_CHAO) as Texture2D
	chao.stretch_mode = TextureRect.STRETCH_TILE
	chao.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	chao.size = TAMANHO_ARENA
	chao.position = Vector2.ZERO
	chao.z_index = -20
	chao.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(chao)
	move_child(chao, 0)
	var visual: ArenaVisual = ArenaVisual.new()
	visual.z_index = -10
	add_child(visual)
	move_child(visual, 1)
	_criar_paredes()


func _criar_paredes() -> void:
	var espessura: float = 40.0
	var paredes: Array[Rect2] = [
		Rect2(Vector2(-espessura, -espessura), Vector2(TAMANHO_ARENA.x + espessura * 2.0, espessura)),
		Rect2(Vector2(-espessura, TAMANHO_ARENA.y), Vector2(TAMANHO_ARENA.x + espessura * 2.0, espessura)),
		Rect2(Vector2(-espessura, 0.0), Vector2(espessura, TAMANHO_ARENA.y)),
		Rect2(Vector2(TAMANHO_ARENA.x, 0.0), Vector2(espessura, TAMANHO_ARENA.y)),
	]
	for r: Rect2 in paredes:
		var corpo: StaticBody2D = StaticBody2D.new()
		corpo.collision_layer = 4
		corpo.collision_mask = 0
		corpo.position = r.position + r.size * 0.5
		var forma: CollisionShape2D = CollisionShape2D.new()
		var ret: RectangleShape2D = RectangleShape2D.new()
		ret.size = r.size
		forma.shape = ret
		corpo.add_child(forma)
		add_child(corpo)


func _criar_jogador() -> void:
	var cena: PackedScene = load(CENA_PLAYER) as PackedScene
	jogador = cena.instantiate() as Player
	mundo.add_child(jogador)
	jogador.global_position = TAMANHO_ARENA * 0.5
	jogador.definir_limites(Rect2(Vector2.ZERO, TAMANHO_ARENA))


func _conectar_sinais() -> void:
	jogador.morreu.connect(_ao_morrer)
	spawn_manager.horda_iniciada.connect(_ao_horda_iniciada)
	GlobalManager.horda_concluida.connect(_ao_horda_concluida)
	spawn_manager.run_completa.connect(_ao_vitoria)
	GlobalManager.chefe_surgiu.connect(_ao_chefe_surgir)
	GlobalManager.boss_derrotado.connect(_ao_chefe_morrer)
	hud.recomecar_solicitado.connect(_ao_recomecar)
	hud.loja_solicitada.connect(_ao_ir_loja)
	hud.menu_solicitado.connect(_ao_ir_menu)
	jogador.vida_alterada.connect(hud.atualizar_vida)
	jogador.cargas_alteradas.connect(hud.atualizar_cargas)


func _unhandled_input(evento: InputEvent) -> void:
	if evento.is_action_pressed("pausar"):
		if hud != null:
			hud.alternar_pausa()
			get_viewport().set_input_as_handled()
		return
	if _eh_atalho_salto(evento):
		if _ao_pular_horda():
			get_viewport().set_input_as_handled()


func _eh_atalho_salto(evento: InputEvent) -> bool:
	## Shift+P: passa para a horda seguinte (seletor rápido de fases).
	var tecla: InputEventKey = evento as InputEventKey
	if tecla == null or not tecla.pressed or tecla.echo:
		return false
	if not tecla.shift_pressed or tecla.ctrl_pressed or tecla.alt_pressed or tecla.meta_pressed:
		return false
	var codigo: int = tecla.physical_keycode if tecla.physical_keycode != 0 else tecla.keycode
	return codigo == KEY_P


func _ao_pular_horda() -> bool:
	if _finalizada or not GlobalManager.partida_ativa or spawn_manager == null:
		return false
	_salto_manual = true
	if not spawn_manager.pular_horda():
		_salto_manual = false
		hud.mostrar_banner("ÚLTIMA HORDA", UI.COR_AMBAR, "NÃO HÁ HORDA SEGUINTE")
		AudioManager.tocar_sfx("clique", -8.0, 0.0)
		return false
	Efeitos.tremor(4.0)
	AudioManager.tocar_sfx("horda", -6.0, 0.05)
	return true


func _ao_chefe_surgir(nome: String, vida_maxima: float) -> void:
	AudioManager.tocar_bgm("chefe")
	if GlobalManager.horda_atual >= GlobalManager.HORDA_MAXIMA:
		_ao_cutscene_final(nome)
		return
	hud.mostrar_banner("CHEFE: %s" % nome.to_upper(), UI.COR_VERMELHO, "PERIGO IMINENTE")


func _ao_cutscene_final(nome: String) -> void:
	## O chefe final despenca do céu enquanto a arena inteira treme.
	hud.iniciar_cinema("O ELEMENTO SUPREMO", "%s DESPERTOU — A ARENA ESTÁ CAINDO" % nome.to_upper())
	if jogador != null and is_instance_valid(jogador):
		jogador.controle_bloqueado = true
	AudioManager.tocar_bgm("chefe")
	var arvore: SceneTree = get_tree()
	var passado: float = 0.0
	while passado < 3.2:
		await arvore.create_timer(0.4).timeout
		if not is_inside_tree():
			return
		passado += 0.4
		Efeitos.tremor(4.0 + passado * 3.5)
	if jogador != null and is_instance_valid(jogador):
		jogador.controle_bloqueado = false
	hud.encerrar_cinema()


func _ao_horda_iniciada(horda: int) -> void:
	if _finalizada:
		return
	var subtitulo: String = "SALTO MANUAL — PREPARE-SE" if _salto_manual else "ENXAME QUÍMICO EM APROXIMAÇÃO"
	_salto_manual = false
	hud.mostrar_banner("HORDA %d" % horda, UI.COR_CIANO, subtitulo)
	AudioManager.tocar_sfx("horda", -8.0, 0.06)


func _ao_horda_concluida(horda: int) -> void:
	if _finalizada or horda >= GlobalManager.HORDA_MAXIMA:
		return
	hud.mostrar_banner("HORDA %d LIMPA" % horda, UI.COR_VERDE, "PRÓXIMA ONDA EM INSTANTES")
	AudioManager.tocar_sfx("horda", -6.0, 0.04)


func _ao_chefe_morrer(_nome: String) -> void:
	AudioManager.tocar_bgm("jogo")


func _ao_morrer() -> void:
	if _finalizada:
		return
	_finalizada = true
	spawn_manager.parar()
	_aguardando = true
	var arvore: SceneTree = get_tree()
	await arvore.create_timer(1.3).timeout
	if not is_inside_tree():
		return
	GlobalManager.finalizar_partida(false)
	spawn_manager.parar()
	hud.mostrar_morte(false)


func _ao_vitoria() -> void:
	if _finalizada:
		return
	_finalizada = true
	await get_tree().create_timer(1.6).timeout
	if not is_inside_tree():
		return
	GlobalManager.finalizar_partida(true)
	hud.mostrar_morte(true)


func _ao_recomecar(horda: int) -> void:
	get_tree().paused = false
	GlobalManager.horda_skip_alvo = clampi(horda, 1, GlobalManager.HORDA_MAXIMA)
	get_tree().reload_current_scene()


func _ao_ir_loja() -> void:
	get_tree().paused = false
	GlobalManager.horda_skip_alvo = 1
	get_tree().change_scene_to_file("res://scenes/loja.tscn")


func _ao_ir_menu() -> void:
	get_tree().paused = false
	GlobalManager.horda_skip_alvo = 1
	get_tree().change_scene_to_file("res://scenes/menu.tscn")
