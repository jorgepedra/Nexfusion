class_name MaoChefe
extends Node2D
## Ataque da mão gigante do Elemento Supremo: marca o alvo, desce esmagando
## e, ao tocar o chão, espalha projéteis em todas as direções.

signal terminou

const MIRA: float = 0.95
const QUEDA: float = 0.34
const REPOUSO: float = 0.7
const SAIDA: float = 0.35
const ALTURA_QUEDA: float = 760.0

var chefe: ChefeFinal = null
var alvo: Vector2 = Vector2.ZERO
var raio_impacto: float = 118.0
var dano: float = 26.0

var _t: float = 0.0
var _p: float = 0.0
var _fase: String = "mira"
var _impactou: bool = false


func configurar(alvo_pos: Vector2, valor: float, raio: float) -> void:
	alvo = alvo_pos
	dano = valor
	raio_impacto = raio
	global_position = alvo_pos
	z_index = 40


func _chefe_vivo() -> bool:
	## O chefe pode morrer no meio do ataque: nesse caso o objeto é liberado.
	return chefe != null and is_instance_valid(chefe) and not chefe.morto


func _process(delta: float) -> void:
	if not _chefe_vivo():
		terminou.emit()
		queue_free()
		return
	_t += delta
	match _fase:
		"mira":
			var p: Player = chefe.jogador
			if p != null and is_instance_valid(p) and p.vivo:
				alvo = alvo.lerp(p.global_position, clampf(delta * 1.7, 0.0, 1.0))
			global_position = alvo
			if _t >= MIRA:
				_fase = "queda"
				_t = 0.0
				AudioManager.tocar_sfx("dash", -6.0, 0.08)
		"queda":
			_p = clampf(_t / QUEDA, 0.0, 1.0)
			if _t >= QUEDA:
				_fase = "repouso"
				_t = 0.0
				_impactar()
		"repouso":
			if _t >= REPOUSO:
				_fase = "saida"
				_t = 0.0
		_:
			if _t >= SAIDA:
				terminou.emit()
				queue_free()
				return
	queue_redraw()


func _impactar() -> void:
	if _impactou:
		return
	_impactou = true
	if not _chefe_vivo():
		return
	Efeitos.tremor(22.0)
	AudioManager.tocar_sfx("explosao", 0.0, 0.04)
	Efeitos.particulas(get_parent(), global_position, Color("ffa347"), 32, 400.0, 0.7, 4.0)
	Efeitos.anel(get_parent(), global_position, raio_impacto * 1.3, Color(1.0, 0.55, 0.3, 0.9), 0.5, 6.0)
	if not _chefe_vivo():
		return
	chefe.dano_area(global_position, raio_impacto, dano)
	for i: int in range(14):
		var ang: float = TAU * float(i) / 14.0 + randf_range(-0.12, 0.12)
		var dir: Vector2 = Vector2.RIGHT.rotated(ang)
		chefe.projetil(global_position + dir * (raio_impacto * 0.6), dir, 11.0, 520.0, 1.5)


func _draw() -> void:
	if _fase == "mira":
		var alerta: float = clampf(_t / MIRA, 0.0, 1.0)
		draw_circle(Vector2.ZERO, raio_impacto, Color(1.0, 0.25, 0.2, 0.08 + alerta * 0.14))
		draw_arc(Vector2.ZERO, raio_impacto * (0.55 + alerta * 0.45), 0.0, TAU, 44, Color(1.0, 0.35, 0.3, 0.75), 3.0, true)
		draw_circle(Vector2.ZERO, 7.0 + alerta * 5.0, Color(1.0, 0.55, 0.4, 0.85))
		draw_line(Vector2(-14, 0), Vector2(14, 0), Color(1.0, 0.5, 0.35, 0.7), 2.0)
		draw_line(Vector2(0, -14), Vector2(0, 14), Color(1.0, 0.5, 0.35, 0.7), 2.0)
		return
	var altura: float = 0.0
	if _fase == "queda":
		altura = ALTURA_QUEDA * (1.0 - _p * _p)
	elif _fase == "saida":
		altura = ALTURA_QUEDA * (_t / SAIDA)
	var centro: Vector2 = Vector2(0.0, -altura)
	# sombra no chão encolhendo conforme a mão sobe
	var escala_sombra: float = clampf(1.0 - altura / ALTURA_QUEDA * 0.8, 0.2, 1.0)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.42))
	draw_circle(Vector2.ZERO, raio_impacto * 0.8 * escala_sombra, Color(0.0, 0.0, 0.0, 0.4))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	draw_circle(Vector2.ZERO, raio_impacto, Color(1.0, 0.3, 0.22, 0.14))
	# braço que desce do céu
	draw_rect(Rect2(centro + Vector2(-36, -900), Vector2(72, 900)), Color(0.24, 0.14, 0.2))
	draw_rect(Rect2(centro + Vector2(-28, -900), Vector2(20, 900)), Color(0.33, 0.2, 0.28))
	# punho
	draw_circle(centro, 66.0, Color(0.3, 0.16, 0.24))
	draw_circle(centro, 56.0, Color(0.44, 0.24, 0.33))
	draw_circle(centro + Vector2(-14, -16), 18.0, Color(0.55, 0.32, 0.42))
	# dedos
	for i: int in range(4):
		var fx: float = -42.0 + float(i) * 28.0
		draw_circle(centro + Vector2(fx, -50.0), 17.0, Color(0.38, 0.2, 0.29))
		draw_circle(centro + Vector2(fx, -50.0), 13.0, Color(0.5, 0.28, 0.37))
	# runas elementares
	draw_arc(centro, 80.0, 0.0, TAU, 40, Color(1.0, 0.55, 0.35, 0.8), 3.0, true)
	for i: int in range(6):
		var ang: float = TAU * float(i) / 6.0 + _t * 2.0
		draw_circle(centro + Vector2(cos(ang), sin(ang)) * 80.0, 4.0, Color(1.0, 0.8, 0.5, 0.9))
