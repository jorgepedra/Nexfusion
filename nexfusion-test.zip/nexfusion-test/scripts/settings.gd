extends Control
## Configurações: volumes lineares (Música/SFX), tela cheia e remapeamento de teclas.

const ACOES_REMAPEAVEIS: Array[String] = [
	"mover_esquerda", "mover_direita", "mover_cima", "mover_baixo",
	"dash_esquiva", "tiro_primario", "tiro_carregado", "aparar_melee", "pausar",
]

var _acao_em_espera: String = ""
var _botoes_tecla: Dictionary = {}
var _aviso: Label


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var fundo: ColorRect = ColorRect.new()
	fundo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fundo.color = Color(0.03, 0.045, 0.07)
	add_child(fundo)
	_construir()
	AudioManager.tocar_bgm("menu")


func _construir() -> void:
	var margem: MarginContainer = MarginContainer.new()
	margem.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margem.add_theme_constant_override("margin_left", 80)
	margem.add_theme_constant_override("margin_right", 80)
	margem.add_theme_constant_override("margin_top", 30)
	margem.add_theme_constant_override("margin_bottom", 30)
	add_child(margem)
	var principal: VBoxContainer = VBoxContainer.new()
	principal.add_theme_constant_override("separation", 14)
	margem.add_child(principal)

	var topo: HBoxContainer = HBoxContainer.new()
	principal.add_child(topo)
	topo.add_child(UI.titulo("CONFIGURAÇÕES", 38, UI.COR_CIANO))
	var espaco: Control = Control.new()
	espaco.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	topo.add_child(espaco)
	var b_voltar: Button = UI.botao("VOLTAR", 16, UI.COR_TEXTO_FRACO)
	b_voltar.custom_minimum_size = Vector2(140, 44)
	b_voltar.pressed.connect(func() -> void: get_tree().change_scene_to_file("res://scenes/menu.tscn"))
	topo.add_child(b_voltar)

	var rolagem: ScrollContainer = ScrollContainer.new()
	rolagem.size_flags_vertical = Control.SIZE_EXPAND_FILL
	rolagem.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	principal.add_child(rolagem)
	var lista: VBoxContainer = VBoxContainer.new()
	lista.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lista.add_theme_constant_override("separation", 10)
	rolagem.add_child(lista)

	lista.add_child(_secao("ÁUDIO", UI.COR_CIANO))
	lista.add_child(_linha_slider("Música", GlobalManager.volume_musica, func(v: float) -> void:
		GlobalManager.definir_volume_musica(v)))
	lista.add_child(_linha_slider("Efeitos (SFX)", GlobalManager.volume_sfx, func(v: float) -> void:
		GlobalManager.definir_volume_sfx(v)
		AudioManager.tocar_sfx("hit", -14.0)))

	lista.add_child(_secao("VÍDEO", UI.COR_MAGENTA))
	var linha_tela: HBoxContainer = HBoxContainer.new()
	linha_tela.add_theme_constant_override("separation", 14)
	var lbl_tela: Label = UI.rotulo("Tela cheia", 17, UI.COR_TEXTO)
	lbl_tela.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	linha_tela.add_child(lbl_tela)
	var check: CheckButton = CheckButton.new()
	check.button_pressed = GlobalManager.tela_cheia
	check.add_theme_color_override("font_color", UI.COR_TEXTO)
	check.toggled.connect(func(ativa: bool) -> void: GlobalManager.definir_tela_cheia(ativa))
	linha_tela.add_child(check)
	lista.add_child(_envolver(linha_tela))

	lista.add_child(_secao("CONTROLES", UI.COR_VERMELHO))
	var dica: Label = UI.rotulo("Clique em um atalho e pressione a nova tecla ou botão do mouse.", 13, UI.COR_TEXTO_FRACO)
	lista.add_child(dica)
	_aviso = UI.rotulo("", 14, UI.COR_AMBAR)
	lista.add_child(_aviso)
	var grade: GridContainer = GridContainer.new()
	grade.columns = 3
	grade.add_theme_constant_override("h_separation", 14)
	grade.add_theme_constant_override("v_separation", 8)
	lista.add_child(grade)
	for acao: String in ACOES_REMAPEAVEIS:
		var lbl: Label = UI.rotulo(_nome_acao(acao), 15, UI.COR_TEXTO)
		lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		grade.add_child(lbl)
		var b: Button = UI.botao(GlobalManager.nome_tecla(acao), 14, UI.COR_CIANO)
		b.custom_minimum_size = Vector2(200, 38)
		b.pressed.connect(_esperar_tecla.bind(acao))
		grade.add_child(b)
		_botoes_tecla[acao] = b
		var vazio: Control = Control.new()
		vazio.custom_minimum_size = Vector2(200, 1)
		grade.add_child(vazio)

	lista.add_child(_secao("PROGRESSO", UI.COR_VERMELHO))
	var linha_reset: HBoxContainer = HBoxContainer.new()
	linha_reset.add_theme_constant_override("separation", 12)
	var lbl_reset: Label = UI.rotulo("Apagar todo o progresso salvo (moedas, upgrades e recordes).", 14, UI.COR_TEXTO_FRACO)
	lbl_reset.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	linha_reset.add_child(lbl_reset)
	var b_reset: Button = UI.botao("APAGAR SAVE", 14, UI.COR_VERMELHO)
	b_reset.custom_minimum_size = Vector2(180, 40)
	b_reset.pressed.connect(func() -> void:
		GlobalManager.resetar_progresso()
		_aviso.text = "Progresso apagado."
		_aviso.add_theme_color_override("font_color", UI.COR_VERMELHO))
	linha_reset.add_child(b_reset)
	lista.add_child(_envolver(linha_reset))


func _secao(texto: String, cor: Color) -> Control:
	var v: VBoxContainer = VBoxContainer.new()
	var espaco: Control = Control.new()
	espaco.custom_minimum_size = Vector2(0, 12)
	v.add_child(espaco)
	var h: HBoxContainer = HBoxContainer.new()
	h.add_child(UI.rotulo(texto, 18, cor))
	var linha: HSeparator = HSeparator.new()
	linha.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	linha.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(linha)
	v.add_child(h)
	return v


func _linha_slider(nome: String, valor: float, ao_mudar: Callable) -> Control:
	var h: HBoxContainer = HBoxContainer.new()
	h.add_theme_constant_override("separation", 14)
	var lbl: Label = UI.rotulo(nome, 17, UI.COR_TEXTO)
	lbl.custom_minimum_size = Vector2(200, 32)
	h.add_child(lbl)
	var slider: HSlider = HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.05
	slider.value = valor
	slider.custom_minimum_size = Vector2(340, 28)
	slider.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(slider)
	var pct: Label = UI.rotulo("%d%%" % int(round(valor * 100.0)), 15, UI.COR_CIANO)
	pct.custom_minimum_size = Vector2(60, 30)
	pct.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	h.add_child(pct)
	slider.value_changed.connect(func(v: float) -> void:
		pct.text = "%d%%" % int(round(v * 100.0))
		ao_mudar.call(v))
	return _envolver(h)


func _envolver(filho: Control) -> Control:
	var p: PanelContainer = PanelContainer.new()
	p.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.06, 0.09, 0.13, 0.95), UI.COR_BORDA, 4))
	p.add_child(filho)
	return p


func _nome_acao(acao: String) -> String:
	match acao:
		"mover_esquerda":
			return "Mover esquerda"
		"mover_direita":
			return "Mover direita"
		"mover_cima":
			return "Mover cima"
		"mover_baixo":
			return "Mover baixo"
		"dash_esquiva":
			return "Dash / esquiva"
		"tiro_primario":
			return "Tiro primário"
		"tiro_carregado":
			return "Catalisador (moeda)"
		"aparar_melee":
			return "Aparar (parry)"
		"pausar":
			return "Pausar"
		_:
			return acao


func _esperar_tecla(acao: String) -> void:
	_acao_em_espera = acao
	_aviso.text = "Pressione a nova tecla para '%s' (ESC cancela)" % _nome_acao(acao)
	_aviso.add_theme_color_override("font_color", UI.COR_AMBAR)
	var b: Button = _botoes_tecla.get(acao, null) as Button
	if b != null:
		b.text = "…"
		b.release_focus()


func _unhandled_input(evento: InputEvent) -> void:
	if _acao_em_espera == "":
		return
	if evento is InputEventKey:
		var k: InputEventKey = evento as InputEventKey
		if not k.pressed or k.echo:
			return
		if k.physical_keycode == KEY_ESCAPE:
			_acao_em_espera = ""
			_aviso.text = "Remapeamento cancelado."
			_atualizar_botoes()
			get_viewport().set_input_as_handled()
			return
		GlobalManager.remapear_acao(_acao_em_espera, k)
	elif evento is InputEventMouseButton:
		var m: InputEventMouseButton = evento as InputEventMouseButton
		if not m.pressed:
			return
		GlobalManager.remapear_acao(_acao_em_espera, m)
	else:
		return
	_aviso.text = "Atalho atualizado."
	_aviso.add_theme_color_override("font_color", UI.COR_VERDE)
	_acao_em_espera = ""
	_atualizar_botoes()
	get_viewport().set_input_as_handled()


func _atualizar_botoes() -> void:
	for acao_v: Variant in _botoes_tecla.keys():
		var acao: String = String(acao_v)
		var b: Button = _botoes_tecla[acao_v] as Button
		if b != null:
			b.text = GlobalManager.nome_tecla(acao)
