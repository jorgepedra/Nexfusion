class_name SpawnManager
extends Node
## Gerencia as 30 hordas, o escalonamento de spawn e as fases de chefe (10/20/30).
## Catálogo 100% data-driven: lê todos os DadosInimigo de res://resources/inimigos/.

signal horda_iniciada(horda: int)
signal horda_limpa(horda: int)
signal run_completa

const PASTA_INIMIGOS: String = "res://resources/inimigos"

var jogador: Player
var arena: Rect2 = Rect2(0, 0, 2400, 1500)
var container: Node2D
var ativo: bool = false

var _catalogo: Array[DadosInimigo] = []
var _fase: String = "idle"
var _restantes: int = 0
var _spawn_timer: float = 0.0
var _intervalo: float = 0.7
var _espera: float = 0.0
var _chefe: Boss = null
var _chefe_atual: int = 0
var _vivos_timer: float = 0.0
var _vivos: int = 0


func _ready() -> void:
	add_to_group("spawn_manager")
	_carregar_catalogo()


func _carregar_catalogo() -> void:
	_catalogo.clear()
	var dir: DirAccess = DirAccess.open(PASTA_INIMIGOS)
	if dir == null:
		push_warning("SpawnManager: pasta de inimigos não encontrada")
		return
	dir.list_dir_begin()
	var arquivo: String = dir.get_next()
	while arquivo != "":
		if arquivo.ends_with(".tres"):
			var rec: Resource = load(PASTA_INIMIGOS.path_join(arquivo))
			if rec is DadosInimigo:
				_catalogo.append(rec as DadosInimigo)
		arquivo = dir.get_next()
	dir.list_dir_end()
	_catalogo.sort_custom(func(a: DadosInimigo, b: DadosInimigo) -> bool: return a.horda_minima < b.horda_minima)


func iniciar(jogador_ref: Player, arena_rect: Rect2, container_ref: Node2D) -> void:
	jogador = jogador_ref
	arena = arena_rect
	container = container_ref
	ativo = true
	if _catalogo.is_empty():
		_carregar_catalogo()
	_iniciar_horda(GlobalManager.horda_atual)


func parar() -> void:
	ativo = false
	_fase = "idle"


func pular_horda(quantidade: int = 1) -> bool:
	## Salta direto para outra horda, limpando a arena (atalho escondido Shift+P).
	if not ativo or not GlobalManager.partida_ativa:
		return false
	if GlobalManager.horda_atual >= GlobalManager.HORDA_MAXIMA:
		return false
	var alvo: int = clampi(GlobalManager.horda_atual + maxi(1, quantidade), 1, GlobalManager.HORDA_MAXIMA)
	_limpar_combate()
	_iniciar_horda(alvo)
	_espera = 0.6
	GlobalManager.salvar()
	return true


func _limpar_combate() -> void:
	for grupo: String in ["inimigos", "projeteis_inimigos", "granadas"]:
		for n: Node in get_tree().get_nodes_in_group(grupo):
			if is_instance_valid(n):
				n.queue_free()
	_vivos = 0
	_vivos_timer = 0.0
	_chefe = null
	_chefe_atual = 0
	GlobalManager.chefe_vida.emit(0.0, 1.0)


func _iniciar_horda(horda: int) -> void:
	GlobalManager.horda_atual = horda
	_fase = "preparando"
	_espera = 1.6
	_chefe = null
	_chefe_atual = 0
	if _eh_horda_chefe(horda):
		_restantes = 0 if horda >= GlobalManager.HORDA_MAXIMA else 6 + horda / 2
	else:
		_restantes = mini(36, 7 + horda * 2)
	_intervalo = maxf(0.11, 0.74 - float(horda) * 0.021)
	_spawn_timer = 0.4
	horda_iniciada.emit(horda)
	GlobalManager.horda_alterada.emit(horda)


func _eh_horda_chefe(horda: int) -> bool:
	return horda >= GlobalManager.HORDA_MAXIMA or horda % GlobalManager.TAMANHO_FASE == 0


func _process(delta: float) -> void:
	if not ativo or not GlobalManager.partida_ativa:
		return
	_vivos_timer -= delta
	if _vivos_timer <= 0.0:
		_vivos_timer = 0.2
		_vivos = _contar_vivos()
	match _fase:
		"preparando":
			_espera -= delta
			if _espera <= 0.0:
				_fase = "spawnando"
				if _eh_horda_chefe(GlobalManager.horda_atual):
					_spawnar_chefe(GlobalManager.horda_atual)
		"spawnando":
			_spawn_timer -= delta
			if _spawn_timer <= 0.0 and _restantes > 0:
				_spawn_timer = _intervalo
				if _vivos < _limite_vivos():
					_spawnar_comum()
					_restantes -= 1
			if _restantes <= 0:
				_fase = "limpando"
		"limpando":
			# Contagem direta: o chefe final surge sem inimigos comuns e precisa
			# ser contado no mesmo quadro para a arena não ser dada como limpa.
			if _contar_vivos() == 0:
				_fase = "concluida"
				_espera = 2.0
				horda_limpa.emit(GlobalManager.horda_atual)
				var concluida: int = GlobalManager.horda_atual
				GlobalManager.concluir_horda()
				if concluida >= GlobalManager.HORDA_MAXIMA:
					ativo = false
					run_completa.emit()
					return
		"concluida":
			_espera -= delta
			if _espera <= 0.0 and GlobalManager.partida_ativa:
				_iniciar_horda(GlobalManager.horda_atual)


func _limite_vivos() -> int:
	return mini(56, 18 + GlobalManager.horda_atual * 2)


func _contar_vivos() -> int:
	var total: int = 0
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		var e: Enemy = n as Enemy
		if e != null and is_instance_valid(e) and not e.morto:
			total += 1
	return total


func _spawnar_comum() -> void:
	var opcoes: Array[DadosInimigo] = []
	for d: DadosInimigo in _catalogo:
		if d.is_boss:
			continue
		if d.horda_minima <= GlobalManager.horda_atual:
			opcoes.append(d)
	if opcoes.is_empty():
		return
	var peso_total: float = 0.0
	for d: DadosInimigo in opcoes:
		peso_total += maxf(0.01, d.peso_spawn)
	var sorteio: float = randf() * peso_total
	var escolhido: DadosInimigo = opcoes[0]
	for d: DadosInimigo in opcoes:
		sorteio -= maxf(0.01, d.peso_spawn)
		if sorteio <= 0.0:
			escolhido = d
			break
	_instanciar(escolhido, _posicao_spawn())


func _spawnar_chefe(horda: int) -> void:
	var indice: int = 4 if horda >= GlobalManager.HORDA_MAXIMA else clampi(horda / GlobalManager.TAMANHO_FASE, 1, 3)
	_chefe_atual = indice
	for d: DadosInimigo in _catalogo:
		if not d.is_boss:
			continue
		if d.ordem_chefe != indice:
			continue
		var pos: Vector2 = Vector2(arena.get_center().x, arena.position.y + 300.0)
		if horda >= GlobalManager.HORDA_MAXIMA:
			# o chefe final despenca do céu durante a cutscene
			pos = Vector2(arena.get_center().x, arena.position.y - 260.0)
		var chefe: Boss = _instanciar(d, pos) as Boss
		if chefe != null:
			_chefe = chefe
			GlobalManager.chefe_surgiu.emit(d.nome, chefe.vida_max)
		return


func invocar_guardioes(pos: Vector2, quantidade: int = 3) -> Array:
	## Invoca inimigos que protegem a vida do chefe final até serem mortos.
	var lista: Array = []
	var opcoes: Array[DadosInimigo] = []
	for d: DadosInimigo in _catalogo:
		if d.is_boss or d.comportamento == "atirador":
			continue
		if d.horda_minima <= GlobalManager.horda_atual:
			opcoes.append(d)
	if opcoes.is_empty():
		return lista
	for i: int in range(quantidade):
		var d: DadosInimigo = opcoes[randi() % opcoes.size()]
		var ang: float = TAU * float(i) / float(maxi(1, quantidade)) + randf_range(-0.3, 0.3)
		var e: Enemy = _instanciar(d, pos + Vector2(cos(ang), sin(ang)) * 150.0)
		if e == null:
			continue
		e.vida_max *= 2.4
		e.vida = e.vida_max
		e.add_to_group("guardioes_chefe")
		Efeitos.anel(container, e.global_position, 70.0, Color(0.72, 0.6, 1.0, 0.85), 0.45, 3.0)
		lista.append(e)
	return lista


func _instanciar(d: DadosInimigo, pos: Vector2) -> Enemy:
	if container == null or not is_instance_valid(container):
		return null
	var cena_caminho: String = d.cena if d.cena != "" else "res://scenes/enemy.tscn"
	if not ResourceLoader.exists(cena_caminho):
		return null
	var cena: PackedScene = load(cena_caminho) as PackedScene
	if cena == null:
		return null
	var e: Enemy = cena.instantiate() as Enemy
	if e == null:
		return null
	e.dados = d
	container.add_child(e)
	e.configurar(d, GlobalManager.horda_atual)
	e.global_position = pos
	Efeitos.particulas(container, pos, d.cor, 6, 110.0, 0.4, 2.0)
	Efeitos.anel(container, pos, 34.0, Color(d.cor.r, d.cor.g, d.cor.b, 0.5), 0.3, 2.0)
	return e


func invocar_minions(pos: Vector2, quantidade: int) -> void:
	var opcoes: Array[DadosInimigo] = []
	for d: DadosInimigo in _catalogo:
		if not d.is_boss and d.horda_minima <= GlobalManager.horda_atual:
			opcoes.append(d)
	if opcoes.is_empty():
		return
	for i: int in range(quantidade):
		var d: DadosInimigo = opcoes[randi() % opcoes.size()]
		var ang: float = randf() * TAU
		_instanciar(d, pos + Vector2(cos(ang), sin(ang)) * 90.0)


func _posicao_spawn() -> Vector2:
	var centro: Vector2 = jogador.global_position if jogador != null else arena.get_center()
	for tentativa: int in range(12):
		var ang: float = randf() * TAU
		var dist: float = randf_range(560.0, 820.0)
		var p: Vector2 = centro + Vector2(cos(ang), sin(ang)) * dist
		p.x = clampf(p.x, arena.position.x + 40.0, arena.end.x - 40.0)
		p.y = clampf(p.y, arena.position.y + 40.0, arena.end.y - 40.0)
		if p.distance_to(centro) > 420.0:
			return p
	return Vector2(
		clampf(centro.x + randf_range(-700.0, 700.0), arena.position.x + 40.0, arena.end.x - 40.0),
		clampf(centro.y + randf_range(-520.0, 520.0), arena.position.y + 40.0, arena.end.y - 40.0)
	)
