extends Control
## Menu inicial: iniciar partida, loja, configurações e sair.

var _label_recorde: Label
var _label_moedas: Label
var _fundo: Control


class FundoQuimico extends Control:
	var particulas: Array[Dictionary] = []
	var _tempo: float = 0.0

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		var rng: RandomNumberGenerator = RandomNumberGenerator.new()
		rng.randomize()
		for i: int in range(46):
			particulas.append({
				"pos": Vector2(rng.randf(), rng.randf()),
				"vel": Vector2(rng.randf_range(-0.012, 0.012), rng.randf_range(-0.02, -0.004)),
				"raio": rng.randf_range(2.0, 6.0),
				"cor": [Color("8ff3ff"), Color("ff5fd2"), Color("5fe08a"), Color("ffcf4a")][i % 4],
			})

	func _process(delta: float) -> void:
		_tempo += delta
		for p: Dictionary in particulas:
			var pos: Vector2 = p["pos"] as Vector2
			pos += (p["vel"] as Vector2) * delta
			if pos.y < -0.05:
				pos.y = 1.05
			if pos.x < -0.05:
				pos.x = 1.05
			elif pos.x > 1.05:
				pos.x = -0.05
			p["pos"] = pos
		queue_redraw()

	func _draw() -> void:
		var s: Vector2 = size
		draw_rect(Rect2(Vector2.ZERO, s), Color(0.03, 0.045, 0.07))
		# malha de fundo
		for i: int in range(0, int(s.x), 64):
			draw_line(Vector2(i, 0), Vector2(i, s.y), Color(0.09, 0.16, 0.22, 0.35), 1.0)
		for j: int in range(0, int(s.y), 64):
			draw_line(Vector2(0, j), Vector2(s.x, j), Color(0.09, 0.16, 0.22, 0.35), 1.0)
		# elos entre partículas próximas
		for i: int in range(particulas.size()):
			var a: Dictionary = particulas[i]
			var pa: Vector2 = (a["pos"] as Vector2) * s
			for j: int in range(i + 1, particulas.size()):
				var b: Dictionary = particulas[j]
				var pb: Vector2 = (b["pos"] as Vector2) * s
				var d: float = pa.distance_to(pb)
				if d < 120.0:
					var alfa: float = (1.0 - d / 120.0) * 0.16
					draw_line(pa, pb, Color(0.45, 0.85, 0.95, alfa), 1.0)
		for p: Dictionary in particulas:
			var pp: Vector2 = (p["pos"] as Vector2) * s
			var cor: Color = p["cor"] as Color
			var r: float = float(p["raio"])
			draw_circle(pp, r, Color(cor.r, cor.g, cor.b, 0.55))
			draw_circle(pp, r * 2.6, Color(cor.r, cor.g, cor.b, 0.08))
		# vinheta inferior
		draw_rect(Rect2(0, s.y * 0.72, s.x, s.y * 0.28), Color(0.02, 0.03, 0.05, 0.55))


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_fundo = FundoQuimico.new()
	_fundo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_fundo)
	_construir()
	AudioManager.tocar_bgm("menu")
	_animar_titulo()


func _construir() -> void:
	var centro: VBoxContainer = VBoxContainer.new()
	centro.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	centro.alignment = BoxContainer.ALIGNMENT_CENTER
	centro.add_theme_constant_override("separation", 8)
	add_child(centro)

	var titulo: Label = UI.titulo("NEXFUSION", 76, UI.COR_CIANO)
	titulo.name = "Titulo"
	centro.add_child(titulo)
	var sub: Label = UI.rotulo("ARENA QUÍMICA  ·  ROGUE-LITE DE SOBREVIVÊNCIA", 16, UI.COR_TEXTO_FRACO)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	centro.add_child(sub)
	centro.add_child(UI.separador(26.0))

	var experimento: Label = UI.rotulo("[ EXPERIMENTO #%d ]" % (GlobalManager.partidas_jogadas + 1), 13, UI.COR_MAGENTA)
	experimento.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	centro.add_child(experimento)
	centro.add_child(UI.separador(10.0))

	var b_comecar: Button = UI.botao("COMEÇAR", 24, UI.COR_CIANO)
	b_comecar.custom_minimum_size = Vector2(320, 54)
	b_comecar.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	b_comecar.pressed.connect(_ao_comecar)
	centro.add_child(b_comecar)
	var b_loja: Button = UI.botao("LOJA", 22, UI.COR_AMBAR)
	b_loja.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	b_loja.pressed.connect(_ao_loja)
	centro.add_child(b_loja)
	var b_config: Button = UI.botao("CONFIGURAÇÕES", 22, UI.COR_VIOLETA)
	b_config.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	b_config.pressed.connect(_ao_config)
	centro.add_child(b_config)
	var b_sair: Button = UI.botao("SAIR", 22, UI.COR_VERMELHO)
	b_sair.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	b_sair.pressed.connect(_ao_sair)
	centro.add_child(b_sair)

	centro.add_child(UI.separador(24.0))
	var rodape: HBoxContainer = HBoxContainer.new()
	rodape.alignment = BoxContainer.ALIGNMENT_CENTER
	rodape.add_theme_constant_override("separation", 26)
	centro.add_child(rodape)
	_label_recorde = UI.rotulo("RECORDE: HORDA %d" % GlobalManager.maior_horda_alcancada, 15, UI.COR_TEXTO)
	rodape.add_child(_label_recorde)
	_label_moedas = UI.rotulo("◈ %s" % UI.formatar(GlobalManager.moedas), 15, UI.COR_AMBAR)
	rodape.add_child(_label_moedas)
	var arma: DadosArma = GlobalManager.arma_atual()
	var label_arma: Label = UI.rotulo("ARMA: %s" % (arma.nome.to_upper() if arma != null else "—"), 15, UI.COR_CIANO)
	rodape.add_child(label_arma)

	var versao: Label = UI.rotulo("v1.0  ·  Godot 4.x  ·  pixel art procedural", 11, Color(0.4, 0.47, 0.56))
	versao.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	versao.offset_left = -340
	versao.offset_top = -34
	versao.offset_right = -16
	versao.offset_bottom = -10
	versao.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	add_child(versao)


func _animar_titulo() -> void:
	var titulo: Label = get_node_or_null("") as Label
	if titulo == null:
		for filho: Node in get_children():
			if filho is VBoxContainer:
				titulo = (filho as VBoxContainer).get_node_or_null("Titulo") as Label
	if titulo == null:
		return
	var tw: Tween = create_tween().set_loops()
	tw.tween_property(titulo, "modulate", Color(0.75, 1.0, 1.0), 1.6)
	tw.tween_property(titulo, "modulate", Color.WHITE, 1.6)


func _ao_comecar() -> void:
	GlobalManager.horda_skip_alvo = 1
	get_tree().change_scene_to_file("res://scenes/jogo.tscn")


func _ao_loja() -> void:
	get_tree().change_scene_to_file("res://scenes/loja.tscn")


func _ao_config() -> void:
	get_tree().change_scene_to_file("res://scenes/configuracoes.tscn")


func _ao_sair() -> void:
	get_tree().quit()
