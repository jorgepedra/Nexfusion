class_name TelaMorte
extends Control
## Tela de estatísticas ao morrer ou vencer. Processa sempre (árvore pausada).

signal recomecar_solicitado(horda: int)
signal loja_solicitada
signal menu_solicitado

var _conteudo: VBoxContainer


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false


func mostrar(venceu: bool, resultado: Dictionary) -> void:
	visible = true
	for filho: Node in get_children():
		filho.queue_free()
	var fundo: ColorRect = ColorRect.new()
	fundo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fundo.color = Color(0.02, 0.02, 0.04, 0.92)
	add_child(fundo)
	_conteudo = VBoxContainer.new()
	_conteudo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_conteudo.alignment = BoxContainer.ALIGNMENT_CENTER
	_conteudo.add_theme_constant_override("separation", 10)
	add_child(_conteudo)

	var titulo: Label = UI.titulo("VITÓRIA" if venceu else "VOCÊ MORREU", 54, UI.COR_VERDE if venceu else UI.COR_VERMELHO)
	_conteudo.add_child(titulo)

	var rank: String = String(resultado.get("rank", "C"))
	var cor_rank: Color = GlobalManager.cor_rank(rank)
	if rank == "S++":
		cor_rank = Color("8ff3ff")
	var lbl_rank: Label = UI.titulo("RANK %s" % rank, 40, cor_rank)
	_conteudo.add_child(lbl_rank)

	var subtitulo: Label = UI.rotulo(
		"Horda %d  •  Nível %d  •  %s abates  •  %s" % [
			int(resultado.get("horda", 1)),
			int(resultado.get("nivel", 1)),
			UI.formatar(int(resultado.get("abates", 0))),
			_formatar_tempo(float(resultado.get("tempo", 0.0))),
		],
		16, UI.COR_TEXTO_FRACO)
	subtitulo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_conteudo.add_child(subtitulo)

	_conteudo.add_child(UI.separador(14.0))
	var painel: PanelContainer = PanelContainer.new()
	painel.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.07, 0.1, 0.15, 0.95), UI.COR_BORDA, 6))
	painel.custom_minimum_size = Vector2(440, 0)
	painel.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_conteudo.add_child(painel)
	var vb: VBoxContainer = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	painel.add_child(vb)
	vb.add_child(_linha("Pontuação final", UI.formatar(int(resultado.get("pontuacao", 0))), UI.COR_TEXTO))
	vb.add_child(_linha("Estilo máximo", "%.0f" % float(resultado.get("estilo_maximo", 0.0)), UI.COR_CIANO))
	vb.add_child(_linha("Moedas da run", UI.formatar(int(resultado.get("moedas_base", 0))), UI.COR_AMBAR))
	vb.add_child(_linha("Multiplicador de rank", "x%.2f" % float(resultado.get("multiplicador", 1.0)), cor_rank))
	var separador_linha: HSeparator = HSeparator.new()
	vb.add_child(separador_linha)
	vb.add_child(_linha("MOEDAS GANHAS", "+%s" % UI.formatar(int(resultado.get("moedas_finais", 0))), UI.COR_AMBAR, 22))

	var cartas: Array = resultado.get("cartas", []) as Array
	if not cartas.is_empty():
		var lbl_cartas: Label = UI.rotulo("CATALISADORES: %d" % cartas.size(), 13, UI.COR_MAGENTA)
		lbl_cartas.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		_conteudo.add_child(lbl_cartas)

	_conteudo.add_child(UI.separador(12.0))
	var linha_botoes: HBoxContainer = HBoxContainer.new()
	linha_botoes.alignment = BoxContainer.ALIGNMENT_CENTER
	linha_botoes.add_theme_constant_override("separation", 12)
	_conteudo.add_child(linha_botoes)
	var btn_replay: Button = UI.botao("JOGAR NOVAMENTE", 18, UI.COR_CIANO)
	btn_replay.custom_minimum_size = Vector2(240, 46)
	btn_replay.pressed.connect(func() -> void: recomecar_solicitado.emit(1))
	linha_botoes.add_child(btn_replay)
	if GlobalManager.maior_horda_alcancada >= 4:
		var alvo: int = maxi(2, GlobalManager.maior_horda_alcancada / 2)
		var btn_skip: Button = UI.botao("PULAR PARA HORDA %d" % alvo, 18, UI.COR_AMBAR)
		btn_skip.custom_minimum_size = Vector2(240, 46)
		btn_skip.pressed.connect(func() -> void: recomecar_solicitado.emit(alvo))
		linha_botoes.add_child(btn_skip)
	var btn_loja: Button = UI.botao("IR PARA A LOJA", 18, UI.COR_MAGENTA)
	btn_loja.custom_minimum_size = Vector2(200, 46)
	btn_loja.pressed.connect(func() -> void: loja_solicitada.emit())
	linha_botoes.add_child(btn_loja)
	var btn_menu: Button = UI.botao("MENU", 18, UI.COR_TEXTO_FRACO)
	btn_menu.custom_minimum_size = Vector2(140, 46)
	btn_menu.pressed.connect(func() -> void: menu_solicitado.emit())
	linha_botoes.add_child(btn_menu)

	modulate.a = 0.0
	var tw: Tween = create_tween()
	tw.tween_property(self, "modulate:a", 1.0, 0.35)


func _linha(rotulo_texto: String, valor: String, cor: Color, tamanho: int = 16) -> Control:
	var h: HBoxContainer = HBoxContainer.new()
	var l: Label = UI.rotulo(rotulo_texto, tamanho - 2, UI.COR_TEXTO_FRACO)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(l)
	var v: Label = UI.rotulo(valor, tamanho, cor)
	v.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	h.add_child(v)
	return h


func _formatar_tempo(segundos: float) -> String:
	var total: int = int(segundos)
	return "%02d:%02d" % [total / 60, total % 60]
