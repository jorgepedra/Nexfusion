class_name Projetil
extends Area2D
## Projétil genérico (jogador ou inimigo) com varredura por raio (sem tunelamento),
## perfuração, cadeia elétrica, ricochete em paredes, explosão em área e
## redirecionamento em moedas (mecânica marksman do ULTRAKILL).

const CENA_EXPLOSAO: String = "res://scenes/explosao.tscn"
const RAIO_MOEDA: float = 20.0

var amigavel: bool = true
var direcao: Vector2 = Vector2.RIGHT
var dano: float = 5.0
var velocidade: float = 900.0
var cor: Color = Color.WHITE
var tamanho: float = 1.0
var perfuracao: int = 0
var cadeia: int = 0
var ricochetes: int = 0
var raio_explosao: float = 0.0
var critico: bool = false
var alcance: float = 900.0
## Tempo de vida em segundos (0 = só termina pelo alcance).
var duracao: float = 0.0
var elemento: String = ""
## id da arma que gerou o projétil (para a regra de neutralização química).
var arma_id: String = ""
var origem: Vector2 = Vector2.ZERO
var perseguicao: Enemy = null

var _hits: int = 0
var _distancia: float = 0.0
var _tempo_vida: float = 0.0
var _sprite: Sprite2D
var _glow: Sprite2D
var _cena_explosao: PackedScene = null


func _ready() -> void:
	z_index = 25
	collision_layer = 0
	collision_mask = 0
	monitoring = false
	monitorable = false
	var forma: CollisionShape2D = CollisionShape2D.new()
	var circle: CircleShape2D = CircleShape2D.new()
	circle.radius = 4.0
	forma.shape = circle
	add_child(forma)
	_construir_visual()
	if ResourceLoader.exists(CENA_EXPLOSAO):
		_cena_explosao = load(CENA_EXPLOSAO) as PackedScene


func configurar(cfg: Dictionary) -> void:
	amigavel = bool(cfg.get("amigavel", true))
	direcao = (cfg.get("direcao", Vector2.RIGHT) as Vector2).normalized()
	dano = float(cfg.get("dano", 5.0))
	velocidade = float(cfg.get("velocidade", 900.0))
	cor = cfg.get("cor", Color.WHITE) as Color
	tamanho = float(cfg.get("tamanho", 1.0))
	perfuracao = int(cfg.get("perfuracao", 0))
	cadeia = int(cfg.get("cadeia", 0))
	ricochetes = int(cfg.get("ricochetes", 0))
	raio_explosao = float(cfg.get("raio_explosao", 0.0))
	critico = bool(cfg.get("critico", false))
	alcance = float(cfg.get("alcance", 900.0))
	duracao = float(cfg.get("duracao", 0.0))
	elemento = String(cfg.get("elemento", ""))
	arma_id = String(cfg.get("arma", ""))
	origem = global_position
	if amigavel:
		add_to_group("projeteis_jogador")
	else:
		add_to_group("projeteis_inimigos")
	_construir_visual()


func _construir_visual() -> void:
	if _sprite != null:
		_sprite.queue_free()
	if _glow != null:
		_glow.queue_free()
	var tex: Texture2D = null
	if ResourceLoader.exists("res://sprites/props/particula.png"):
		tex = load("res://sprites/props/particula.png") as Texture2D
	_glow = Sprite2D.new()
	_glow.texture = tex
	_glow.modulate = Color(cor.r, cor.g, cor.b, 0.35)
	_glow.scale = Vector2(tamanho * 4.0, tamanho * 4.0)
	_glow.z_index = -1
	add_child(_glow)
	_sprite = Sprite2D.new()
	_sprite.texture = tex
	_sprite.modulate = cor
	_sprite.scale = Vector2(tamanho * 1.6, tamanho * 3.4) if amigavel else Vector2(tamanho * 2.4, tamanho * 2.4)
	_sprite.rotation = direcao.angle()
	_sprite.z_index = 1
	add_child(_sprite)


func _physics_process(delta: float) -> void:
	if duracao > 0.0:
		_tempo_vida += delta
		if _tempo_vida >= duracao:
			_expirar()
			return
	if perseguicao != null:
		if not is_instance_valid(perseguicao) or perseguicao.morto:
			perseguicao = null
		else:
			var quer: Vector2 = (perseguicao.global_position - global_position).normalized()
			direcao = direcao.slerp(quer, clampf(delta * 8.0, 0.0, 1.0)).normalized()
	var passo: float = velocidade * delta
	var alvo: Vector2 = global_position + direcao * passo
	_verificar_moedas()
	var espaco: PhysicsDirectSpaceState2D = get_world_2d().direct_space_state
	if espaco != null:
		var consulta: PhysicsRayQueryParameters2D = PhysicsRayQueryParameters2D.create(global_position, alvo)
		consulta.collide_with_areas = true
		consulta.collide_with_bodies = true
		consulta.collision_mask = _mascara()
		var res: Dictionary = espaco.intersect_ray(consulta)
		if not res.is_empty():
			var ponto: Vector2 = res.get("position", alvo) as Vector2
			var normal: Vector2 = res.get("normal", Vector2.ZERO) as Vector2
			var colisor: Object = res.get("collider") as Object
			alvo = ponto
			# Aplica o ponto ANTES do handler: no ricochete ele reposiciona o
			# projétil 3 px para dentro; sobrescrever depois o prendia na parede.
			global_position = alvo
			_ao_atingir(colisor, ponto, normal)
			if not is_instance_valid(self) or _removido:
				return
			# Ricochete já afastou o projétil da parede; não sobrescrever.
			if global_position.distance_to(alvo) < 0.01:
				global_position = alvo
		else:
			global_position = alvo
	_distancia += passo
	if _sprite != null:
		_sprite.rotation = direcao.angle()
	if _distancia >= alcance:
		_expirar()


var _removido: bool = false


func _mascara() -> int:
	if amigavel:
		return 2 | 16 | 4
	return 1 | 4


func _ao_atingir(colisor: Object, ponto: Vector2, normal: Vector2) -> void:
	if colisor == null:
		return
	if amigavel:
		if colisor is Enemy:
			var e: Enemy = colisor as Enemy
			if e.morto:
				return
			# Química real: água num metal alcalino não apaga nada — alimenta.
			if e.dados != null and e.dados.id == "sodio" and arma_id == "agua":
				e.curar_com_agua(dano)
				Efeitos.particulas(get_parent(), ponto, Color("ffcf4a"), 8, 190.0, 0.4, 3.0, "fogo")
				AudioManager.tocar_sfx("explosao", -14.0, 0.08)
				_finalizar()
				return
			var multiplicador: float = e.multiplicador_neutralizacao(arma_id)
			if multiplicador <= 0.0:
				Efeitos.texto_flutuante(get_parent(), ponto, "SEM EFEITO", Color("8899b0"), 11)
				Efeitos.particulas(get_parent(), ponto, Color("8899b0"), 3, 90.0, 0.2, 2.0)
				_finalizar()
				return
			e.receber_dano(dano * multiplicador, critico)
			_hits += 1
			Efeitos.particulas(get_parent(), ponto, cor, 4 if not critico else 7, 160.0, 0.25, 2.0)
			AudioManager.tocar_sfx("hit", -14.0, 0.12)
			if cadeia > 0:
				_encadear(e)
			if raio_explosao > 0.0:
				_explodir(ponto)
				return
			if _hits > perfuracao:
				_finalizar()
			return
		if colisor is GranadaInimiga:
			var g: GranadaInimiga = colisor as GranadaInimiga
			g.rebater(direcao)
			_finalizar()
			return
		# parede / obstáculo
		if ricochetes > 0 and normal != Vector2.ZERO:
			ricochetes -= 1
			direcao = direcao.bounce(normal).normalized()
			global_position = ponto + normal * 3.0
			AudioManager.tocar_sfx("ricochete", -18.0, 0.1)
			GlobalManager.registrar_estilo("RICOCHETE", 4.0, cor)
			return
		if raio_explosao > 0.0:
			_explodir(ponto)
			return
		_finalizar()
		return
	# projétil inimigo
	if colisor is Player:
		var p: Player = colisor as Player
		p.receber_dano(dano)
		if elemento != "":
			p.aplicar_efeito_elemental(elemento)
		_finalizar()
		return
	if raio_explosao > 0.0:
		_explodir(ponto)
		return
	_finalizar()


func _encadear(primeiro: Enemy) -> void:
	var alvos: Array[Enemy] = []
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		var e: Enemy = n as Enemy
		if e == null or not is_instance_valid(e) or e.morto or e == primeiro:
			continue
		if e.global_position.distance_to(primeiro.global_position) <= 165.0:
			alvos.append(e)
	alvos.sort_custom(func(a: Enemy, b: Enemy) -> bool:
		return a.global_position.distance_to(primeiro.global_position) < b.global_position.distance_to(primeiro.global_position))
	var limite: int = mini(cadeia, alvos.size())
	for i: int in range(limite):
		var alvo: Enemy = alvos[i]
		Efeitos.raio(get_parent(), primeiro.global_position, alvo.global_position, cor)
		alvo.receber_dano(dano * 0.55, false)
		if i > 0:
			Efeitos.raio(get_parent(), alvos[i - 1].global_position, alvo.global_position, cor)
	GlobalManager.registrar_estilo("CADEIA", 6.0, cor)


func _verificar_moedas() -> void:
	if not amigavel:
		return
	for n: Node in get_tree().get_nodes_in_group("moedas_ar"):
		var m: MoedaAr = n as MoedaAr
		if m == null or not is_instance_valid(m) or m.usada:
			continue
		if _distancia_ponto_segmento(m.global_position, global_position, global_position + direcao * 26.0) <= RAIO_MOEDA:
			_ricochetear(m)


func _distancia_ponto_segmento(p: Vector2, a: Vector2, b: Vector2) -> float:
	var ab: Vector2 = b - a
	var t: float = 0.0
	var denom: float = ab.length_squared()
	if denom > 0.001:
		t = clampf((p - a).dot(ab) / denom, 0.0, 1.0)
	return p.distance_to(a + ab * t)


func _ricochetear(moeda: MoedaAr) -> void:
	moeda.usada = true
	var mira: Enemy = null
	var menor: float = 999999.0
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		var e: Enemy = n as Enemy
		if e == null or not is_instance_valid(e) or e.morto:
			continue
		var d: float = global_position.distance_to(e.global_position)
		if d < menor:
			menor = d
			mira = e
	if mira != null:
		direcao = (mira.global_position - global_position).normalized()
		perseguicao = mira
	else:
		direcao = -direcao
	dano *= 2.5
	critico = true
	_zerar_distancia()
	moeda.explodir()
	Efeitos.anel(get_parent(), global_position, 40.0, Color(1.0, 0.82, 0.29, 0.9), 0.3, 2.0)
	Efeitos.particulas(get_parent(), global_position, Color("ffcf4a"), 8, 180.0, 0.3, 2.0)
	AudioManager.tocar_sfx("ricochete", -4.0, 0.05)
	GlobalManager.registrar_estilo("+RICOCHETE", 18.0, Color("ffcf4a"))


func _zerar_distancia() -> void:
	origem = global_position
	_distancia = 0.0
	if _sprite != null:
		_sprite.rotation = direcao.angle()


func refletir(nova_direcao: Vector2) -> void:
	amigavel = true
	remove_from_group("projeteis_inimigos")
	add_to_group("projeteis_jogador")
	direcao = nova_direcao.normalized()
	dano *= 2.0
	critico = true
	velocidade = maxf(velocidade, 1000.0)
	alcance = maxf(alcance, 1000.0)
	_zerar_distancia()
	_construir_visual()
	Efeitos.particulas(get_parent(), global_position, Color("8ff3ff"), 6, 180.0, 0.25, 2.0)


func remover_grupos() -> void:
	if has_method("remove_from_group"):
		remove_from_group("projeteis_inimigos")
	remove_from_group("projeteis_jogador")


func _explodir(ponto: Vector2) -> void:
	if _cena_explosao != null:
		var ex: Explosao = _cena_explosao.instantiate() as Explosao
		if ex != null:
			get_parent().add_child(ex)
			ex.global_position = ponto
			ex.configurar(raio_explosao, dano * 0.85, amigavel, cor)
	_finalizar()


func _expirar() -> void:
	if raio_explosao > 0.0:
		_explodir(global_position)
		return
	_finalizar()


func _finalizar() -> void:
	if _removido:
		return
	_removido = true
	queue_free()
