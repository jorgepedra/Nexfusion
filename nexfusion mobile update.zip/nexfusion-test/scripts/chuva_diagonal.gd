class_name ChuvaDiagonal
extends Node2D
## Chuva diagonal: gotas cruzam a arena em diagonal e, de tempos em tempos,
## uma gota sólida grande cai, se espatifa e libera projéteis.

signal terminou

const DURACAO: float = 3.8
const INTERVALO_GOTA: float = 0.05
const INTERVALO_GRANDE: float = 1.15
const VELOCIDADE: float = 640.0
const DANO_GOTA: float = 8.0
const DANO_GRANDE: float = 15.0

var chefe: ChefeFinal = null
var arena: Rect2 = Rect2(0.0, 0.0, 2400.0, 1500.0)
var fator: float = 1.0

var _t: float = 0.0
var _spawn: float = 0.0
var _grande_t: float = 0.95
var _gotas: Array[Vector2] = []
var _grandes: Array[Vector2] = []
var _vel: Vector2 = Vector2(0.45, 1.0).normalized() * VELOCIDADE


func configurar(chefe_ref: ChefeFinal, caixa: Rect2, multiplicador: float = 1.0) -> void:
	chefe = chefe_ref
	arena = caixa
	fator = multiplicador
	global_position = Vector2.ZERO
	z_index = 39


func _chefe_vivo() -> bool:
	## O chefe pode morrer no meio do ataque: nesse caso o objeto é liberado.
	return chefe != null and is_instance_valid(chefe) and not chefe.morto


func _process(delta: float) -> void:
	if not _chefe_vivo():
		terminou.emit()
		queue_free()
		return
	_t += delta
	if _t < DURACAO:
		_spawn -= delta
		if _spawn <= 0.0:
			_spawn = INTERVALO_GOTA
			_gotas.append(Vector2(randf_range(arena.position.x - 200.0, arena.end.x), arena.position.y - randf_range(20.0, 180.0)))
		_grande_t -= delta
		if _grande_t <= 0.0:
			_grande_t = INTERVALO_GRANDE
			_grandes.append(Vector2(randf_range(arena.position.x + 160.0, arena.end.x - 160.0), arena.position.y - 120.0))
	_atualizar(delta)
	if _t >= DURACAO and _gotas.is_empty() and _grandes.is_empty():
		terminou.emit()
		queue_free()
		return
	queue_redraw()


func _atualizar(delta: float) -> void:
	var p: Player = chefe.jogador_atual() if _chefe_vivo() else null
	var passo: Vector2 = _vel * delta
	var i: int = _gotas.size() - 1
	while i >= 0:
		_gotas[i] += passo
		if p != null and p.vivo and _gotas[i].distance_to(p.global_position) <= 16.0:
			chefe.ferir_jogador(DANO_GOTA * fator)
			Efeitos.particulas(get_parent(), _gotas[i], Color("9df5ff"), 4, 120.0, 0.25, 2.0)
			_gotas.remove_at(i)
		elif _gotas[i].y > arena.end.y + 40.0 or _gotas[i].x > arena.end.x + 260.0:
			_gotas.remove_at(i)
		i -= 1
	i = _grandes.size() - 1
	while i >= 0:
		_grandes[i] += passo * 0.82
		if p != null and p.vivo and _grandes[i].distance_to(p.global_position) <= 34.0:
			chefe.ferir_jogador(DANO_GRANDE * fator)
			_espatifar(_grandes[i])
			_grandes.remove_at(i)
		elif _grandes[i].y > arena.end.y + 40.0 or _grandes[i].x > arena.end.x + 260.0:
			_espatifar(_grandes[i])
			_grandes.remove_at(i)
		i -= 1


func _espatifar(pos: Vector2) -> void:
	if not _chefe_vivo():
		return
	Efeitos.particulas(get_parent(), pos, Color("8ff3ff"), 16, 260.0, 0.45, 3.5)
	Efeitos.anel(get_parent(), pos, 90.0, Color(0.56, 0.95, 1.0, 0.8), 0.35, 3.0)
	AudioManager.tocar_sfx("explosao", -10.0, 0.08)
	chefe.dano_area(pos, 88.0, DANO_GRANDE * 0.7 * fator)
	for i: int in range(9):
		var ang: float = TAU * float(i) / 9.0 + randf_range(-0.15, 0.15)
		var dir: Vector2 = Vector2.RIGHT.rotated(ang)
		chefe.projetil(pos + dir * 22.0, dir, 9.0 * fator, 430.0, 1.2)


func _draw() -> void:
	for g: Vector2 in _gotas:
		var cauda: Vector2 = g - _vel.normalized() * 34.0
		draw_line(cauda, g, Color(0.56, 0.92, 1.0, 0.35), 2.0)
		draw_line(cauda + _vel.normalized() * 10.0, g, Color(0.85, 0.98, 1.0, 0.85), 3.0)
		draw_circle(g, 4.0, Color(0.75, 0.95, 1.0, 0.95))
	for g: Vector2 in _grandes:
		var cauda: Vector2 = g - _vel.normalized() * 70.0
		draw_line(cauda, g, Color(0.5, 0.85, 1.0, 0.4), 6.0)
		draw_circle(g, 26.0, Color(0.45, 0.8, 1.0, 0.35))
		draw_circle(g, 18.0, Color(0.65, 0.92, 1.0, 0.8))
		draw_arc(g, 20.0, 0.0, TAU, 24, Color(0.9, 1.0, 1.0, 0.9), 2.0, true)
		draw_circle(g + Vector2(-5, -6), 5.0, Color(1.0, 1.0, 1.0, 0.9))
