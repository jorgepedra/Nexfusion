extends Control
## Loja de melhorias permanentes. A lista é gerada por código a partir dos
## recursos ItemLoja (.tres) de res://resources/loja/.
## Pode rodar como cena (menu) ou EMBUTIDA na partida: assim, abrir a loja
## depois de morrer/vencer não abandona a run.

signal fechado

const PASTA_ITENS: String = "res://resources/loja"
const IMG_MERCANTE: String = "res://sprites/NPC/mercante.png"

var embutida: bool = false

var _lista: VBoxContainer
var _label_moedas: Label
var _label_arma: Label
var _itens: Array[ItemLoja] = []


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	GlobalManager.definir_cursor(true)
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	var fundo: ColorRect = ColorRect.new()
	fundo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fundo.color = Color(0.03, 0.045, 0.07)
	add_child(fundo)
	_carregar()
	_construir()
	if not embutida:
		AudioManager.tocar_bgm("menu")


func _carregar() -> void:
	_itens.clear()
	var dir: DirAccess = DirAccess.open(PASTA_ITENS)
	if dir == null:
		push_warning("Loja: pasta de itens não encontrada")
		return
	dir.list_dir_begin()
	var arquivo: String = dir.get_next()
	while arquivo != "":
		if arquivo.ends_with(".tres"):
			var rec: Resource = load(PASTA_ITENS.path_join(arquivo))
			if rec is ItemLoja:
				_itens.append(rec as ItemLoja)
		arquivo = dir.get_next()
	dir.list_dir_end()
	_itens.sort_custom(func(a: ItemLoja, b: ItemLoja) -> bool: return a.ordem < b.ordem)


func _construir() -> void:
	var mobile: bool = GlobalManager.modo_mobile
	# Empilha só em telas estreitas; no celular em paisagem o cabeçalho
	# compacto em linha evita um bloco gigante de espaço vazio.
	var empilhado: bool = mobile and get_viewport_rect().size.x < 900.0
	var margem: MarginContainer = MarginContainer.new()
	margem.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var m: int = 18 if mobile else 60
	margem.add_theme_constant_override("margin_left", m)
	margem.add_theme_constant_override("margin_right", m)
	margem.add_theme_constant_override("margin_top", 12 if mobile else 26)
	margem.add_theme_constant_override("margin_bottom", 12 if mobile else 26)
	add_child(margem)
	var principal: VBoxContainer = VBoxContainer.new()
	principal.add_theme_constant_override("separation", 12)
	margem.add_child(principal)

	# ---- cabeçalho do mercador
	var cabecalho: PanelContainer = PanelContainer.new()
	cabecalho.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.07, 0.11, 0.16, 0.98), UI.COR_AMBAR.darkened(0.35), 8))
	principal.add_child(cabecalho)
	# No celular o cabeçalho empilha: retrato/título em cima, moedas e
	# voltar em uma linha própria (não estoura a largura de 360 px).
	var topo: BoxContainer = VBoxContainer.new() if empilhado else HBoxContainer.new()
	topo.add_theme_constant_override("separation", 8 if empilhado else 16)
	cabecalho.add_child(topo)
	if ResourceLoader.exists(IMG_MERCANTE):
		var retrato: TextureRect = TextureRect.new()
		retrato.texture = load(IMG_MERCANTE) as Texture2D
		retrato.custom_minimum_size = Vector2(64, 78) if mobile else Vector2(78, 96)
		retrato.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		retrato.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		retrato.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		if empilhado:
			retrato.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
		topo.add_child(retrato)
	var textos_topo: VBoxContainer = VBoxContainer.new()
	textos_topo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	textos_topo.alignment = BoxContainer.ALIGNMENT_CENTER
	textos_topo.add_theme_constant_override("separation", 2)
	topo.add_child(textos_topo)
	var titulo: Label = UI.titulo("MERCADO DE ISÓTOPOS", 21 if empilhado else (26 if mobile else 34), UI.COR_AMBAR)
	titulo.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	textos_topo.add_child(titulo)
	textos_topo.add_child(UI.rotulo("\"Compre com o que você coletou. O progresso fica entre tentativas.\"", 13, UI.COR_TEXTO_FRACO))
	_label_arma = UI.rotulo("EQUIPADA: %s" % _nome_equipada(), 14, UI.COR_CIANO)
	textos_topo.add_child(_label_arma)
	var lado: BoxContainer = HBoxContainer.new() if empilhado else VBoxContainer.new()
	lado.alignment = BoxContainer.ALIGNMENT_CENTER
	lado.add_theme_constant_override("separation", 6)
	if empilhado:
		lado.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	topo.add_child(lado)
	_label_moedas = UI.rotulo("◈ %s" % UI.formatar(GlobalManager.moedas), 21 if mobile else 24, UI.COR_AMBAR)
	_label_moedas.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	if empilhado:
		_label_moedas.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lado.add_child(_label_moedas)
	var b_voltar: Button = UI.botao("VOLTAR", 18 if mobile else 16, UI.COR_TEXTO_FRACO)
	b_voltar.custom_minimum_size = Vector2(140 if mobile else 140, 54 if mobile else 42)
	b_voltar.pressed.connect(_ao_voltar)
	lado.add_child(b_voltar)

	var sub: Label = UI.rotulo("Cartas de habilidade permanentes (até 20 cópias) e arsenal elemental.", 13, UI.COR_TEXTO_FRACO)
	sub.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	principal.add_child(sub)

	var rolagem: ScrollContainer = ScrollContainer.new()
	rolagem.size_flags_vertical = Control.SIZE_EXPAND_FILL
	rolagem.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	principal.add_child(rolagem)
	_lista = VBoxContainer.new()
	_lista.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_lista.add_theme_constant_override("separation", 10)
	rolagem.add_child(_lista)
	_reconstruir_lista()


func _reconstruir_lista() -> void:
	for filho: Node in _lista.get_children():
		filho.queue_free()
	_lista.add_child(_secao("CARTAS DE HABILIDADE PERMANENTES", UI.COR_CIANO))
	for item: ItemLoja in _itens:
		if item.tipo == "upgrade":
			_lista.add_child(_linha_upgrade(item))
	_lista.add_child(_secao("ARSENAL ELEMENTAL", UI.COR_MAGENTA))
	for item: ItemLoja in _itens:
		if item.tipo == "arma":
			_lista.add_child(_linha_arma(item))
	_atualizar_cabecalho()


func _ao_voltar() -> void:
	if embutida:
		fechado.emit()
		queue_free()
		return
	get_tree().change_scene_to_file("res://scenes/menu.tscn")


func _atualizar_cabecalho() -> void:
	if _label_moedas != null:
		_label_moedas.text = "◈ %s" % UI.formatar(GlobalManager.moedas)
	if _label_arma != null:
		_label_arma.text = "EQUIPADA: %s" % _nome_equipada()


func _nome_equipada() -> String:
	var arma: DadosArma = GlobalManager.arma_atual()
	return arma.nome.to_upper() if arma != null else "—"


func _secao(texto: String, cor: Color) -> Control:
	var painel: PanelContainer = PanelContainer.new()
	painel.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.05, 0.08, 0.12, 0.9), cor.darkened(0.5), 4))
	var h: HBoxContainer = HBoxContainer.new()
	h.add_theme_constant_override("separation", 10)
	var l: Label = UI.rotulo(texto, 18, cor)
	h.add_child(l)
	var linha: HSeparator = HSeparator.new()
	linha.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	linha.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(linha)
	painel.add_child(h)
	var topo: Control = Control.new()
	topo.custom_minimum_size = Vector2(0, 10)
	var v: VBoxContainer = VBoxContainer.new()
	v.add_child(topo)
	v.add_child(painel)
	return v


func _linha_upgrade(item: ItemLoja) -> Control:
	var dados: Dictionary = GlobalManager.UPGRADES.get(item.alvo, {}) as Dictionary
	if dados.is_empty():
		return UI.rotulo("Upgrade desconhecido: %s" % item.alvo, 14, UI.COR_VERMELHO)
	var nivel: int = GlobalManager.nivel_upgrade(item.alvo)
	var maximo: int = int(dados["max"])
	var preco: int = GlobalManager.preco_upgrade(item.alvo)
	var cheio: bool = nivel >= maximo
	if GlobalManager.modo_mobile:
		return _linha_upgrade_mobile(item, dados, nivel, maximo, preco, cheio)
	var linha: HBoxContainer = HBoxContainer.new()
	linha.add_theme_constant_override("separation", 14)
	var icone: Label = UI.rotulo(item.simbolo, 26, item.cor)
	icone.custom_minimum_size = Vector2(40, 40)
	icone.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	icone.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	linha.add_child(icone)
	var textos: VBoxContainer = VBoxContainer.new()
	textos.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	textos.add_child(UI.rotulo(item.titulo, 17, UI.COR_TEXTO))
	var nivel_label: Label = UI.rotulo("%s   ·   CÓPIA %d/%d" % [String(dados["desc"]), nivel, maximo], 13, UI.COR_TEXTO_FRACO)
	textos.add_child(nivel_label)
	var barra: ProgressBar = UI.barra(item.cor, 8.0, 300.0)
	barra.max_value = float(maximo)
	barra.value = float(nivel)
	barra.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	barra.mouse_filter = Control.MOUSE_FILTER_IGNORE
	textos.add_child(barra)
	linha.add_child(textos)
	var botao: Button = UI.botao("MÁXIMO" if cheio else "◈ %s" % UI.formatar(preco), 16, item.cor)
	botao.custom_minimum_size = Vector2(150, 44)
	botao.disabled = cheio or GlobalManager.moedas < preco
	if not cheio:
		botao.pressed.connect(_comprar_upgrade.bind(item.alvo))
	linha.add_child(botao)
	return _envolver(linha, item.cor)


func _linha_upgrade_mobile(item: ItemLoja, dados: Dictionary, nivel: int, maximo: int, preco: int, cheio: bool) -> Control:
	var painel: PanelContainer = PanelContainer.new()
	painel.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.06, 0.09, 0.13, 0.95), item.cor.darkened(0.6), 6))
	var vb: VBoxContainer = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	painel.add_child(vb)
	var topo: HBoxContainer = HBoxContainer.new()
	topo.add_theme_constant_override("separation", 10)
	var icone: Label = UI.rotulo(item.simbolo, 22, item.cor)
	icone.custom_minimum_size = Vector2(58, 40)
	icone.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	topo.add_child(icone)
	var titulo: Label = UI.rotulo(item.titulo, 17, UI.COR_TEXTO)
	titulo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	topo.add_child(titulo)
	topo.add_child(UI.rotulo("%d/%d" % [nivel, maximo], 14, item.cor))
	vb.add_child(topo)
	var desc: Label = UI.rotulo(String(dados["desc"]), 13, UI.COR_TEXTO_FRACO)
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vb.add_child(desc)
	var barra: ProgressBar = UI.barra(item.cor, 8.0, 280.0)
	barra.max_value = float(maximo)
	barra.value = float(nivel)
	barra.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(barra)
	var botao: Button = UI.botao("MÁXIMO" if cheio else "COMPRAR  ◈ %s" % UI.formatar(preco), 17, item.cor)
	botao.custom_minimum_size = Vector2(0, 56)
	botao.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	botao.disabled = cheio or GlobalManager.moedas < preco
	if not cheio:
		botao.pressed.connect(_comprar_upgrade.bind(item.alvo))
	vb.add_child(botao)
	return painel


func _linha_arma(item: ItemLoja) -> Control:
	var dados: DadosArma = GlobalManager.carregar_arma(item.alvo)
	if dados == null:
		return UI.rotulo("Arma desconhecida: %s" % item.alvo, 14, UI.COR_VERMELHO)
	var desbloqueada: bool = GlobalManager.arma_desbloqueada(item.alvo)
	var equipada: bool = GlobalManager.arma_equipada == item.alvo
	if GlobalManager.modo_mobile:
		return _linha_arma_mobile(item, dados, desbloqueada, equipada)
	var linha: HBoxContainer = HBoxContainer.new()
	linha.add_theme_constant_override("separation", 14)
	var moldura: PanelContainer = PanelContainer.new()
	moldura.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.04, 0.07, 0.11, 1.0), dados.cor.darkened(0.4), 4))
	moldura.custom_minimum_size = Vector2(96, 62)
	linha.add_child(moldura)
	var imagem: TextureRect = TextureRect.new()
	var caminho_img: String = "res://sprites/guns/arma_%s.png" % item.alvo
	if ResourceLoader.exists(caminho_img):
		imagem.texture = load(caminho_img) as Texture2D
	imagem.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	imagem.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	imagem.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	imagem.custom_minimum_size = Vector2(72, 46)
	moldura.add_child(imagem)
	var textos: VBoxContainer = VBoxContainer.new()
	textos.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var nome: Label = UI.rotulo("%s  (%s)" % [dados.nome, dados.elemento], 17, UI.COR_TEXTO)
	textos.add_child(nome)
	var stats: Label = UI.rotulo(
		"%s   ·   Dano %.0f  ·  Cadência %.1f/s  ·  Projéteis %d" % [dados.descricao, dados.dano, dados.cadencia, dados.projeteis],
		13, UI.COR_TEXTO_FRACO)
	stats.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	stats.custom_minimum_size = Vector2(560, 0)
	textos.add_child(stats)
	linha.add_child(textos)
	if not desbloqueada:
		var botao: Button = UI.botao("◈ %s" % UI.formatar(dados.custo), 16, dados.cor)
		botao.custom_minimum_size = Vector2(150, 44)
		botao.disabled = GlobalManager.moedas < dados.custo
		botao.pressed.connect(_comprar_arma.bind(item.alvo))
		linha.add_child(botao)
	else:
		var btn_equipar: Button = UI.botao("EQUIPADO" if equipada else "EQUIPAR", 16, dados.cor)
		btn_equipar.custom_minimum_size = Vector2(150, 44)
		btn_equipar.disabled = equipada
		btn_equipar.pressed.connect(_equipar.bind(item.alvo))
		linha.add_child(btn_equipar)
	return _envolver(linha, dados.cor)


func _linha_arma_mobile(item: ItemLoja, dados: DadosArma, desbloqueada: bool, equipada: bool) -> Control:
	var painel: PanelContainer = PanelContainer.new()
	painel.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.06, 0.09, 0.13, 0.95), dados.cor.darkened(0.6), 6))
	var vb: VBoxContainer = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	painel.add_child(vb)
	var topo: HBoxContainer = HBoxContainer.new()
	topo.add_theme_constant_override("separation", 10)
	var imagem: TextureRect = TextureRect.new()
	var caminho_img: String = "res://sprites/guns/arma_%s.png" % item.alvo
	if ResourceLoader.exists(caminho_img):
		imagem.texture = load(caminho_img) as Texture2D
	imagem.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	imagem.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	imagem.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	imagem.custom_minimum_size = Vector2(78, 48)
	topo.add_child(imagem)
	var textos: VBoxContainer = VBoxContainer.new()
	textos.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	textos.add_child(UI.rotulo("%s (%s)" % [dados.nome, dados.elemento], 17, UI.COR_TEXTO))
	var stats: Label = UI.rotulo("Dano %.0f · Cadência %.1f/s · Projéteis %d" % [dados.dano, dados.cadencia, dados.projeteis], 12, UI.COR_TEXTO_FRACO)
	stats.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	textos.add_child(stats)
	topo.add_child(textos)
	vb.add_child(topo)
	var desc: Label = UI.rotulo(dados.descricao, 12, UI.COR_TEXTO_FRACO)
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vb.add_child(desc)
	var botao: Button = UI.botao(("EQUIPADO" if equipada else "EQUIPAR") if desbloqueada else "COMPRAR  ◈ %s" % UI.formatar(dados.custo), 17, dados.cor)
	botao.custom_minimum_size = Vector2(0, 56)
	botao.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	botao.disabled = equipada or (not desbloqueada and GlobalManager.moedas < dados.custo)
	if not desbloqueada:
		botao.pressed.connect(_comprar_arma.bind(item.alvo))
	elif not equipada:
		botao.pressed.connect(_equipar.bind(item.alvo))
	vb.add_child(botao)
	return painel


func _envolver(filho: Control, cor: Color) -> Control:
	var painel: PanelContainer = PanelContainer.new()
	painel.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.06, 0.09, 0.13, 0.95), cor.darkened(0.6), 4))
	painel.add_child(filho)
	return painel


func _comprar_upgrade(id: String) -> void:
	if GlobalManager.comprar_upgrade(id):
		AudioManager.tocar_sfx("moeda", -4.0, 0.05)
		_reconstruir_lista()
	else:
		AudioManager.tocar_sfx("perigo", -8.0, 0.05)


func _comprar_arma(id: String) -> void:
	if GlobalManager.comprar_arma(id):
		AudioManager.tocar_sfx("levelup", -6.0, 0.03)
		_reconstruir_lista()
	else:
		AudioManager.tocar_sfx("perigo", -8.0, 0.05)


func _equipar(id: String) -> void:
	if GlobalManager.equipar_arma(id):
		AudioManager.tocar_sfx("clique", -6.0, 0.03)
		_reconstruir_lista()
