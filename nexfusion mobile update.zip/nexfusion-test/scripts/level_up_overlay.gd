class_name LevelUpOverlay
extends Control
## Escolha de cartas rogue-lite ao subir de nível, com mercador ao lado.
## Pausa a árvore (processa sempre) e permite TROCAR as cartas pagando moedas
## colectadas na run (moedas_partida) — o custo sobe a cada troca.

signal carta_selecionada(carta: CartaRoguelite)

const PASTA_CARTAS: String = "res://resources/cartas_roguelite"
const IMG_MERCANTE: String = "res://sprites/NPC/mercante.png"
const CUSTO_BASE: int = 20

var _cartas: Array[CartaRoguelite] = []
var _oferecidas: Array[CartaRoguelite] = []
var _container: HBoxContainer
var _titulo: Label
var _subtitulo: Label
var _label_moedas: Label
var _b_trocar: Button
var _fala: Label
var _trocas: int = 0

const FALAS: Array[String] = [
	"Escolha com cuidado. O laboratório não perdoa.",
	"Moedas por cartas? Um bom negócio para nós dois.",
	"Esse catalisador combina com o seu caos.",
	"Se não gostou, pague e eu troco a mão.",
]


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false
	_carregar_cartas()
	_construir()


func _construir() -> void:
	var fundo: ColorRect = ColorRect.new()
	fundo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fundo.color = Color(0.02, 0.03, 0.05, 0.9)
	add_child(fundo)

	var centro: VBoxContainer = VBoxContainer.new()
	centro.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	centro.alignment = BoxContainer.ALIGNMENT_CENTER
	centro.add_theme_constant_override("separation", 8)
	add_child(centro)

	_titulo = UI.titulo("NÍVEL 2", 40, UI.COR_CIANO)
	centro.add_child(_titulo)
	_subtitulo = UI.rotulo("ESCOLHA UM CATALISADOR PARA ESTA TENTATIVA", 15, UI.COR_TEXTO_FRACO)
	_subtitulo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	centro.add_child(_subtitulo)
	if NetworkManager.modo != "off":
		# A2.1: em LAN ninguém pausa o tempo — avisa que o jogador segue exposto.
		var aviso: Label = UI.rotulo("O JOGO CONTINUA  ·  VOCÊ ESTÁ VULNERÁVEL", 13, UI.COR_VERMELHO)
		aviso.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		centro.add_child(aviso)

	# ---- painel principal: mercador + cartas
	var painel: PanelContainer = PanelContainer.new()
	painel.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.06, 0.09, 0.14, 0.98), UI.COR_VIOLETA.darkened(0.35), 8))
	painel.custom_minimum_size = Vector2(1120, 400)
	painel.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	centro.add_child(painel)
	var corpo: HBoxContainer = HBoxContainer.new()
	corpo.add_theme_constant_override("separation", 20)
	painel.add_child(corpo)

	# mercador
	var lado_mercador: VBoxContainer = VBoxContainer.new()
	lado_mercador.custom_minimum_size = Vector2(210, 0)
	lado_mercador.alignment = BoxContainer.ALIGNMENT_CENTER
	lado_mercador.add_theme_constant_override("separation", 6)
	corpo.add_child(lado_mercador)
	if ResourceLoader.exists(IMG_MERCANTE):
		var retrato: TextureRect = TextureRect.new()
		retrato.texture = load(IMG_MERCANTE) as Texture2D
		retrato.custom_minimum_size = Vector2(150, 190)
		retrato.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		retrato.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		retrato.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		lado_mercador.add_child(retrato)
	lado_mercador.add_child(UI.rotulo("MERCANTE DE ISÓTOPOS", 13, UI.COR_AMBAR))
	_fala = UI.rotulo(String(FALAS[randi() % FALAS.size()]), 12, UI.COR_TEXTO_FRACO)
	_fala.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_fala.custom_minimum_size = Vector2(200, 0)
	lado_mercador.add_child(_fala)

	# cartas
	_container = HBoxContainer.new()
	_container.alignment = BoxContainer.ALIGNMENT_CENTER
	_container.add_theme_constant_override("separation", 16)
	_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	corpo.add_child(_container)

	# ---- rodapé: moedas e troca
	var rodape: HBoxContainer = HBoxContainer.new()
	rodape.alignment = BoxContainer.ALIGNMENT_CENTER
	rodape.add_theme_constant_override("separation", 18)
	centro.add_child(rodape)
	_label_moedas = UI.rotulo("◈ %s" % UI.formatar(GlobalManager.moedas_partida), 18, UI.COR_AMBAR)
	rodape.add_child(_label_moedas)
	_b_trocar = UI.botao("TROCAR CARTAS  ◈ %d" % _custo_troca(), 16, UI.COR_MAGENTA)
	_b_trocar.custom_minimum_size = Vector2(300, 42)
	_b_trocar.pressed.connect(_trocar_cartas)
	rodape.add_child(_b_trocar)
	var dica: Label = UI.rotulo("1 / 2 / 3 para escolher", 12, UI.COR_TEXTO_FRACO)
	rodape.add_child(dica)


func _carregar_cartas() -> void:
	_cartas.clear()
	var dir: DirAccess = DirAccess.open(PASTA_CARTAS)
	if dir == null:
		push_warning("LevelUpOverlay: pasta de cartas não encontrada")
		return
	dir.list_dir_begin()
	var arquivo: String = dir.get_next()
	while arquivo != "":
		if arquivo.ends_with(".tres"):
			var rec: Resource = load(PASTA_CARTAS.path_join(arquivo))
			if rec is CartaRoguelite:
				_cartas.append(rec as CartaRoguelite)
		arquivo = dir.get_next()
	dir.list_dir_end()


func abrir(nivel: int, _jogador: Player) -> void:
	visible = true
	_trocas = 0
	_titulo.text = "NÍVEL %d" % nivel
	_fala.text = String(FALAS[randi() % FALAS.size()])
	_oferecidas = _sortear(3)
	_reconstruir_cartas()
	modulate.a = 0.0
	var tw: Tween = create_tween()
	tw.tween_property(self, "modulate:a", 1.0, 0.18)


func fechar() -> void:
	visible = false


func _custo_troca() -> int:
	return CUSTO_BASE + _trocas * 15


func _trocar_cartas() -> void:
	if not visible:
		return
	var custo: int = _custo_troca()
	if not GlobalManager.gastar_moedas_partida(custo):
		AudioManager.tocar_sfx("perigo", -8.0, 0.05)
		_fala.text = "Sem moedas suficientes na run. Volte com mais."
		return
	_trocas += 1
	AudioManager.tocar_sfx("moeda", -6.0, 0.04)
	_oferecidas = _sortear(3)
	_reconstruir_cartas()


func _reconstruir_cartas() -> void:
	for filho: Node in _container.get_children():
		filho.queue_free()
	for i: int in range(_oferecidas.size()):
		_container.add_child(_criar_carta(_oferecidas[i], i))
	if _label_moedas != null:
		_label_moedas.text = "◈ %s" % UI.formatar(GlobalManager.moedas_partida)
	if _b_trocar != null:
		var custo: int = _custo_troca()
		_b_trocar.text = "TROCAR CARTAS  ◈ %d" % custo
		_b_trocar.disabled = GlobalManager.moedas_partida < custo


func _sortear(qtd: int) -> Array[CartaRoguelite]:
	var disponiveis: Array[CartaRoguelite] = []
	var em_lan: bool = NetworkManager.modo != "off"
	for c: CartaRoguelite in _cartas:
		# A ressurreição é exclusiva do co-op LAN.
		if c.atributo == "ressurreicao" and not em_lan:
			continue
		disponiveis.append(c)
	var escolhidas: Array[CartaRoguelite] = []
	while escolhidas.size() < qtd and not disponiveis.is_empty():
		var total: float = 0.0
		for c: CartaRoguelite in disponiveis:
			total += _peso(c)
		var sorteio: float = randf() * total
		var indice: int = 0
		for i: int in range(disponiveis.size()):
			sorteio -= _peso(disponiveis[i])
			if sorteio <= 0.0:
				indice = i
				break
		escolhidas.append(disponiveis[indice])
		disponiveis.remove_at(indice)
	return escolhidas


func _peso(c: CartaRoguelite) -> float:
	var base: float = c.peso
	# Raras, míticas (épicas) e lendárias (isotópicas) aparecem bem mais.
	match c.raridade:
		"raro":
			base *= 0.95
		"epico":
			base *= 0.55
		"isotopico":
			base *= 0.32
	return maxf(0.05, base)


func _criar_carta(carta: CartaRoguelite, indice: int) -> Control:
	var cor: Color = UI.cor_raridade(carta.raridade)
	var botao: Button = Button.new()
	botao.custom_minimum_size = Vector2(250, 330)
	botao.focus_mode = Control.FOCUS_NONE
	botao.add_theme_stylebox_override("normal", UI.estilo_painel(Color(0.06, 0.09, 0.14, 0.96), cor.darkened(0.35), 6))
	botao.add_theme_stylebox_override("hover", UI.estilo_painel(Color(0.1, 0.14, 0.21, 0.98), cor, 6))
	botao.add_theme_stylebox_override("pressed", UI.estilo_painel(Color(0.04, 0.06, 0.1, 1.0), cor, 6))
	botao.pressed.connect(_ao_clicar.bind(carta))
	var vb: VBoxContainer = VBoxContainer.new()
	vb.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vb.offset_left = 14
	vb.offset_right = -14
	vb.offset_top = 16
	vb.offset_bottom = -14
	vb.add_theme_constant_override("separation", 6)
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	botao.add_child(vb)
	var arte: String = "res://sprites/cartas/%s.png" % carta.id
	if ResourceLoader.exists(arte):
		var icone: TextureRect = TextureRect.new()
		icone.texture = load(arte) as Texture2D
		icone.custom_minimum_size = Vector2(90, 120)
		icone.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icone.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icone.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		icone.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		icone.mouse_filter = Control.MOUSE_FILTER_IGNORE
		vb.add_child(icone)
	var simbolo: Label = UI.rotulo(carta.simbolo, 26, cor)
	simbolo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	simbolo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(simbolo)
	var nome: Label = UI.rotulo(carta.nome, 18, UI.COR_TEXTO)
	nome.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	nome.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	nome.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(nome)
	var raridade: Label = UI.rotulo(String(carta.raridade).to_upper(), 12, cor)
	raridade.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	raridade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(raridade)
	var desc: Label = UI.rotulo(carta.descricao, 13, UI.COR_TEXTO_FRACO)
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	desc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(desc)
	var atalho: Label = UI.rotulo("[%d]" % (indice + 1), 12, UI.COR_TEXTO_FRACO)
	atalho.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	atalho.offset_top = -24
	atalho.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	atalho.mouse_filter = Control.MOUSE_FILTER_IGNORE
	botao.add_child(atalho)
	botao.modulate.a = 0.0
	botao.position = Vector2(0, 22)
	var tw: Tween = botao.create_tween()
	tw.set_parallel(true)
	tw.tween_property(botao, "modulate:a", 1.0, 0.2).set_delay(0.05 * float(indice))
	tw.tween_property(botao, "position:y", 0.0, 0.24).set_delay(0.05 * float(indice)).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	return botao


func _unhandled_input(evento: InputEvent) -> void:
	if not visible:
		return
	if evento is InputEventKey and evento.pressed and not evento.echo:
		var k: InputEventKey = evento as InputEventKey
		var numero: int = int(k.physical_keycode) - 49
		if numero >= 0 and numero < _oferecidas.size() and (k.physical_keycode >= KEY_1 and k.physical_keycode <= KEY_3):
			_ao_clicar(_oferecidas[numero])
			get_viewport().set_input_as_handled()


func _ao_clicar(carta: CartaRoguelite) -> void:
	if not visible:
		return
	carta_selecionada.emit(carta)
