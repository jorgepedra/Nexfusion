class_name Bestiario
extends RefCounted
## Textos do bestiário (Quimidex): o que a espécie é, o que ela faz na arena e
## qual fenômeno real explica o comportamento. Fonte: livro de personagens do
## jogo. Só ciência geral e segurança — nenhum procedimento ou receita real.

const DADOS: Dictionary = {
	"uranio": {
		"sobre": "Metal pesado e radioativo: bolinha verde-escura com aura pulsante e faíscas girando. Carrega o símbolo de radiação na barriga.",
		"faz": "Anda devagar, atira ondas lentas e grandes que continuam corroendo a vida por alguns segundos após o impacto e reduz o alcance das armas por perto. É preciso atravessar o anel com o dash.",
		"real": "O urânio emite radiação ionizante de forma contínua, com meia-vida longuíssima: a exposição segue machucando mesmo depois do contato. Daí o dano residual lento e duradouro.",
	},
	"cesio": {
		"sobre": "Bolinha prateada com tom dourado e coroa de radiação. Sorriso de quem se acha o mais forte do enxame.",
		"faz": "Mais rápido que o urânio, com aura maior: reduz 30% do alcance das armas próximas enquanto passa e causa dano pesado na base. Exige a Blindagem Reforçada para ser contido.",
		"real": "O césio-137 é um isótopo radioativo gerado em processos nucleares e virou o exemplo mais conhecido de contaminação radioativa. Por se espalhar com facilidade, combater a contaminação exige blindagem reforçada e isolamento.",
	},
	"sulfurico": {
		"sobre": "Gota grande amarelo-âmbar, com bolhas subindo e gotinhas pingando dos lados. Sobrancelhas franzidas.",
		"faz": "Atira respingos corrosivos: se passar perto de uma arma, ela fica desativada por 3 segundos. Três camadas de concentração antes de virar água levemente ácida.",
		"real": "É um dos ácidos mais usados na indústria e muito corrosivo: queima pele e corrói materiais. Bases fracas, como o bicarbonato, ajudam a neutralizá-lo formando água, sal e gás carbônico.",
	},
	"cloridrico": {
		"sobre": "Gota verde-limão neon, mais fina e rápida que a sulfúrica, com fumacinha saindo da cabeça.",
		"faz": "Corre em ziguezague curto e espirra ácido; duas camadas só, mas chega rápido na base. Também corrói as armas que toca.",
		"real": "É um ácido forte que libera vapores irritantes e exige ventilação e proteção. Existe até no suco gástrico humano, mas em concentração muito menor — concentrado, é perigoso.",
	},
	"soda": {
		"sobre": "Bolinha branca e rugosa de cristais, com chifrinhos e bochechas rosadas de ardida. Anda de braços cruzados.",
		"faz": "Avança pesado e corrosivo, corroendo as armas que encosta. Duas camadas de cristal antes de virar água clara.",
		"real": "A soda cáustica é uma base muito forte, corrosiva para pele e olhos e usada em limpeza pesada. Ácidos e bases se anulam, mas isso só é seguro em laboratório, com controle e proteção.",
	},
	"cloro": {
		"sobre": "Nuvem verde-amarelada com fiapos subindo e um sorriso malicioso. Gás mais denso que o ar, então rasteja baixo.",
		"faz": "Atira leques de gás e gotas em anel que deixam poças tóxicas no chão por alguns segundos — a área fica perigosa por tempo, não só no impacto.",
		"real": "O cloro é um gás amarelo-esverdeado mais denso que o ar: afunda, se acumula em baixadas e irrita olhos e pulmões. Por isso as nuvens são lentas, ficam no chão e duram vários segundos.",
	},
	"amonia": {
		"sobre": "Nuvem azul-clara com narizinho franzido de quem sente cheiro forte e braços para cima.",
		"faz": "Flutua devagar e causa pouco dano de contato, mas persiste e atrapalha a visão. É a metade que sobra quando a mistura de limpeza se rompe.",
		"real": "Gás de cheiro forte e muito solúvel em água, presente em produtos de limpeza. Misturar produtos diferentes é o erro doméstico que produz gases tóxicos.",
	},
	"co": {
		"sobre": "Nuvem cinza quase transparente: só os olhos amarelos brilham. Calma demais, assustadoramente calma.",
		"faz": "Desliza rápido e é quase invisível — só o carvão ativado (ou uma arma com detector) o enxerga bem. Dano médio, mas difícil de acertar.",
		"real": "O monóxido de carbono não tem cor nem cheiro e impede o sangue de transportar oxigênio. É por isso que detectores e ventilação salvam vidas.",
	},
	"mistura": {
		"sobre": "Dois frascos abraçados, um azul e um verde, soltando uma nuvem amarelada com cara de \"ops!\".",
		"faz": "Ao perder a primeira camada se rompe e se divide em um Cloro e uma Amônia, como um balão que estoura em dois inimigos.",
		"real": "Nunca misture produtos de limpeza: água sanitária com amônia forma cloraminas, gases tóxicos. É um erro comum em casa e um dos acidentes domésticos mais evitáveis.",
	},
	"sodio": {
		"sobre": "Bolinha prateada brilhante, com faíscas laranja e perninhas pontudas. Tem medo de água — e razão para isso.",
		"faz": "Corre rápido e arremessa granadas em arco depois de piscar em amarelo. Se a Água o atinge, ele explode em faíscas e se cura: contra ele, óleo mineral ou areia.",
		"real": "O sódio é um metal macio e muito reativo, guardado mergulhado em óleo justamente para não encontrar ar nem umidade. Com água, reage violentamente liberando calor e hidrogênio.",
	},
	"metano": {
		"sobre": "Nuvem branca translúcida com uma chaminha azul na cabeça, como um fogão aceso. Boceja.",
		"faz": "Vem devagar, mas é inflamável: qualquer chama ou faísca o enfurece. Só o extintor de CO2 o apaga de vez.",
		"real": "O metano é o principal componente do gás natural: inflamável e, em certas concentrações no ar, explosivo. O perigo cresce em ambientes fechados.",
	},
	"nitroglicerina": {
		"sobre": "Frasco amarelo-pálido tremendo, com suor na testa e um fusível desenhado (sem acender).",
		"faz": "Anda devagar, mas carrega dano pesado. Neutralizada de qualquer jeito, detona: a explosão machuca quem estiver perto. Gelo seco estabiliza sem estrago.",
		"real": "Composto explosivo muito instável, sensível a choque e calor. Por isso só especialistas lidam com ele e o controle de temperatura é essencial.",
	},
	"fosforo": {
		"sobre": "Bolinha branco-amarelada e cerosa, com uma chaminha na cabeça e fagulhas laranja.",
		"faz": "Avança faiscando e incendeia o que toca — a área atingida fica perigosa por alguns segundos. Água ou areia apagam a chama.",
		"real": "O fósforo branco pode se inflamar sozinho em contato com o ar, por isso é guardado debaixo d'água. É o exemplo clássico de material pirofórico.",
	},
	"mercurio": {
		"sobre": "Bolinha de prata líquida super brilhante, seguida por poças menores como uma gosma metálica. Sorriso simpático e enganoso.",
		"faz": "Resistente (quatro camadas) e atira gotas que quicam nas paredes até seis vezes, transformando as quinas em armadilha. Se for atingido pela arma errada, se divide em gotinhas.",
		"real": "É o único metal líquido à temperatura ambiente; a densidade e a altíssima tensão superficial formam gotas que rolam e quicam sem molhar a superfície. O vapor e os compostos são tóxicos para o sistema nervoso — daí o quelante.",
	},
	"reator": {
		"sobre": "Mini-reator com barras de combustível como chifres e tubulações como braços. O brilho muda de cor conforme a fase: verde, laranja e cinza.",
		"faz": "Fúria em três fases: radiação lenta e persistente, depois superaquecimento com explosivos, e por fim resíduos de metais pesados. Invoca filhotes radioativos a cada 10 segundos.",
		"real": "Reatores usam combustível radioativo para gerar energia e são feitos com várias barreiras e sistemas de resfriamento. Blindagem, resfriamento e contenção são as três defesas contra superaquecimento e liberação de radiação.",
	},
	"nuvem_quimica": {
		"sobre": "Nuvem gigante multicolorida com rostinhos aparecendo dentro dela e relâmpagos pequenos. Cada fase muda a cor e o risco.",
		"faz": "Fase 1 gás tóxico, fase 2 ácido, fase 3 oxidante: cada fase exige uma arma diferente, obrigando a levar defesa variada para a arena.",
		"real": "Vazamentos industriais podem misturar várias substâncias ao mesmo tempo. É por isso que fábricas mantêm planos de emergência e equipes treinadas.",
	},
	"elemento_supremo": {
		"sobre": "O núcleo final: a fusão de tudo o que já apareceu na tabela, protegido por quatro guardiões de contenção.",
		"faz": "Fase 1 alterna punho que marca o chão, maré ácida com placas seguras, feixe aniquilador e chuva isotópica. Em 50% de vida entra em fúria, abre a dimensão 3D e volta com espiral iônica e órbitas de plasma.",
		"real": "Reúne os fenômenos reais do resto do jogo: impacto mecânico, corrosão ácida, radiação em feixe, precipitação radioativa e campos eletromagnéticos/plasma da fusão nuclear.",
	},
	"guardiao_final": {
		"sobre": "Estátua de contenção que sela o núcleo do Elemento Supremo. Não ataca: é barreira.",
		"faz": "Fica imóvel em um dos quatro cantos, com 2,4x de vida; enquanto os quatro existem, o núcleo é invulnerável. Derrubar os quatro atordoa o chefe por 10 segundos.",
		"real": "Blindagem de contenção (chumbo, concreto, boro) não ataca: só isola a radiação. Os guardiões fazem o papel desse escudo físico em volta do núcleo.",
	},
}
