class_name ControlesMoveis
extends CanvasLayer
## Controles de toque (BLOCO B).
##
## Esquerda: joystick de movimento. Direita: joystick de MIRA que também
## atira automaticamente enquanto estiver fora da zona morta. Um joystick por
## dedo (multitoque real), botões de ação sempre com 76 px ou mais e NUNCA
## escondidos/recriados: as janelas (camada 20) ficam por cima desta camada 10.

const ESCALA_PADRAO: float = 1.0

var entrada: Vector2 = Vector2.ZERO
## True enquanto o stick de mira está fora da zona morta (tiro automático).
var atirando: bool = false
## Direção unitária da mira; continua valendo depois de soltar o stick.
var mira_direcao: Vector2 = Vector2.RIGHT
## True depois do primeiro toque no stick de mira (antes disso o jogo usa a
## mira automática no inimigo mais próximo).
var mira_definida: bool = false
var mira_ativa: bool = false

var secundario_pendente: bool = false
var dash_pendente: bool = false
var parar_pendente: bool = false

@export var escala: float = ESCALA_PADRAO
@export var vibracao: bool = true

var _raiz: Control
var _joystick_mov: JoystickVirtual
var _joystick_mira: JoystickVirtual
var _bloqueado: bool = false
var _dica: Label


func _ready() -> void:
	add_to_group("mobile_controls")
	layer = 10
	_construir()
	get_viewport().size_changed.connect(_aplicar_area_segura)
	_aplicar_area_segura()


func _construir() -> void:
	_raiz = Control.new()
	_raiz.name = "RaizToque"
	_raiz.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_raiz.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_raiz)

	# ---------------- joystick de movimento (esquerda)
	_joystick_mov = JoystickVirtual.new()
	_joystick_mov.name = "JoystickMovimento"
	_joystick_mov.raio = 92.0 * escala
	_joystick_mov.zona_morta = 0.2
	_joystick_mov.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	_joystick_mov.offset_left = 24.0 * escala
	_joystick_mov.offset_top = -(208.0 * escala)
	_joystick_mov.offset_right = 24.0 * escala + 208.0 * escala
	_joystick_mov.offset_bottom = -24.0 * escala
	_joystick_mov.valor_alterado.connect(_ao_mover)
	_raiz.add_child(_joystick_mov)

	# ---------------- joystick de mira + tiro automático (direita)
	_joystick_mira = JoystickVirtual.new()
	_joystick_mira.name = "JoystickMira"
	_joystick_mira.raio = 92.0 * escala
	_joystick_mira.zona_morta = 0.2
	_joystick_mira.cor = UI.COR_MAGENTA
	_joystick_mira.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	_joystick_mira.offset_left = -(208.0 * escala)
	_joystick_mira.offset_top = -(208.0 * escala)
	_joystick_mira.offset_right = -24.0 * escala
	_joystick_mira.offset_bottom = -24.0 * escala
	_joystick_mira.iniciou.connect(func() -> void:
		mira_definida = true
		mira_ativa = true)
	_joystick_mira.soltou.connect(func() -> void: mira_ativa = false)
	_joystick_mira.valor_alterado.connect(_ao_mirar)
	_raiz.add_child(_joystick_mira)

	# ---------------- botões de ação (coluna à esquerda do stick de mira)
	var b_sec: Button = _criar_botao("SECUND.", UI.COR_MAGENTA)
	b_sec.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	b_sec.offset_left = -(344.0 * escala)
	b_sec.offset_top = -(356.0 * escala)
	b_sec.offset_right = -(248.0 * escala)
	b_sec.offset_bottom = -(272.0 * escala)
	b_sec.pressed.connect(func() -> void:
		secundario_pendente = true
		_vibrar())
	_raiz.add_child(b_sec)

	var b_parar: Button = _criar_botao("APARAR", UI.COR_AMBAR)
	b_parar.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	b_parar.offset_left = -(344.0 * escala)
	b_parar.offset_top = -(240.0 * escala)
	b_parar.offset_right = -(248.0 * escala)
	b_parar.offset_bottom = -(156.0 * escala)
	b_parar.pressed.connect(func() -> void:
		parar_pendente = true
		_vibrar())
	_raiz.add_child(b_parar)

	var b_dash: Button = _criar_botao("DASH", UI.COR_VERDE)
	b_dash.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	b_dash.offset_left = -(344.0 * escala)
	b_dash.offset_top = -(124.0 * escala)
	b_dash.offset_right = -(248.0 * escala)
	b_dash.offset_bottom = -(40.0 * escala)
	b_dash.pressed.connect(func() -> void:
		dash_pendente = true
		_vibrar())
	_raiz.add_child(b_dash)

	# Topo-esquerda (logo abaixo da barra de vida): o canto superior direito é
	# do painel de ESTILO do HUD.
	var b_inv: Button = _criar_botao("INVENTÁRIO", UI.COR_MAGENTA)
	b_inv.set_anchors_preset(Control.PRESET_TOP_LEFT)
	b_inv.offset_left = 18.0 * escala
	b_inv.offset_top = 128.0 * escala
	b_inv.offset_right = 146.0 * escala
	b_inv.offset_bottom = 212.0 * escala
	b_inv.pressed.connect(_ao_inventario)
	_raiz.add_child(b_inv)

	var b_pausa: Button = _criar_botao("PAUSA", UI.COR_CIANO)
	b_pausa.set_anchors_preset(Control.PRESET_TOP_LEFT)
	b_pausa.offset_left = 18.0 * escala
	b_pausa.offset_top = 224.0 * escala
	b_pausa.offset_right = 146.0 * escala
	b_pausa.offset_bottom = 308.0 * escala
	b_pausa.pressed.connect(_ao_pausa)
	_raiz.add_child(b_pausa)

	_dica = UI.rotulo("ESQUERDA ANDA  ·  DIREITA MIRA E ATIRA", 11, UI.COR_TEXTO_FRACO)
	_dica.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_dica.offset_left = -240.0
	_dica.offset_right = 240.0
	_dica.offset_top = -30.0
	_dica.offset_bottom = -8.0
	_dica.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_dica.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(_dica)


func _criar_botao(texto: String, cor: Color) -> Button:
	var b: Button = UI.botao(texto, 14, cor)
	b.custom_minimum_size = Vector2.ZERO
	b.focus_mode = Control.FOCUS_NONE
	b.mouse_filter = Control.MOUSE_FILTER_STOP
	b.add_theme_stylebox_override("normal", UI.estilo_painel(Color(0.06, 0.09, 0.14, 0.72), cor.darkened(0.25), 24))
	b.add_theme_stylebox_override("hover", UI.estilo_painel(Color(0.1, 0.15, 0.21, 0.85), cor, 24))
	b.add_theme_stylebox_override("pressed", UI.estilo_painel(Color(0.03, 0.05, 0.09, 0.9), cor, 24))
	return b


func _ao_mover(valor: Vector2) -> void:
	entrada = valor


func _ao_mirar(valor: Vector2) -> void:
	mira_ativa = valor.length() > 0.01
	atirando = mira_ativa
	if valor.length() > 0.01:
		mira_direcao = valor.normalized()
		mira_definida = true


func _vibrar() -> void:
	if vibracao:
		Input.vibrate_handheld(15)


func _ao_inventario() -> void:
	if not UiState.aceita_entrada():
		return
	var hud: Node = get_tree().get_first_node_in_group("hud")
	if hud != null and hud.has_method("alternar_inventario"):
		hud.call("alternar_inventario")


func _ao_pausa() -> void:
	if not UiState.aceita_entrada():
		return
	var hud: Node = get_tree().get_first_node_in_group("hud")
	if hud != null and hud.has_method("alternar_pausa"):
		hud.call("alternar_pausa")


## Chamado pelo HUD. NUNCA esconde nem remove os controles (B4.1/B4.2): só
## bloqueia a entrada e solta os dedos presos.
func definir_ativa(ativa: bool) -> void:
	_bloqueado = not ativa
	if _joystick_mov != null:
		_joystick_mov.definir_bloqueado(_bloqueado)
	if _joystick_mira != null:
		_joystick_mira.definir_bloqueado(_bloqueado)
	if _raiz != null:
		_raiz.modulate.a = 1.0 if ativa else 0.6
	if not ativa:
		entrada = Vector2.ZERO
		atirando = false
		mira_ativa = false
		secundario_pendente = false
		dash_pendente = false
		parar_pendente = false


func _aplicar_area_segura() -> void:
	## Respeita notch/bordas curvas (B5). Em desktop o safe area é a tela toda.
	if _raiz == null:
		return
	_raiz.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	if not OS.has_feature("mobile"):
		return
	var tela: Vector2i = DisplayServer.screen_get_size()
	if tela.x <= 0 or tela.y <= 0:
		return
	var area: Rect2i = DisplayServer.get_display_safe_area()
	var visivel: Vector2 = get_viewport().get_visible_rect().size
	var fator: float = visivel.x / float(tela.x)
	_raiz.offset_left = float(area.position.x) * fator
	_raiz.offset_top = float(area.position.y) * fator
	_raiz.offset_right = -float(tela.x - area.end.x) * fator
	_raiz.offset_bottom = -float(tela.y - area.end.y) * fator
