extends Node
## UiState (Autoload)
## Ponto único de decisão do BLOCO B (B4.4): o jogo está JOGO ou tem uma
## JANELA por cima. As janelas NUNCA removem nem escondem os controles: elas só
## ficam numa CanvasLayer acima (20) e o estado aqui impede que os dedos
## cheguem aos sticks/botões enquanto a janela estiver aberta.

enum Estado { JOGO, JANELA }

signal estado_alterado(novo: int)

var estado: int = Estado.JOGO


func aceita_entrada() -> bool:
	return estado == Estado.JOGO


func abrir_janela(_nome: String = "") -> void:
	definir_janela(true)


func fechar_janela(_nome: String = "") -> void:
	definir_janela(false)


## Idempotente: o HUD pode chamar a cada mudança de tela sem medo.
func definir_janela(aberta: bool) -> void:
	var novo: int = Estado.JANELA if aberta else Estado.JOGO
	if novo == estado:
		if aberta:
			resetar_controles()
		return
	estado = novo
	resetar_controles()
	estado_alterado.emit(estado)


func resetar_controles() -> void:
	## Solta o dedo de todos os sticks: evita stick "preso" ao abrir janela,
	## ao voltar do segundo plano e ao fechar a janela.
	if not is_inside_tree():
		return
	for n: Node in get_tree().get_nodes_in_group("joysticks_virtuais"):
		if n.has_method("resetar"):
			n.call("resetar")


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		resetar_controles()
