class_name Boss
extends Enemy
## Chefes do livro de personagens: REATOR EM FUSÃO (radiação -> calor ->
## resíduos) e NUVEM QUÍMICA (gás -> ácido -> oxidante). Cada um troca de
## fase conforme perde vida, mudando o perigo e, portanto, a arma eficaz.
## Abaixo de 50% de vida entra em FÚRIA (fase final acelerada).

const CENA_GRANADA: String = "res://scenes/granada_inimiga.tscn"
const IDS_FASE: Array[String] = ["reator", "nuvem_quimica"]

var _padrao_idx: int = 0
var _padrao_timer: float = 2.4
var _furia: bool = false
var _invocar_timer: float = 5.0
var _cena_granada: PackedScene = null
var _nome: String = "CHEFE"
var _aura_timer: float = 0.0
var _fase_vista: int = 1


func _ready() -> void:
	super._ready()
	_nome = dados.nome if dados != null else "CHEFE"
	if ResourceLoader.exists(CENA_GRANADA):
		_cena_granada = load(CENA_GRANADA) as PackedScene
	_padrao_timer = 2.2
	if not como_comum:
		GlobalManager.chefe_surgiu.emit(_nome, vida_max)
		GlobalManager.chefe_vida.emit(vida, vida_max)
		AudioManager.tocar_sfx("chefe", -3.0, 0.02)


func _physics_process(delta: float) -> void:
	if autoridade_remota:
		return
	super._physics_process(delta)
	if morto or not GlobalManager.partida_ativa:
		return
	_aura_timer += delta
	_padrao_timer -= delta
	if not como_comum:
		_invocar_timer -= delta
		_checar_fase()
		if not _furia and vida <= vida_max * 0.5:
			_entrar_furia()
	if _padrao_timer <= 0.0:
		_padrao_timer = _intervalo_padrao()
		_executar_padrao()
	if not como_comum and _invocar_timer <= 0.0:
		_invocar_timer = 8.0 if _furia else 11.0
		_invocar()


func _intervalo_padrao() -> float:
	## Ex-chefe sorteado como inimigo comum volta a atirar no ritmo de um
	## inimigo comum, não no ritmo de chefe (0,5 s era o problema).
	if como_comum:
		return 3.8 if _eh_chefe_de_fase() else 4.6
	if _eh_chefe_de_fase():
		return 1.7 if _furia else 2.4
	return 1.45 if _furia else 2.6


func _calcular_direcao(_delta: float) -> Vector2:
	if jogador == null:
		return Vector2.ZERO
	var para: Vector2 = jogador.global_position - global_position
	var dist: float = para.length()
	var dir: Vector2 = para.normalized()
	if dist < 240.0:
		return -dir * 0.6 + dir.orthogonal() * 0.4
	if dist > 480.0:
		return dir * 0.8
	return dir.orthogonal() * 0.5


func _entrar_furia() -> void:
	if como_comum or _furia:
		return
	_furia = true
	velocidade *= 1.25
	_padrao_timer = 0.6
	if corpo != null:
		var tw: Tween = create_tween().set_loops(6)
		tw.tween_property(corpo, "modulate", Color(1.8, 0.5, 0.5), 0.18)
		tw.tween_property(corpo, "modulate", Color.WHITE, 0.18)
	Efeitos.anel(get_parent(), global_position, 180.0, Color(1.0, 0.25, 0.25, 0.9), 0.6, 6.0)
	Efeitos.tremor(12.0)
	AudioManager.tocar_sfx("chefe", -2.0, 0.04)
	GlobalManager.registrar_estilo("FÚRIA DO CHEFE", 10.0, Color("ff5f5f"))
	GlobalManager.chefe_aviso.emit("FÚRIA", "A REAÇÃO SAIU DE CONTROLE")


func _eh_chefe_de_fase() -> bool:
	return dados != null and dados.id in IDS_FASE


# ------------------------------------------------------------------ fases
func _fase_atual() -> int:
	## 1: acima de 66% | 2: entre 66% e 33% | 3: abaixo de 33%.
	var pct: float = percentual_vida()
	if pct > 0.66:
		return 1
	if pct > 0.33:
		return 2
	return 3


func _cor_fase(fase: int) -> Color:
	if dados != null and dados.id == "nuvem_quimica":
		match fase:
			2:
				return Color("ffe066")
			3:
				return Color("7ac8ff")
			_:
				return Color("9dff5a")
	match fase:
		2:
			return Color("ff9b45")
		3:
			return Color("c58bff")
		_:
			return Color("b6ff5a")


func _checar_fase() -> void:
	if not _eh_chefe_de_fase():
		return
	var fase: int = _fase_atual()
	if fase == _fase_vista:
		return
	_fase_vista = fase
	_padrao_timer = 0.9
	var cor: Color = _cor_fase(fase)
	if corpo != null:
		corpo.modulate = cor.lightened(0.35)
		var tw: Tween = corpo.create_tween()
		tw.tween_property(corpo, "modulate", Color.WHITE, 0.5)
	Efeitos.anel(get_parent(), global_position, 200.0, Color(cor.r, cor.g, cor.b, 0.9), 0.55, 5.0)
	Efeitos.particulas(get_parent(), global_position, cor, 16, 240.0, 0.7, 3.5, "fumaca")
	AudioManager.tocar_sfx("chefe", -6.0, 0.08)
	if dados != null and dados.id == "nuvem_quimica":
		match fase:
			2:
				GlobalManager.chefe_aviso.emit("FASE 2 — ÁCIDO", "BICARBONATO NEUTRALIZA")
			3:
				GlobalManager.chefe_aviso.emit("FASE 3 — OXIDANTE", "TIOSSULFATO REDUZ")
			_:
				GlobalManager.chefe_aviso.emit("FASE 1 — GÁS TÓXICO", "CARVÃO ATIVADO ADSORVE")
	else:
		match fase:
			2:
				GlobalManager.chefe_aviso.emit("FASE 2 — SUPERAQUECIMENTO", "GELO SECO RESFRIA")
			3:
				GlobalManager.chefe_aviso.emit("FASE 3 — RESÍDUOS", "QUELANTE PRENDE O METAL")
			_:
				GlobalManager.chefe_aviso.emit("FASE 1 — RADIAÇÃO", "CHUMBO BLINDA")


func _executar_padrao() -> void:
	if animador != null:
		animador.tocar("ataque")
	if como_comum:
		# Sem anúncio de ataque e com dano bem menor: é só um inimigo do enxame.
		_padrao_comum()
		return
	if _eh_chefe_de_fase():
		if dados.id == "nuvem_quimica":
			_padrao_nuvem(_fase_atual())
		else:
			_padrao_reator(_fase_atual())
		_padrao_idx += 1
		return
	if _furia:
		# Em fúria o chefe troca de repertório: nada de repetir o leque comum.
		_furia_espiral()
		_padrao_idx += 1
		return
	match _padrao_idx % 4:
		0:
			_leque()
		1:
			_radial()
		2:
			_chuva_granadas()
		_:
			_radial()
	_padrao_idx += 1


func _dano_comum(base: float) -> float:
	## Dano de um ex-chefe no enxame comum: ~40% do original.
	return base * 0.4


func _padrao_comum() -> void:
	## Ex-chefe virou inimigo comum: um leque curto e fraco, sem aviso na tela.
	if jogador == null:
		return
	var dir: Vector2 = (jogador.global_position - global_position).normalized()
	for i: int in range(3):
		var ang: float = deg_to_rad(-16.0 + 16.0 * float(i))
		_disparar_custom(dir.rotated(ang), _dano_comum(8.0 + float(horda) * 0.3), 250.0, 0.8)
	AudioManager.tocar_sfx("tiro", -10.0, 0.08)


# ------------------------------------------------ REATOR EM FUSÃO (3 fases)
func _padrao_reator(fase: int) -> void:
	match fase:
		2:
			_reator_calor()
		3:
			_reator_residuos()
		_:
			_reator_radiacao()


func _reator_radiacao() -> void:
	## Fase 1: nuvem de radiação lenta que cerca e continua corroendo a vida.
	var cor: Color = Color("b6ff5a")
	var qtd: int = 18 if _furia else 13
	for i: int in range(qtd):
		var ang: float = TAU * float(i) / float(qtd) + _aura_timer * 0.4
		_disparar_custom(Vector2.RIGHT.rotated(ang), 9.0 + float(horda) * 0.3, 165.0, 2.1, {
			"cor": cor, "duracao": 4.2, "elemento": "U",
		})
	if jogador != null:
		var alvo: Vector2 = (jogador.global_position - global_position).normalized()
		for i: int in range(3):
			_disparar_custom(alvo.rotated(deg_to_rad(-12.0 + 12.0 * float(i))), 11.0, 320.0, 1.4, {
				"cor": cor, "duracao": 2.4, "elemento": "U",
			})
	Efeitos.anel(get_parent(), global_position, 210.0, Color(0.72, 1.0, 0.35, 0.8), 0.45, 5.0)
	AudioManager.tocar_sfx("tiro_pesado", -8.0, 0.05)
	GlobalManager.chefe_aviso.emit("VAZAMENTO RADIOATIVO", "CURVE ENTRE OS ANÉIS")


func _reator_calor() -> void:
	## Fase 2: o núcleo esquenta — projéteis rápidos e chuva de explosivos.
	var cor: Color = Color("ff9b45")
	var offset: float = randf() * TAU
	var qtd: int = 16 if _furia else 11
	for i: int in range(qtd):
		var ang: float = offset + TAU * float(i) / float(qtd)
		_disparar_custom(Vector2.RIGHT.rotated(ang), 12.0 + float(horda) * 0.35, 380.0, 1.5, {
			"cor": cor, "duracao": 2.0, "elemento": "P4",
		})
	_chuva_granadas()
	Efeitos.anel(get_parent(), global_position, 180.0, Color(1.0, 0.6, 0.25, 0.85), 0.4, 5.0)
	AudioManager.tocar_sfx("explosao", -10.0, 0.07)
	GlobalManager.chefe_aviso.emit("SUPERAQUECIMENTO", "O CALOR RACHA O PISO")


func _reator_residuos() -> void:
	## Fase 3: resíduos de metais pesados — gotas densas que não somem.
	var cor: Color = Color("c58bff")
	for i: int in range(10):
		var ang: float = TAU * float(i) / 10.0 + _aura_timer * 0.7
		_disparar_custom(Vector2.RIGHT.rotated(ang), 14.0 + float(horda) * 0.4, 250.0, 2.4, {
			"cor": cor, "duracao": 4.6, "ricochetes": 4, "elemento": "Hg",
		})
	var offset: float = randf() * TAU
	for i: int in range(4):
		var ang2: float = offset + PI * 0.5 * float(i)
		_disparar_custom(Vector2.RIGHT.rotated(ang2), 16.0, 560.0, 1.1, {
			"cor": Color("e6d4ff"), "duracao": 2.6,
		})
	Efeitos.particulas(get_parent(), global_position, cor, 20, 280.0, 0.8, 4.0, "plasma")
	AudioManager.tocar_sfx("tiro_pesado", -6.0, 0.05)
	GlobalManager.chefe_aviso.emit("RESÍDUOS PESADOS", "NÃO ENCOSTE NAS GOTAS")


# -------------------------------------------------- NUVEM QUÍMICA (3 fases)
func _padrao_nuvem(fase: int) -> void:
	match fase:
		2:
			_nuvem_acido()
		3:
			_nuvem_oxidante()
		_:
			_nuvem_gas()


func _nuvem_gas() -> void:
	## Fase 1: leque de nuvens tóxicas lentas + anel que fecha o cerco.
	var cor: Color = Color("9dff5a")
	if jogador != null:
		var alvo: Vector2 = (jogador.global_position - global_position).normalized()
		for i: int in range(7):
			var ang: float = deg_to_rad(-54.0 + 18.0 * float(i))
			_disparar_custom(alvo.rotated(ang), 8.0 + float(horda) * 0.3, 220.0, 2.1, {
				"cor": cor, "duracao": 3.4, "elemento": "Cl",
			})
	for i: int in range(10):
		var ang2: float = TAU * float(i) / 10.0 + _aura_timer * 0.5
		_disparar_custom(Vector2.RIGHT.rotated(ang2), 6.0, 150.0, 1.7, {
			"cor": Color("5cff8a"), "duracao": 2.8, "elemento": "NH3",
		})
	Efeitos.particulas(get_parent(), global_position, cor, 14, 200.0, 0.7, 3.0, "acido")
	AudioManager.tocar_sfx("tiro_helio", -8.0, 0.06)
	GlobalManager.chefe_aviso.emit("NÉVOA TÓXICA", "CARVÃO ATIVADO ADSORVE")


func _nuvem_acido() -> void:
	## Fase 2: respingos corrosivos rápidos que deixam poças no chão.
	var cor: Color = Color("ffe066")
	for i: int in range(16 if _furia else 11):
		var ang: float = TAU * float(i) / float(16 if _furia else 11) + _aura_timer
		_disparar_custom(Vector2.RIGHT.rotated(ang), 10.0 + float(horda) * 0.3, 300.0, 1.6, {
			"cor": cor, "duracao": 3.8, "elemento": "H2SO4",
		})
	if jogador != null:
		var alvo: Vector2 = (jogador.global_position - global_position).normalized()
		for i: int in range(3):
			_disparar_custom(alvo.rotated(deg_to_rad(-10.0 + 10.0 * float(i))), 13.0, 460.0, 1.3, {
				"cor": Color("ffe9a8"), "duracao": 2.2, "elemento": "HCl",
			})
	Efeitos.anel(get_parent(), global_position, 200.0, Color(1.0, 0.88, 0.4, 0.85), 0.4, 4.0)
	AudioManager.tocar_sfx("tiro_pesado", -8.0, 0.05)
	GlobalManager.chefe_aviso.emit("CHUVA ÁCIDA", "BICARBONATO NEUTRALIZA")


func _nuvem_oxidante() -> void:
	## Fase 3: oxidante puro — rajada rápida de fora para dentro.
	var cor: Color = Color("7ac8ff")
	var offset: float = randf() * TAU
	for i: int in range(20 if _furia else 14):
		var ang: float = offset + TAU * float(i) / float(20 if _furia else 14)
		_disparar_custom(Vector2.RIGHT.rotated(ang), 9.0 + float(horda) * 0.35, 430.0, 1.2, {
			"cor": cor, "duracao": 2.4, "elemento": "Cl",
		})
	for i: int in range(5):
		var ang2: float = -PI * 0.5 + PI * float(i) / 4.0
		_disparar_custom(Vector2.RIGHT.rotated(ang2), 15.0, 320.0, 2.0, {
			"cor": Color("bfe4ff"), "duracao": 3.0, "elemento": "Cl",
		})
	Efeitos.particulas(get_parent(), global_position, cor, 22, 320.0, 0.8, 4.0, "plasma")
	AudioManager.tocar_sfx("explosao", -8.0, 0.06)
	GlobalManager.chefe_aviso.emit("OXIDANTE PURO", "TIOSSULFATO REDUZ")


func _furia_espiral() -> void:
	## FÚRIA genérica: espiral de fissão em três braços.
	var passos: int = 7
	for p: int in range(passos):
		var base: float = _aura_timer + TAU * float(p) / float(passos)
		for b: int in range(3):
			var ang: float = base + TAU * float(b) / 3.0
			_disparar(Vector2.RIGHT.rotated(ang), 8.0 + float(horda) * 0.3, 250.0 + float(p) * 26.0)
	Efeitos.anel(get_parent(), global_position, 170.0, Color(1.0, 0.45, 0.3, 0.7), 0.4, 3.0)
	AudioManager.tocar_sfx("tiro_pesado", -8.0, 0.05)
	GlobalManager.chefe_aviso.emit("ESPIRAL DE FISSÃO", "GIRE COM AS BRECHAS")


func _leque() -> void:
	if _cena_projetil == null or jogador == null:
		return
	var dir: Vector2 = (jogador.global_position - global_position).normalized()
	var qtd: int = 7 if _furia else 5
	var abertura: float = deg_to_rad(46.0)
	for i: int in range(qtd):
		var f: float = float(i) / float(qtd - 1) if qtd > 1 else 0.5
		var ang: float = -abertura * 0.5 + abertura * f
		_disparar(dir.rotated(ang), 12.0 + float(horda) * 0.4, 420.0)
	AudioManager.tocar_sfx("tiro_pesado", -8.0, 0.06)


func _radial() -> void:
	var qtd: int = 18 if _furia else 12
	var offset: float = randf() * TAU
	for i: int in range(qtd):
		var ang: float = offset + TAU * float(i) / float(qtd)
		_disparar(Vector2.RIGHT.rotated(ang), 10.0 + float(horda) * 0.35, 320.0)
	Efeitos.anel(get_parent(), global_position, 120.0, Color(1.0, 0.5, 0.3, 0.6), 0.3, 2.0)
	AudioManager.tocar_sfx("explosao", -12.0, 0.08)


func _disparar_custom(dir: Vector2, dano: float, vel: float, tam: float, extra: Dictionary = {}) -> void:
	if _cena_projetil == null:
		return
	var p: Projetil = _cena_projetil.instantiate() as Projetil
	if p == null:
		return
	get_parent().add_child(p)
	p.global_position = global_position + dir * (raio + 6.0)
	var cfg: Dictionary = {
		"amigavel": false,
		"direcao": dir,
		"dano": dano,
		"velocidade": vel,
		"cor": dados.cor if dados != null else Color("ff7a59"),
		"tamanho": tam,
		"alcance": 1800.0,
	}
	for chave: Variant in extra.keys():
		cfg[chave] = extra[chave]
	p.configurar(cfg)


func _disparar(dir: Vector2, dano: float, vel: float) -> void:
	if _cena_projetil == null:
		return
	var p: Projetil = _cena_projetil.instantiate() as Projetil
	if p == null:
		return
	get_parent().add_child(p)
	p.global_position = global_position + dir * (raio + 6.0)
	p.configurar({
		"amigavel": false,
		"direcao": dir,
		"dano": dano,
		"velocidade": vel,
		"cor": dados.cor if dados != null else Color("ff7a59"),
		"tamanho": 1.3,
		"alcance": 1200.0,
	})


func _chuva_granadas() -> void:
	if _cena_granada == null or jogador == null:
		return
	var qtd: int = 3 if _furia else 2
	for i: int in range(qtd):
		var g: GranadaInimiga = _cena_granada.instantiate() as GranadaInimiga
		if g == null:
			continue
		get_parent().add_child(g)
		var alvo: Vector2 = jogador.global_position + Vector2(randf_range(-160.0, 160.0), randf_range(-160.0, 160.0))
		g.configurar(global_position, alvo, 84.0, 18.0 + float(horda) * 0.5, self)
	AudioManager.tocar_sfx("perigo", -8.0, 0.1)


func _invocar() -> void:
	var sm: Node = get_tree().get_first_node_in_group("spawn_manager")
	if sm != null and sm.has_method("invocar_minions"):
		sm.call("invocar_minions", global_position, 3 if _furia else 2)
		GlobalManager.registrar_estilo("INVOCAÇÃO", 4.0, Color("c58bff"))


func receber_dano(valor: float, critico: bool = false) -> void:
	super.receber_dano(valor, critico)
	if not morto and not como_comum:
		GlobalManager.chefe_vida.emit(vida, vida_max)


func _morrer() -> void:
	if morto:
		return
	if not como_comum:
		GlobalManager.boss_derrotado.emit(_nome)
		GlobalManager.chefe_vida.emit(0.0, vida_max)
		# O chefe derrotado passa a integrar o enxame comum das próximas hordas.
		# O Elemento Supremo NUNCA vira inimigo comum: existe só na fase final.
		if dados != null:
			if dados.id != "elemento_supremo":
				var sm: Node = get_tree().get_first_node_in_group("spawn_manager")
				if sm != null and sm.has_method("liberar_como_comum"):
					sm.call("liberar_como_comum", dados.id)
			GlobalManager.desbloquear_conquista("derrotar_%s" % dados.id)
	Efeitos.tremor(18.0)
	for i: int in range(5):
		Efeitos.anel(get_parent(), global_position, 140.0 + float(i) * 30.0, Color(1.0, 0.6, 0.3, 0.7), 0.5 + float(i) * 0.1, 4.0)
	super._morrer()
