extends Node
## Co-op LAN (ENet). O host é a autoridade: simula inimigos, projéteis e todos
## os jogadores. Os clientes enviam entrada/mira e desenham o mundo pelos
## snapshots. A sala é encontrada automaticamente na rede local pela porta.

signal sala_criada
signal conectado
signal conexao_falhou(texto: String)
signal jogador_conectado(id: int)
signal jogador_desconectado(id: int)
signal snapshot(dados: Dictionary)
signal host_encontrado(endereco: String, porta: int)
signal busca_encerrada
## Uma sala aberta na rede (tabela do menu LAN).
signal servidor_encontrado(dados: Dictionary)
signal lista_servidores_atualizada(lista: Array)

const PORTA_PADRAO: int = 7777
## A descoberta usa uma porta fixa própria: o cliente só informa a porta do jogo.
const PORTA_DESCOBERTA: int = 7778
const MAX_CLIENTES: int = 3
const INTERVALO_SNAPSHOT: float = 0.1
const INTERVALO_ENTRADA: float = 0.05
const INTERVALO_PING: float = 1.5
const MAGIC: String = "NEXFUSION_LAN_V1"
## Versão do protocolo de rede. Vai no anúncio e no handshake: builds
## diferentes se recusam com mensagem clara em vez de falhar em silêncio.
const VERSAO_REDE: String = "1.1"

var modo: String = "off"
var porta: int = PORTA_PADRAO
var ip: String = "127.0.0.1"
var ping_ms: int = 0

var _peer: ENetMultiplayerPeer = null
var _jogo: Node = null
var _jogador_local: Player = null
var _remotos: Dictionary = {}
var _nicks: Dictionary = {}
## Ping que cada cliente reporta ao host (alimenta a lista do TAB).
var _pings: Dictionary = {}
## Estado guardado de quem saiu, indexado pelo apelido (reconexão).
var _estados: Dictionary = {}
var _aguardando_handshake: bool = false
var _handshake_timer: float = 0.0
var _enviar_timer: float = 0.0
var _ping_timer: float = 0.0

# descoberta automática (UDP broadcast)
var _udp_busca: PacketPeerUDP = null
var _udp_host: PacketPeerUDP = null
var _buscando: bool = false
var _busca_timer: float = 0.0
var _porta_busca: int = PORTA_PADRAO
var _repetir_timer: float = 0.0
var _parar_no_primeiro: bool = true
## Salas abertas descobertas na última busca (ip, porta, nick, jogadores, maximo).
var servidores: Array[Dictionary] = []


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	multiplayer.peer_connected.connect(_ao_peer_conectado)
	multiplayer.peer_disconnected.connect(_ao_peer_desconectado)
	multiplayer.connected_to_server.connect(_ao_conectado)
	multiplayer.connection_failed.connect(func() -> void: conexao_falhou.emit("Host não encontrado. Verifique se a sala está aberta e o firewall liberado."))
	multiplayer.server_disconnected.connect(func() -> void: conexao_falhou.emit("O host encerrou a sala."))


func _process(delta: float) -> void:
	_poll_descoberta(delta)
	if _aguardando_handshake:
		_handshake_timer -= delta
		if _handshake_timer <= 0.0:
			# Host de build antiga (sem handshake): não deixa o cliente preso.
			_aguardando_handshake = false
			conectado.emit()
	if modo == "off" or _jogo == null or not is_instance_valid(_jogo):
		return
	if get_tree().paused:
		return
	_enviar_timer -= delta
	if _enviar_timer > 0.0:
		return
	if modo == "client":
		_enviar_timer = INTERVALO_ENTRADA
		_enviar_entrada()
	else:
		_enviar_timer = INTERVALO_SNAPSHOT
		_enviar_snapshot()


func _poll_descoberta(delta: float) -> void:
	if _udp_host != null:
		while _udp_host.get_available_packet_count() > 0:
			var dado: PackedByteArray = _udp_host.get_packet()
			var remetente: String = _udp_host.get_packet_ip()
			if dado.get_string_from_utf8() == MAGIC:
				_udp_host.set_dest_address(remetente, _udp_host.get_packet_port())
				_udp_host.put_packet(_texto_anuncio().to_utf8_buffer())
	if not _buscando or _udp_busca == null:
		return
	_busca_timer -= delta
	_repetir_timer -= delta
	while _udp_busca.get_available_packet_count() > 0:
		var pacote: PackedByteArray = _udp_busca.get_packet()
		var origem: String = _udp_busca.get_packet_ip()
		var info: Dictionary = _ler_anuncio(pacote.get_string_from_utf8(), origem)
		if info.is_empty():
			continue
		_registrar_servidor(info)
		servidor_encontrado.emit(info)
		lista_servidores_atualizada.emit(servidores.duplicate())
		if _parar_no_primeiro:
			var ip_alvo: String = String(info["ip"])
			var porta_alvo: int = int(info["porta"])
			_encerrar_busca()
			host_encontrado.emit(ip_alvo, porta_alvo)
			busca_encerrada.emit()
			return
	if _repetir_timer <= 0.0:
		_repetir_timer = 0.8
		_enviar_consulta()
	if _busca_timer > 0.0:
		return
	var sem_salas: bool = servidores.is_empty()
	_encerrar_busca()
	if _parar_no_primeiro and sem_salas:
		conexao_falhou.emit("Nenhum host respondeu na porta %d. Confira a rede e o firewall." % _porta_busca)
	busca_encerrada.emit()


func _texto_anuncio() -> String:
	## Informações que o host devolve na busca: alimentam a tabela de salas.
	return JSON.stringify({
		"magic": MAGIC,
		"versao": VERSAO_REDE,
		"porta": porta,
		"nick": GlobalManager.nick,
		"jogadores": total_jogadores(),
		"maximo": MAX_CLIENTES + 1,
	})


func _ler_anuncio(texto: String, origem: String) -> Dictionary:
	if origem == "":
		return {}
	if texto.is_valid_int():
		# Compatibilidade: host antigo respondia só com o número da porta.
		return {"ip": origem, "porta": int(texto), "nick": "JOGADOR", "jogadores": 1, "maximo": MAX_CLIENTES + 1, "versao": "", "compativel": false}
	var parsed: Variant = JSON.parse_string(texto)
	if not parsed is Dictionary:
		return {}
	var d: Dictionary = parsed as Dictionary
	if String(d.get("magic", "")) != MAGIC:
		return {}
	var versao_sala: String = String(d.get("versao", ""))
	return {
		"ip": origem,
		"porta": clampi(int(d.get("porta", PORTA_PADRAO)), 1, 65535),
		"nick": String(d.get("nick", "JOGADOR")).substr(0, 16),
		"jogadores": clampi(int(d.get("jogadores", 1)), 1, MAX_CLIENTES + 1),
		"maximo": clampi(int(d.get("maximo", MAX_CLIENTES + 1)), 1, MAX_CLIENTES + 1),
		"versao": versao_sala,
		"compativel": versao_sala == VERSAO_REDE,
	}


func _registrar_servidor(info: Dictionary) -> void:
	var chave: String = "%s:%d" % [String(info["ip"]), int(info["porta"])]
	for i: int in range(servidores.size()):
		var atual: Dictionary = servidores[i]
		if "%s:%d" % [String(atual["ip"]), int(atual["porta"])] == chave:
			servidores[i] = info
			return
	servidores.append(info)


func ip_local() -> String:
	## IP da máquina na rede local, para o host compartilhar com os convidados.
	var enderecos: PackedStringArray = IP.get_local_addresses()
	for a: String in enderecos:
		if a.contains(":") or a.begins_with("127.") or a == "0.0.0.0":
			continue
		if a.begins_with("192.168.") or a.begins_with("10."):
			return a
	for a: String in enderecos:
		if a.contains(":") or a.begins_with("127.") or a == "0.0.0.0":
			continue
		if a.begins_with("172."):
			var partes: PackedStringArray = a.split(".")
			if partes.size() == 4 and int(partes[1]) >= 16 and int(partes[1]) <= 31:
				return a
	return "127.0.0.1"


# ------------------------------------------------------------------ descoberta
func procurar_host(p: int = PORTA_PADRAO) -> bool:
	## Procura UMA sala (fluxo antigo) sem o jogador digitar IP.
	return _iniciar_busca(p, 3.0, true)


func listar_servidores(p: int = PORTA_PADRAO, duracao: float = 2.5) -> bool:
	## Busca por alguns segundos e acumula TODAS as salas abertas na tabela.
	servidores.clear()
	lista_servidores_atualizada.emit([])
	return _iniciar_busca(p, maxf(0.5, duracao), false)


func _iniciar_busca(p: int, duracao: float, parar_no_primeiro: bool) -> bool:
	_encerrar_busca()
	var udp: PacketPeerUDP = PacketPeerUDP.new()
	var erro: int = udp.bind(0)
	if erro != OK:
		conexao_falhou.emit("Não foi possível iniciar a busca na rede (erro %d)." % erro)
		return false
	udp.set_broadcast_enabled(true)
	_udp_busca = udp
	_buscando = true
	_busca_timer = maxf(0.5, duracao)
	_repetir_timer = 0.8
	_porta_busca = p
	_parar_no_primeiro = parar_no_primeiro
	_enviar_consulta()
	return true


func _enviar_consulta() -> void:
	if _udp_busca == null:
		return
	_udp_busca.set_dest_address("255.255.255.255", PORTA_DESCOBERTA)
	_udp_busca.put_packet(MAGIC.to_utf8_buffer())
	# Loopback: permite testar duas instâncias no mesmo computador.
	_udp_busca.set_dest_address("127.0.0.1", PORTA_DESCOBERTA)
	_udp_busca.put_packet(MAGIC.to_utf8_buffer())


func _encerrar_busca() -> void:
	_buscando = false
	if _udp_busca != null:
		_udp_busca.close()
		_udp_busca = null


func _iniciar_anuncio() -> void:
	_parar_anuncio()
	var udp: PacketPeerUDP = PacketPeerUDP.new()
	if udp.bind(PORTA_DESCOBERTA) != OK:
		return
	udp.set_broadcast_enabled(true)
	_udp_host = udp


func _parar_anuncio() -> void:
	if _udp_host != null:
		_udp_host.close()
		_udp_host = null


# ------------------------------------------------------------------ sala
func criar_sala(p: int = PORTA_PADRAO) -> bool:
	sair()
	_peer = ENetMultiplayerPeer.new()
	# Uma vaga extra no transporte: se a sala já estiver cheia, o host consegue
	# responder "SALA CHEIA" antes de fechar a conexão (A2.6).
	var erro: int = _peer.create_server(p, MAX_CLIENTES + 1)
	if erro != OK:
		_peer = null
		conexao_falhou.emit("Não foi possível abrir a porta %d (erro %d)." % [p, erro])
		return false
	multiplayer.multiplayer_peer = _peer
	modo = "host"
	porta = p
	_iniciar_anuncio()
	sala_criada.emit()
	return true


func entrar_sala(endereco: String, p: int = PORTA_PADRAO) -> bool:
	sair()
	_peer = ENetMultiplayerPeer.new()
	var erro: int = _peer.create_client(endereco, p)
	if erro != OK:
		_peer = null
		conexao_falhou.emit("Endereço inválido ou porta fechada (erro %d)." % erro)
		return false
	multiplayer.multiplayer_peer = _peer
	modo = "client"
	ip = endereco
	porta = p
	return true


func sair() -> void:
	_remotos.clear()
	_nicks.clear()
	_pings.clear()
	_estados.clear()
	_aguardando_handshake = false
	_jogo = null
	_jogador_local = null
	_parar_anuncio()
	_encerrar_busca()
	if _peer != null:
		_peer.close()
		multiplayer.multiplayer_peer = null
		_peer = null
	modo = "off"
	ping_ms = 0


func _exit_tree() -> void:
	_parar_anuncio()
	_encerrar_busca()
	if _peer != null:
		_peer.close()
		_peer = null
		multiplayer.multiplayer_peer = null


func total_jogadores() -> int:
	if modo == "off":
		return 1
	return clampi(multiplayer.get_peers().size() + 1, 1, MAX_CLIENTES + 1)


func multiplicador_dificuldade() -> int:
	## A2.3: vida dos inimigos x1 (1 jogador), x2, x3, x4 (4 ou mais).
	if modo == "off":
		return 1
	return clampi(total_jogadores(), 1, 4)


func nomes_da_sala() -> Array[Dictionary]:
	## Lista do TAB: apelido e ping de cada jogador (o IP nunca entra aqui).
	var lista: Array[Dictionary] = []
	if modo == "off":
		lista.append({"id": 1, "nick": GlobalManager.nick, "host": true, "ping": 0})
		return lista
	var eu: int = multiplayer.get_unique_id()
	var ids: Array[int] = [1]
	for id: int in multiplayer.get_peers():
		if id != 1:
			ids.append(id)
	if modo == "client" and not ids.has(eu):
		ids.append(eu)
	for id_p: int in ids:
		var sou_eu: bool = id_p == eu
		var nome: String = GlobalManager.nick if sou_eu else nick_de(id_p)
		if nome.strip_edges() == "" or nome == "JOGADOR":
			if id_p == 1 and modo == "client":
				nome = "HOST"
			else:
				nome = "JOGADOR %d" % id_p
		var ms: int = 0
		if modo == "host":
			ms = 0 if id_p == 1 else int(_pings.get(id_p, 0))
		else:
			ms = ping_ms if (sou_eu or id_p == 1) else 0
		lista.append({"id": id_p, "nick": nome, "host": id_p == 1, "ping": ms})
	return lista


func configurar_jogo_host(jogo: Node, jogador: Player) -> void:
	_jogo = jogo
	_jogador_local = jogador
	modo = "host"
	_enviar_timer = 0.0
	# Clientes que conectaram ANTES da cena de jogo carregar precisam ser
	# materializados agora (senão o host os ignora para sempre).
	for id: int in multiplayer.get_peers():
		if jogador_remoto(id) == null and jogo.has_method("criar_jogador_remoto"):
			jogo.call("criar_jogador_remoto", id)
		_tentar_restaurar(id)


func configurar_jogo_cliente(jogo: Node, jogador: Player) -> void:
	_jogo = jogo
	_jogador_local = jogador
	modo = "client"
	_enviar_timer = 0.0
	_ping_timer = 0.0
	_rpc_informar_nick.rpc_id(1, GlobalManager.nick)
	if jogador != null:
		jogador.definir_nick(GlobalManager.nick)


func jogador_remoto(id: int) -> Player:
	return _remotos.get(id) as Player


func registrar_remoto(id: int, jogador: Player) -> void:
	_remotos[id] = jogador


func nick_de(id: int) -> String:
	return String(_nicks.get(id, "JOGADOR"))


# ------------------------------------------------------------------ host
func _ao_peer_conectado(id: int) -> void:
	if modo != "host":
		return
	# A2.6: com a sala cheia a entrada é recusada com mensagem (nunca calada).
	if multiplayer.get_peers().size() > MAX_CLIENTES:
		_recusar(id, "SALA CHEIA (%d/%d) — TENTE OUTRA SALA" % [total_jogadores(), MAX_CLIENTES + 1])
		return
	if _jogo != null and _jogo.has_method("criar_jogador_remoto"):
		_jogo.call("criar_jogador_remoto", id)
	jogador_conectado.emit(id)


func _ao_conectado() -> void:
	# O host confere versão e vagas antes de liberar a entrada (A2.5).
	_aguardando_handshake = true
	_handshake_timer = 3.0
	_rpc_handshake.rpc_id(1, VERSAO_REDE, GlobalManager.nick)


func _ao_peer_desconectado(id: int) -> void:
	var p: Player = _remotos.get(id) as Player
	if p != null and is_instance_valid(p):
		# A2.5: guarda o estado de quem saiu para devolvê-lo na reconexão.
		var nome: String = nick_de(id)
		if nome != "":
			_estados[nome] = {
				"x": p.global_position.x,
				"y": p.global_position.y,
				"vida": p.vida,
				"max": p.vida_maxima,
			}
		p.queue_free()
	_remotos.erase(id)
	_nicks.erase(id)
	_pings.erase(id)
	jogador_desconectado.emit(id)


func _enviar_snapshot() -> void:
	var dados: Dictionary = {"jogadores": [], "inimigos": [], "guardioes": [], "projeteis": []}
	dados["horda"] = GlobalManager.horda_atual
	dados["fase"] = GlobalManager.fase
	dados["resurreicoes"] = GlobalManager.cargas_ressurreicao
	# A2.2: uma única barra/nível para a sala inteira (o host é a autoridade).
	dados["equipe"] = {
		"xp": GlobalManager.xp_run,
		"necessario": GlobalManager.xp_necessario,
		"nivel": GlobalManager.nivel_run,
	}
	dados["maximo"] = MAX_CLIENTES + 1
	var nomes: Dictionary = {1: GlobalManager.nick}
	for id_nome: int in multiplayer.get_peers():
		if id_nome != 1:
			nomes[id_nome] = nick_de(id_nome)
	dados["nomes"] = nomes
	for n: Node in get_tree().get_nodes_in_group("player"):
		var p: Player = n as Player
		if p == null or not is_instance_valid(p):
			continue
		var id_p: int = 1 if not p.remoto else _id_do_remoto(p)
		dados["jogadores"].append({
			"id": id_p,
			"x": p.global_position.x,
			"y": p.global_position.y,
			"vida": p.vida,
			"max": p.vida_maxima,
			"vivo": p.vivo,
			"nick": p.nome_exibicao if p.nome_exibicao != "" else "JOGADOR",
			"ping": 0 if id_p == 1 else int(_pings.get(id_p, 0)),
		})
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		var e: Enemy = n as Enemy
		if e == null or not is_instance_valid(e) or e.morto or e.id_rede == 0:
			continue
		dados["inimigos"].append({
			"id": e.id_rede,
			"dados": e.dados.id if e.dados != null else "",
			"x": e.global_position.x,
			"y": e.global_position.y,
			"vida": e.vida,
			"max": e.vida_max,
			"escala": e.escala_visual,
			"comum": e.como_comum,
		})
	for n: Node in get_tree().get_nodes_in_group("guardioes_final"):
		var g: Enemy = n as Enemy
		if g == null or not is_instance_valid(g) or g.morto:
			continue
		dados["guardioes"].append({
			"x": g.global_position.x,
			"y": g.global_position.y,
			"vida": g.vida,
			"max": g.vida_max,
		})
	for n: Node in get_tree().get_nodes_in_group("projeteis_inimigos"):
		var proj: Node2D = n as Node2D
		if proj == null or not is_instance_valid(proj):
			continue
		dados["projeteis"].append({"x": proj.global_position.x, "y": proj.global_position.y})
	_rpc_snapshot.rpc(dados)


func _id_do_remoto(p: Player) -> int:
	for id: int in _remotos.keys():
		if _remotos[id] == p:
			return id
	return 0


# ------------------------------------------------------------------ cliente
func _enviar_entrada() -> void:
	if _jogador_local == null or not is_instance_valid(_jogador_local):
		return
	var dir: Vector2 = _jogador_local.entrada_local()
	var mira: Vector2 = _jogador_local.mira_local()
	_rpc_entrada.rpc_id(1, dir, mira,
		_jogador_local.segurando_tiro(),
		_jogador_local.consumir_secundario_mobile(),
		_jogador_local.consumir_dash_mobile())
	_ping_timer -= INTERVALO_ENTRADA
	if _ping_timer <= 0.0:
		_ping_timer = INTERVALO_PING
		_rpc_pedir_ping.rpc_id(1, Time.get_ticks_msec())
		# Reporta a última medição para o host montar a lista do TAB.
		_rpc_reportar_ping.rpc_id(1, ping_ms)


@rpc("any_peer", "reliable")
func _rpc_handshake(versao: String, nome: String) -> void:
	## Primeiro pacote do cliente: versão + apelido. Só depois disso a entrada
	## é liberada (e o estado antigo do jogador é devolvido, se existir).
	if modo != "host":
		return
	var id: int = multiplayer.get_remote_sender_id()
	if id == 0:
		return
	if versao != VERSAO_REDE:
		_recusar(id, "VERSÃO INCOMPATÍVEL (sala %s / você %s)" % [VERSAO_REDE, versao])
		return
	if multiplayer.get_peers().size() > MAX_CLIENTES:
		_recusar(id, "SALA CHEIA (%d/%d) — TENTE OUTRA SALA" % [total_jogadores(), MAX_CLIENTES + 1])
		return
	var limpo: String = nome.strip_edges().substr(0, 16).to_upper()
	if limpo == "":
		limpo = "JOGADOR"
	_nicks[id] = limpo
	var p: Player = _remotos.get(id) as Player
	if p != null and is_instance_valid(p):
		p.definir_nick(limpo)
	_rpc_handshake_resultado.rpc_id(id, true, "")
	_tentar_restaurar(id)


func _tentar_restaurar(id: int) -> void:
	if _jogo == null or not is_instance_valid(_jogo) or not _jogo.has_method("restaurar_jogador_remoto"):
		return
	var nome: String = nick_de(id)
	if nome == "" or not _estados.has(nome):
		return
	var estado: Dictionary = _estados[nome] as Dictionary
	_estados.erase(nome)
	_jogo.call("restaurar_jogador_remoto", id, estado)


@rpc("authority", "reliable")
func _rpc_handshake_resultado(aceito: bool, motivo: String) -> void:
	_aguardando_handshake = false
	if aceito:
		conectado.emit()
		return
	conexao_falhou.emit(motivo)
	sair()


func _recusar(id: int, motivo: String) -> void:
	_rpc_handshake_resultado.rpc_id(id, false, motivo)
	_aguardar_e_expulsar(id)


func _aguardar_e_expulsar(id: int) -> void:
	## Dá tempo do pacote de recusa chegar antes de fechar a conexão.
	await get_tree().create_timer(0.7).timeout
	if modo != "host" or _peer == null:
		return
	_peer.disconnect_peer(id)


@rpc("any_peer", "unreliable")
func _rpc_reportar_ping(ms: int) -> void:
	if modo != "host":
		return
	var id: int = multiplayer.get_remote_sender_id()
	if id != 0:
		_pings[id] = clampi(ms, 0, 999)


@rpc("any_peer", "reliable")
func _rpc_informar_nick(nome: String) -> void:
	if modo != "host":
		return
	var id: int = multiplayer.get_remote_sender_id()
	var limpo: String = nome.strip_edges().substr(0, 16).to_upper()
	if limpo == "":
		limpo = "JOGADOR"
	_nicks[id] = limpo
	var p: Player = _remotos.get(id) as Player
	if p != null and is_instance_valid(p):
		p.definir_nick(limpo)


@rpc("any_peer", "unreliable_ordered")
func _rpc_entrada(dir: Vector2, mira: Vector2, atirando: bool, secundario: bool, dash: bool) -> void:
	if modo != "host":
		return
	var id: int = multiplayer.get_remote_sender_id()
	var p: Player = _remotos.get(id) as Player
	if p == null or not is_instance_valid(p) or not p.vivo:
		return
	p.entrada_externa = dir.limit_length(1.0)
	p.mira_externa = mira
	if atirando and p._cooldown_tiro <= 0.0:
		p._tentar_atirar()
	if secundario:
		p._usar_secundario()
	if dash:
		p._tentar_dash()


@rpc("any_peer", "unreliable_ordered")
func _rpc_pedir_ping(instante: int) -> void:
	if modo != "host":
		return
	_rpc_pong.rpc_id(multiplayer.get_remote_sender_id(), instante)


@rpc("authority", "unreliable")
func _rpc_pong(instante: int) -> void:
	ping_ms = clampi(Time.get_ticks_msec() - instante, 0, 999)


@rpc("authority", "unreliable_ordered")
func _rpc_snapshot(dados: Dictionary) -> void:
	if modo != "client":
		return
	var nomes: Variant = dados.get("nomes", null)
	if nomes is Dictionary:
		_nicks = (nomes as Dictionary).duplicate()
	snapshot.emit(dados)
