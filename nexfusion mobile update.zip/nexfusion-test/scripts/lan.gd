extends Control
## Multiplayer LAN: o host abre a sala e os demais entram pela TABELA de salas
## abertas na rede (ou digitando o IP). A tela é rolável e usa alvos grandes,
## então funciona igual no computador e no celular.

const MARGEM_TELA: int = 22

var _campo_nick: LineEdit
var _campo_ip: LineEdit
var _campo_porta: SpinBox
var _status: Label
var _tabela: GridContainer
var _aviso_vazio: Label
var _janela_ip: PanelContainer = null
var _label_ip: Label = null
var _b_atualizar: Button
var _botoes: Array[Button] = []
var _conectando: bool = false
var _procurando: bool = false
var _timer: Timer


func _ready() -> void:
	GlobalManager.definir_cursor(true)
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var fundo: ColorRect = ColorRect.new()
	fundo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fundo.color = Color(0.03, 0.045, 0.07)
	add_child(fundo)

	var margem: MarginContainer = MarginContainer.new()
	margem.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for lado: String in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		margem.add_theme_constant_override(lado, MARGEM_TELA)
	add_child(margem)
	var rolagem: ScrollContainer = ScrollContainer.new()
	rolagem.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	rolagem.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	margem.add_child(rolagem)
	var centro: VBoxContainer = VBoxContainer.new()
	centro.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	centro.add_theme_constant_override("separation", 6)
	rolagem.add_child(centro)

	centro.add_child(UI.titulo("MULTIPLAYER LAN", 36, UI.COR_VERDE))
	var sub: Label = UI.rotulo("Até 4 jogadores na mesma rede — computadores e celulares podem jogar juntos.", 13, UI.COR_TEXTO_FRACO)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	centro.add_child(sub)
	# A2.4: o IP fica escondido até o host pedir (botão MOSTRAR IP).
	var linha_mostrar_ip: HBoxContainer = HBoxContainer.new()
	linha_mostrar_ip.alignment = BoxContainer.ALIGNMENT_CENTER
	linha_mostrar_ip.add_theme_constant_override("separation", 8)
	centro.add_child(linha_mostrar_ip)
	var b_mostrar_ip: Button = UI.botao("MOSTRAR IP E PORTA", 13, UI.COR_CIANO)
	b_mostrar_ip.custom_minimum_size = Vector2(250, 38)
	b_mostrar_ip.pressed.connect(_alternar_janela_ip)
	linha_mostrar_ip.add_child(b_mostrar_ip)

	# ---------------------------------------------------------------- apelido
	var linha_nick: HBoxContainer = HBoxContainer.new()
	linha_nick.alignment = BoxContainer.ALIGNMENT_CENTER
	linha_nick.add_theme_constant_override("separation", 8)
	centro.add_child(linha_nick)
	linha_nick.add_child(UI.rotulo("Seu apelido:", 15, UI.COR_TEXTO))
	_campo_nick = LineEdit.new()
	_campo_nick.text = GlobalManager.nick
	_campo_nick.max_length = 16
	_campo_nick.custom_minimum_size = Vector2(240, 44)
	_campo_nick.add_theme_font_size_override("font_size", 16)
	_campo_nick.text_submitted.connect(_ao_nick)
	_campo_nick.focus_exited.connect(func() -> void: _ao_nick(_campo_nick.text))
	linha_nick.add_child(_campo_nick)

	# ---------------------------------------------------------------- tabela
	var cabecalho: Label = UI.rotulo("SALAS ABERTAS NA REDE", 15, UI.COR_AMBAR)
	centro.add_child(cabecalho)
	var painel: PanelContainer = PanelContainer.new()
	painel.add_theme_stylebox_override("panel", UI.estilo_painel())
	centro.add_child(painel)
	var caixa: VBoxContainer = VBoxContainer.new()
	caixa.add_theme_constant_override("separation", 6)
	painel.add_child(caixa)
	_tabela = GridContainer.new()
	_tabela.columns = 3
	_tabela.add_theme_constant_override("h_separation", 14)
	_tabela.add_theme_constant_override("v_separation", 6)
	_tabela.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	caixa.add_child(_tabela)
	_aviso_vazio = UI.rotulo("Nenhuma sala encontrada ainda. Toque em ATUALIZAR LISTA.", 13, UI.COR_TEXTO_FRACO)
	_aviso_vazio.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	caixa.add_child(_aviso_vazio)
	_atualizar_tabela()

	_b_atualizar = UI.botao("ATUALIZAR LISTA", 18, UI.COR_CIANO)
	_b_atualizar.custom_minimum_size = Vector2(360, 42)
	_b_atualizar.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_b_atualizar.pressed.connect(_atualizar)
	centro.add_child(_b_atualizar)
	_botoes.append(_b_atualizar)

	# ---------------------------------------------------------------- criar / entrar (duas colunas)
	var colunas: HBoxContainer = HBoxContainer.new()
	colunas.alignment = BoxContainer.ALIGNMENT_CENTER
	colunas.add_theme_constant_override("separation", 14)
	centro.add_child(colunas)

	var painel_host: PanelContainer = PanelContainer.new()
	painel_host.add_theme_stylebox_override("panel", UI.estilo_painel())
	painel_host.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	colunas.add_child(painel_host)
	var caixa_host: VBoxContainer = VBoxContainer.new()
	caixa_host.add_theme_constant_override("separation", 6)
	painel_host.add_child(caixa_host)
	caixa_host.add_child(UI.rotulo("CRIAR SALA (HOST)", 13, UI.COR_CIANO))
	var linha_porta: HBoxContainer = HBoxContainer.new()
	linha_porta.add_theme_constant_override("separation", 8)
	caixa_host.add_child(linha_porta)
	linha_porta.add_child(UI.rotulo("Porta da sala:", 14, UI.COR_TEXTO))
	_campo_porta = SpinBox.new()
	_campo_porta.min_value = 1024
	_campo_porta.max_value = 65535
	_campo_porta.value = float(NetworkManager.PORTA_PADRAO)
	_campo_porta.custom_minimum_size = Vector2(140, 42)
	linha_porta.add_child(_campo_porta)
	var b_host: Button = UI.botao("ABRIR SALA", 18, UI.COR_CIANO)
	b_host.custom_minimum_size = Vector2(0, 46)
	b_host.pressed.connect(_ao_criar)
	caixa_host.add_child(b_host)
	_botoes.append(b_host)
	var dica_host: Label = UI.rotulo("Quem abre a sala simula o mundo.", 12, UI.COR_TEXTO_FRACO)
	dica_host.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	caixa_host.add_child(dica_host)

	var painel_entrar: PanelContainer = PanelContainer.new()
	painel_entrar.add_theme_stylebox_override("panel", UI.estilo_painel())
	painel_entrar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	colunas.add_child(painel_entrar)
	var caixa_entrar: VBoxContainer = VBoxContainer.new()
	caixa_entrar.add_theme_constant_override("separation", 6)
	painel_entrar.add_child(caixa_entrar)
	caixa_entrar.add_child(UI.rotulo("ENTRAR POR IP", 13, UI.COR_VERDE))
	var linha_ip: HBoxContainer = HBoxContainer.new()
	linha_ip.add_theme_constant_override("separation", 8)
	caixa_entrar.add_child(linha_ip)
	_campo_ip = LineEdit.new()
	_campo_ip.placeholder_text = "IP do host (vazio = buscar)"
	_campo_ip.text = NetworkManager.ip if NetworkManager.ip != "127.0.0.1" else ""
	_campo_ip.max_length = 64
	_campo_ip.custom_minimum_size = Vector2(0, 42)
	_campo_ip.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_campo_ip.add_theme_font_size_override("font_size", 15)
	linha_ip.add_child(_campo_ip)
	var b_local: Button = UI.botao("LOCAL", 12, UI.COR_TEXTO_FRACO)
	b_local.custom_minimum_size = Vector2(90, 42)
	b_local.pressed.connect(func() -> void: _campo_ip.text = "127.0.0.1")
	linha_ip.add_child(b_local)
	var b_entrar_ip: Button = UI.botao("CONECTAR", 18, UI.COR_VERDE)
	b_entrar_ip.custom_minimum_size = Vector2(0, 46)
	b_entrar_ip.pressed.connect(_ao_entrar_ip)
	caixa_entrar.add_child(b_entrar_ip)
	_botoes.append(b_entrar_ip)
	var dica_entrar: Label = UI.rotulo("Sem IP: a busca automática usa a tabela acima.", 12, UI.COR_TEXTO_FRACO)
	dica_entrar.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	caixa_entrar.add_child(dica_entrar)

	var b_voltar: Button = UI.botao("VOLTAR", 18, UI.COR_TEXTO_FRACO)
	b_voltar.custom_minimum_size = Vector2(360, 42)
	b_voltar.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	b_voltar.pressed.connect(func() -> void:
		NetworkManager.sair()
		get_tree().change_scene_to_file("res://scenes/menu.tscn"))
	centro.add_child(b_voltar)
	_botoes.append(b_voltar)

	_status = UI.rotulo("", 14, UI.COR_AMBAR)
	_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	centro.add_child(_status)
	var limite: Label = UI.rotulo("Dica: todos precisam estar no mesmo Wi-Fi/roteador e com o firewall liberado.", 12, UI.COR_TEXTO_FRACO)
	limite.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	limite.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	centro.add_child(limite)

	NetworkManager.conexao_falhou.connect(_ao_falha)
	NetworkManager.host_encontrado.connect(_ao_host_encontrado)
	NetworkManager.busca_encerrada.connect(_ao_busca_encerrada)
	NetworkManager.servidor_encontrado.connect(_ao_servidor_encontrado)
	NetworkManager.lista_servidores_atualizada.connect(_ao_lista_atualizada)
	AudioManager.tocar_bgm("menu")

	# Atualiza sozinho a tabela para refletir salas que abriram/fecharam.
	_timer = Timer.new()
	_timer.wait_time = 8.0
	_timer.autostart = true
	_timer.timeout.connect(func() -> void: _atualizar(true))
	add_child(_timer)
	_construir_janela_ip()
	_atualizar()


func _construir_janela_ip() -> void:
	## A2.4: janelinha com IP + porta, aberta só quando o host pede.
	_janela_ip = PanelContainer.new()
	_janela_ip.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.05, 0.08, 0.12, 0.97), UI.COR_CIANO, 8))
	_janela_ip.set_anchors_and_offsets_preset(Control.PRESET_CENTER, Control.PRESET_MODE_MINSIZE, 0)
	_janela_ip.custom_minimum_size = Vector2(420, 0)
	_janela_ip.visible = false
	_janela_ip.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_janela_ip)
	var vb: VBoxContainer = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 8)
	_janela_ip.add_child(vb)
	var titulo: Label = UI.rotulo("ENDEREÇO DA SALA", 16, UI.COR_CIANO)
	titulo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(titulo)
	_label_ip = UI.rotulo("", 22, UI.COR_TEXTO)
	_label_ip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_label_ip)
	var linha: HBoxContainer = HBoxContainer.new()
	linha.alignment = BoxContainer.ALIGNMENT_CENTER
	linha.add_theme_constant_override("separation", 10)
	vb.add_child(linha)
	var b_copiar: Button = UI.botao("COPIAR", 16, UI.COR_VERDE)
	b_copiar.custom_minimum_size = Vector2(150, 42)
	b_copiar.pressed.connect(_copiar_ip)
	linha.add_child(b_copiar)
	var b_fechar: Button = UI.botao("FECHAR", 16, UI.COR_TEXTO_FRACO)
	b_fechar.custom_minimum_size = Vector2(150, 42)
	b_fechar.pressed.connect(func() -> void: _janela_ip.visible = false)
	linha.add_child(b_fechar)
	var dica: Label = UI.rotulo("Quem entra pela tabela não precisa do IP. Use isto só para conexão direta.", 11, UI.COR_TEXTO_FRACO)
	dica.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	dica.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(dica)


func _alternar_janela_ip() -> void:
	if _janela_ip == null:
		return
	_janela_ip.visible = not _janela_ip.visible
	if not _janela_ip.visible:
		return
	var ip: String = NetworkManager.ip_local()
	var porta_sala: int = int(_campo_porta.value)
	_label_ip.text = "%s:%d" % [ip, porta_sala]
	_status.text = "Mostrando o endereço da sua sala." if ip != "127.0.0.1" else "Sem rede local detectada (só este computador)."


func _copiar_ip() -> void:
	if _label_ip == null:
		return
	DisplayServer.clipboard_set(_label_ip.text)
	_status.text = "Endereço copiado: %s" % _label_ip.text


# ------------------------------------------------------------------ tabela
func _celula(texto: String, tamanho: int, cor: Color, largura: float) -> Label:
	var l: Label = UI.rotulo(texto, tamanho, cor)
	l.custom_minimum_size = Vector2(largura, 0)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	return l


func _construir_cabecalho() -> void:
	# A2.4: a tabela mostra só nome da sala e vagas — nunca o IP.
	_tabela.add_child(_celula("SALA", 12, UI.COR_TEXTO_FRACO, 380))
	_tabela.add_child(_celula("JOGADORES", 12, UI.COR_TEXTO_FRACO, 160))
	_tabela.add_child(_celula("", 12, UI.COR_TEXTO_FRACO, 150))


func _atualizar_tabela() -> void:
	for filho: Node in _tabela.get_children():
		_tabela.remove_child(filho)
		filho.queue_free()
	_construir_cabecalho()
	var lista: Array = NetworkManager.servidores
	_aviso_vazio.visible = lista.is_empty()
	for dado: Dictionary in lista:
		var ip: String = String(dado["ip"])
		var porta_sala: int = int(dado["porta"])
		var nome: Label = _celula("SALA DE %s" % String(dado["nick"]).to_upper(), 14, UI.COR_TEXTO, 380)
		nome.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		nome.clip_text = true
		_tabela.add_child(nome)
		var qtd: String = "%d/%d" % [int(dado["jogadores"]), int(dado["maximo"])]
		_tabela.add_child(_celula(qtd, 14, UI.COR_AMBAR, 160))
		var compativel: bool = bool(dado.get("compativel", true))
		var entrar: Button = UI.botao("ENTRAR" if compativel else "VERSÃO", 14, UI.COR_VERDE if compativel else UI.COR_VERMELHO)
		entrar.custom_minimum_size = Vector2(150, 42)
		entrar.disabled = not compativel
		entrar.tooltip_text = "" if compativel else "Sala em outra versão do jogo (host %s)." % String(dado.get("versao", "?"))
		entrar.pressed.connect(_conectar.bind(ip, porta_sala))
		_tabela.add_child(entrar)


func _ao_servidor_encontrado(_dados: Dictionary) -> void:
	_atualizar_tabela()


func _ao_lista_atualizada(_lista: Array) -> void:
	_atualizar_tabela()


# ------------------------------------------------------------------ busca
func _atualizar(_silencioso: bool = false) -> void:
	if _conectando or _procurando:
		return
	_procurando = true
	_b_atualizar.disabled = true
	_status.text = "Procurando salas abertas na rede..."
	_atualizar_tabela()
	if not NetworkManager.listar_servidores(int(_campo_porta.value), 2.5):
		_procurando = false
		_b_atualizar.disabled = false
		_status.text = "Não foi possível iniciar a busca na rede."


func _ao_busca_encerrada() -> void:
	_procurando = false
	_b_atualizar.disabled = false
	_atualizar_tabela()
	if _conectando:
		return
	if NetworkManager.servidores.is_empty():
		_status.text = "Nenhuma sala aberta. Verifique o Wi-Fi/roteador e o firewall."
	else:
		_status.text = "%d sala(s) aberta(s). Toque em ENTRAR para jogar." % NetworkManager.servidores.size()


func _ao_host_encontrado(endereco: String, porta_host: int) -> void:
	_conectar(endereco, porta_host)


# ------------------------------------------------------------------ ações
func _ao_nick(texto: String) -> void:
	GlobalManager.definir_nick(texto)
	_campo_nick.text = GlobalManager.nick


func _ao_criar() -> void:
	_ao_nick(_campo_nick.text)
	_travar("Abrindo sala...")
	if NetworkManager.criar_sala(int(_campo_porta.value)):
		GlobalManager.horda_skip_alvo = 1
		get_tree().change_scene_to_file("res://scenes/jogo.tscn")
	else:
		_destravar()


func _ao_entrar_ip() -> void:
	var endereco: String = _campo_ip.text.strip_edges()
	if endereco == "":
		_atualizar()
		return
	_conectar(endereco, int(_campo_porta.value))


func _conectar(endereco: String, porta_alvo: int) -> void:
	if _conectando:
		return
	_ao_nick(_campo_nick.text)
	_conectando = true
	_travar("Conectando a %s:%d..." % [endereco, porta_alvo])
	NetworkManager.conectado.connect(_ao_conectado, CONNECT_ONE_SHOT)
	if not NetworkManager.entrar_sala(endereco, porta_alvo):
		_conectando = false
		_destravar()


func _ao_conectado() -> void:
	GlobalManager.horda_skip_alvo = 1
	get_tree().change_scene_to_file("res://scenes/jogo.tscn")


func _ao_falha(texto: String) -> void:
	_status.text = texto
	_conectando = false
	_procurando = false
	_destravar()


func _travar(texto: String) -> void:
	_status.text = texto
	_b_atualizar.disabled = true
	for b: Button in _botoes:
		b.disabled = true


func _destravar() -> void:
	_b_atualizar.disabled = false
	for b: Button in _botoes:
		b.disabled = false
