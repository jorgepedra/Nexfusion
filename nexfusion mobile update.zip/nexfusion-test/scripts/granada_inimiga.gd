class_name GranadaInimiga
extends Area2D
## Granada química com arco parabólico 2D, sombra no chão, pavio com raio de
## aviso e rebatida via Parry (explode no primeiro inimigo que tocar).

const CENA_EXPLOSAO: String = "res://scenes/explosao.tscn"
const TEMPO_VOO: float = 0.72
const TEMPO_PAVIO: float = 1.2

var raio_explosao: float = 78.0
var dano: float = 16.0
var refletida: bool = false
var _origem: Vector2 = Vector2.ZERO
var _alvo: Vector2 = Vector2.ZERO
var _t: float = 0.0
var _fase: String = "voo"
var _pavio: float = TEMPO_PAVIO
var _direcao: Vector2 = Vector2.ZERO
var _dono: Node = null
var _sprite: Sprite2D
var _sombra: Sprite2D
var _cena_explosao: PackedScene = null
var _explodiu: bool = false


func _ready() -> void:
	add_to_group("granadas")
	collision_layer = 16
	collision_mask = 4
	z_index = 24
	var forma: CollisionShape2D = CollisionShape2D.new()
	var circle: CircleShape2D = CircleShape2D.new()
	circle.radius = 10.0
	forma.shape = circle
	add_child(forma)
	var tex: Texture2D = null
	if ResourceLoader.exists("res://sprites/props/granada.png"):
		tex = load("res://sprites/props/granada.png") as Texture2D
	_sombra = Sprite2D.new()
	_sombra.texture = tex
	_sombra.modulate = Color(0, 0, 0, 0.45)
	_sombra.scale = Vector2(1.6, 1.0)
	_sombra.z_index = -2
	add_child(_sombra)
	_sprite = Sprite2D.new()
	_sprite.texture = tex
	_sprite.scale = Vector2(1.8, 1.8)
	_sprite.z_index = 1
	add_child(_sprite)
	if ResourceLoader.exists(CENA_EXPLOSAO):
		_cena_explosao = load(CENA_EXPLOSAO) as PackedScene


func configurar(origem: Vector2, alvo: Vector2, raio: float, dano_granada: float, dono: Node = null) -> void:
	_origem = origem
	_alvo = alvo
	raio_explosao = raio
	dano = dano_granada
	_dono = dono
	global_position = origem
	_t = 0.0


func _physics_process(delta: float) -> void:
	if _explodiu:
		return
	_t += delta
	if refletida:
		_processar_refletida(delta)
		return
	if _fase == "voo":
		var p: float = clampf(_t / TEMPO_VOO, 0.0, 1.0)
		global_position = _origem.lerp(_alvo, p)
		var altura: float = sin(p * PI) * 92.0
		if _sprite != null:
			_sprite.position = Vector2(0.0, -altura)
			var escala: float = 1.8 + sin(p * PI) * 0.44
			_sprite.scale = Vector2(escala, escala)
			_sprite.rotation += delta * 6.0
		if _sombra != null:
			_sombra.scale = Vector2(1.6 - sin(p * PI) * 0.5, 1.0 - sin(p * PI) * 0.3)
		if p >= 1.0:
			_fase = "pavio"
			_pavio = TEMPO_PAVIO
			if _sprite != null:
				_sprite.position = Vector2.ZERO
				_sprite.scale = Vector2(1.8, 1.8)
			AudioManager.tocar_sfx("perigo", -16.0, 0.08)
		queue_redraw()
		return
	# pavio
	_pavio -= delta
	if _sprite != null:
		_sprite.position.y = sin(_t * 18.0) * 1.5
		_sprite.modulate = Color(1.0, 1.0, 1.0) if fmod(_t, 0.18) < 0.09 else Color(1.6, 0.6, 0.6)
	queue_redraw()
	if _pavio <= 0.0:
		_explodir()


func _processar_refletida(delta: float) -> void:
	global_position += _direcao * 980.0 * delta
	if _sprite != null:
		_sprite.rotation += delta * 16.0
		_sprite.modulate = Color(0.6, 1.0, 1.0)
	var espaco: PhysicsDirectSpaceState2D = get_world_2d().direct_space_state
	if espaco != null:
		var q: PhysicsRayQueryParameters2D = PhysicsRayQueryParameters2D.create(global_position, global_position + _direcao * 26.0)
		q.collision_mask = 2 | 4
		q.collide_with_areas = false
		var res: Dictionary = espaco.intersect_ray(q)
		if not res.is_empty():
			_explodir()
			return
	_t += delta
	if _t > 3.0:
		_explodir()


func rebater(nova_direcao: Vector2) -> void:
	if _explodiu:
		return
	refletida = true
	_fase = "refletida"
	_direcao = nova_direcao.normalized()
	if _direcao.length() < 0.1:
		_direcao = Vector2.RIGHT
	dano *= 3.0
	raio_explosao *= 1.2
	z_index = 26
	Efeitos.anel(get_parent(), global_position, 46.0, Color(0.56, 0.95, 1.0, 0.9), 0.25, 3.0)
	AudioManager.tocar_sfx("parry", -2.0, 0.04)
	if _sombra != null:
		_sombra.visible = false


func _explodir() -> void:
	if _explodiu:
		return
	_explodiu = true
	if _cena_explosao != null:
		var ex: Explosao = _cena_explosao.instantiate() as Explosao
		if ex != null:
			get_parent().add_child(ex)
			ex.global_position = global_position
			ex.configurar(raio_explosao, dano, true, Color("ff8a4a") if not refletida else Color("8ff3ff"))
	queue_free()


func _draw() -> void:
	if _fase == "pavio" and not refletida:
		var pulso: float = 0.55 + absf(sin(_t * 8.0)) * 0.45
		draw_circle(Vector2.ZERO, raio_explosao, Color(1.0, 0.25, 0.2, 0.10 * pulso))
		draw_arc(Vector2.ZERO, raio_explosao * pulso, 0.0, TAU, 40, Color(1.0, 0.3, 0.25, 0.65), 2.0, true)
