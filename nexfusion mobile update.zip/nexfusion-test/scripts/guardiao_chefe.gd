extends Enemy
## Guardião de contenção do chefe final: estátua fixa num canto da arena.
## Não pertence ao enxame comum ("inimigos") e não se move: atira orbes lentos.
## Destruir os quatro quebra a proteção do ELEMENTO SUPREMO.

var _giro: float = 0.0


func _ready() -> void:
	super._ready()
	# Fora do grupo comum: não conta como inimigo do jogo, não entra na música
	# de combate nem no spawner de hordas.
	remove_from_group("inimigos")
	add_to_group("guardioes_final")
	z_index = 9
	collision_layer = 2
	collision_mask = 0
	_tiro_timer = randf_range(1.2, 2.4)


func _physics_process(delta: float) -> void:
	if morto or autoridade_remota:
		return
	_tempo += delta
	_giro += delta
	invulneravel = maxf(0.0, invulneravel - delta)
	queue_redraw()
	jogador = _jogador_mais_proximo()
	if jogador == null or not jogador.vivo:
		return
	_tiro_timer -= delta
	if _tiro_timer <= 0.0:
		_tiro_timer = 2.5
		_disparar()


func _disparar() -> void:
	if _cena_projetil == null or jogador == null:
		return
	var base: Vector2 = (jogador.global_position - global_position).normalized()
	for i: int in range(3):
		var dir: Vector2 = base.rotated(deg_to_rad(-12.0 + 12.0 * float(i)))
		var p: Projetil = _cena_projetil.instantiate() as Projetil
		if p == null:
			continue
		get_parent().add_child(p)
		p.global_position = global_position + dir * (raio + 8.0)
		p.configurar({
			"amigavel": false,
			"direcao": dir,
			"dano": 8.0,
			"velocidade": 260.0,
			"cor": Color("8ff3ff"),
			"tamanho": 1.1,
			"alcance": 1100.0,
		})
	AudioManager.tocar_sfx("tiro_pesado", -10.0, 0.08)


func _morrer() -> void:
	if morto:
		return
	morto = true
	collision_layer = 0
	collision_mask = 0
	Efeitos.tremor(6.0)
	Efeitos.particulas(get_parent(), global_position, Color("8ff3ff"), 18, 260.0, 0.7, 3.0, "plasma")
	Efeitos.anel(get_parent(), global_position, 130.0, Color(0.55, 0.95, 1.0, 0.85), 0.6, 4.0)
	AudioManager.tocar_sfx("explosao", -8.0, 0.06)
	morreu.emit(self)
	queue_free()


func _draw() -> void:
	super._draw()
	if morto:
		return
	var pulso: float = sin(_giro * 2.6) * 4.0
	draw_arc(Vector2.ZERO, 34.0 + pulso, 0.0, TAU, 32, Color(0.45, 0.9, 1.0, 0.35), 2.0, true)
	draw_arc(Vector2.ZERO, 26.0 - pulso, 0.0, TAU, 28, Color(0.7, 0.95, 1.0, 0.22), 1.0, true)
