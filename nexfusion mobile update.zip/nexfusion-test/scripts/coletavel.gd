class_name Coletavel
extends Area2D
## Moeda, elétron (XP) ou isótopo de cura. Atraído magneticamente pelo jogador.

var tipo: String = "moeda"
var valor: int = 1
var jogador: Player = null
var _sprite: Sprite2D
var _tempo: float = 0.0
var _fase: float = 0.0
var _velocidade: float = 0.0
var _coletado: bool = false
var _escala_base: float = 2.0


func _ready() -> void:
	add_to_group("coletaveis")
	collision_layer = 32
	collision_mask = 0
	z_index = 12
	_fase = randf() * TAU
	var forma: CollisionShape2D = CollisionShape2D.new()
	var circle: CircleShape2D = CircleShape2D.new()
	circle.radius = 10.0
	forma.shape = circle
	add_child(forma)
	_sprite = Sprite2D.new()
	add_child(_sprite)
	_atualizar_visual()
	_tempo = randf() * 0.4


func configurar(tipo_coletavel: String, valor_coletavel: int) -> void:
	tipo = tipo_coletavel
	valor = valor_coletavel
	if _sprite != null:
		_atualizar_visual()


func _atualizar_visual() -> void:
	var caminho: String = "res://sprites/props/moeda.png"
	match tipo:
		"xp":
			caminho = "res://sprites/props/eletron.png"
			_escala_base = 1.7
		"isotopo":
			caminho = "res://sprites/props/isotopo.png"
			_escala_base = 2.0
		_:
			caminho = "res://sprites/props/moeda.png"
			_escala_base = 2.0
	if ResourceLoader.exists(caminho):
		_sprite.texture = load(caminho) as Texture2D
	_sprite.scale = Vector2.ONE * _escala_base


func _physics_process(delta: float) -> void:
	if _coletado:
		return
	_tempo += delta
	if jogador == null or not is_instance_valid(jogador):
		var lista: Array[Node] = get_tree().get_nodes_in_group("player")
		if not lista.is_empty():
			jogador = lista[0] as Player
	if jogador == null:
		return
	if not jogador.vivo:
		return
	var dist: float = global_position.distance_to(jogador.global_position)
	if _velocidade > 0.0 or dist <= jogador.raio_magnetismo:
		_velocidade = minf(_velocidade + 1400.0 * delta, 900.0)
		var dir: Vector2 = (jogador.global_position - global_position).normalized()
		global_position += dir * _velocidade * delta
		if _sprite != null:
			_sprite.scale = Vector2.ONE * _escala_base * (1.0 + _velocidade / 2600.0)
		if dist <= 20.0:
			_coletar()
		return
	if _sprite != null:
		_sprite.position.y = sin(_tempo * 4.0 + _fase) * 3.0
		_sprite.rotation = sin(_tempo * 2.0 + _fase) * 0.12


func _coletar() -> void:
	if _coletado or jogador == null:
		return
	_coletado = true
	match tipo:
		"xp":
			GlobalManager.adicionar_xp(valor)
			GlobalManager.registrar_estilo("ELÉTRON", 1.0, Color("59d8ff"))
		"isotopo":
			jogador.curar(float(valor) + jogador.cura_extra)
			AudioManager.tocar_sfx("cura", -12.0, 0.1)
			Efeitos.particulas(get_parent(), global_position, Color("ff5f92"), 5, 120.0, 0.3, 2.0)
		_:
			GlobalManager.adicionar_moedas_partida(valor)
			AudioManager.tocar_sfx("moeda", -16.0, 0.15)
			GlobalManager.registrar_estilo("MOEDA", 0.5, Color("ffcf4a"))
	queue_free()
