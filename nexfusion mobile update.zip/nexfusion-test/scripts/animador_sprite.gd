class_name AnimadorSprite
extends Node
## Anima um Sprite2D a partir de uma folha 4x4 gerada pelo tools/gerar_sprites.gd.
## Linhas: 0 idle, 1 andar, 2 ataque, 3 dano. Colunas: quadros.

const COLUNAS: int = 4
const LINHAS: int = 4
const FPS_ANIMACAO := {
	"idle": 6.0,
	"andar": 12.0,
	"ataque": 18.0,
	"dano": 10.0,
}
const DURACAO := {
	"ataque": 0.30,
	"dano": 0.24,
}

var sprite: Sprite2D
var _folha: Texture2D = null
var _linha: int = 0
var _coluna: int = 0
var _tempo: float = 0.0
var _estado: String = "idle"
var _trava: float = 0.0
var _movendo: bool = false
var _pos_base: Vector2 = Vector2.ZERO
var _tempo_estado: float = 0.0
var _ultimo_frame: int = -1


func configurar(textura_base: String) -> void:
	## Usa <base>_sheet.png; se não existir, mantém o sprite estático.
	if textura_base == "" or sprite == null:
		return
	var caminho: String = textura_base.get_basename() + "_sheet.png"
	if not ResourceLoader.exists(caminho):
		return
	var folha: Texture2D = load(caminho) as Texture2D
	if folha == null:
		return
	_folha = folha
	_pos_base = sprite.position
	_ultimo_frame = -1
	sprite.texture = folha
	sprite.hframes = COLUNAS
	sprite.vframes = LINHAS
	_linha = 0
	_coluna = 0
	_tempo = 0.0
	_estado = "idle"
	_trava = 0.0
	sprite.frame = 0
	set_process(true)


func definir_movendo(movendo: bool) -> void:
	_movendo = movendo


func tocar(estado: String) -> void:
	## Dispara uma animação curta (ataque/dano) que volta sozinha ao normal.
	if _folha == null:
		return
	if not ESTADOS.has(estado):
		return
	_estado = estado
	_trava = float(DURACAO.get(estado, 0.0))
	_tempo = 0.0
	_tempo_estado = 0.0
	_coluna = 0
	_linha = _linha_de(estado)
	_aplicar()


func textura_frame() -> Texture2D:
	## Quadro atual isolado (usado pelos rastros do dash).
	if _folha == null:
		return sprite.texture if sprite != null else null
	var largura: int = _folha.get_width() / COLUNAS
	var altura: int = _folha.get_height() / LINHAS
	var atlas: AtlasTexture = AtlasTexture.new()
	atlas.atlas = _folha
	atlas.region = Rect2(float(_coluna * largura), float(_linha * altura), float(largura), float(altura))
	return atlas


const ESTADOS: Array[String] = ["idle", "andar", "ataque", "dano"]


func _linha_de(estado: String) -> int:
	match estado:
		"andar":
			return 1
		"ataque":
			return 2
		"dano":
			return 3
		_:
			return 0


func _process(delta: float) -> void:
	if _folha == null or sprite == null:
		return
	if _trava > 0.0:
		_trava = maxf(0.0, _trava - delta)
	else:
		_estado = "andar" if _movendo else "idle"
	_linha = _linha_de(_estado)
	var fps: float = float(FPS_ANIMACAO.get(_estado, 6.0))
	_tempo += delta * fps
	_coluna = int(_tempo) % COLUNAS
	_tempo_estado += delta
	_aplicar()
	_animar_pose()


func _animar_pose() -> void:
	## Micro-animação por cima do quadro: respiração, passada, avanço e tremor.
	if sprite == null:
		return
	var destino: Vector2 = _pos_base
	match _estado:
		"idle":
			destino.y += sin(_tempo_estado * 2.4) * 1.2
		"andar":
			destino.y += -absf(sin(_tempo_estado * 9.0)) * 2.0
		"ataque":
			var p: float = clampf(_tempo_estado / maxf(0.01, float(DURACAO.get("ataque", 0.3))), 0.0, 1.0)
			destino.x += sin(p * PI) * 3.0
		"dano":
			destino.x += sin(_tempo_estado * 60.0) * 2.0
	sprite.position = destino


func _aplicar() -> void:
	if sprite == null:
		return
	var quadro: int = _linha * COLUNAS + _coluna
	if quadro == _ultimo_frame:
		return
	_ultimo_frame = quadro
	sprite.frame = quadro


func parar() -> void:
	set_process(false)
