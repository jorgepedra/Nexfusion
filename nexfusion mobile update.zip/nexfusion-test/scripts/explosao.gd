class_name Explosao
extends Area2D
## Explosão em área: dano único, visual expansivo, partículas e tremor.

var raio: float = 60.0
var dano: float = 10.0
var atinge_inimigos: bool = true
var atinge_jogador: bool = true
var cor: Color = Color("ff8a4a")
var _t: float = 0.0
var _duracao: float = 0.42
var _aplicado: bool = false


func _ready() -> void:
	z_index = 30
	collision_layer = 0
	collision_mask = 0
	monitoring = false
	var tw: Tween = create_tween()
	tw.tween_property(self, "modulate:a", 0.0, _duracao)


func configurar(raio_explosao: float, dano_explosao: float, amigavel: bool, cor_explosao: Color = Color("ff8a4a")) -> void:
	raio = raio_explosao
	dano = dano_explosao
	atinge_jogador = not amigavel
	atinge_inimigos = amigavel
	cor = cor_explosao


func _process(delta: float) -> void:
	_t += delta
	if not _aplicado and _t >= 0.025:
		_aplicar_dano()
	if _t >= _duracao:
		queue_free()
		return
	queue_redraw()


func _aplicar_dano() -> void:
	_aplicado = true
	Efeitos.tremor(minf(14.0, 5.0 + raio * 0.08))
	Efeitos.particulas(get_parent(), global_position, cor, int(raio * 0.28), raio * 4.5, 0.5, 3.0, "fogo")
	Efeitos.anel(get_parent(), global_position, raio * 1.15, Color(cor.r, cor.g, cor.b, 0.85), 0.36, 4.0)
	AudioManager.tocar_sfx("explosao", -4.0, 0.07)
	if atinge_inimigos:
		for grupo: String in ["inimigos", "guardioes_final"]:
			for n: Node in get_tree().get_nodes_in_group(grupo):
				var e: Enemy = n as Enemy
				if e == null or not is_instance_valid(e) or e.morto:
					continue
				if global_position.distance_to(e.global_position) <= raio + e.raio:
					e.receber_dano(dano, false)
	if atinge_jogador:
		var lista: Array[Node] = get_tree().get_nodes_in_group("player")
		if not lista.is_empty():
			var p: Player = lista[0] as Player
			if p != null and is_instance_valid(p) and p.vivo:
				if global_position.distance_to(p.global_position) <= raio + 10.0:
					p.receber_dano(dano)


func _draw() -> void:
	var p: float = clampf(_t / _duracao, 0.0, 1.0)
	var r: float = raio * (0.35 + p * 0.95)
	draw_circle(Vector2.ZERO, r, Color(cor.r, cor.g, cor.b, (1.0 - p) * 0.45))
	draw_circle(Vector2.ZERO, r * 0.62, Color(1.0, 0.95, 0.8, (1.0 - p) * 0.65))
	draw_arc(Vector2.ZERO, r, 0.0, TAU, 42, Color(1.0, 1.0, 1.0, (1.0 - p) * 0.85), 3.0, true)
