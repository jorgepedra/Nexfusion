class_name UI
extends RefCounted
## Fábrica de UI e paleta compartilhada (tema químico escuro + neon).

const COR_FUNDO: Color = Color("070a12")
const COR_PAINEL: Color = Color("0f1624")
const COR_PAINEL_CLARO: Color = Color("162033")
const COR_BORDA: Color = Color("28384f")
const COR_TEXTO: Color = Color("dfe9f7")
const COR_TEXTO_FRACO: Color = Color("8899b0")
const COR_CIANO: Color = Color("8ff3ff")
const COR_TEAL: Color = Color("2b8f95")
const COR_MAGENTA: Color = Color("ff5fd2")
const COR_AMBAR: Color = Color("ffcf4a")
const COR_VERDE: Color = Color("5fe08a")
const COR_VERMELHO: Color = Color("ff5f5f")
const COR_VIOLETA: Color = Color("a78bfa")


static func estilo_painel(cor: Color = COR_PAINEL, borda: Color = COR_BORDA, raio: int = 6) -> StyleBoxFlat:
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = cor
	sb.border_color = borda
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(raio)
	sb.content_margin_left = 10.0
	sb.content_margin_right = 10.0
	sb.content_margin_top = 6.0
	sb.content_margin_bottom = 6.0
	return sb


static func estilo_barra_fundo() -> StyleBoxFlat:
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = Color("0a111d")
	sb.border_color = Color("233045")
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(3)
	return sb


static func estilo_barra(cor: Color) -> StyleBoxFlat:
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = cor
	sb.set_corner_radius_all(2)
	return sb


static func aplicar_tema_botao(b: Button, cor: Color = COR_CIANO) -> void:
	b.add_theme_stylebox_override("normal", estilo_painel(COR_PAINEL_CLARO, COR_BORDA, 4))
	b.add_theme_stylebox_override("hover", estilo_painel(Color("1d2b42"), cor, 4))
	b.add_theme_stylebox_override("pressed", estilo_painel(Color("0a111d"), cor, 4))
	b.add_theme_stylebox_override("focus", estilo_painel(Color("141f31"), cor.darkened(0.2), 4))
	b.add_theme_stylebox_override("disabled", estilo_painel(Color("0c121d"), Color("1e2838"), 4))
	b.add_theme_color_override("font_color", COR_TEXTO)
	b.add_theme_color_override("font_hover_color", cor)
	b.add_theme_color_override("font_pressed_color", cor)
	b.add_theme_color_override("font_disabled_color", Color("4a566b"))
	b.focus_mode = Control.FOCUS_ALL


static func botao(texto: String, tamanho: int = 20, cor: Color = COR_CIANO) -> Button:
	var b: Button = Button.new()
	b.text = texto
	b.custom_minimum_size = Vector2(300, 46)
	b.add_theme_font_size_override("font_size", tamanho)
	aplicar_tema_botao(b, cor)
	return b


static func rotulo(texto: String, tamanho: int = 18, cor: Color = COR_TEXTO) -> Label:
	var l: Label = Label.new()
	l.text = texto
	l.add_theme_font_size_override("font_size", tamanho)
	l.add_theme_color_override("font_color", cor)
	l.add_theme_color_override("font_outline_color", Color("05070d"))
	l.add_theme_constant_override("outline_size", 4)
	return l


static func titulo(texto: String, tamanho: int = 40, cor: Color = COR_CIANO) -> Label:
	var l: Label = rotulo(texto, tamanho, cor)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_constant_override("outline_size", 8)
	l.add_theme_color_override("font_outline_color", Color("0a1a24"))
	return l


static func barra(cor: Color, altura: float = 18.0, largura: float = 260.0) -> ProgressBar:
	var pb: ProgressBar = ProgressBar.new()
	pb.custom_minimum_size = Vector2(largura, altura)
	pb.show_percentage = false
	pb.add_theme_stylebox_override("background", estilo_barra_fundo())
	pb.add_theme_stylebox_override("fill", estilo_barra(cor))
	return pb


static func barra_custom(cor: Color, altura: float, largura: float) -> ProgressBar:
	var pb: ProgressBar = barra(cor, altura, largura)
	return pb


static func formatar(n: int) -> String:
	var s: String = str(absi(n))
	var out: String = ""
	var count: int = 0
	for i: int in range(s.length() - 1, -1, -1):
		out = s[i] + out
		count += 1
		if count % 3 == 0 and i > 0:
			out = "." + out
	return ("-" if n < 0 else "") + out


static func separador(altura: float = 8.0) -> Control:
	var c: Control = Control.new()
	c.custom_minimum_size = Vector2(0, altura)
	return c


static func cor_raridade(raridade: String) -> Color:
	match raridade:
		"raro":
			return Color("68b7ff")
		"epico":
			return Color("c58bff")
		"isotopico":
			return Color("ffcf4a")
		_:
			return Color("9fb0c6")
