class_name EnemyGranadeiro
extends Enemy
## Granadeiro químico: mantém distância tática, faz telegraph e arremessa
## granadas com trajetória parabólica (rebatíveis com Parry).

const CENA_GRANADA: String = "res://scenes/granada_inimiga.tscn"
const DISTANCIA_IDEAL: float = 275.0

var _arremesso_timer: float = 2.2
var _telegraph: float = 0.0
var _cena_granada: PackedScene = null


func _ready() -> void:
	super._ready()
	comportamento = "granadeiro"
	if ResourceLoader.exists(CENA_GRANADA):
		_cena_granada = load(CENA_GRANADA) as PackedScene
	_arremesso_timer = randf_range(1.4, 2.6)


func _physics_process(delta: float) -> void:
	if morto:
		return
	super._physics_process(delta)
	_arremesso_timer -= delta
	if _telegraph > 0.0:
		_telegraph -= delta
		if corpo != null:
			corpo.modulate = Color(1.0, 1.0, 0.5) if fmod(_telegraph, 0.16) < 0.08 else Color.WHITE
		if _telegraph <= 0.0 and corpo != null:
			corpo.modulate = Color.WHITE
			_arremessar()
	elif _arremesso_timer <= 0.0 and jogador != null and jogador.vivo:
		_arremesso_timer = maxf(1.5, 2.6 - float(horda) * 0.03)
		_telegraph = 0.55
		AudioManager.tocar_sfx("perigo", -12.0, 0.1)


func _calcular_direcao(_delta: float) -> Vector2:
	if jogador == null:
		return Vector2.ZERO
	var para: Vector2 = jogador.global_position - global_position
	var dist: float = para.length()
	var dir: Vector2 = para.normalized() if dist > 1.0 else Vector2.ZERO
	if dist < 190.0:
		return -dir
	if dist > 340.0:
		return dir
	return dir.orthogonal() * 0.7


func _arremessar() -> void:
	if _cena_granada == null or jogador == null:
		return
	var g: GranadaInimiga = _cena_granada.instantiate() as GranadaInimiga
	if g == null:
		return
	get_parent().add_child(g)
	var previsao: Vector2 = jogador.global_position + jogador.velocity * 0.35
	g.configurar(global_position, previsao, 78.0, 16.0 + float(horda) * 0.6, self)
	AudioManager.tocar_sfx("perigo", -6.0, 0.12)
