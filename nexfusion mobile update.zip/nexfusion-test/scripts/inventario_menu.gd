extends Control
## Acesso ao Inventário / Caderno de Registros fora da partida (menu principal).

var _fechando: bool = false


func _ready() -> void:
	GlobalManager.definir_cursor(true)
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var tela: TelaInventario = TelaInventario.new()
	add_child(tela)
	tela.fechar_solicitado.connect(_ao_fechar)
	tela.abrir()
	AudioManager.tocar_bgm("menu")


func _unhandled_input(evento: InputEvent) -> void:
	if not (evento is InputEventKey):
		return
	var tecla: InputEventKey = evento as InputEventKey
	if not tecla.pressed or tecla.echo:
		return
	var codigo: int = tecla.physical_keycode if tecla.physical_keycode != 0 else tecla.keycode
	if codigo == KEY_ESCAPE or codigo == KEY_TAB:
		if _fechando:
			return
		_fechando = true
		get_viewport().set_input_as_handled()
		call_deferred("_ao_fechar")


func _ao_fechar() -> void:
	get_tree().change_scene_to_file("res://scenes/menu.tscn")
