class_name Player
extends CharacterBody2D
## Jogador: mobilidade (dash com i-frames), parry (Feedbacker),
## moedas de catalisador para ricochete, cura à queima-roupa e stats rogue-lite.

signal morreu
signal vida_alterada(atual: float, maxima: float)
signal cargas_alteradas(atual: int, maxima: int)

const VELOCIDADE_BASE: float = 240.0
const VELOCIDADE_DASH: float = 860.0
const DURACAO_DASH: float = 0.15
const IFRAMES_DASH: float = 0.24
const CARGAS_DASH_MAX: int = 3
const RECARGA_DASH: float = 1.05
const RAIO_PARRY: float = 92.0
const ALCANCE_PARRY: float = 0.18
const COOLDOWN_PARRY: float = 0.42
const ESCALA_SPRITE: float = 3.0
## Posição de repouso da arma na mão do jogador (o recuo volta para cá).
const ARMA_POSICAO: Vector2 = Vector2(15.0, 6.0)

const CENA_PROJETIL: String = "res://scenes/projetil.tscn"
## Ataque secundário (botão direito) — único por arma, sem upgrade de dano.
## Cada um reproduz o que aquele material faz de verdade ao neutralizar o risco.
const SECUNDARIOS := {
	"chumbo": {"nome": "CÁPSULA DE CONTENÇÃO", "recarga": 1.4},
	"bicarbonato": {"nome": "MAR DE ESPUMA", "recarga": 1.3},
	"vinagre": {"nome": "BORRIFO ÁCIDO", "recarga": 1.1},
	"carvao": {"nome": "PURIFICADOR", "recarga": 1.6},
	"agua": {"nome": "JATO DE PRESSÃO", "recarga": 0.9},
	"co2": {"nome": "ABAFAMENTO", "recarga": 1.5},
	"areia": {"nome": "PÁ DE AREIA", "recarga": 1.2},
	"quelante": {"nome": "GARRA QUELANTE", "recarga": 1.7},
	"tiossulfato": {"nome": "NÉVOA REDUTORA", "recarga": 1.4},
	"oleo": {"nome": "ONDA DE ÓLEO", "recarga": 1.5},
	"gelo_seco": {"nome": "NÉVOA FRIA", "recarga": 1.8},
}

var vida: float = 100.0
var vida_maxima: float = 100.0
var vivo: bool = true
## Painel de Desenvolvimento: ignora todo o dano enquanto estiver ligado.
var modo_deus: bool = false
var controle_bloqueado: bool = false
## Co-op LAN: quando true, a posição/mira vêm do host (jogador remoto).
var remoto: bool = false
## Apelido exibido acima do personagem (LAN e single player).
var nome_exibicao: String = ""
var entrada_externa: Vector2 = Vector2.ZERO
var mira_externa: Vector2 = Vector2.ZERO
var velocidade: float = VELOCIDADE_BASE
var limites: Rect2 = Rect2(0.0, 0.0, 2400.0, 1500.0)

# bônus de cartas rogue-lite
var bonus_dano: float = 1.0
var bonus_cadencia: float = 1.0
var projeteis_extra: int = 0
var perfuracao_extra: int = 0
var cadeia_extra: int = 0
var ricochete_extra: int = 0
var critico_extra: float = 0.0
var area_explosao_extra: float = 0.0
var aura_dano: float = 0.0
var magnetismo_extra: float = 0.0
var cura_extra: float = 0.0
var dash_bonus: float = 1.0
var esquiva_chance: float = 0.0
var escudo_golpes: int = 0
var escudo_max: int = 0
var escudo_absorb: int = 0

# estado
var dash_cargas: int = CARGAS_DASH_MAX
var raio_magnetismo: float = 165.0
var invulneravel: float = 0.0
var vida_recente: float = 0.0

var _dash_ativo: bool = false
var _dash_tempo: float = 0.0
var _direcao_dash: Vector2 = Vector2.RIGHT
var _recarga_dash: float = 0.0
var _cooldown_tiro: float = 0.0
var _cooldown_secundario: float = 0.0
var _cooldown_aparar: float = 0.0
var _bonus_precisao: float = 0.0
var _aura_timer: float = 0.0
var _shake: float = 0.0
var _tempo_afterimage: float = 0.0
var _textura_proj: Texture2D = null
var _cena_proj: PackedScene = null
var animador: AnimadorSprite = null
var _cor_skin: Color = Color.WHITE
var _mobile: Node = null
var _label_nick: Label = null
var _foco_offset: Vector2 = Vector2.ZERO
var _foco_tween: Tween = null
var _efeito_elemento: String = ""
var _efeito_tempo: float = 0.0
var _efeito_tick: float = 0.0
var _lentidao_tempo: float = 0.0

@onready var corpo: Sprite2D = $Corpo
@onready var arma_pivot: Node2D = $ArmaPivot
@onready var arma_sprite: Sprite2D = $ArmaPivot/Arma
@onready var muzzle: Marker2D = $ArmaPivot/Muzzle
@onready var camera: Camera2D = $Camera2D


func _ready() -> void:
	add_to_group("player")
	z_index = 10
	_cor_skin = GlobalManager.cor_skin_player()
	vida_maxima = 100.0 + GlobalManager.vida_maxima_bonus()
	vida = vida_maxima
	velocidade = VELOCIDADE_BASE * GlobalManager.multiplicador_velocidade()
	if ResourceLoader.exists("res://sprites/player/player.png"):
		corpo.texture = load("res://sprites/player/player.png") as Texture2D
	corpo.scale = Vector2.ONE * ESCALA_SPRITE
	corpo.modulate = _cor_skin
	animador = AnimadorSprite.new()
	animador.name = "Animador"
	animador.sprite = corpo
	add_child(animador)
	animador.configurar("res://sprites/player/player.png")
	_textura_proj = load("res://sprites/props/particula.png") as Texture2D if ResourceLoader.exists("res://sprites/props/particula.png") else null
	if ResourceLoader.exists(CENA_PROJETIL):
		_cena_proj = load(CENA_PROJETIL) as PackedScene
	if camera != null:
		camera.enabled = not remoto
		camera.position_smoothing_enabled = true
		camera.position_smoothing_speed = 9.0
	_atualizar_arma_visual()
	_criar_nick()
	_mobile = get_tree().get_first_node_in_group("mobile_controls")
	GlobalManager.aparencia_alterada.connect(_ao_mudar_aparencia)
	GlobalManager.tela_tremeu.connect(_ao_tremer)
	GlobalManager.horda_alterada.connect(_ao_nova_horda)
	emit_signal("vida_alterada", vida, vida_maxima)
	emit_signal("cargas_alteradas", dash_cargas, CARGAS_DASH_MAX)


func definir_limites(r: Rect2) -> void:
	limites = r
	if camera != null:
		camera.limit_left = int(r.position.x)
		camera.limit_top = int(r.position.y)
		camera.limit_right = int(r.end.x)
		camera.limit_bottom = int(r.end.y)


func _criar_nick() -> void:
	## Etiqueta simples acima da cabeça para diferenciar os jogadores no LAN.
	_label_nick = Label.new()
	_label_nick.text = nome_exibicao if nome_exibicao != "" else GlobalManager.nick
	_label_nick.add_theme_font_size_override("font_size", 11)
	_label_nick.add_theme_color_override("font_color", Color(0.88, 0.97, 1.0))
	_label_nick.add_theme_color_override("font_outline_color", Color(0.02, 0.03, 0.05))
	_label_nick.add_theme_constant_override("outline_size", 4)
	_label_nick.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label_nick.custom_minimum_size = Vector2(120, 0)
	_label_nick.position = Vector2(-60.0, -78.0)
	_label_nick.z_index = 30
	_label_nick.mouse_filter = Control.MOUSE_FILTER_IGNORE
	# Em single-player o apelido sobre o personagem só poluía a tela.
	_label_nick.visible = remoto or NetworkManager.modo != "off"
	add_child(_label_nick)


func definir_nick(nome: String) -> void:
	nome_exibicao = nome.to_upper()
	if _label_nick != null:
		_label_nick.text = nome_exibicao


func _ao_mudar_aparencia() -> void:
	_cor_skin = GlobalManager.cor_skin_player()
	if vivo:
		corpo.modulate = _cor_skin
	_atualizar_arma_visual()


# ------------------------------------------------------------------ entrada (LAN / mobile)
func _controles_moveis() -> Node:
	## Os controles de toque nascem depois do jogador em alguns fluxos; busca de
	## novo quando o nó antigo não existe mais (nunca guardar referência morta).
	if _mobile == null or not is_instance_valid(_mobile):
		_mobile = get_tree().get_first_node_in_group("mobile_controls")
	return _mobile


func entrada_local() -> Vector2:
	## Direção atual do jogador local (teclado ou joystick virtual).
	var controles: Node = _controles_moveis()
	if GlobalManager.modo_mobile and controles != null:
		return (controles.get("entrada") as Vector2).limit_length(1.0)
	return Vector2(
		Input.get_action_strength("mover_direita") - Input.get_action_strength("mover_esquerda"),
		Input.get_action_strength("mover_baixo") - Input.get_action_strength("mover_cima")
	)


func mira_local() -> Vector2:
	## Mira do jogador local: mouse no PC; no mobile, o joystick direito.
	## Sem toque no stick (ou antes do primeiro toque), cai na mira automática
	## no inimigo mais próximo. Ao soltar, a última direção continua valendo.
	if GlobalManager.modo_mobile:
		var controles: Node = _controles_moveis()
		if controles != null and bool(controles.get("mira_definida")):
			var direcao: Vector2 = controles.get("mira_direcao") as Vector2
			if direcao.length() > 0.01:
				return global_position + direcao.normalized() * 240.0
		var alvo: Enemy = _inimigo_mais_proximo()
		if alvo != null:
			return alvo.global_position
		var dir: Vector2 = entrada_local()
		if dir.length() < 0.1:
			dir = Vector2.RIGHT
		return global_position + dir.normalized() * 240.0
	return get_global_mouse_position()


func _inimigo_mais_proximo() -> Enemy:
	var melhor: Enemy = null
	var melhor_dist: float = 900.0
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		var e: Enemy = n as Enemy
		if e == null or not is_instance_valid(e) or e.morto:
			continue
		var d: float = global_position.distance_to(e.global_position)
		if d < melhor_dist:
			melhor_dist = d
			melhor = e
	return melhor


func segurando_tiro() -> bool:
	var controles: Node = _controles_moveis()
	if GlobalManager.modo_mobile and controles != null:
		return bool(controles.get("atirando"))
	return Input.is_action_pressed("tiro_primario")


func consumir_secundario_mobile() -> bool:
	var controles: Node = _controles_moveis()
	if controles == null:
		return Input.is_action_just_pressed("tiro_carregado")
	if bool(controles.get("secundario_pendente")):
		controles.set("secundario_pendente", false)
		return true
	return false


func consumir_dash_mobile() -> bool:
	var controles: Node = _controles_moveis()
	if controles == null:
		return Input.is_action_just_pressed("dash_esquiva")
	if bool(controles.get("dash_pendente")):
		controles.set("dash_pendente", false)
		return true
	return false


func consumir_parar_mobile() -> bool:
	var controles: Node = _controles_moveis()
	if controles == null:
		return Input.is_action_just_pressed("aparar_melee")
	if bool(controles.get("parar_pendente")):
		controles.set("parar_pendente", false)
		return true
	return false


func _ao_tremer(forca: float) -> void:
	_shake = maxf(_shake, forca)


func aplicar_efeito_elemental(elemento: String) -> void:
	## Ataques inimigos correspondem ao elemento: Cl/Na corrosão, U radiação,
	## Hg lentidão, Fe empurrão. O efeito é curto para não virar stunlock.
	if elemento in ["Cl", "Na", "Li", "H2SO4", "HCl", "NaOH", "P4", "Cl2+NH3"]:
		_efeito_elemento = "corrosao"
		_efeito_tempo = 3.0
		_efeito_tick = 0.7
	elif elemento in ["U", "X", "Cs"]:
		_efeito_elemento = "radiacao"
		_efeito_tempo = 4.0
		_efeito_tick = 0.8
	elif elemento == "Hg":
		_lentidao_tempo = maxf(_lentidao_tempo, 2.2)
		_efeito_elemento = ""
	elif elemento == "Fe":
		velocity += Vector2(randf_range(-90.0, 90.0), randf_range(-90.0, 90.0))
	else:
		return
	Efeitos.particulas(get_parent(), global_position, Color("9dff8a"), 6, 90.0, 0.35, 2.0, "acido")


func _tick_efeito_elemental(delta: float) -> void:
	_lentidao_tempo = maxf(0.0, _lentidao_tempo - delta)
	if _efeito_tempo <= 0.0:
		return
	_efeito_tempo = maxf(0.0, _efeito_tempo - delta)
	_efeito_tick -= delta
	if _efeito_tick > 0.0:
		return
	_efeito_tick = 0.75
	var dano: float = 2.0 if _efeito_elemento == "corrosao" else 3.0
	vida = maxf(0.0, vida - dano)
	vida_alterada.emit(vida, vida_maxima)
	Efeitos.texto_flutuante(get_parent(), global_position, str(int(dano)), Color("9dff8a"), 11)
	if vida <= 0.0:
		_morrer()


func _ao_nova_horda(_horda: int) -> void:
	## Escudo Protetor só recarrega no início da próxima horda.
	if escudo_max > 0:
		escudo_golpes = escudo_max
		queue_redraw()


func focar_camera(alvo: Vector2, duracao: float = 0.7) -> void:
	if camera == null:
		return
	var deslocamento: Vector2 = (alvo - global_position).limit_length(460.0)
	if _foco_tween != null and _foco_tween.is_valid():
		_foco_tween.kill()
	_foco_tween = create_tween()
	_foco_tween.tween_property(self, "_foco_offset", deslocamento, duracao).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)


func liberar_camera(duracao: float = 0.6) -> void:
	if camera == null:
		return
	if _foco_tween != null and _foco_tween.is_valid():
		_foco_tween.kill()
	_foco_tween = create_tween()
	_foco_tween.tween_property(self, "_foco_offset", Vector2.ZERO, duracao).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)


func _draw() -> void:
	if escudo_golpes <= 0:
		return
	var pulso: float = 0.55 + sin(float(Time.get_ticks_msec()) * 0.006) * 0.12
	draw_arc(Vector2.ZERO, 36.0, 0.0, TAU, 40, Color(0.68, 0.55, 1.0, pulso), 3.0, true)
	draw_arc(Vector2.ZERO, 42.0, 0.0, TAU, 40, Color(0.45, 0.35, 0.8, pulso * 0.45), 1.5, true)


func _process(delta: float) -> void:
	if camera != null:
		var tremor: Vector2 = Vector2.ZERO
		if _shake > 0.05:
			tremor = Vector2(randf_range(-_shake, _shake), randf_range(-_shake, _shake))
			_shake = lerpf(_shake, 0.0, clampf(delta * 12.0, 0.0, 1.0))
		else:
			_shake = 0.0
		camera.offset = _foco_offset + tremor


func _physics_process(delta: float) -> void:
	if not vivo:
		return
	_tick_timers(delta)
	_tick_efeito_elemental(delta)
	_mover(delta)
	_mirar()
	_processar_acoes()
	_processar_aura(delta)


func _tick_timers(delta: float) -> void:
	invulneravel = maxf(0.0, invulneravel - delta)
	_cooldown_tiro = maxf(0.0, _cooldown_tiro - delta)
	_cooldown_secundario = maxf(0.0, _cooldown_secundario - delta)
	_cooldown_aparar = maxf(0.0, _cooldown_aparar - delta)
	_bonus_precisao = maxf(0.0, _bonus_precisao - delta)
	vida_recente = maxf(0.0, vida_recente - delta)
	if _dash_tempo > 0.0:
		_dash_tempo = maxf(0.0, _dash_tempo - delta)
		if _dash_tempo <= 0.0:
			_dash_ativo = false
	if not _dash_ativo and dash_cargas < CARGAS_DASH_MAX:
		_recarga_dash += delta
		var necessario: float = RECARGA_DASH * GlobalManager.multiplicador_recarga_dash() / maxf(0.2, dash_bonus)
		if _recarga_dash >= necessario:
			_recarga_dash = 0.0
			dash_cargas += 1
			cargas_alteradas.emit(dash_cargas, CARGAS_DASH_MAX)
	if invulneravel > 0.0:
		corpo.modulate.a = 0.55 if fmod(invulneravel, 0.12) > 0.06 else 1.0
	else:
		corpo.modulate.a = 1.0


func _mover(delta: float) -> void:
	var dir: Vector2 = entrada_externa if remoto else entrada_local()
	if dir.length() > 1.0:
		dir = dir.normalized()
	if controle_bloqueado:
		dir = Vector2.ZERO
		_dash_ativo = false
	if _dash_ativo:
		velocity = _direcao_dash * VELOCIDADE_DASH
		_tempo_afterimage -= delta
		var tex_rastro: Texture2D = animador.textura_frame() if animador != null else corpo.texture
		if _tempo_afterimage <= 0.0 and tex_rastro != null:
			_tempo_afterimage = 0.02
			Efeitos.afterimage(get_parent(), tex_rastro, global_position, 0.0, corpo.scale, Color(0.56, 0.95, 1.0, 0.45))
	else:
		var fator_lento: float = 0.55 if _lentidao_tempo > 0.0 else 1.0
		velocity = dir * velocidade * fator_lento
	if animador != null:
		animador.definir_movendo(not _dash_ativo and dir.length() > 0.15)
	# Espelhamento pelo sentido do movimento (não pela mira).
	if absf(dir.x) > 0.12:
		corpo.flip_h = dir.x < 0.0
	move_and_slide()
	# Fora dos limites (dash, empurrão, teleporte): volta ao centro da arena.
	if not limites.grow(-6.0).has_point(global_position):
		global_position = limites.get_center()
		velocity = Vector2.ZERO
		_dash_ativo = false
		Efeitos.anel(get_parent(), global_position, 96.0, Color(1.0, 0.45, 0.45, 0.85), 0.4, 3.0)
		AudioManager.tocar_sfx("dash", -10.0, 0.1)
	global_position.x = clampf(global_position.x, limites.position.x + 22.0, limites.end.x - 22.0)
	global_position.y = clampf(global_position.y, limites.position.y + 22.0, limites.end.y - 22.0)


func _mirar() -> void:
	var mira: Vector2 = mira_externa if remoto else mira_local()
	var dir: Vector2 = (mira - global_position)
	if dir.length() < 1.0:
		dir = Vector2.RIGHT
	arma_pivot.rotation = dir.angle()
	arma_sprite.flip_v = dir.x < 0.0


func _processar_acoes() -> void:
	if controle_bloqueado or remoto:
		return
	if segurando_tiro():
		_tentar_atirar()
	if consumir_dash_mobile():
		_tentar_dash()
	if consumir_parar_mobile():
		_tentar_aparar()
	if consumir_secundario_mobile():
		_usar_secundario()


func _processar_aura(delta: float) -> void:
	if aura_dano <= 0.0:
		return
	_aura_timer -= delta
	if _aura_timer > 0.0:
		return
	_aura_timer = 0.45
	var afetados: int = 0
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		var e: Enemy = n as Enemy
		if e == null or not is_instance_valid(e) or e.morto:
			continue
		if global_position.distance_to(e.global_position) <= 84.0:
			e.receber_dano(aura_dano, false)
			afetados += 1
	if afetados > 0:
		Efeitos.anel(get_parent(), global_position, 84.0, Color(0.37, 0.88, 0.4, 0.5), 0.35, 2.0)


func _purificar(raio: float, dano: float, critico: bool) -> void:
	## Carvão ativado: adsorve todos os gases no alcance de uma vez.
	var arma_id: String = GlobalManager.arma_equipada
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		var e: Enemy = n as Enemy
		if e == null or not is_instance_valid(e) or e.morto:
			continue
		if global_position.distance_to(e.global_position) <= raio:
			var mult: float = e.multiplicador_neutralizacao(arma_id)
			if mult > 0.0:
				e.receber_dano(dano * mult, critico)
				e.aplicar_knockback((e.global_position - global_position).normalized() * 200.0)
	Efeitos.anel(get_parent(), global_position, raio + 10.0, Color(0.35, 0.35, 0.42, 0.85), 0.45, 5.0)
	Efeitos.particulas(get_parent(), global_position, Color("6b6b78"), 14, 210.0, 0.55, 3.0, "fumaca")


# ------------------------------------------------------------------ disparo
func _tentar_atirar() -> void:
	if _cooldown_tiro > 0.0:
		return
	var arma: DadosArma = GlobalManager.arma_atual()
	if arma == null:
		return
	var cadencia: float = maxf(0.4, arma.cadencia * bonus_cadencia * GlobalManager.multiplicador_cadencia_permanente())
	_cooldown_tiro = 1.0 / cadencia
	var mira: Vector2 = ((mira_externa if remoto else mira_local()) - global_position)
	if mira.length() < 1.0:
		mira = Vector2.RIGHT
	var dir_base: Vector2 = mira.normalized()
	var qtd: int = maxi(1, arma.projeteis + projeteis_extra)
	var crit_chance: float = arma.critico + critico_extra + GlobalManager.bonus_critico_permanente() + (0.45 if _bonus_precisao > 0.0 else 0.0)
	var dano_base: float = arma.dano * bonus_dano * GlobalManager.multiplicador_dano_permanente() * (1.15 if _bonus_precisao > 0.0 else 1.0)
	# CO2: o extintor sopra um jato contínuo (feixe) em vez de balas.
	if arma.id == "co2":
		for i: int in range(qtd):
			var ang_laser: float = 0.0
			if qtd > 1:
				ang_laser = deg_to_rad(-6.0 + 12.0 * float(i) / float(qtd - 1))
			var crit_l: bool = randf() < crit_chance
			_feixe_plasma(dir_base.rotated(ang_laser), dano_base * (2.0 if crit_l else 1.0), 1050.0, 15.0, arma.id)
		Efeitos.particulas(get_parent(), muzzle.global_position, arma.cor, 4, 120.0, 0.18, 2.0)
		AudioManager.tocar_sfx(arma.som, -8.0, 0.09)
		GlobalManager.registrar_estilo("DISPARO", 0.8, arma.cor, false)
		return
	for i: int in range(qtd):
		var angulo: float = 0.0
		if qtd > 1:
			# Leque mínimo: cartas de projéteis não saem mais grudadas.
			var abertura: float = maxf(arma.dispersao, 5.0 + 3.5 * float(qtd - 1))
			var passo: float = deg_to_rad(abertura) * 2.0 / float(qtd - 1)
			angulo = -deg_to_rad(abertura) + passo * float(i)
			angulo += randf_range(-0.02, 0.02)
		var dir: Vector2 = dir_base.rotated(angulo)
		var critico: bool = randf() < crit_chance
		var extra_tiro: Dictionary = {}
		if arma.id == "agua":
			# Pingos d'água respingam nas paredes e voltam.
			extra_tiro["duracao"] = 2.0
			extra_tiro["ricochetes"] = 999
		_disparar(dir, dano_base * (2.0 if critico else 1.0), arma, critico, extra_tiro)
	Efeitos.particulas(get_parent(), muzzle.global_position, arma.cor, 3, 90.0, 0.16, 2.0)
	AudioManager.tocar_sfx(arma.som, -8.0, 0.09)
	arma_sprite.position.x = ARMA_POSICAO.x - 2.0
	var tw: Tween = arma_sprite.create_tween()
	tw.tween_property(arma_sprite, "position:x", ARMA_POSICAO.x, 0.09)
	GlobalManager.registrar_estilo("DISPARO", 0.8, arma.cor, false)


func _disparar(dir: Vector2, dano: float, arma: DadosArma, critico: bool, extra: Dictionary = {}) -> void:
	if _cena_proj == null:
		return
	var p: Projetil = _cena_proj.instantiate() as Projetil
	if p == null:
		return
	get_parent().add_child(p)
	p.global_position = muzzle.global_position
	p.configurar({
		"amigavel": true,
		"direcao": dir,
		"dano": dano,
		"velocidade": float(extra.get("velocidade", arma.velocidade_projetil)),
		"cor": arma.cor,
		"tamanho": float(extra.get("tamanho", arma.tamanho_projetil)),
		"perfuracao": int(extra.get("perfuracao", arma.perfuracao + perfuracao_extra)),
		"cadeia": int(extra.get("cadeia", arma.cadeia + cadeia_extra)),
		"ricochetes": int(extra.get("ricochetes", arma.ricochetes + ricochete_extra)),
		"raio_explosao": float(extra.get("raio_explosao", arma.raio_explosao + area_explosao_extra)),
		"critico": critico,
		"alcance": float(extra.get("alcance", arma.alcance)),
		"duracao": float(extra.get("duracao", 0.0)),
		"arma": arma.id,
	})


# ------------------------------------------------------------------ dash
func _tentar_dash() -> void:
	if _dash_ativo or dash_cargas <= 0:
		return
	# No co-op o host simula o jogador remoto: usar a entrada/mira que o
	# cliente enviou, e não o teclado/mouse de quem hospeda.
	var dir: Vector2 = entrada_externa if remoto else entrada_local()
	if dir.length() < 0.1:
		var mira_dash: Vector2 = mira_externa if remoto else mira_local()
		dir = (mira_dash - global_position).normalized()
	_direcao_dash = dir.normalized()
	_dash_ativo = true
	_dash_tempo = DURACAO_DASH
	dash_cargas -= 1
	_recarga_dash = 0.0
	invulneravel = maxf(invulneravel, IFRAMES_DASH)
	_bonus_precisao = 0.35
	cargas_alteradas.emit(dash_cargas, CARGAS_DASH_MAX)
	AudioManager.tocar_sfx("dash", -6.0, 0.1)
	Efeitos.anel(get_parent(), global_position, 46.0, Color(0.56, 0.95, 1.0, 0.7), 0.28, 2.0)
	GlobalManager.registrar_estilo("DASH", 3.0, Color("8ff3ff"))


# ------------------------------------------------------------------ parry
func _tentar_aparar() -> void:
	if _cooldown_aparar > 0.0:
		return
	_cooldown_aparar = COOLDOWN_PARRY
	var mira: Vector2 = ((mira_externa if remoto else mira_local()) - global_position)
	if mira.length() < 1.0:
		mira = Vector2.RIGHT
	var dir: Vector2 = mira.normalized()
	var afetados: int = 0
	for n: Node in get_tree().get_nodes_in_group("projeteis_inimigos"):
		var b: Projetil = n as Projetil
		if b == null or not is_instance_valid(b):
			continue
		var dv: Vector2 = b.global_position - global_position
		if dv.length() <= RAIO_PARRY and dv.normalized().dot(dir) > -0.15:
			b.refletir(dir)
			afetados += 1
	for n: Node in get_tree().get_nodes_in_group("granadas"):
		var g: GranadaInimiga = n as GranadaInimiga
		if g == null or not is_instance_valid(g):
			continue
		var dv2: Vector2 = g.global_position - global_position
		if dv2.length() <= RAIO_PARRY + 30.0:
			g.rebater(dir)
			afetados += 1
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		var e: Enemy = n as Enemy
		if e == null or not is_instance_valid(e) or e.morto:
			continue
		var dv3: Vector2 = e.global_position - global_position
		if dv3.length() <= 112.0 and dv3.normalized().dot(dir) > 0.1:
			e.receber_dano(18.0 * bonus_dano, true)
			e.aplicar_knockback(dir * 260.0)
			afetados += 1
	if afetados > 0:
		curar(4.0 + cura_extra)
		GlobalManager.registrar_estilo("+PARRY", 22.0, Color("8ff3ff"))
		Efeitos.hitstop(70)
		Efeitos.tremor(6.0)
		AudioManager.tocar_sfx("parry", -2.0, 0.04)
	else:
		GlobalManager.registrar_estilo("APARO", 1.0, Color("8ff3ff"))
		AudioManager.tocar_sfx("perigo", -14.0, 0.1)
	Efeitos.anel(get_parent(), global_position + dir * 40.0, 62.0, Color(1.0, 1.0, 1.0, 0.85), 0.2, 4.0)


# ------------------------------------------------------------------ secundário (botão direito)
func _usar_secundario() -> void:
	if _cooldown_secundario > 0.0 or not vivo:
		return
	var arma: DadosArma = GlobalManager.arma_atual()
	if arma == null:
		return
	var cfg: Dictionary = SECUNDARIOS.get(arma.id, SECUNDARIOS["chumbo"]) as Dictionary
	_cooldown_secundario = float(cfg["recarga"])
	var mira: Vector2 = ((mira_externa if remoto else mira_local()) - global_position)
	if mira.length() < 1.0:
		mira = Vector2.RIGHT
	var dir: Vector2 = mira.normalized()
	var dano: float = arma.dano * bonus_dano
	var critico: bool = randf() < arma.critico + critico_extra
	match arma.id:
		"chumbo":
			# Cápsula de contenção: agulha densa que atravessa a fila inteira.
			_disparar(dir, dano * 2.0 * (2.0 if critico else 1.0), arma, critico, {
				"velocidade": 1450.0, "perfuracao": 8, "tamanho": arma.tamanho_projetil * 1.3,
			})
			_recuo(7.0)
			AudioManager.tocar_sfx("tiro_pesado", -7.0, 0.05)
		"bicarbonato":
			# Mar de espuma: a bolha estoura em área e neutraliza o ácido.
			_disparar(dir, dano * 2.6 * (2.0 if critico else 1.0), arma, critico, {
				"velocidade": 640.0, "raio_explosao": 135.0, "alcance": 680.0,
				"tamanho": arma.tamanho_projetil * 1.8,
			})
			_recuo(5.0)
			AudioManager.tocar_sfx("tiro", -5.0, 0.08)
		"vinagre":
			# Borrifo: cone largo de gotas que derretem cristais de base.
			for i: int in range(9):
				var ang: float = deg_to_rad(-45.0 + 90.0 * float(i) / 8.0) + randf_range(-0.02, 0.02)
				_disparar(dir.rotated(ang), dano * 0.7, arma, critico, {
					"velocidade": 1080.0, "alcance": 430.0, "tamanho": arma.tamanho_projetil * 0.9,
				})
			_recuo(5.0)
			AudioManager.tocar_sfx("tiro", -5.0, 0.08)
		"carvao":
			# Purificador: adsorve todos os gases no alcance de uma vez.
			_purificar(215.0, dano * 2.2 * (2.0 if critico else 1.0), critico)
			AudioManager.tocar_sfx("tiro_helio", -6.0, 0.05)
		"agua":
			# Jato de pressão: três veios rápidos que atravessam dois alvos.
			for i: int in range(3):
				_disparar(dir.rotated(deg_to_rad(-6.0 + 6.0 * float(i))), dano * 1.4, arma, critico, {
					"velocidade": 1250.0, "perfuracao": 2, "alcance": 760.0,
				})
			_recuo(4.0)
			AudioManager.tocar_sfx("tiro", -6.0, 0.06)
		"co2":
			# Abafamento: nuvem contínua, mais larga e mais longa.
			_feixe_plasma(dir, dano * 2.2 * (2.0 if critico else 1.0), 1150.0, 34.0, arma.id)
			AudioManager.tocar_sfx("tiro_helio", -5.0, 0.03)
		"areia":
			# Pá de areia: carga densa em leque curto que cobre o material.
			for i: int in range(6):
				_disparar(dir.rotated(deg_to_rad(-24.0 + 9.6 * float(i))), dano * 1.1, arma, critico, {
					"velocidade": 900.0, "alcance": 520.0, "tamanho": arma.tamanho_projetil * 1.2,
				})
			_recuo(6.0)
			AudioManager.tocar_sfx("tiro_pesado", -6.0, 0.05)
		"quelante":
			# Garra quelante: projétil lento e enorme que prende o metal pesado.
			_disparar(dir, dano * 3.0 * (2.0 if critico else 1.0), arma, critico, {
				"velocidade": 500.0, "raio_explosao": 120.0, "alcance": 640.0,
				"tamanho": arma.tamanho_projetil * 2.0,
			})
			_recuo(8.0)
			AudioManager.tocar_sfx("tiro_pesado", -4.0, 0.04)
		"tiossulfato":
			# Névoa redutora: nuvem que reduz o oxidante em área.
			_disparar(dir, dano * 2.2, arma, critico, {
				"velocidade": 560.0, "raio_explosao": 105.0, "alcance": 700.0,
				"tamanho": arma.tamanho_projetil * 2.1,
			})
			AudioManager.tocar_sfx("tiro", -6.0, 0.07)
		"oleo":
			# Onda de óleo: gotas largas e lentas que isolam o alcalino.
			for i: int in range(3):
				_disparar(dir.rotated(deg_to_rad(-14.0 + 14.0 * float(i))), dano * 1.6, arma, critico, {
					"velocidade": 620.0, "alcance": 560.0, "perfuracao": 1,
					"tamanho": arma.tamanho_projetil * 2.4,
				})
			AudioManager.tocar_sfx("tiro_pesado", -6.0, 0.07)
		"gelo_seco":
			# Névoa fria: nuvem congelante que estabiliza o composto instável.
			_disparar(dir, dano * 2.4 * (2.0 if critico else 1.0), arma, critico, {
				"velocidade": 700.0, "raio_explosao": 150.0, "alcance": 720.0,
				"tamanho": arma.tamanho_projetil * 1.9,
			})
			_recuo(6.0)
			AudioManager.tocar_sfx("tiro_helio", -5.0, 0.05)
		_:
			_disparar(dir, dano * 1.6, arma, critico)
	Efeitos.particulas(get_parent(), muzzle.global_position, arma.cor, 6, 140.0, 0.25, 2.4)
	GlobalManager.registrar_estilo("SECUNDÁRIO", 2.0, arma.cor)


func _feixe_plasma(dir: Vector2, dano: float, alcance: float = 950.0, largura: float = 12.0, arma_usada: String = "") -> void:
	var origem: Vector2 = muzzle.global_position
	var destino: Vector2 = origem + dir * alcance
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		var e: Enemy = n as Enemy
		if e == null or not is_instance_valid(e) or e.morto:
			continue
		var rel: Vector2 = e.global_position - origem
		var proj: float = rel.dot(dir)
		if proj < 0.0 or proj > alcance:
			continue
		if absf(rel.cross(dir)) <= largura + e.raio:
			var mult: float = e.multiplicador_neutralizacao(arma_usada)
			if mult > 0.0:
				e.receber_dano(dano * mult, true)
	Efeitos.feixe(get_parent(), origem, destino, Color(0.55, 1.0, 1.0, 0.95), largura * 1.2, 0.2)
	Efeitos.anel(get_parent(), destino, largura * 3.6, Color(0.55, 1.0, 1.0, 0.5), 0.3, 3.0)


func _recuo(forca: float) -> void:
	if animador != null:
		animador.tocar("ataque")
	_shake = maxf(_shake, forca)
	arma_sprite.position.x = ARMA_POSICAO.x - 6.0
	var tw: Tween = arma_sprite.create_tween()
	tw.tween_property(arma_sprite, "position:x", ARMA_POSICAO.x, 0.14)


# ------------------------------------------------------------------ vida
func receber_dano(valor: float) -> void:
	if not vivo or invulneravel > 0.0 or modo_deus:
		return
	# Esquiva: chance percentual de ignorar completamente o golpe.
	if esquiva_chance > 0.0 and randf() < esquiva_chance:
		Efeitos.texto_flutuante(get_parent(), global_position, "ESQUIVA", Color("8ff3ff"), 15)
		Efeitos.anel(get_parent(), global_position, 46.0, Color(0.55, 0.95, 1.0, 0.7), 0.22, 2.0)
		AudioManager.tocar_sfx("dash", -10.0, 0.08)
		return
	# Escudo: absorve golpes inteiros até acabar (recarrega na próxima horda).
	if escudo_golpes > 0:
		escudo_golpes -= 1
		Efeitos.texto_flutuante(get_parent(), global_position, "ESCUDO %d" % escudo_golpes, Color("a78bfa"), 15)
		Efeitos.anel(get_parent(), global_position, 58.0, Color(0.65, 0.55, 1.0, 0.9), 0.28, 3.0)
		AudioManager.tocar_sfx("parry", -10.0, 0.06)
		queue_redraw()
		return
	vida = maxf(0.0, vida - valor)
	if animador != null:
		animador.tocar("dano")
	invulneravel = 0.55
	vida_recente = 0.0
	corpo.modulate = Color(1.0, 0.45, 0.45)
	var tw: Tween = corpo.create_tween()
	tw.tween_property(corpo, "modulate", _cor_skin, 0.18)
	Efeitos.particulas(get_parent(), global_position, Color("ff5f5f"), 8, 150.0, 0.4, 2.5, "sangue")
	Efeitos.tremor(9.0)
	AudioManager.tocar_sfx("dano", -3.0, 0.08)
	GlobalManager.sofrer_dano_penalidade()
	vida_alterada.emit(vida, vida_maxima)
	if vida <= 0.0:
		_morrer()


func curar(valor: float) -> void:
	if not vivo or valor <= 0.0:
		return
	vida = minf(vida_maxima, vida + valor)
	vida_recente = 1.4
	vida_alterada.emit(vida, vida_maxima)


func _morrer() -> void:
	if not vivo:
		return
	vivo = false
	velocity = Vector2.ZERO
	set_physics_process(false)
	GlobalManager.registrar_estilo("MORTE", 0.0)
	Efeitos.particulas(get_parent(), global_position, Color("8ff3ff"), 18, 260.0, 0.8, 4.0, "plasma")
	Efeitos.anel(get_parent(), global_position, 120.0, Color(1.0, 0.4, 0.4, 0.8), 0.5, 5.0)
	Efeitos.tremor(16.0)
	AudioManager.tocar_sfx("explosao", 0.0, 0.05)
	corpo.visible = false
	arma_pivot.visible = false
	morreu.emit()


func _atualizar_arma_visual() -> void:
	var arma: DadosArma = GlobalManager.arma_atual()
	if arma == null or arma_sprite == null:
		return
	arma_sprite.position = ARMA_POSICAO
	arma_sprite.scale = Vector2.ONE * 2.2
	arma_sprite.z_index = 11
	if arma.textura != "" and ResourceLoader.exists(arma.textura):
		arma_sprite.texture = load(arma.textura) as Texture2D
	arma_sprite.modulate = GlobalManager.cor_skin_arma()
	if muzzle != null:
		muzzle.position = Vector2(30.0, 0.0)


func atualizar_arma() -> void:
	_atualizar_arma_visual()


# ------------------------------------------------------------------ cartas rogue-lite
func aplicar_carta(carta: CartaRoguelite) -> void:
	if carta == null:
		return
	match carta.atributo:
		"dano":
			bonus_dano += carta.valor
		"cadencia":
			bonus_cadencia += carta.valor
		"projeteis":
			projeteis_extra += int(carta.valor)
		"perfuracao":
			perfuracao_extra += int(carta.valor)
		"cadeia":
			cadeia_extra += int(carta.valor)
		"ricochete":
			ricochete_extra += int(carta.valor)
		"critico":
			critico_extra += carta.valor
		"area_explosao":
			area_explosao_extra += carta.valor
		"aura":
			aura_dano += carta.valor
		"magnetismo":
			magnetismo_extra += carta.valor
			raio_magnetismo = 165.0 + magnetismo_extra
		"cura":
			cura_extra += carta.valor
		"curar_agora":
			curar(carta.valor)
			Efeitos.particulas(get_parent(), global_position, Color("5fe08a"), 10, 140.0, 0.5, 2.5, "estrela")
		"esquiva":
			esquiva_chance = minf(0.65, esquiva_chance + carta.valor)
		"escudo":
			escudo_max += maxi(1, int(round(carta.valor)))
			escudo_golpes = escudo_max
			queue_redraw()
		"vida":
			vida_maxima += carta.valor
			vida = minf(vida_maxima, vida + carta.valor)
			vida_alterada.emit(vida, vida_maxima)
		"velocidade":
			velocidade += carta.valor
		"dash":
			dash_bonus += carta.valor
		"ressurreicao":
			GlobalManager.cargas_ressurreicao += maxi(1, int(round(carta.valor)))
		_:
			bonus_dano += 0.05
	GlobalManager.registrar_carta(carta.id)
	Efeitos.anel(get_parent(), global_position, 70.0, Color(1.0, 0.82, 0.29, 0.7), 0.4, 3.0)


# ------------------------------------------------------------------ ressurreição (LAN)
func reviver(posicao: Vector2) -> void:
	if vivo:
		return
	vivo = true
	global_position = posicao
	velocity = Vector2.ZERO
	_dash_ativo = false
	controle_bloqueado = false
	vida = maxf(1.0, vida_maxima * 0.6)
	invulneravel = 1.8
	dash_cargas = CARGAS_DASH_MAX
	corpo.visible = true
	arma_pivot.visible = true
	corpo.modulate = _cor_skin
	set_physics_process(true)
	vida_alterada.emit(vida, vida_maxima)
	cargas_alteradas.emit(dash_cargas, CARGAS_DASH_MAX)
	Efeitos.anel(get_parent(), global_position, 130.0, Color(0.6, 1.0, 0.75, 0.9), 0.6, 5.0)
	Efeitos.particulas(get_parent(), global_position, Color("5fe08a"), 16, 220.0, 0.7, 3.0, "estrela")
	AudioManager.tocar_sfx("revive", -4.0, 0.02)
