class_name JoystickVirtual
extends Control
## Joystick virtual reutilizável (movimento 2D/3D, mira 2D e olhar 3D).
##
## Regras do BLOCO B:
##  - cada stick guarda o ÍNDICE DE TOQUE do dedo dono e ignora os outros dedos;
##  - o vetor de saída já vem sem a zona morta e limitado a 0..1;
##  - resetar() solta o dedo e zera o valor (usado ao abrir janelas, ao perder
##    o foco do app e ao desativar os controles);
##  - nunca usa queue_free/visible=false por conta própria.

signal valor_alterado(valor: Vector2)
signal iniciou()
signal soltou()

enum Modo { FIXO, FLUTUANTE }
enum Eixo { NENHUM, HORIZONTAL, VERTICAL }

@export var raio: float = 92.0:
	set(valor):
		raio = maxf(24.0, valor)
		custom_minimum_size = Vector2.ONE * (raio * 2.0 + 24.0)
		queue_redraw()
## Fração do raio que é ignorada (padrão 0.2 do enunciado).
@export_range(0.0, 0.9, 0.01) var zona_morta: float = 0.2
@export var modo: Modo = Modo.FIXO
## FIXO: o anel fica parado. FLUTUANTE: o anel nasce onde o dedo encostou.
@export var eixo_travado: Eixo = Eixo.NENHUM
@export_range(0.0, 1.0, 0.01) var opacidade_repouso: float = 0.35
@export_range(0.0, 1.0, 0.01) var opacidade_em_uso: float = 0.7
@export var cor: Color = Color("8ff3ff")

var valor: Vector2 = Vector2.ZERO
var em_uso: bool = false

var _indice_toque: int = -1
var _mouse: bool = false
var _bloqueado: bool = false
var _centro: Vector2 = Vector2.ZERO
var _knob: Vector2 = Vector2.ZERO


func _ready() -> void:
	add_to_group("joysticks_virtuais")
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2.ONE * (raio * 2.0 + 24.0)
	_centro = size * 0.5
	resized.connect(_ao_redimensionar)


func _ao_redimensionar() -> void:
	if not em_uso:
		_centro = size * 0.5
	queue_redraw()


## Calcula o valor a partir de um deslocamento em pixels (público para testes).
func calcular_valor(deslocamento: Vector2) -> Vector2:
	var d: Vector2 = deslocamento
	if eixo_travado == Eixo.HORIZONTAL:
		d.y = 0.0
	elif eixo_travado == Eixo.VERTICAL:
		d.x = 0.0
	var bruto: float = clampf(d.length() / maxf(1.0, raio), 0.0, 1.0)
	if bruto <= zona_morta:
		return Vector2.ZERO
	var ajustado: float = (bruto - zona_morta) / maxf(0.001, 1.0 - zona_morta)
	return d.normalized() * clampf(ajustado, 0.0, 1.0)


func definir_bloqueado(bloqueado: bool) -> void:
	_bloqueado = bloqueado
	if bloqueado:
		resetar()


func aceita_entrada() -> bool:
	if _bloqueado or not is_visible_in_tree():
		return false
	if UiState != null and not UiState.aceita_entrada():
		return false
	return true


func _input(evento: InputEvent) -> void:
	if not aceita_entrada():
		return
	if evento is InputEventScreenTouch:
		var toque: InputEventScreenTouch = evento as InputEventScreenTouch
		if toque.pressed:
			if _indice_toque == -1 and get_global_rect().has_point(toque.position):
				_iniciar_toque(toque.index, toque.position)
				get_viewport().set_input_as_handled()
		elif toque.index == _indice_toque:
			resetar()
			get_viewport().set_input_as_handled()
	elif evento is InputEventScreenDrag:
		var arrasto: InputEventScreenDrag = evento as InputEventScreenDrag
		if arrasto.index == _indice_toque:
			_atualizar(arrasto.position)
			get_viewport().set_input_as_handled()
	elif evento is InputEventMouseButton:
		var clique: InputEventMouseButton = evento as InputEventMouseButton
		if clique.button_index != MOUSE_BUTTON_LEFT:
			return
		if clique.pressed:
			if _indice_toque == -1 and get_global_rect().has_point(clique.position):
				_mouse = true
				_iniciar_toque(-2, clique.position)
				get_viewport().set_input_as_handled()
		elif _mouse:
			_mouse = false
			resetar()
			get_viewport().set_input_as_handled()
	elif evento is InputEventMouseMotion and _mouse:
		var movimento: InputEventMouseMotion = evento as InputEventMouseMotion
		_atualizar(movimento.position)


func _iniciar_toque(indice: int, posicao: Vector2) -> void:
	_indice_toque = indice
	em_uso = true
	if modo == Modo.FLUTUANTE:
		var local: Vector2 = posicao - global_position
		_centro = Vector2(
			clampf(local.x, minf(raio, size.x * 0.5), maxf(size.x - raio, size.x * 0.5)),
			clampf(local.y, minf(raio, size.y * 0.5), maxf(size.y - raio, size.y * 0.5))
		)
	else:
		_centro = size * 0.5
	_atualizar(posicao)
	iniciou.emit()
	queue_redraw()


func _atualizar(posicao: Vector2) -> void:
	var deslocamento: Vector2 = posicao - global_position - _centro
	_knob = deslocamento.limit_length(raio)
	valor = calcular_valor(deslocamento)
	valor_alterado.emit(valor)
	queue_redraw()


func resetar() -> void:
	var estava_em_uso: bool = em_uso or _indice_toque != -1
	_indice_toque = -1
	_mouse = false
	em_uso = false
	_knob = Vector2.ZERO
	_centro = size * 0.5
	if valor != Vector2.ZERO:
		valor = Vector2.ZERO
		valor_alterado.emit(Vector2.ZERO)
	if estava_em_uso:
		soltou.emit()
	queue_redraw()


func _draw() -> void:
	var alfa: float = opacidade_em_uso if em_uso else opacidade_repouso
	var centro: Vector2 = _centro if _centro != Vector2.ZERO else size * 0.5
	if size == Vector2.ZERO:
		return
	draw_circle(centro, raio, Color(0.05, 0.09, 0.13, alfa * 0.8))
	draw_arc(centro, raio, 0.0, TAU, 48, Color(cor.r, cor.g, cor.b, alfa), 3.0, true)
	draw_arc(centro, raio * zona_morta, 0.0, TAU, 32, Color(cor.r, cor.g, cor.b, alfa * 0.45), 1.5, true)
	var pos_knob: Vector2 = centro + _knob
	draw_circle(pos_knob, raio * 0.34, Color(cor.r, cor.g, cor.b, alfa * 0.75))
	draw_circle(pos_knob, raio * 0.16, Color(0.9, 1.0, 1.0, minf(1.0, alfa + 0.25)))
