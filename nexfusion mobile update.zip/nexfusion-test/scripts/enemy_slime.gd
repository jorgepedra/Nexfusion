class_name EnemySlime
extends Enemy
## Slime Químico / Polímero Instável — UMA divisão: 1 grande -> 2 menores.
## Estágios: 0 grande (2.0x), 1 pequeno (1.3x). Filhos não se dividem mais.

const ESCALAS: Array[float] = [2.0, 1.3, 0.8]
const VIDA_FILHO: float = 0.45

var estagio: int = 0
var _impulso_inicial: Vector2 = Vector2.ZERO
var _tempo_invuln: float = 0.0


func _ready() -> void:
	super._ready()
	_estado = "normal"
	corpo.scale = Vector2.ONE * ESCALA_PIXEL * ESCALAS[clampi(estagio, 0, 2)]
	# Hitbox generosa: o slime é grande e precisa ser fácil de acertar.
	raio = 21.0 * ESCALAS[clampi(estagio, 0, 2)]
	_aplicar_visual()
	if colisao != null:
		var forma: CircleShape2D = colisao.shape as CircleShape2D
		if forma != null:
			forma = forma.duplicate() as CircleShape2D
			forma.radius = raio
			colisao.shape = forma
	velocidade *= 1.0 + float(estagio) * 0.25


func configurar_estagio(novo: int, vida_herdada: float = -1.0, impulso: Vector2 = Vector2.ZERO) -> void:
	estagio = clampi(novo, 0, 2)
	_impulso_inicial = impulso
	if is_inside_tree():
		corpo.scale = Vector2.ONE * ESCALA_PIXEL * ESCALAS[estagio]
		raio = 21.0 * ESCALAS[estagio]
		if colisao != null:
			var forma: CircleShape2D = colisao.shape as CircleShape2D
			if forma != null:
				forma = forma.duplicate() as CircleShape2D
				forma.radius = raio
				colisao.shape = forma
	if vida_herdada > 0.0:
		vida_max = vida_herdada
		vida = vida_herdada
	invulneravel = 0.15
	_tempo_invuln = 0.15


func _physics_process(delta: float) -> void:
	_tempo_invuln = maxf(0.0, _tempo_invuln - delta)
	if _impulso_inicial.length() > 1.0:
		_knockback += _impulso_inicial
		_impulso_inicial = _impulso_inicial.lerp(Vector2.ZERO, clampf(delta * 10.0, 0.0, 1.0))
		if _impulso_inicial.length() < 8.0:
			_impulso_inicial = Vector2.ZERO
	super._physics_process(delta)
	_animar_pulo(delta)


func _animar_pulo(_delta: float) -> void:
	if corpo == null:
		return
	var t: float = _tempo * (3.0 + float(estagio) * 1.2) + _fase_salto
	var altura: float = absf(sin(t)) * (5.0 - float(estagio) * 1.2)
	corpo.position.y = -altura
	var achatamento: float = 1.0 + sin(t * 2.0) * 0.06
	corpo.scale = Vector2(
		ESCALA_PIXEL * ESCALAS[clampi(estagio, 0, 2)] * (2.0 - achatamento),
		ESCALA_PIXEL * ESCALAS[clampi(estagio, 0, 2)] * achatamento
	)


func _dividir_em_especies() -> bool:
	## A nuvem se rompe em espécies diferentes (ex.: Cl2 + NH3).
	var feitos: int = 0
	var total: int = maxi(1, dados.divisao_em.size())
	for id: String in dados.divisao_em:
		var caminho: String = "res://resources/inimigos/%s.tres" % id
		if not ResourceLoader.exists(caminho):
			continue
		var d: DadosInimigo = load(caminho) as DadosInimigo
		if d == null or not ResourceLoader.exists(d.cena):
			continue
		var cena: PackedScene = load(d.cena) as PackedScene
		if cena == null:
			continue
		var filho: Enemy = cena.instantiate() as Enemy
		if filho == null:
			continue
		filho.dados = d
		get_parent().add_child(filho)
		filho.configurar(d, horda)
		var ang: float = TAU * float(feitos) / float(total) + randf_range(-0.25, 0.25)
		filho.global_position = global_position + Vector2(cos(ang), sin(ang)) * 28.0
		filho.vida_max *= 0.6
		filho.vida = filho.vida_max
		filho.invulneravel = 0.2
		Efeitos.particulas(get_parent(), filho.global_position, d.cor, 7, 130.0, 0.4, 2.0, "acido")
		feitos += 1
	if feitos == 0:
		return false
	AudioManager.tocar_sfx("morte_inimigo", -8.0, 0.15)
	GlobalManager.registrar_estilo("DIVISÃO", 4.0, Color("e8e07a"))
	return true


func _dividir() -> bool:
	# Apenas o slime grande se divide; os filhos são a última etapa.
	if estagio >= 1 or dados == null:
		return false
	# Mistura de produtos de limpeza: não vira "mais do mesmo", vira as
	# duas espécies que ela realmente libera (cloro e amônia).
	if not dados.divisao_em.is_empty():
		return _dividir_em_especies()
	var proximo: int = estagio + 1
	var vida_filho: float = vida_max * VIDA_FILHO
	var cena: PackedScene = load(dados.cena) as PackedScene
	if cena == null:
		return false
	var eixo: Vector2 = Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)).normalized()
	if eixo.length() < 0.1:
		eixo = Vector2.RIGHT
	for i: int in range(2):
		var filho: EnemySlime = cena.instantiate() as EnemySlime
		if filho == null:
			continue
		filho.estagio = proximo
		filho.configurar(dados, horda)
		get_parent().add_child(filho)
		var lado: float = 1.0 if i == 0 else -1.0
		filho.global_position = global_position + eixo.orthogonal() * 22.0 * lado
		filho.configurar_estagio(proximo, vida_filho, eixo * 95.0 * lado)
		filho.invulneravel = 0.15
		Efeitos.particulas(get_parent(), filho.global_position, Color("6ee06a"), 7, 130.0, 0.4, 2.0, "acido")
	AudioManager.tocar_sfx("morte_inimigo", -8.0, 0.15)
	GlobalManager.registrar_estilo("DIVISÃO", 4.0, Color("6ee06a"))
	return true
