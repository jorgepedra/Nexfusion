class_name Efeitos
extends RefCounted
## Game feel: números de dano, partículas, anéis de choque, afterimages,
## raios elétricos, flash de tela e hit-stop global.

const TEXTO_PARTICULA: String = "res://sprites/props/particula.png"
const PASTA_PARTICULAS: String = "res://sprites/particulas"
## Teto global de EMISSORES (cada um espalha várias partículas em GPU/CPU leve).
## Antes eram centenas de Sprite2D + Tween por segundo; agora são poucos nós.
const MAX_PARTICULAS: int = 60
static var _particulas_vivas: int = 0
static var _tex_particula: Texture2D = null
static var _tex_por_tipo: Dictionary = {}
var _cache_particula: Texture2D = null


static func _limite_particulas() -> int:
	## Qualidade leve reduz bastante; moderada/pesada mantêm o efeito completo.
	if GlobalManager.particulas_reduzidas():
		return 2
	return 8


static func _textura_tipo(tipo: String) -> Texture2D:
	## Cada efeito tem seu sprite próprio (faísca, fumaça, ácido, plasma...).
	if _tex_por_tipo.has(tipo):
		return _tex_por_tipo[tipo] as Texture2D
	var caminho: String = PASTA_PARTICULAS.path_join("%s.png" % tipo)
	var tex: Texture2D = null
	if ResourceLoader.exists(caminho):
		tex = load(caminho) as Texture2D
	if tex == null:
		tex = _textura_particula()
	_tex_por_tipo[tipo] = tex
	return tex


class Anel extends Node2D:
	var raio_final: float = 40.0
	var cor: Color = Color.WHITE
	var duracao: float = 0.3
	var espessura: float = 3.0
	var _t: float = 0.0

	func _process(delta: float) -> void:
		_t += delta
		if _t >= duracao:
			queue_free()
			return
		queue_redraw()

	func _draw() -> void:
		var p: float = clampf(_t / duracao, 0.0, 1.0)
		var r: float = lerpf(6.0, raio_final, p)
		var a: float = 1.0 - p
		draw_arc(Vector2.ZERO, r, 0.0, TAU, 28, Color(cor.r, cor.g, cor.b, a * 0.9), espessura * (1.0 - p * 0.6), true)


class Raio extends Node2D:
	var destino: Vector2 = Vector2.ZERO
	var cor: Color = Color("8ff3ff")
	var duracao: float = 0.12
	var _t: float = 0.0
	var _pontos: PackedVector2Array = PackedVector2Array()

	func _ready() -> void:
		var passos: int = 5
		for i: int in range(passos + 1):
			var f: float = float(i) / float(passos)
			var p: Vector2 = destino * f
			if i > 0 and i < passos:
				p += Vector2(randf_range(-8.0, 8.0), randf_range(-8.0, 8.0))
			_pontos.append(p)

	func _process(delta: float) -> void:
		_t += delta
		if _t >= duracao:
			queue_free()
			return
		queue_redraw()

	func _draw() -> void:
		var a: float = 1.0 - _t / duracao
		for i: int in range(_pontos.size() - 1):
			draw_line(_pontos[i], _pontos[i + 1], Color(cor.r, cor.g, cor.b, a), 3.0, true)
			draw_line(_pontos[i], _pontos[i + 1], Color(1, 1, 1, a * 0.8), 1.0, true)


class Feixe extends Node2D:
	var destino: Vector2 = Vector2.RIGHT
	var cor: Color = Color("8ff3ff")
	var largura: float = 7.0
	var duracao: float = 0.16
	var _t: float = 0.0

	func _process(delta: float) -> void:
		_t += delta
		if _t >= duracao:
			queue_free()
			return
		queue_redraw()

	func _draw() -> void:
		var a: float = 1.0 - _t / duracao
		draw_line(Vector2.ZERO, destino, Color(cor.r, cor.g, cor.b, a * 0.9), largura * a, true)
		draw_line(Vector2.ZERO, destino, Color(1, 1, 1, a), largura * a * 0.35, true)


static func _textura_particula() -> Texture2D:
	if _tex_particula != null:
		return _tex_particula
	if not ResourceLoader.exists(TEXTO_PARTICULA):
		return null
	_tex_particula = load(TEXTO_PARTICULA) as Texture2D
	return _tex_particula


static func texto_flutuante(pai: Node, pos: Vector2, texto: String, cor: Color = Color.WHITE, tamanho: int = 14, critico: bool = false) -> void:
	if pai == null or not pai.is_inside_tree():
		return
	var l: Label = Label.new()
	l.text = texto
	l.add_theme_font_size_override("font_size", tamanho + (4 if critico else 0))
	l.add_theme_color_override("font_color", cor)
	l.add_theme_color_override("font_outline_color", Color(0.02, 0.02, 0.05, 0.95))
	l.add_theme_constant_override("outline_size", 5)
	l.z_index = 60
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pai.add_child(l)
	l.global_position = pos + Vector2(randf_range(-6.0, 6.0), -8.0)
	var tw: Tween = l.create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "global_position", l.global_position + Vector2(randf_range(-10.0, 10.0), -34.0), 0.55)
	tw.tween_property(l, "modulate:a", 0.0, 0.55).set_delay(0.12)
	tw.chain().tween_callback(l.queue_free)


static func particulas(pai: Node, pos: Vector2, cor: Color, quantidade: int = 8, velocidade: float = 140.0, vida: float = 0.45, tamanho: float = 3.0, tipo: String = "faisca") -> void:
	## UM emissor por chamada (CPUParticles2D) em vez de N sprites + N tweens.
	if pai == null or not pai.is_inside_tree():
		return
	if _particulas_vivas >= MAX_PARTICULAS:
		return
	# Densidade global reduzida para manter a leitura sem pescar o frame.
	quantidade = maxi(1, int(round(float(quantidade) * 0.5)))
	quantidade = mini(quantidade, _limite_particulas())
	var tex: Texture2D = _textura_tipo(tipo)
	if tex == null:
		return
	_particulas_vivas += 1
	var p: CPUParticles2D = CPUParticles2D.new()
	p.texture = tex
	p.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	p.color = cor
	p.amount = quantidade
	p.one_shot = true
	p.explosiveness = 1.0
	p.lifetime = maxf(0.12, vida)
	p.direction = Vector2.UP
	p.spread = 180.0
	p.gravity = Vector2.ZERO
	p.initial_velocity_min = velocidade * 0.25
	p.initial_velocity_max = velocidade
	p.scale_amount_min = tamanho * 0.35
	p.scale_amount_max = tamanho * 0.65
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_SPHERE
	p.emission_sphere_radius = 3.0
	p.z_index = 45
	p.local_coords = false
	p.tree_exited.connect(func() -> void: _particulas_vivas = maxi(0, _particulas_vivas - 1))
	pai.add_child(p)
	p.global_position = pos
	p.finished.connect(p.queue_free)
	# Rede de segurança: libera o emissor mesmo se o sinal não disparar.
	var t: SceneTreeTimer = pai.get_tree().create_timer(vida + 0.4, true, false, true)
	# Conexão direta: se o emissor já foi liberado, a conexão é descartada
	# automaticamente (lambda com captura gerava "capture freed" no console).
	t.timeout.connect(p.queue_free)
	p.emitting = true


static func anel(pai: Node, pos: Vector2, raio: float, cor: Color, duracao: float = 0.3, espessura: float = 3.0) -> void:
	if pai == null or not pai.is_inside_tree():
		return
	var a: Anel = Anel.new()
	a.raio_final = raio
	a.cor = cor
	a.duracao = duracao
	a.espessura = espessura
	a.z_index = 44
	pai.add_child(a)
	a.global_position = pos


static func feixe(pai: Node, origem: Vector2, destino: Vector2, cor: Color = Color("8ff3ff"), largura: float = 7.0, duracao: float = 0.16) -> void:
	if pai == null or not pai.is_inside_tree():
		return
	var f: Feixe = Feixe.new()
	f.destino = destino - origem
	f.cor = cor
	f.largura = largura
	f.duracao = duracao
	f.z_index = 46
	pai.add_child(f)
	f.global_position = origem


static func raio(pai: Node, origem: Vector2, destino: Vector2, cor: Color = Color("8ff3ff")) -> void:
	if pai == null or not pai.is_inside_tree():
		return
	var r: Raio = Raio.new()
	r.destino = destino - origem
	r.cor = cor
	r.z_index = 46
	pai.add_child(r)
	r.global_position = origem


static func afterimage(pai: Node, textura: Texture2D, pos: Vector2, rotacao: float, escala: Vector2, cor: Color) -> void:
	if pai == null or textura == null or not pai.is_inside_tree():
		return
	var s: Sprite2D = Sprite2D.new()
	s.texture = textura
	s.global_position = pos
	s.rotation = rotacao
	s.scale = escala
	s.modulate = cor
	s.z_index = -1
	pai.add_child(s)
	var tw: Tween = s.create_tween()
	tw.set_parallel(true)
	tw.tween_property(s, "modulate:a", 0.0, 0.25)
	tw.tween_property(s, "scale", escala * 0.8, 0.25)
	tw.chain().tween_callback(s.queue_free)


static func hitstop(duracao_ms: int) -> void:
	var arvore: SceneTree = Engine.get_main_loop() as SceneTree
	if arvore == null:
		return
	Engine.time_scale = 0.06
	var timer: SceneTreeTimer = arvore.create_timer(float(duracao_ms) / 1000.0, true, false, true)
	timer.timeout.connect(func() -> void: Engine.time_scale = 1.0)


static func tremor(forca: float) -> void:
	GlobalManager.tela_tremeu.emit(forca)
