class_name Fase3D
extends CanvasLayer
## Transição dimensional do Elemento Supremo.
## Arena 3D em primeira pessoa no espaço, com a Terra abaixo. O chefe voa com
## asas de elétrons e dispara ondas de projéteis; o jogador atira e desvia.
## Ao vencer (ou cair), o jogo volta ao 2D para a Fase 2 do confronto.

signal concluida(venceu: bool)

const VIDA_CHEFE: float = 900.0
const VIDA_JOGADOR: float = 100.0
const VELOCIDADE_JOGADOR: float = 7.0
const RAIO_ARENA: float = 11.0
const RAIO_PLATAFORMA: float = 18.0
const RAIO_TERRA: float = 145.0

var _viewport: SubViewport
var _container: SubViewportContainer
var _mundo: Node3D
var _arena: Node3D = null
var _terra: MeshInstance3D = null
var _nuvens: Node3D = null
var _planetas: Array[Node3D] = []
var _estrelas: MultiMeshInstance3D = null
var _camera: Camera3D
var _chefe: Node3D
var _eletrons: Array[MeshInstance3D] = []
var _tiros: Array[MeshInstance3D] = []
var _rastros: Array[MeshInstance3D] = []
var _vida_chefe: float = VIDA_CHEFE
var _vida_jogador: float = VIDA_JOGADOR
var _yaw: float = 0.0
var _pitch: float = -0.12
var _pos_jogador: Vector3 = Vector3(0.0, 2.0, 6.0)
var _tempo: float = 0.0
var _cooldown_tiro: float = 0.0
var _cooldown_onda: float = 2.0
var _cooldown_mirado: float = 3.5
var _terminando: bool = false
var _hud_2d: CanvasLayer = null

var _barra: ProgressBar
var _barra_jogador: ProgressBar
var _label_aviso: Label
var _mira: Control

# --- arma equipada / viewmodel em primeira pessoa
var _arma: DadosArma = null
var _jogador: Player = null
var _nome_arma: String = ""
var _cor_arma: Color = Color("8ff3ff")
var _dano_tiro: float = 14.0
var _cadencia: float = 6.0
var _critico_chance: float = 0.08
var _projeteis: int = 1
var _dispersao: float = 2.0
var _tamanho_bala: float = 1.0
var _vel_bala: float = 45.0
var _vida_inicial: float = VIDA_JOGADOR
var _balas: Array[MeshInstance3D] = []
var _sprite_arma: TextureRect = null
var _flash_vm: TextureRect = null
var _sway: Vector2 = Vector2.ZERO
var _recuo: float = 0.0
var _flash_tempo: float = 0.0
var _tempo_passo: float = 0.0
var _movendo: bool = false

var _mat_chefe: StandardMaterial3D
var _mat_eletron: StandardMaterial3D
var _mat_tiro: StandardMaterial3D
var _mat_laser: StandardMaterial3D


func configurar(jogador: Player, arma: DadosArma) -> void:
	## Chamado antes de entrar na árvore: a arma equipada e as cartas da run
	## mudam o viewmodel, o dano, a cadência e a quantidade de balas.
	_jogador = jogador
	_arma = arma


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 60
	_calcular_stats()
	_vida_jogador = _vida_inicial
	_montar_interface()
	_montar_3d()
	get_tree().paused = true
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	AudioManager.tocar_bgm("espaco")
	AudioManager.tocar_sfx("chefe", 0.0, 0.02)
	GlobalManager.definir_cursor(false)


func _calcular_stats() -> void:
	if _arma == null:
		_arma = GlobalManager.arma_atual()
	if _arma == null:
		_arma = load("res://resources/armas/chumbo.tres") as DadosArma
	if _arma == null:
		return
	_nome_arma = String(_arma.nome)
	_cor_arma = _arma.cor
	_dano_tiro = _arma.dano * GlobalManager.multiplicador_dano_permanente()
	_cadencia = maxf(0.6, _arma.cadencia * GlobalManager.multiplicador_cadencia_permanente())
	_critico_chance = _arma.critico + GlobalManager.bonus_critico_permanente()
	_projeteis = maxi(1, _arma.projeteis)
	_dispersao = maxf(0.0, _arma.dispersao)
	_tamanho_bala = clampf(_arma.tamanho_projetil, 0.6, 3.0)
	_vel_bala = clampf(_arma.velocidade_projetil * 0.05, 30.0, 90.0)
	# Cartas e escolhas da run continuam valendo na dimensão 3D.
	if _jogador != null and is_instance_valid(_jogador):
		_dano_tiro *= _jogador.bonus_dano
		_cadencia *= _jogador.bonus_cadencia
		_critico_chance += _jogador.critico_extra
		_projeteis += _jogador.projeteis_extra
		_dispersao += float(_jogador.projeteis_extra) * 3.0
		_vida_inicial = clampf(_jogador.vida_maxima * 10.0, 60.0, 220.0)


func _montar_interface() -> void:
	var raiz: Control = Control.new()
	raiz.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	raiz.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(raiz)

	_mira = Control.new()
	_mira.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_mira.custom_minimum_size = Vector2(34, 34)
	_mira.offset_left = -17
	_mira.offset_top = -17
	_mira.offset_right = 17
	_mira.offset_bottom = 17
	_mira.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_mira.draw.connect(func() -> void:
		_mira.draw_arc(Vector2(17, 17), 12.0, 0.0, TAU, 28, Color(0.65, 1.0, 1.0, 0.9), 2.0, true)
		_mira.draw_line(Vector2(17, 4), Vector2(17, 12), Color(1, 1, 1, 0.9), 2.0)
		_mira.draw_line(Vector2(17, 22), Vector2(17, 30), Color(1, 1, 1, 0.9), 2.0)
		_mira.draw_line(Vector2(4, 17), Vector2(12, 17), Color(1, 1, 1, 0.9), 2.0)
		_mira.draw_line(Vector2(22, 17), Vector2(30, 17), Color(1, 1, 1, 0.9), 2.0))
	raiz.add_child(_mira)

	var topo: VBoxContainer = VBoxContainer.new()
	topo.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	topo.offset_left = -340
	topo.offset_right = 340
	topo.offset_top = 28
	topo.add_theme_constant_override("separation", 4)
	topo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	raiz.add_child(topo)
	var titulo: Label = UI.titulo("DIMENSÃO ZERO — ELEMENTO SUPREMO", 26, UI.COR_CIANO)
	topo.add_child(titulo)
	_barra = UI.barra(UI.COR_MAGENTA, 18.0, 660.0)
	_barra.max_value = VIDA_CHEFE
	_barra.value = VIDA_CHEFE
	topo.add_child(_barra)
	_label_aviso = UI.rotulo("CLIQUE / ESPAÇO PARA ATIRAR  ·  WASD PARA VOAR  ·  MOUSE PARA MIRAR", 13, UI.COR_TEXTO_FRACO)
	_label_aviso.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	topo.add_child(_label_aviso)

	_barra_jogador = UI.barra(UI.COR_VERDE, 14.0, 280.0)
	_barra_jogador.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	_barra_jogador.offset_left = 34
	_barra_jogador.offset_top = -52
	_barra_jogador.offset_bottom = -38
	_barra_jogador.max_value = _vida_inicial
	_barra_jogador.value = _vida_jogador
	raiz.add_child(_barra_jogador)
	var label_vida: Label = UI.rotulo("INTEGRIDADE", 12, UI.COR_VERDE)
	label_vida.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	label_vida.offset_left = 34
	label_vida.offset_top = -74
	label_vida.offset_bottom = -56
	raiz.add_child(label_vida)

	var plural: String = "1 BALA" if _projeteis == 1 else "%d BALAS" % _projeteis
	var label_arma: Label = UI.rotulo("ARMA: %s · %s  ·  %s" % [_nome_arma.to_upper(), _arma.elemento if _arma != null else "", plural], 12, _cor_arma)
	label_arma.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	label_arma.offset_left = 34
	label_arma.offset_top = -100
	label_arma.offset_bottom = -80
	raiz.add_child(label_arma)
	_montar_viewmodel(raiz)


func _montar_viewmodel(raiz: Control) -> void:
	## Arma equipada na mão, em primeira pessoa, com balanço, recuo e flash de cano.
	if _arma == null or _arma.textura == "" or not ResourceLoader.exists(_arma.textura):
		return
	var tex: Texture2D = load(_arma.textura) as Texture2D
	if tex == null:
		return
	_sprite_arma = TextureRect.new()
	_sprite_arma.texture = tex
	_sprite_arma.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_sprite_arma.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_sprite_arma.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_sprite_arma.flip_h = true
	_sprite_arma.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_sprite_arma.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	_sprite_arma.offset_left = -300.0
	_sprite_arma.offset_top = -205.0
	_sprite_arma.offset_right = -40.0
	_sprite_arma.offset_bottom = -8.0
	_sprite_arma.pivot_offset = Vector2(215.0, 98.0)
	_sprite_arma.rotation = 0.2
	_sprite_arma.modulate = GlobalManager.cor_skin_arma()
	raiz.add_child(_sprite_arma)

	# Flash de cano preso à arma (acompanha o balanço e o recuo).
	_flash_vm = TextureRect.new()
	_flash_vm.texture = load("res://sprites/props/particula.png") as Texture2D
	_flash_vm.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_flash_vm.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_flash_vm.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_flash_vm.mouse_filter = Control.MOUSE_FILTER_IGNORE
	# Boca do cano calculada no espaço do controle (o sprite é centralizado e
	# espelhado, então o cano fica na borda esquerda do desenho, não do retângulo).
	var tam_tex: Vector2 = tex.get_size()
	var esc_ajuste: float = minf(260.0 / maxf(1.0, tam_tex.x), 197.0 / maxf(1.0, tam_tex.y))
	var conteudo: Vector2 = tam_tex * esc_ajuste
	var canto: Vector2 = (Vector2(260.0, 197.0) - conteudo) * 0.5
	var boca_local: Vector2 = canto + Vector2(0.0, conteudo.y * 0.5)
	_flash_vm.position = boca_local - Vector2(25.0, 25.0)
	_flash_vm.size = Vector2(50.0, 50.0)
	_flash_vm.modulate = Color(_cor_arma.r, _cor_arma.g, _cor_arma.b, 0.0)
	_sprite_arma.add_child(_flash_vm)


func _animar_viewmodel(delta: float) -> void:
	if _sprite_arma == null:
		return
	_tempo_passo += delta * (11.0 if _movendo else 3.0)
	_recuo = maxf(0.0, _recuo - delta * 5.5)
	_flash_tempo = maxf(0.0, _flash_tempo - delta)
	var bob: float = sin(_tempo_passo) * (6.0 if _movendo else 2.0)
	var desloc: Vector2 = Vector2(_sway.x + sin(_tempo_passo * 0.5) * 3.0, _sway.y + bob + _recuo * 16.0)
	_sprite_arma.offset_left = -300.0 + desloc.x
	_sprite_arma.offset_right = -40.0 + desloc.x
	_sprite_arma.offset_top = -205.0 + desloc.y
	_sprite_arma.offset_bottom = -8.0 + desloc.y
	_sprite_arma.rotation = 0.2 - _recuo * 0.13 + _sway.x * 0.004
	_sway = _sway.lerp(Vector2.ZERO, clampf(delta * 7.0, 0.0, 1.0))
	if _flash_vm != null:
		var alfa: float = clampf(_flash_tempo / 0.07, 0.0, 1.0)
		_flash_vm.modulate.a = alfa
		var escala: float = 1.0 + (1.0 - alfa) * 0.6
		_flash_vm.scale = Vector2(escala, escala)


func _montar_3d() -> void:
	_container = SubViewportContainer.new()
	_container.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_container.stretch = true
	_container.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_container)
	move_child(_container, 0)
	_viewport = SubViewport.new()
	_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	_viewport.msaa_3d = Viewport.MSAA_2X
	_container.add_child(_viewport)

	_mundo = Node3D.new()
	_mundo.name = "Espaco"
	_viewport.add_child(_mundo)
	_criar_ambiente()
	_criar_arena()
	_criar_terra_gigante()
	_criar_planetas()
	_criar_nebulosas()
	_criar_estrelas()
	_criar_chefe()

	_camera = Camera3D.new()
	_camera.fov = 78.0
	_camera.far = 2600.0
	_camera.position = _pos_jogador
	_camera.rotation = Vector3(_pitch, _yaw, 0.0)
	_camera.current = true
	_mundo.add_child(_camera)


func _criar_ambiente() -> void:
	var env: Environment = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.005, 0.008, 0.02)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.35, 0.5, 0.8)
	env.ambient_light_energy = 0.55
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var mundo_env: WorldEnvironment = WorldEnvironment.new()
	mundo_env.environment = env
	_mundo.add_child(mundo_env)
	var luz: DirectionalLight3D = DirectionalLight3D.new()
	luz.rotation_degrees = Vector3(-35.0, 25.0, 0.0)
	luz.light_color = Color(0.75, 0.88, 1.0)
	luz.light_energy = 1.1
	_mundo.add_child(luz)


func _material(cor: Color, brilho: float = 0.0) -> StandardMaterial3D:
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.albedo_color = cor
	if brilho > 0.0:
		m.emission_enabled = true
		m.emission = cor
		m.emission_energy_multiplier = brilho
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	return m


func _criar_arena() -> void:
	## Plataforma de duelo flutuando sobre a Terra: piso metálico, anéis de
	## energia e pilares de contenção nas bordas.
	_arena = Node3D.new()
	_arena.name = "Arena"
	_arena.position = Vector3(0.0, -3.6, 2.0)
	_mundo.add_child(_arena)

	var piso: MeshInstance3D = MeshInstance3D.new()
	var cilindro: CylinderMesh = CylinderMesh.new()
	cilindro.top_radius = RAIO_PLATAFORMA
	cilindro.bottom_radius = RAIO_PLATAFORMA * 0.93
	cilindro.height = 0.9
	cilindro.radial_segments = 72
	piso.mesh = cilindro
	var mat_piso: StandardMaterial3D = StandardMaterial3D.new()
	mat_piso.albedo_color = Color(0.17, 0.21, 0.29)
	mat_piso.metallic = 0.15
	mat_piso.roughness = 0.62
	piso.material_override = mat_piso
	_arena.add_child(piso)

	# Anéis de energia no piso marcam a área de combate.
	var aneis: Array[float] = [5.5, 10.5, 15.5, RAIO_PLATAFORMA - 0.15]
	for i: int in range(aneis.size()):
		var anel: MeshInstance3D = MeshInstance3D.new()
		var toro: TorusMesh = TorusMesh.new()
		toro.inner_radius = aneis[i] - 0.09
		toro.outer_radius = aneis[i] + 0.09
		toro.rings = 96
		toro.ring_segments = 6
		anel.mesh = toro
		anel.position = Vector3(0.0, 0.47, 0.0)
		anel.material_override = _material(Color(0.35, 0.95, 1.0), 1.6 if i < aneis.size() - 1 else 2.8)
		_arena.add_child(anel)

	# Emblema central.
	var emblema: MeshInstance3D = MeshInstance3D.new()
	var disco: CylinderMesh = CylinderMesh.new()
	disco.top_radius = 1.4
	disco.bottom_radius = 1.4
	disco.height = 0.08
	disco.radial_segments = 40
	emblema.mesh = disco
	emblema.position = Vector3(0.0, 0.5, 0.0)
	emblema.material_override = _material(Color(0.12, 0.3, 0.45), 0.25)
	_arena.add_child(emblema)

	# Pilares de contenção com topos luminosos.
	var mat_pilar: StandardMaterial3D = StandardMaterial3D.new()
	mat_pilar.albedo_color = Color(0.12, 0.16, 0.24)
	mat_pilar.metallic = 0.8
	mat_pilar.roughness = 0.3
	var mat_luz: StandardMaterial3D = _material(Color(0.45, 0.98, 1.0), 3.2)
	for i: int in range(8):
		var ang: float = TAU * float(i) / 8.0
		var pos: Vector3 = Vector3(cos(ang) * (RAIO_PLATAFORMA - 1.2), 1.6, sin(ang) * (RAIO_PLATAFORMA - 1.2))
		var pilar: MeshInstance3D = MeshInstance3D.new()
		var caixa: BoxMesh = BoxMesh.new()
		caixa.size = Vector3(0.55, 3.2, 0.55)
		pilar.mesh = caixa
		pilar.position = pos
		pilar.rotation = Vector3(0.0, -ang, 0.0)
		pilar.material_override = mat_pilar
		_arena.add_child(pilar)
		var topo: MeshInstance3D = MeshInstance3D.new()
		var esfera_topo: SphereMesh = SphereMesh.new()
		esfera_topo.radius = 0.34
		esfera_topo.height = 0.68
		esfera_topo.radial_segments = 12
		esfera_topo.rings = 6
		topo.mesh = esfera_topo
		topo.position = pos + Vector3(0.0, 1.75, 0.0)
		topo.material_override = mat_luz
		_arena.add_child(topo)


func _direcao_aleatoria() -> Vector3:
	var z: float = randf_range(-1.0, 1.0)
	var a: float = randf() * TAU
	var r: float = sqrt(maxf(0.0, 1.0 - z * z))
	return Vector3(r * cos(a), z, r * sin(a))


func _criar_terra_gigante() -> void:
	## Terra GIGANTE logo abaixo da arena: preenche o fundo da tela e dá a
	## sensação de estar duelando em órbita.
	_terra = MeshInstance3D.new()
	_terra.name = "Terra"
	var esfera: SphereMesh = SphereMesh.new()
	esfera.radius = RAIO_TERRA
	esfera.height = RAIO_TERRA * 2.0
	esfera.radial_segments = 128
	esfera.rings = 64
	_terra.mesh = esfera
	_terra.position = Vector3(0.0, -149.0, -165.0)
	var mat: StandardMaterial3D = StandardMaterial3D.new()
	mat.albedo_color = Color(0.05, 0.2, 0.5)
	mat.emission_enabled = true
	mat.emission = Color(0.04, 0.14, 0.36)
	mat.emission_energy_multiplier = 0.6
	mat.roughness = 0.9
	_terra.material_override = mat
	_mundo.add_child(_terra)

	# Continentes: manchas achatadas coladas na superfície.
	var cores_terra: Array[Color] = [
		Color(0.18, 0.5, 0.24), Color(0.3, 0.46, 0.16),
		Color(0.6, 0.5, 0.24), Color(0.34, 0.54, 0.32),
	]
	for i: int in range(30):
		var mancha: MeshInstance3D = MeshInstance3D.new()
		var m2: SphereMesh = SphereMesh.new()
		m2.radius = randf_range(14.0, 42.0)
		m2.height = m2.radius * 2.0
		m2.radial_segments = 20
		m2.rings = 10
		mancha.mesh = m2
		var dir: Vector3 = _direcao_aleatoria()
		mancha.position = dir * (RAIO_TERRA * 0.985)
		var up: Vector3 = Vector3.RIGHT if absf(dir.y) > 0.97 else Vector3.UP
		mancha.look_at(Vector3.ZERO, up)
		# Achatada contra a superfície: continente, não montanha saindo do planeta.
		mancha.scale = Vector3(1.0, 1.0, 0.05)
		mancha.material_override = _material(cores_terra[i % cores_terra.size()], 0.25)
		_terra.add_child(mancha)

	# Camada de nuvens girando um pouco mais rápido que o planeta.
	_nuvens = Node3D.new()
	_nuvens.name = "Nuvens"
	_nuvens.position = _terra.position
	_mundo.add_child(_nuvens)
	var mat_nuvem: StandardMaterial3D = _material(Color(0.92, 0.96, 1.0), 0.1)
	mat_nuvem.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat_nuvem.albedo_color = Color(0.92, 0.96, 1.0, 0.22)
	for i: int in range(16):
		var nuvem: MeshInstance3D = MeshInstance3D.new()
		var n_esfera: SphereMesh = SphereMesh.new()
		n_esfera.radius = randf_range(8.0, 20.0)
		n_esfera.height = n_esfera.radius * 2.0
		n_esfera.radial_segments = 14
		n_esfera.rings = 7
		nuvem.mesh = n_esfera
		var dir: Vector3 = _direcao_aleatoria()
		nuvem.position = dir * (RAIO_TERRA * 1.005)
		var up: Vector3 = Vector3.RIGHT if absf(dir.y) > 0.97 else Vector3.UP
		nuvem.look_at(Vector3.ZERO, up)
		nuvem.scale = Vector3(2.1, 0.75, 0.12)
		nuvem.material_override = mat_nuvem
		_nuvens.add_child(nuvem)

	# Atmosfera: só as faces internas aparecem, formando o halo azul na borda.
	var atmosfera: MeshInstance3D = MeshInstance3D.new()
	var a_esfera: SphereMesh = SphereMesh.new()
	a_esfera.radius = RAIO_TERRA * 1.035
	a_esfera.height = RAIO_TERRA * 2.07
	a_esfera.radial_segments = 96
	a_esfera.rings = 48
	atmosfera.mesh = a_esfera
	atmosfera.position = _terra.position
	var mat_a: StandardMaterial3D = StandardMaterial3D.new()
	mat_a.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat_a.albedo_color = Color(0.3, 0.7, 1.0, 0.32)
	mat_a.emission_enabled = true
	mat_a.emission = Color(0.22, 0.6, 1.0)
	mat_a.emission_energy_multiplier = 0.9
	mat_a.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat_a.cull_mode = BaseMaterial3D.CULL_FRONT
	atmosfera.material_override = mat_a
	_mundo.add_child(atmosfera)

	# Lua.
	var lua: MeshInstance3D = MeshInstance3D.new()
	var lua_esfera: SphereMesh = SphereMesh.new()
	lua_esfera.radius = 12.0
	lua_esfera.height = 24.0
	lua_esfera.radial_segments = 40
	lua_esfera.rings = 20
	lua.mesh = lua_esfera
	lua.position = Vector3(176.0, -74.0, -252.0)
	lua.material_override = _material(Color(0.55, 0.58, 0.62), 0.1)
	_mundo.add_child(lua)


func _criar_planetas() -> void:
	## Outros mundos no horizonte: gigante gasoso com anéis, deserto vermelho,
	## planeta gelado e uma lua distante.
	_planetas.append(_criar_planeta(Vector3(-108.0, 64.0, -232.0), 30.0, Color(0.82, 0.55, 0.32), true))
	_planetas.append(_criar_planeta(Vector3(122.0, -70.0, -200.0), 18.0, Color(0.72, 0.26, 0.2), false))
	_planetas.append(_criar_planeta(Vector3(-152.0, -26.0, -66.0), 12.0, Color(0.5, 0.78, 0.95), false))
	_planetas.append(_criar_planeta(Vector3(156.0, 46.0, -262.0), 9.0, Color(0.78, 0.72, 0.62), false))


func _criar_planeta(pos: Vector3, raio: float, cor: Color, com_anel: bool) -> Node3D:
	var corpo: Node3D = Node3D.new()
	corpo.position = pos
	_mundo.add_child(corpo)
	var corpo_mesh: MeshInstance3D = MeshInstance3D.new()
	var esfera: SphereMesh = SphereMesh.new()
	esfera.radius = raio
	esfera.height = raio * 2.0
	esfera.radial_segments = 48
	esfera.rings = 24
	corpo_mesh.mesh = esfera
	var mat: StandardMaterial3D = StandardMaterial3D.new()
	mat.albedo_color = cor
	mat.emission_enabled = true
	mat.emission = cor
	mat.emission_energy_multiplier = 0.38
	mat.roughness = 0.82
	corpo_mesh.material_override = mat
	corpo.add_child(corpo_mesh)
	if com_anel:
		var anel: MeshInstance3D = MeshInstance3D.new()
		var toro: TorusMesh = TorusMesh.new()
		toro.inner_radius = raio * 1.45
		toro.outer_radius = raio * 2.35
		toro.rings = 120
		toro.ring_segments = 4
		anel.mesh = toro
		anel.scale = Vector3(1.0, 0.06, 1.0)
		anel.rotation = Vector3(deg_to_rad(16.0), 0.0, deg_to_rad(-14.0))
		anel.material_override = _material(cor.lerp(Color.WHITE, 0.4), 0.6)
		corpo.add_child(anel)
	# Halo tênue: as faces internas aparecem na borda do planeta.
	var halo: MeshInstance3D = MeshInstance3D.new()
	var h_esfera: SphereMesh = SphereMesh.new()
	h_esfera.radius = raio * 1.07
	h_esfera.height = raio * 2.14
	h_esfera.radial_segments = 32
	h_esfera.rings = 16
	halo.mesh = h_esfera
	var mat_h: StandardMaterial3D = StandardMaterial3D.new()
	mat_h.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat_h.albedo_color = Color(cor.r, cor.g, cor.b, 0.14)
	mat_h.emission_enabled = true
	mat_h.emission = cor.lerp(Color.WHITE, 0.2)
	mat_h.emission_energy_multiplier = 0.7
	mat_h.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat_h.cull_mode = BaseMaterial3D.CULL_FRONT
	halo.material_override = mat_h
	corpo.add_child(halo)
	return corpo


func _criar_nebulosas() -> void:
	## Manchas de poeira estelar bem ao fundo, para o espaço não ficar vazio.
	var tex: Texture2D = load("res://sprites/particulas/plasma.png") as Texture2D
	if tex == null:
		return
	var dados: Array = [
		[Vector3(-330.0, 120.0, -520.0), Color(0.35, 0.45, 1.0, 0.11), 7.0],
		[Vector3(300.0, -80.0, -470.0), Color(0.75, 0.35, 0.9, 0.09), 9.0],
		[Vector3(60.0, 210.0, -560.0), Color(0.3, 0.8, 0.85, 0.08), 11.0],
	]
	for item_v: Variant in dados:
		var item: Array = item_v as Array
		var neb: Sprite3D = Sprite3D.new()
		neb.texture = tex
		neb.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		neb.pixel_size = float(item[2])
		neb.position = item[0] as Vector3
		neb.modulate = item[1] as Color
		_mundo.add_child(neb)


func _criar_estrelas() -> void:
	## Milhares de estrelas em uma única MultiMesh: custa quase nada renderizar.
	var malha: SphereMesh = SphereMesh.new()
	malha.radius = 0.3
	malha.height = 0.6
	malha.radial_segments = 6
	malha.rings = 3
	var mm: MultiMesh = MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = malha
	mm.instance_count = 900
	for i: int in range(mm.instance_count):
		var dir: Vector3 = _direcao_aleatoria()
		var raio: float = randf_range(70.0, 330.0)
		var escala: float = randf_range(0.5, 1.5)
		var base: Basis = Basis.from_scale(Vector3.ONE * escala)
		mm.set_instance_transform(i, Transform3D(base, dir * raio))
	_estrelas = MultiMeshInstance3D.new()
	_estrelas.name = "Estrelas"
	_estrelas.multimesh = mm
	_estrelas.material_override = _material(Color(0.9, 0.96, 1.0), 3.4)
	_mundo.add_child(_estrelas)


func _atualizar_corpos(delta: float) -> void:
	if _terra == null:
		return
	_terra.rotation.y += delta * 0.02
	if _nuvens != null:
		_nuvens.rotation.y += delta * 0.032
	for i: int in range(_planetas.size()):
		var corpo: Node3D = _planetas[i]
		if is_instance_valid(corpo):
			corpo.rotation.y += delta * (0.05 + 0.02 * float(i))


func _criar_chefe() -> void:
	_chefe = Node3D.new()
	_chefe.name = "ElementoSupremo"
	_chefe.position = Vector3(0.0, 2.2, -12.0)
	_mundo.add_child(_chefe)
	var nucleo: MeshInstance3D = MeshInstance3D.new()
	var esfera: SphereMesh = SphereMesh.new()
	esfera.radius = 1.35
	esfera.height = 2.7
	esfera.radial_segments = 32
	esfera.rings = 16
	nucleo.mesh = esfera
	_mat_chefe = _material(Color(1.0, 0.55, 0.28), 2.6)
	nucleo.material_override = _mat_chefe
	_chefe.add_child(nucleo)
	# Anéis de energia.
	for i: int in range(3):
		var anel: MeshInstance3D = MeshInstance3D.new()
		var toro: TorusMesh = TorusMesh.new()
		toro.inner_radius = 1.7 + float(i) * 0.45
		toro.outer_radius = 1.85 + float(i) * 0.45
		anel.mesh = toro
		anel.rotation = Vector3(randf() * PI, randf() * PI, randf() * PI)
		anel.material_override = _material(Color(1.0, 0.72, 0.35), 1.8)
		_chefe.add_child(anel)
	# Asas de elétrons orbitando.
	_mat_eletron = _material(Color(0.55, 0.95, 1.0), 3.0)
	for i: int in range(18):
		var eletron: MeshInstance3D = MeshInstance3D.new()
		var e_esfera: SphereMesh = SphereMesh.new()
		e_esfera.radius = 0.16
		e_esfera.height = 0.32
		eletron.mesh = e_esfera
		eletron.material_override = _mat_eletron
		_chefe.add_child(eletron)
		_eletrons.append(eletron)


func _process(delta: float) -> void:
	if _terminando:
		return
	_tempo += delta
	_atualizar_chefe(delta)
	_atualizar_corpos(delta)
	_atualizar_camera(delta)
	_atualizar_tiros(delta)
	_atualizar_balas(delta)
	_atualizar_rastros(delta)
	_animar_viewmodel(delta)
	_cooldown_tiro = maxf(0.0, _cooldown_tiro - delta)
	_cooldown_onda -= delta
	_cooldown_mirado -= delta
	if _cooldown_onda <= 0.0:
		_cooldown_onda = 2.7
		_onda_radial()
	if _cooldown_mirado <= 0.0:
		_cooldown_mirado = 4.0
		_rajada_mirada()
	if Input.is_action_pressed("tiro_primario") and _cooldown_tiro <= 0.0:
		_atirar()
	if _barra != null:
		_barra.value = _vida_chefe
	if _barra_jogador != null:
		_barra_jogador.value = _vida_jogador


func _atualizar_chefe(delta: float) -> void:
	if _chefe == null:
		return
	var t: float = _tempo
	_chefe.position = Vector3(sin(t * 0.55) * 6.5, 2.2 + sin(t * 0.9) * 1.3, -11.5 + cos(t * 0.4) * 3.2)
	_chefe.rotation = Vector3(sin(t * 0.7) * 0.15, t * 0.4, cos(t * 0.5) * 0.12)
	for i: int in range(_eletrons.size()):
		var e: MeshInstance3D = _eletrons[i]
		if not is_instance_valid(e):
			continue
		var lado: float = 1.0 if i % 2 == 0 else -1.0
		var ang: float = t * 2.4 + TAU * float(i) / float(_eletrons.size())
		var raio: float = 2.2 + float(i % 4) * 0.45
		e.position = Vector3(cos(ang) * raio * 1.35, sin(ang * 1.3) * 0.9, sin(ang) * raio * 0.45 + lado * 0.2)
	if _mat_chefe != null:
		_mat_chefe.emission_energy_multiplier = 2.2 + sin(t * 4.0) * 0.7


func _atualizar_camera(delta: float) -> void:
	if _camera == null:
		return
	var frente: Vector3 = Vector3(-sin(_yaw), 0.0, -cos(_yaw))
	var direita: Vector3 = Vector3(cos(_yaw), 0.0, -sin(_yaw))
	var dir: Vector3 = Vector3.ZERO
	if Input.is_action_pressed("mover_cima"):
		dir += frente
	if Input.is_action_pressed("mover_baixo"):
		dir -= frente
	if Input.is_action_pressed("mover_direita"):
		dir += direita
	if Input.is_action_pressed("mover_esquerda"):
		dir -= direita
	if Input.is_key_pressed(KEY_SPACE):
		dir += Vector3.UP
	if Input.is_key_pressed(KEY_CTRL) or Input.is_key_pressed(KEY_C):
		dir -= Vector3.UP
	_movendo = dir.length() > 0.1
	if _movendo:
		_pos_jogador += dir.normalized() * VELOCIDADE_JOGADOR * delta
		_pos_jogador.x = clampf(_pos_jogador.x, -RAIO_ARENA, RAIO_ARENA)
		_pos_jogador.y = clampf(_pos_jogador.y, 0.8, 7.0)
		_pos_jogador.z = clampf(_pos_jogador.z, -4.0, 10.0)
	_camera.position = _pos_jogador
	_camera.rotation = Vector3(_pitch, _yaw, 0.0)


func _unhandled_input(evento: InputEvent) -> void:
	if _terminando:
		return
	if evento is InputEventMouseMotion:
		var mov: InputEventMouseMotion = evento as InputEventMouseMotion
		_yaw -= mov.relative.x * 0.0022
		_pitch = clampf(_pitch - mov.relative.y * 0.0022, -1.15, 0.9)
		_sway = (_sway + Vector2(mov.relative.x * 0.05, mov.relative.y * 0.05)).limit_length(16.0)
	elif evento is InputEventMouseButton:
		var clique: InputEventMouseButton = evento as InputEventMouseButton
		if clique.pressed and clique.button_index == MOUSE_BUTTON_LEFT:
			_atirar()
		get_viewport().set_input_as_handled()


func _atirar() -> void:
	if _cooldown_tiro > 0.0 or _camera == null or _chefe == null:
		return
	_cooldown_tiro = 1.0 / maxf(0.6, _cadencia)
	var tamanho: Vector2 = _viewport.size
	var origem: Vector3 = _camera.project_ray_origin(tamanho * 0.5)
	var direcao: Vector3 = _camera.project_ray_normal(tamanho * 0.5)
	# Boca do cano um pouco à frente e à direita: o viewmodel fica nesse canto.
	var boca: Vector3 = origem + direcao * 1.6 + _camera.global_basis * Vector3(1.0, -0.72, 0.0)
	for i: int in range(_projeteis):
		var dir: Vector3 = direcao
		if _projeteis > 1:
			# Leque: armas de múltiplos projéteis abrem as balas na horizontal.
			var abertura: float = maxf(_dispersao, 4.0 + 3.0 * float(_projeteis - 1))
			var passo: float = deg_to_rad(abertura) * 2.0 / float(_projeteis - 1)
			dir = direcao.rotated(Vector3.UP, -deg_to_rad(abertura) + passo * float(i))
		dir = _espalhar(dir, _dispersao * 0.45)
		_criar_bala(boca, dir, randf() < _critico_chance)
	_criar_flash(boca, _cor_arma, 0.1)
	_flash_tempo = 0.07
	_recuo = minf(1.2, _recuo + 0.55)
	AudioManager.tocar_sfx(_arma.som if _arma != null else "tiro", -8.0, 0.05)


func _espalhar(dir: Vector3, graus: float) -> Vector3:
	if graus <= 0.01:
		return dir
	var lateral: Vector3 = dir.cross(Vector3.UP)
	if lateral.length() < 0.001:
		lateral = Vector3.RIGHT
	lateral = lateral.normalized()
	var vertical: Vector3 = lateral.cross(dir).normalized()
	var a_h: float = deg_to_rad(randf_range(-graus, graus))
	var a_v: float = deg_to_rad(randf_range(-graus, graus))
	return (dir + lateral * sin(a_h) * 0.4 + vertical * sin(a_v) * 0.4).normalized()


func _criar_bala(origem: Vector3, dir: Vector3, critico: bool) -> void:
	## Bala visível de verdade: caixa luminosa alongada que viaja até o chefe.
	var bala: MeshInstance3D = MeshInstance3D.new()
	var caixa: BoxMesh = BoxMesh.new()
	var comprimento: float = 2.4 * _tamanho_bala * (1.5 if critico else 1.0)
	var largura: float = 0.16 * _tamanho_bala
	caixa.size = Vector3(largura, largura, comprimento)
	bala.mesh = caixa
	var cor: Color = Color(1.0, 0.86, 0.35) if critico else _cor_arma.lerp(Color.WHITE, 0.45)
	var mat: StandardMaterial3D = _material(cor, 7.0)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color = Color(cor.r, cor.g, cor.b, 0.95)
	bala.material_override = mat
	_mundo.add_child(bala)
	bala.position = origem
	bala.look_at(origem + dir, Vector3.UP)
	# Brilho sempre virado para a câmera: a bala fica legível mesmo indo embora.
	var brilho: Sprite3D = Sprite3D.new()
	var tex_brilho: Texture2D = load("res://sprites/particulas/plasma.png") as Texture2D
	if tex_brilho == null:
		tex_brilho = load("res://sprites/props/particula.png") as Texture2D
	if tex_brilho != null:
		brilho.texture = tex_brilho
		brilho.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		brilho.no_depth_test = true
		brilho.pixel_size = 0.02
		brilho.scale = Vector3.ONE * (1.1 * _tamanho_bala * (1.4 if critico else 1.0))
		brilho.modulate = cor
		bala.add_child(brilho)
	bala.set_meta("vel", dir * _vel_bala)
	bala.set_meta("dano", _dano_tiro * (1.6 if critico else 1.0))
	bala.set_meta("critico", critico)
	bala.set_meta("vida", 2.4)
	_balas.append(bala)


func _atualizar_balas(delta: float) -> void:
	if _chefe == null:
		_balas.clear()
		return
	for i: int in range(_balas.size() - 1, -1, -1):
		var bala: MeshInstance3D = _balas[i]
		if not is_instance_valid(bala):
			_balas.remove_at(i)
			continue
		var vel: Vector3 = bala.get_meta("vel", Vector3.ZERO) as Vector3
		bala.position += vel * delta
		var vida: float = float(bala.get_meta("vida", 1.0)) - delta
		bala.set_meta("vida", vida)
		var raio_chefe: float = 1.9 + 0.15 * _tamanho_bala
		if bala.position.distance_to(_chefe.global_position) < raio_chefe:
			var critico: bool = bool(bala.get_meta("critico", false))
			var dano: float = float(bala.get_meta("dano", 10.0))
			_criar_flash(bala.position, Color(1.0, 0.9, 0.45) if critico else Color(1.0, 0.62, 0.28), 0.8 if critico else 0.5)
			_vida_chefe = maxf(0.0, _vida_chefe - dano)
			if _mat_chefe != null:
				_mat_chefe.emission_energy_multiplier = 6.0
			AudioManager.tocar_sfx("hit", -8.0, 0.04)
			bala.queue_free()
			_balas.remove_at(i)
			if _vida_chefe <= 0.0:
				_finalizar(true)
				return
			continue
		if vida <= 0.0 or bala.position.distance_to(Vector3.ZERO) > 120.0:
			bala.queue_free()
			_balas.remove_at(i)


func _criar_rastro(origem: Vector3, destino: Vector3) -> void:
	var rastro: MeshInstance3D = MeshInstance3D.new()
	var caixa: BoxMesh = BoxMesh.new()
	var comprimento: float = origem.distance_to(destino)
	caixa.size = Vector3(0.09, 0.09, maxf(0.1, comprimento))
	rastro.mesh = caixa
	_mat_laser = _material(Color(0.55, 1.0, 1.0), 4.0)
	_mat_laser.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rastro.material_override = _mat_laser
	_mundo.add_child(rastro)
	var meio: Vector3 = (origem + destino) * 0.5
	rastro.position = meio
	rastro.look_at(destino, Vector3.UP)
	_rastros.append(rastro)


func _criar_flash(posicao: Vector3, cor: Color, raio: float) -> void:
	var flash: MeshInstance3D = MeshInstance3D.new()
	var esfera: SphereMesh = SphereMesh.new()
	esfera.radius = raio
	esfera.height = raio * 2.0
	flash.mesh = esfera
	var mat: StandardMaterial3D = _material(cor, 4.0)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	flash.material_override = mat
	flash.position = posicao
	_mundo.add_child(flash)
	_rastros.append(flash)


func _atualizar_rastros(delta: float) -> void:
	for i: int in range(_rastros.size() - 1, -1, -1):
		var r: MeshInstance3D = _rastros[i]
		if not is_instance_valid(r):
			_rastros.remove_at(i)
			continue
		var mat: StandardMaterial3D = r.material_override as StandardMaterial3D
		if mat != null:
			mat.albedo_color.a = maxf(0.0, mat.albedo_color.a - delta * 1.5)
		if mat == null or mat.albedo_color.a <= 0.01:
			r.queue_free()
			_rastros.remove_at(i)


func _onda_radial() -> void:
	if _chefe == null:
		return
	var centro: Vector3 = _chefe.global_position
	var para_jogador: Vector3 = (_pos_jogador - centro).normalized()
	for i: int in range(16):
		var ang: float = TAU * float(i) / 16.0
		var dir: Vector3 = Vector3(cos(ang), sin(ang) * 0.55, sin(ang)).normalized()
		# Mistura um pouco da direção do jogador para não ser trivial.
		dir = (dir + para_jogador * 0.25).normalized()
		_criar_tiro(centro, dir, 5.8, 13.0)
	AudioManager.tocar_sfx("explosao", -8.0, 0.06)


func _rajada_mirada() -> void:
	if _chefe == null:
		return
	var centro: Vector3 = _chefe.global_position
	var base: Vector3 = (_pos_jogador - centro).normalized()
	for i: int in range(5):
		var desvio: Vector3 = Vector3(randf_range(-0.18, 0.18), randf_range(-0.12, 0.12), randf_range(-0.18, 0.18))
		_criar_tiro(centro, (base + desvio).normalized(), 7.5, 11.0)
	AudioManager.tocar_sfx("tiro_pesado", -10.0, 0.05)


func _criar_tiro(origem: Vector3, dir: Vector3, vel: float, dano: float) -> void:
	var tiro: MeshInstance3D = MeshInstance3D.new()
	var esfera: SphereMesh = SphereMesh.new()
	esfera.radius = 0.22
	esfera.height = 0.44
	tiro.mesh = esfera
	_mat_tiro = _material(Color(1.0, 0.25, 0.35), 2.6)
	tiro.material_override = _mat_tiro
	tiro.position = origem
	tiro.set_meta("vel", dir * vel)
	tiro.set_meta("dano", dano)
	_mundo.add_child(tiro)
	_tiros.append(tiro)


func _atualizar_tiros(delta: float) -> void:
	for i: int in range(_tiros.size() - 1, -1, -1):
		var tiro: MeshInstance3D = _tiros[i]
		if not is_instance_valid(tiro):
			_tiros.remove_at(i)
			continue
		var vel: Vector3 = tiro.get_meta("vel", Vector3.ZERO) as Vector3
		tiro.position += vel * delta
		var d: float = tiro.position.distance_to(_pos_jogador)
		if d < 0.85:
			var dano: float = float(tiro.get_meta("dano", 10.0))
			_dano_jogador(dano)
			tiro.queue_free()
			_tiros.remove_at(i)
			continue
		if tiro.position.distance_to(Vector3.ZERO) > 130.0 or tiro.position.z < -90.0:
			tiro.queue_free()
			_tiros.remove_at(i)


func _dano_jogador(valor: float) -> void:
	_vida_jogador = maxf(0.0, _vida_jogador - valor)
	AudioManager.tocar_sfx("dano", -5.0, 0.06)
	if _label_aviso != null:
		_label_aviso.text = "IMPACTO — INTEGRIDADE %d%%" % int(round(_vida_jogador))
		_label_aviso.add_theme_color_override("font_color", UI.COR_VERMELHO)
	if _vida_jogador <= 0.0:
		_finalizar(false)


func _finalizar(venceu: bool) -> void:
	if _terminando:
		return
	_terminando = true
	if venceu:
		if _label_aviso != null:
			_label_aviso.text = "NÚCLEO DESTRUÍDO — RETORNANDO AO LABORATÓRIO"
			_label_aviso.add_theme_color_override("font_color", UI.COR_CIANO)
		AudioManager.tocar_sfx("explosao", 0.0, 0.03)
		Efeitos.tremor(26.0)
	else:
		if _label_aviso != null:
			_label_aviso.text = "INTEGRIDADE ZERO — VOLTANDO À ARENA"
			_label_aviso.add_theme_color_override("font_color", UI.COR_VERMELHO)
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	get_tree().paused = false
	concluida.emit(venceu)
	queue_free()
