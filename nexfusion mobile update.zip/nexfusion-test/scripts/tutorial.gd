extends Control
## Tutorial rápido mostrado antes da primeira partida de um save novo.
## Pode ser pulado a qualquer momento pelo botão PULAR TUTORIAL ou por ESC.

const PAGINAS: Array = [
	{
		"titulo": "OBJETIVO",
		"cor": Color("8ff3ff"),
		"linhas": [
			"Sobreviva às hordas de criaturas químicas e chegue à horda 31, onde o Elemento Supremo espera.",
			"Cada horda derrotada avança a fase e deixa os inimigos mais fortes.",
			"Colete moedas ◈ e orbes de XP que caem dos inimigos abatidos.",
			"Moedas compram cartas permanentes na Loja, fora da partida.",
		],
	},
	{
		"titulo": "CONTROLES",
		"cor": Color("5fe08a"),
		"linhas": [],
		"mobile": [
			"Analógico esquerdo: mover. Analógico direito: mirar e atirar.",
			"Botões na tela: tiro, tiro carregado, dash e parry.",
			"Toque nos ícones do HUD para inventário e pausa.",
			"Deite o celular na horizontal para jogar com mais espaço.",
		],
		"desktop": [
			"WASD ou setas: mover. Mouse: mirar.",
			"Clique esquerdo: tiro. Clique direito: tiro carregado.",
			"Espaço ou Shift: dash com esquiva (3 cargas).",
			"F: aparar golpes. TAB: inventário. ESC: pausa.",
		],
	},
	{
		"titulo": "EVOLUÇÃO",
		"cor": Color("ffcf4a"),
		"linhas": [
			"Ao subir de nível, escolha 1 entre 3 cartas — cada uma muda o seu jeito de jogar.",
			"O mercador aparece entre as hordas: troque moedas da run por cartas extras.",
			"Combos rápidos sobem o rank de estilo (D até ULTRAQUÍMICO) e multiplicam seus pontos.",
			"Na Câmara de Fusão você combina elementos e libera armas novas.",
		],
	},
	{
		"titulo": "CO-OP LAN",
		"cor": Color("ff5fd2"),
		"linhas": [
			"Até 4 jogadores na mesma rede (Wi-Fi ou cabo), computadores e celulares juntos.",
			"Um jogador abre a sala em MULTIPLAYER (LAN) e os outros entram pela tabela de salas abertas.",
			"Se a sala não aparecer, conecte pelo IP do host mostrado na tela LAN.",
			"Quem abre a sala comanda a simulação: os convidados acompanham pelo host.",
		],
	},
]

var _total_paginas: int = 0
var _pagina: int = 0
var _b_titulo: Label
var _b_corpo: Label
var _b_contador: Label
var _b_voltar: Button
var _b_proximo: Button
var _saindo: bool = false


func _ready() -> void:
	GlobalManager.definir_cursor(true)
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var fundo: ColorRect = ColorRect.new()
	fundo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fundo.color = Color(0.03, 0.045, 0.07)
	add_child(fundo)

	var margem: MarginContainer = MarginContainer.new()
	margem.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for lado: String in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		margem.add_theme_constant_override(lado, 24)
	add_child(margem)
	var centro: VBoxContainer = VBoxContainer.new()
	centro.alignment = BoxContainer.ALIGNMENT_CENTER
	centro.add_theme_constant_override("separation", 10)
	margem.add_child(centro)

	centro.add_child(UI.titulo("TUTORIAL", 38, UI.COR_CIANO))
	var sub: Label = UI.rotulo("Como funciona o NEXFUSION — dá para pular quando quiser.", 14, UI.COR_TEXTO_FRACO)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	centro.add_child(sub)

	var painel: PanelContainer = PanelContainer.new()
	painel.add_theme_stylebox_override("panel", UI.estilo_painel())
	painel.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	centro.add_child(painel)
	var caixa: VBoxContainer = VBoxContainer.new()
	caixa.add_theme_constant_override("separation", 8)
	painel.add_child(caixa)
	_b_titulo = UI.titulo("", 30, UI.COR_CIANO)
	caixa.add_child(_b_titulo)
	var rolagem: ScrollContainer = ScrollContainer.new()
	rolagem.custom_minimum_size = Vector2(900, 300)
	rolagem.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	caixa.add_child(rolagem)
	_b_corpo = UI.rotulo("", 18, UI.COR_TEXTO)
	_b_corpo.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_b_corpo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_b_corpo.custom_minimum_size = Vector2(880, 0)
	rolagem.add_child(_b_corpo)
	_b_contador = UI.rotulo("", 12, UI.COR_TEXTO_FRACO)
	_b_contador.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	caixa.add_child(_b_contador)

	var linha: HBoxContainer = HBoxContainer.new()
	linha.alignment = BoxContainer.ALIGNMENT_CENTER
	linha.add_theme_constant_override("separation", 12)
	centro.add_child(linha)
	_b_voltar = UI.botao("← VOLTAR", 16, UI.COR_TEXTO_FRACO)
	_b_voltar.custom_minimum_size = Vector2(200, 48)
	_b_voltar.pressed.connect(_voltar)
	linha.add_child(_b_voltar)
	var b_pular: Button = UI.botao("PULAR TUTORIAL", 16, UI.COR_AMBAR)
	b_pular.custom_minimum_size = Vector2(220, 48)
	b_pular.pressed.connect(_pular)
	linha.add_child(b_pular)
	_b_proximo = UI.botao("PRÓXIMO →", 18, UI.COR_VERDE)
	_b_proximo.custom_minimum_size = Vector2(240, 48)
	_b_proximo.pressed.connect(_proximo)
	linha.add_child(_b_proximo)

	var dica: Label = UI.rotulo("ESC também pula o tutorial.", 12, UI.COR_TEXTO_FRACO)
	dica.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	centro.add_child(dica)

	_total_paginas = PAGINAS.size()
	_mostrar_pagina(0)
	AudioManager.tocar_bgm("menu")


func _mostrar_pagina(indice: int) -> void:
	_pagina = clampi(indice, 0, _total_paginas - 1)
	var dados: Dictionary = PAGINAS[_pagina]
	_b_titulo.text = String(dados["titulo"])
	var cor: Color = dados["cor"]
	_b_titulo.add_theme_color_override("font_color", cor)
	var linhas: Array = dados["linhas"]
	if linhas.is_empty():
		linhas = dados["mobile"] if GlobalManager.modo_mobile else dados["desktop"]
	var texto: String = ""
	for l: String in linhas:
		texto += "•  %s\n\n" % l
	_b_corpo.text = texto.strip_edges()
	_b_contador.text = "PÁGINA %d DE %d" % [_pagina + 1, _total_paginas]
	_b_voltar.visible = _pagina > 0
	_b_proximo.text = "COMEÇAR" if _pagina == _total_paginas - 1 else "PRÓXIMO →"


func _voltar() -> void:
	_mostrar_pagina(_pagina - 1)


func _proximo() -> void:
	if _pagina >= _total_paginas - 1:
		_iniciar()
		return
	_mostrar_pagina(_pagina + 1)


func _pular() -> void:
	_iniciar()


func _iniciar() -> void:
	if _saindo:
		return
	_saindo = true
	GlobalManager.definir_tutorial_visto()
	GlobalManager.horda_skip_alvo = 1
	get_tree().change_scene_to_file("res://scenes/jogo.tscn")


func _unhandled_input(evento: InputEvent) -> void:
	if evento.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		_pular()
