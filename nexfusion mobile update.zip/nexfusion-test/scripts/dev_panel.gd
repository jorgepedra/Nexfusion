class_name PainelDev
extends Control
## Painel de Desenvolvedor (Shift+P): progressão, arsenal, enxame, jogador e
## opções de mundo para testar o jogo sem reiniciar a run.
## Pausa a árvore enquanto estiver aberto.

signal fechar_solicitado

const PASTA_ARMAS: String = "res://resources/armas"

var _spawn: SpawnManager = null
var _jogador: Player = null
var _conteudo: VBoxContainer
var _status: Label
var _seletor_horda: SpinBox
var _seletor_mob: OptionButton
var _seletor_qtd: SpinBox
var _seletor_velocidade: OptionButton
var _b_deus: Button
var _b_fps: Button
var _b_qualidade: Button
var _mobs: Array[DadosInimigo] = []


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	z_index = 200
	visible = false


func abrir(spawn: SpawnManager, jogador: Player) -> void:
	_spawn = spawn
	_jogador = jogador
	_reconstruir()
	# Desenha por cima do HUD (senão vida/horda aparecem através do painel).
	if get_parent() != null:
		get_parent().move_child(self, get_parent().get_child_count() - 1)
	visible = true
	modulate.a = 0.0
	var tw: Tween = create_tween()
	tw.tween_property(self, "modulate:a", 1.0, 0.18)


func fechar() -> void:
	visible = false


func _unhandled_input(evento: InputEvent) -> void:
	if not visible:
		return
	var tecla: InputEventKey = evento as InputEventKey
	if tecla == null or not tecla.pressed or tecla.echo:
		return
	var codigo: int = tecla.physical_keycode if tecla.physical_keycode != 0 else tecla.keycode
	if codigo == KEY_P and tecla.shift_pressed:
		fechar_solicitado.emit()
		get_viewport().set_input_as_handled()
	elif codigo == KEY_ESCAPE:
		fechar_solicitado.emit()
		get_viewport().set_input_as_handled()


func _reconstruir() -> void:
	for filho: Node in get_children():
		filho.queue_free()
	_mobs.clear()
	if _spawn != null:
		_mobs = _spawn.catalogo()
	var fundo: ColorRect = ColorRect.new()
	fundo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fundo.color = Color(0.02, 0.03, 0.05, 0.96)
	add_child(fundo)

	var margem: MarginContainer = MarginContainer.new()
	margem.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margem.add_theme_constant_override("margin_left", 24)
	margem.add_theme_constant_override("margin_right", 24)
	margem.add_theme_constant_override("margin_top", 14)
	margem.add_theme_constant_override("margin_bottom", 14)
	add_child(margem)
	var rolagem: ScrollContainer = ScrollContainer.new()
	rolagem.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	rolagem.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	margem.add_child(rolagem)
	var centro: VBoxContainer = VBoxContainer.new()
	centro.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	centro.add_theme_constant_override("separation", 6)
	rolagem.add_child(centro)
	centro.add_child(UI.titulo("PAINEL DE DESENVOLVEDOR", 30, UI.COR_MAGENTA))
	var sub: Label = UI.rotulo("Shift + P abre e fecha  ·  a partida fica pausada", 12, UI.COR_TEXTO_FRACO)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	centro.add_child(sub)

	var painel: PanelContainer = PanelContainer.new()
	painel.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.06, 0.09, 0.14, 0.97), UI.COR_MAGENTA.darkened(0.4), 6))
	painel.custom_minimum_size = Vector2(880, 0)
	painel.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	centro.add_child(painel)
	_conteudo = VBoxContainer.new()
	_conteudo.add_theme_constant_override("separation", 6)
	painel.add_child(_conteudo)

	_linha_progressao()
	_linha_armas()
	_linha_enxame()
	_linha_jogador()
	_linha_mundo()
	_linha_desbloqueios()

	_status = UI.rotulo("Pronto.", 13, UI.COR_TEXTO_FRACO)
	_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	centro.add_child(_status)
	var b_fechar: Button = UI.botao("FECHAR  [Shift+P]", 16, UI.COR_CIANO)
	b_fechar.custom_minimum_size = Vector2(240, 38)
	b_fechar.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	b_fechar.pressed.connect(func() -> void: fechar_solicitado.emit())
	centro.add_child(b_fechar)


func _secao(texto: String) -> void:
	_conteudo.add_child(UI.separador(2.0))
	_conteudo.add_child(UI.rotulo(texto, 13, UI.COR_CIANO))


func _linha() -> HBoxContainer:
	var linha: HBoxContainer = HBoxContainer.new()
	linha.add_theme_constant_override("separation", 8)
	_conteudo.add_child(linha)
	return linha


func _botao(texto: String, cor: Color, largura: float = 0.0, altura: float = 34.0) -> Button:
	var b: Button = UI.botao(texto, 13, cor)
	b.custom_minimum_size = Vector2(largura, altura)
	if largura <= 0.0:
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return b


# ------------------------------------------------------------------ seções
func _linha_progressao() -> void:
	_secao("PROGRESSÃO")
	var linha: HBoxContainer = _linha()
	linha.add_child(UI.rotulo("Horda:", 14, UI.COR_TEXTO))
	_seletor_horda = SpinBox.new()
	_seletor_horda.min_value = 1.0
	_seletor_horda.max_value = float(GlobalManager.HORDA_MAXIMA)
	_seletor_horda.step = 1.0
	_seletor_horda.value = float(GlobalManager.horda_atual)
	_seletor_horda.custom_minimum_size = Vector2(100, 0)
	linha.add_child(_seletor_horda)
	var b_ir: Button = _botao("IR", UI.COR_AMBAR, 70.0)
	b_ir.pressed.connect(_ao_ir_horda)
	linha.add_child(b_ir)
	var b_ant: Button = _botao("◀", UI.COR_TEXTO_FRACO, 56.0)
	b_ant.pressed.connect(func() -> void: _ao_horda_relativa(-1))
	linha.add_child(b_ant)
	var b_prox: Button = _botao("▶", UI.COR_TEXTO_FRACO, 56.0)
	b_prox.pressed.connect(func() -> void: _ao_horda_relativa(1))
	linha.add_child(b_prox)
	var b_fase: Button = _botao("AVANÇAR FASE", UI.COR_VIOLETA, 170.0)
	b_fase.pressed.connect(_ao_avancar_fase)
	linha.add_child(b_fase)
	linha.add_child(UI.rotulo("Fase %d" % GlobalManager.fase, 14, UI.COR_TEXTO_FRACO))


func _linha_armas() -> void:
	var cabecalho: HBoxContainer = HBoxContainer.new()
	cabecalho.add_theme_constant_override("separation", 10)
	_conteudo.add_child(cabecalho)
	var titulo: Label = UI.rotulo("ARSENAL — EQUIPAR QUALQUER ARMA", 13, UI.COR_CIANO)
	titulo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cabecalho.add_child(titulo)
	var b_todas: Button = _botao("LIBERAR TODAS", UI.COR_AMBAR, 180.0, 30.0)
	b_todas.pressed.connect(_ao_liberar_armas)
	cabecalho.add_child(b_todas)
	var grade: GridContainer = GridContainer.new()
	grade.columns = 4
	grade.add_theme_constant_override("h_separation", 8)
	grade.add_theme_constant_override("v_separation", 6)
	_conteudo.add_child(grade)
	for arma: DadosArma in _armas_disponiveis():
		var equipada: bool = GlobalManager.arma_equipada == arma.id
		var b: Button = UI.botao("%s (%s)%s" % [arma.nome.to_upper(), arma.elemento, "  •" if equipada else ""], 13, arma.cor)
		b.custom_minimum_size = Vector2(205, 32)
		b.disabled = equipada
		b.pressed.connect(_ao_equipar.bind(arma.id))
		grade.add_child(b)


func _linha_enxame() -> void:
	_secao("ENXAME — SPAWNAR E LIMPAR")
	var linha: HBoxContainer = _linha()
	_seletor_mob = OptionButton.new()
	_seletor_mob.custom_minimum_size = Vector2(300, 38)
	_seletor_mob.add_theme_font_size_override("font_size", 13)
	for d: DadosInimigo in _mobs:
		_seletor_mob.add_item("%s (%s)%s" % [d.nome, d.elemento, "  [BOSS]" if d.is_boss else ""])
	linha.add_child(_seletor_mob)
	linha.add_child(UI.rotulo("Qtd:", 13, UI.COR_TEXTO))
	_seletor_qtd = SpinBox.new()
	_seletor_qtd.min_value = 1
	_seletor_qtd.max_value = 20
	_seletor_qtd.value = 1
	_seletor_qtd.custom_minimum_size = Vector2(80, 0)
	linha.add_child(_seletor_qtd)
	var b_spawn: Button = _botao("SPAWNAR", UI.COR_VERDE, 130.0)
	b_spawn.pressed.connect(_ao_spawnar)
	linha.add_child(b_spawn)
	var b_matar: Button = _botao("MATAR TODOS", UI.COR_VERMELHO, 150.0)
	b_matar.pressed.connect(_ao_matar_todos)
	linha.add_child(b_matar)

	var linha2: HBoxContainer = _linha()
	var b_chefes: Button = _botao("MATAR SÓ CHEFES", UI.COR_VERMELHO, 190.0)
	b_chefes.pressed.connect(_ao_matar_chefes)
	linha2.add_child(b_chefes)
	var b_1hp: Button = _botao("CHEFE COM 1 DE VIDA", UI.COR_AMBAR, 210.0)
	b_1hp.pressed.connect(_ao_chefe_1hp)
	linha2.add_child(b_1hp)
	var b_guarda: Button = _botao("DESTRUIR GUARDIÕES", UI.COR_VIOLETA, 200.0)
	b_guarda.pressed.connect(_ao_destruir_guardioes)
	linha2.add_child(b_guarda)


func _linha_jogador() -> void:
	_secao("JOGADOR")
	var linha: HBoxContainer = _linha()
	var b_vida: Button = _botao("CURAR TUDO", UI.COR_VERDE, 150.0)
	b_vida.pressed.connect(_ao_curar)
	linha.add_child(b_vida)
	_b_deus = _botao("VIDA INFINITA: %s" % ("ON" if _jogador != null and _jogador.modo_deus else "OFF"), UI.COR_VERDE if _jogador != null and _jogador.modo_deus else UI.COR_TEXTO_FRACO, 210.0)
	_b_deus.pressed.connect(_ao_deus)
	linha.add_child(_b_deus)
	var b_moedas: Button = _botao("MOEDAS +1000", UI.COR_AMBAR, 170.0)
	b_moedas.pressed.connect(_ao_moedas)
	linha.add_child(b_moedas)
	var b_xp: Button = _botao("XP +300", UI.COR_CIANO, 150.0)
	b_xp.pressed.connect(_ao_xp)
	linha.add_child(b_xp)


func _linha_mundo() -> void:
	_secao("MUNDO E RENDERIZAÇÃO")
	var linha: HBoxContainer = _linha()
	linha.add_child(UI.rotulo("Velocidade:", 14, UI.COR_TEXTO))
	_seletor_velocidade = OptionButton.new()
	_seletor_velocidade.custom_minimum_size = Vector2(120, 38)
	_seletor_velocidade.add_theme_font_size_override("font_size", 13)
	_seletor_velocidade.add_item("0,5x")
	_seletor_velocidade.add_item("1x")
	_seletor_velocidade.add_item("2x")
	_seletor_velocidade.select(1 if Engine.time_scale >= 0.95 else 0)
	_seletor_velocidade.item_selected.connect(_ao_velocidade)
	linha.add_child(_seletor_velocidade)
	_b_qualidade = _botao("QUALIDADE: %s" % GlobalManager.nome_qualidade(), UI.COR_VIOLETA, 230.0)
	_b_qualidade.pressed.connect(_ao_qualidade)
	linha.add_child(_b_qualidade)
	_b_fps = _botao("MOSTRAR FPS: %s" % ("ON" if GlobalManager.mostrar_fps else "OFF"), UI.COR_CIANO, 200.0)
	_b_fps.pressed.connect(_ao_fps)
	linha.add_child(_b_fps)


func _linha_desbloqueios() -> void:
	var linha: HBoxContainer = _linha()
	var b_conquistas: Button = _botao("DESBLOQUEAR CONQUISTAS", UI.COR_MAGENTA, 250.0)
	b_conquistas.pressed.connect(_ao_liberar_conquistas)
	linha.add_child(b_conquistas)
	var liberadas: int = 0
	for id: String in GlobalManager.CONQUISTAS.keys():
		if bool(GlobalManager.conquistas.get(id, false)):
			liberadas += 1
	var b_slots: Button = _botao("CONQUISTAS: %d/%d" % [liberadas, GlobalManager.CONQUISTAS.size()], UI.COR_TEXTO_FRACO, 190.0)
	b_slots.disabled = true
	linha.add_child(b_slots)


func _armas_disponiveis() -> Array[DadosArma]:
	var lista: Array[DadosArma] = []
	var dir: DirAccess = DirAccess.open(PASTA_ARMAS)
	if dir == null:
		return lista
	dir.list_dir_begin()
	var arquivo: String = dir.get_next()
	while arquivo != "":
		if arquivo.ends_with(".tres"):
			var rec: Resource = load(PASTA_ARMAS.path_join(arquivo))
			if rec is DadosArma:
				lista.append(rec as DadosArma)
		arquivo = dir.get_next()
	dir.list_dir_end()
	lista.sort_custom(func(a: DadosArma, b: DadosArma) -> bool: return a.custo < b.custo)
	return lista


# ------------------------------------------------------------------ ações
func _ao_ir_horda() -> void:
	if _spawn == null or not is_instance_valid(_spawn):
		_status.text = "Sem gerenciador de hordas na cena."
		return
	var alvo: int = int(_seletor_horda.value)
	if _spawn.definir_horda(alvo):
		_status.text = "Horda %d iniciada (fase %d)." % [alvo, GlobalManager.fase]
		AudioManager.tocar_sfx("horda", -6.0, 0.05)
	else:
		_status.text = "Não foi possível iniciar a horda."


func _ao_horda_relativa(passo: int) -> void:
	_seletor_horda.value = clampf(_seletor_horda.value + float(passo), 1.0, float(GlobalManager.HORDA_MAXIMA))
	_ao_ir_horda()


func _ao_avancar_fase() -> void:
	GlobalManager.avancar_fase()
	if _spawn != null and is_instance_valid(_spawn):
		_spawn.definir_horda(1)
	_status.text = "Fase %d iniciada na horda 1 (inimigos mais fortes, escala %.2fx)." % [GlobalManager.fase, GlobalManager.multiplicador_fase()]


func _ao_equipar(id: String) -> void:
	if not GlobalManager.armas_desbloqueadas.has(id):
		GlobalManager.armas_desbloqueadas.append(id)
	if GlobalManager.equipar_arma(id):
		if _jogador != null and is_instance_valid(_jogador):
			_jogador.atualizar_arma()
		AudioManager.tocar_sfx("clique", -6.0, 0.03)
		_reconstruir()
		_status.text = "Arma equipada: %s." % id.to_upper()


func _ao_liberar_armas() -> void:
	var total: int = 0
	for arma: DadosArma in _armas_disponiveis():
		if not GlobalManager.armas_desbloqueadas.has(arma.id):
			GlobalManager.armas_desbloqueadas.append(arma.id)
			total += 1
	GlobalManager.salvar()
	_status.text = "%d arma(s) liberada(s)." % total
	_reconstruir()


func _ao_spawnar() -> void:
	if _spawn == null or _mobs.is_empty():
		_status.text = "Catálogo de inimigos vazio."
		return
	var indice: int = clampi(_seletor_mob.selected, 0, _mobs.size() - 1)
	var d: DadosInimigo = _mobs[indice]
	var qtd: int = clampi(int(_seletor_qtd.value), 1, 20)
	var criados: int = 0
	for _i: int in range(qtd):
		if _spawn.spawnar_por_id(d.id) != null:
			criados += 1
	if criados > 0:
		_status.text = "%d x %s invocado(s) na arena." % [criados, d.nome]
	else:
		_status.text = "Falha ao invocar %s." % d.nome


func _ao_matar_todos() -> void:
	if _spawn == null:
		return
	var total: int = _spawn.matar_todos()
	_status.text = "%d inimigo(s) eliminado(s)." % total
	AudioManager.tocar_sfx("explosao", -6.0, 0.06)


func _ao_matar_chefes() -> void:
	var total: int = 0
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		var b: Boss = n as Boss
		if b == null or not is_instance_valid(b) or b.morto or b.como_comum:
			continue
		b.receber_dano(b.vida_max * 10.0 + 999.0)
		total += 1
	_status.text = "%d chefe(s) eliminado(s)." % total


func _ao_chefe_1hp() -> void:
	var total: int = 0
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		var b: Boss = n as Boss
		if b == null or not is_instance_valid(b) or b.morto or b.como_comum:
			continue
		b.vida = 1.0
		GlobalManager.chefe_vida.emit(1.0, b.vida_max)
		total += 1
	_status.text = "%d chefe(s) com 1 de vida." % total if total > 0 else "Nenhum chefe ativo agora."


func _ao_destruir_guardioes() -> void:
	var total: int = 0
	for n: Node in get_tree().get_nodes_in_group("guardioes_final"):
		var g: Enemy = n as Enemy
		if g == null or not is_instance_valid(g) or g.morto:
			continue
		g.receber_dano(g.vida_max * 10.0 + 999.0)
		total += 1
	_status.text = "%d guardião(ões) destruído(s)." % total


func _ao_curar() -> void:
	if _jogador != null and is_instance_valid(_jogador):
		_jogador.curar(_jogador.vida_maxima)
		_status.text = "Vida restaurada."


func _ao_deus() -> void:
	if _jogador == null or not is_instance_valid(_jogador):
		return
	_jogador.modo_deus = not _jogador.modo_deus
	_b_deus.text = "VIDA INFINITA: %s" % ("ON" if _jogador.modo_deus else "OFF")
	UI.aplicar_tema_botao(_b_deus, UI.COR_VERDE if _jogador.modo_deus else UI.COR_TEXTO_FRACO)
	_status.text = "Vida infinita %s." % ("ligada" if _jogador.modo_deus else "desligada")


func _ao_moedas() -> void:
	GlobalManager.moedas += 1000
	GlobalManager.salvar()
	GlobalManager.moedas_alteradas.emit(GlobalManager.moedas)
	_status.text = "Moedas: %s." % UI.formatar(GlobalManager.moedas)


func _ao_xp() -> void:
	if not GlobalManager.partida_ativa:
		_status.text = "Sem partida ativa para dar XP."
		return
	GlobalManager.adicionar_xp(300)
	_status.text = "XP +300 (nível %d)." % GlobalManager.nivel_run


func _ao_velocidade(indice: int) -> void:
	var valores: Array[float] = [0.5, 1.0, 2.0]
	Engine.time_scale = valores[clampi(indice, 0, valores.size() - 1)]
	_status.text = "Velocidade do jogo: %.1fx." % Engine.time_scale


func _ao_qualidade() -> void:
	GlobalManager.definir_qualidade((GlobalManager.qualidade + 1) % GlobalManager.QUALIDADES.size())
	_b_qualidade.text = "QUALIDADE: %s" % GlobalManager.nome_qualidade()
	_status.text = "Qualidade gráfica: %s." % GlobalManager.nome_qualidade()


func _ao_fps() -> void:
	GlobalManager.definir_mostrar_fps(not GlobalManager.mostrar_fps)
	_b_fps.text = "MOSTRAR FPS: %s" % ("ON" if GlobalManager.mostrar_fps else "OFF")
	_status.text = "Contador de FPS %s." % ("ligado" if GlobalManager.mostrar_fps else "desligado")


func _ao_liberar_conquistas() -> void:
	for id: String in GlobalManager.CONQUISTAS.keys():
		GlobalManager.conquistas[id] = true
	GlobalManager.salvar()
	_status.text = "Todas as conquistas desbloqueadas."
