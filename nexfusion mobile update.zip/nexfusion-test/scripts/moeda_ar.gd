class_name MoedaAr
extends Area2D
## Catalisador lançado no ar. Um disparo que o acerta redireciona o projétil
## para o inimigo mais próximo com dano crítico (mecânica marksman).

var usada: bool = false
var _alvo: Vector2 = Vector2.ZERO
var _origem: Vector2 = Vector2.ZERO
var _tempo: float = 0.0
var _fase: float = 0.0
var _sprite: Sprite2D
var _sombra: Sprite2D


func _ready() -> void:
	add_to_group("moedas_ar")
	collision_layer = 8
	collision_mask = 0
	z_index = 18
	_fase = randf() * TAU
	var forma: CollisionShape2D = CollisionShape2D.new()
	var circle: CircleShape2D = CircleShape2D.new()
	circle.radius = 8.0
	forma.shape = circle
	add_child(forma)
	_sombra = Sprite2D.new()
	if ResourceLoader.exists("res://sprites/props/moeda.png"):
		_sombra.texture = load("res://sprites/props/moeda.png") as Texture2D
	_sombra.modulate = Color(0, 0, 0, 0.35)
	_sombra.scale = Vector2(1.6, 1.6)
	_sombra.position = Vector2.ZERO
	_sombra.z_index = -2
	add_child(_sombra)
	_sprite = Sprite2D.new()
	_sprite.texture = _sombra.texture
	_sprite.scale = Vector2(1.9, 1.9)
	_sprite.z_index = 1
	add_child(_sprite)


func configurar(origem: Vector2, direcao: Vector2) -> void:
	_origem = origem
	_alvo = origem + direcao * 150.0
	global_position = origem
	_tempo = 0.0


func _process(delta: float) -> void:
	_tempo += delta
	if _tempo >= 4.5:
		queue_free()
		return
	var p: float = clampf(_tempo / 0.28, 0.0, 1.0)
	var base: Vector2 = _origem.lerp(_alvo, p)
	var altura: float = sin(p * PI * 0.85) * 46.0
	var flutua: float = sin(_tempo * 6.0 + _fase) * 5.0
	# A área de colisão acompanha o sprite no ar (para o tiro acertar a moeda);
	# a sombra é desenhada no chão, na posição original do lançamento.
	global_position = base + Vector2(0.0, -(altura + flutua + 10.0))
	if _sprite != null:
		_sprite.position = Vector2.ZERO
		_sprite.rotation = sin(_tempo * 7.0) * 0.25
		_sprite.scale = Vector2(1.9 * (0.35 + absf(cos(_tempo * 6.0)) * 0.65), 1.9)
	if _sombra != null:
		_sombra.position = Vector2(0.0, altura + flutua + 10.0)
		_sombra.modulate.a = 0.3
	if usada:
		return


func explodir() -> void:
	Efeitos.particulas(get_parent(), global_position, Color("ffcf4a"), 8, 210.0, 0.35, 2.0, "estrela")
	queue_free()
