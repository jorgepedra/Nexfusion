class_name CartaRoguelite
extends Resource
## Carta de upgrade temporária oferecida no Level Up (rogue-lite da run).
## atributo é interpretado pelo Player em aplicar_carta().

@export var id: String = ""
@export var nome: String = ""
@export_multiline var descricao: String = ""
@export_enum("comum", "raro", "epico", "isotopico") var raridade: String = "comum"
@export var atributo: String = "dano"
@export var valor: float = 0.1
@export var simbolo: String = "?"
@export var peso: float = 10.0
