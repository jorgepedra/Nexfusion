class_name ItemLoja
extends Resource
## Item exibido na loja permanente. tipo: "upgrade" (usa alvo = id em GlobalManager.UPGRADES)
## ou "arma" (usa alvo = id da arma em resources/armas/).

@export_enum("upgrade", "arma") var tipo: String = "upgrade"
@export var alvo: String = ""
@export var titulo: String = ""
@export_multiline var descricao: String = ""
@export var simbolo: String = ""
@export var cor: Color = Color("8ff3ff")
@export var ordem: int = 0
