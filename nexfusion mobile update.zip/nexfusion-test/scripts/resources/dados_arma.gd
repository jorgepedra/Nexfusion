class_name DadosArma
extends Resource
## Dados modulares de arma elemental (.tres em res://resources/armas/).

@export var id: String = ""
@export var nome: String = ""
@export var elemento: String = ""
@export_multiline var descricao: String = ""
@export var dano: float = 8.0
@export var cadencia: float = 5.0
@export var velocidade_projetil: float = 900.0
@export var projeteis: int = 1
@export var dispersao: float = 2.0
@export var alcance: float = 900.0
@export var perfuracao: int = 0
@export var cadeia: int = 0
@export var ricochetes: int = 0
@export var raio_explosao: float = 0.0
@export var critico: float = 0.05
@export var cor: Color = Color("c6cfe0")
@export var textura: String = ""
@export var custo: int = 0
@export var som: String = "tiro"
@export var tamanho_projetil: float = 1.0
## Que tipo de perigo real esta arma neutraliza (texto exibido na loja/HUD).
@export var neutraliza: String = ""
