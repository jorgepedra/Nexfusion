class_name LaserChefe
extends Node2D
## Super laser: mira uma linha e depois varre a arena. Só dá para atravessar
## com os i-frames do dash no momento exato.

signal terminou

const MIRA: float = 1.15
const FOGO: float = 2.1
const LARGURA: float = 26.0
const COMPRIMENTO: float = 2800.0

var chefe: ChefeFinal = null
var dano: float = 32.0
var angulo: float = 0.0

var _t: float = 0.0
var _fase: String = "mira"
var _giro: float = 0.58
var _pulso: float = 0.0


func configurar(origem: Vector2, alvo: Vector2, valor: float) -> void:
	global_position = origem
	var d: Vector2 = alvo - origem
	angulo = d.angle() if d.length() > 1.0 else 0.0
	_giro = 0.58 * (1.0 if randf() < 0.5 else -1.0)
	dano = valor
	z_index = 42


func _chefe_vivo() -> bool:
	## O chefe pode morrer no meio do ataque: nesse caso o objeto é liberado.
	return chefe != null and is_instance_valid(chefe) and not chefe.morto


func _process(delta: float) -> void:
	if not _chefe_vivo():
		terminou.emit()
		queue_free()
		return
	_t += delta
	_pulso += delta
	if _fase == "mira":
		if _t >= MIRA:
			_fase = "fogo"
			_t = 0.0
			AudioManager.tocar_sfx("explosao", -2.0, 0.04)
			Efeitos.tremor(12.0)
	else:
		angulo += _giro * delta
		_atingir_jogador()
		if _t >= FOGO:
			terminou.emit()
			queue_free()
			return
	queue_redraw()


func _atingir_jogador() -> void:
	if not _chefe_vivo():
		return
	var p: Player = chefe.jogador_atual()
	if p == null or not p.vivo:
		return
	var dir: Vector2 = Vector2.RIGHT.rotated(angulo)
	var rel: Vector2 = p.global_position - global_position
	var proj: float = rel.dot(dir)
	if proj < -30.0 or proj > COMPRIMENTO:
		return
	var perp: float = absf(rel.cross(dir))
	if perp <= LARGURA:
		p.receber_dano(dano)


func _draw() -> void:
	var dir: Vector2 = Vector2.RIGHT.rotated(angulo)
	var ponta: Vector2 = dir * COMPRIMENTO
	if _fase == "mira":
		var alerta: float = clampf(_t / MIRA, 0.0, 1.0)
		draw_line(Vector2.ZERO, ponta, Color(1.0, 0.25, 0.3, 0.18 + alerta * 0.3), 2.0 + alerta * 3.0)
		draw_circle(Vector2.ZERO, 20.0 + alerta * 16.0, Color(1.0, 0.3, 0.35, 0.25 + alerta * 0.3))
		return
	var pulso: float = 0.85 + absf(sin(_pulso * 22.0)) * 0.15
	draw_line(Vector2.ZERO, ponta, Color(1.0, 0.2, 0.25, 0.35), LARGURA * 2.6)
	draw_line(Vector2.ZERO, ponta, Color(1.0, 0.42, 0.35, 0.7), LARGURA * 1.6)
	draw_line(Vector2.ZERO, ponta, Color(1.0, 0.75, 0.65, 0.95), LARGURA * pulso)
	draw_line(Vector2.ZERO, ponta, Color(1.0, 1.0, 1.0, 0.95), LARGURA * 0.35)
	draw_circle(Vector2.ZERO, 46.0 * pulso, Color(1.0, 0.6, 0.5, 0.55))
	draw_arc(Vector2.ZERO, 54.0, 0.0, TAU, 32, Color(1.0, 0.8, 0.7, 0.8), 3.0, true)
