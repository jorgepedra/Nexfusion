extends Node
## Capturas visuais reais em janela: loja mobile, pausa com cartas e fase 3D.

const DIR: String = "res://tools/capturas/"
var _jogo: Node2D
var _chefe: ChefeFinal
var _mobile_antes: bool = false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(DIR))
	DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
	DisplayServer.window_set_size(Vector2i(1280, 720))
	await get_tree().process_frame
	_mobile_antes = GlobalManager.modo_mobile
	GlobalManager.modo_mobile = true
	await _capturar_loja()
	await _capturar_pausa()
	await _capturar_3d()
	GlobalManager.modo_mobile = _mobile_antes
	get_tree().quit(0)


func _salvar(nome: String) -> void:
	await RenderingServer.frame_post_draw
	var img: Image = get_viewport().get_texture().get_image()
	var caminho: String = DIR + nome + ".png"
	img.save_png(caminho)
	print("CAPTURA ", caminho, " ", img.get_width(), "x", img.get_height())


func _capturar_loja() -> void:
	var loja: Control = (load("res://scripts/shop.gd") as Script).new() as Control
	add_child(loja)
	await get_tree().process_frame
	await get_tree().process_frame
	await _salvar("loja_mobile")
	loja.queue_free()
	await get_tree().process_frame


func _capturar_pausa() -> void:
	_jogo = (load("res://scenes/jogo.tscn") as PackedScene).instantiate() as Node2D
	add_child(_jogo)
	await get_tree().create_timer(1.2, true, false, true).timeout
	await _salvar("jogo_inicio")
	var hud_ref: CanvasLayer = _jogo.get_node("HUD") as CanvasLayer
	hud_ref.call("_ao_conquista", "derrotar_cloro", "Cloro Neutralizado", "Derrote o mini-boss Cloro.")
	await get_tree().create_timer(0.6, true, false, true).timeout
	await _salvar("conquista_toast")
	await get_tree().create_timer(3.9, true, false, true).timeout
	GlobalManager.cartas_coletadas = [
		"carta_dano", "carta_cadencia", "carta_projetil", "carta_esquiva",
		"carta_escudo", "carta_cura_direta", "carta_critico", "carta_magnetismo",
		"carta_dano", "carta_projetil", "carta_escudo", "carta_dano",
	]
	var hud: CanvasLayer = _jogo.get_node("HUD") as CanvasLayer
	hud.call("alternar_pausa")
	await get_tree().create_timer(0.4, true, false, true).timeout
	await _salvar("pausa_cartas")
	hud.call("alternar_pausa")
	await get_tree().process_frame


func _capturar_3d() -> void:
	_chefe = (load("res://scenes/chefe_final.tscn") as PackedScene).instantiate() as ChefeFinal
	_jogo.get_node("Mundo").add_child(_chefe)
	_chefe.configurar(load("res://resources/inimigos/elemento_supremo.tres") as DadosInimigo, 31)
	_chefe._chegando = false
	_chefe.global_position = Vector2(1200, 400)
	_jogo.call("cutscene_furia_chefe", _chefe)
	await get_tree().create_timer(3.4, true, false, true).timeout
	await _salvar("3d_entrada")
	var fase: Fase3D = null
	for n: Node in _jogo.get_children():
		if n is Fase3D:
			fase = n as Fase3D
	if fase != null:
		# Mira no chefe para o rastro terminar em impacto visível.
		var alvo: Vector3 = fase._chefe.global_position
		var para_alvo: Vector3 = alvo - fase._camera.global_position
		fase._yaw = atan2(-para_alvo.x, -para_alvo.z)
		fase._pitch = atan2(para_alvo.y, Vector2(para_alvo.x, para_alvo.z).length())
		fase._atualizar_camera(0.0)
		await get_tree().process_frame
		fase._rajada_mirada()
		fase._cooldown_tiro = 0.0
		fase._atirar()
		await get_tree().create_timer(0.05, true, false, true).timeout
		await _salvar("3d_tiros")
		fase._finalizar(true)
	await get_tree().create_timer(1.8, true, false, true).timeout
	await _salvar("retorno_2d")
	await _capturar_config_conquistas()


func _capturar_config_conquistas() -> void:
	var conquistas_antes: Dictionary = GlobalManager.conquistas.duplicate()
	for id: String in GlobalManager.CONQUISTAS.keys():
		GlobalManager.conquistas[id] = true
	_jogo.queue_free()
	await get_tree().process_frame
	var cfg: Control = (load("res://scenes/configuracoes.tscn") as PackedScene).instantiate() as Control
	add_child(cfg)
	await get_tree().process_frame
	await get_tree().process_frame
	cfg.call("_ao_aba", "progresso")
	await get_tree().create_timer(0.4, true, false, true).timeout
	await _salvar("config_conquistas")
	GlobalManager.conquistas = conquistas_antes
