extends Node
## Integração real: jogo 2D -> cutscene de fúria -> Fase 3D -> volta à Fase 2.

var falhas: int = 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	var cena: PackedScene = load("res://scenes/jogo.tscn") as PackedScene
	var jogo: Node2D = cena.instantiate() as Node2D
	add_child(jogo)
	await get_tree().process_frame
	await get_tree().process_frame
	var chefe: ChefeFinal = (load("res://scenes/chefe_final.tscn") as PackedScene).instantiate() as ChefeFinal
	jogo.get_node("Mundo").add_child(chefe)
	chefe.configurar(load("res://resources/inimigos/elemento_supremo.tres") as DadosInimigo, 31)
	chefe._chegando = false
	chefe.global_position = Vector2(1200, 400)
	jogo.call("cutscene_furia_chefe", chefe)
	await get_tree().create_timer(2.6, true, false, true).timeout
	var fase: Fase3D = null
	for n: Node in jogo.get_children():
		if n is Fase3D:
			fase = n as Fase3D
	_ok(fase != null, "cutscene abre a Fase 3D no jogo real")
	if fase != null:
		_ok(fase._viewport != null and fase._camera != null, "viewport/câmera 3D montados")
		fase._finalizar(true)
	await get_tree().create_timer(1.8, true, false, true).timeout
	var hud: CanvasLayer = jogo.get_node("HUD") as CanvasLayer
	_ok(hud.visible, "HUD volta ao terminar a fase 3D")
	_ok(chefe._fase2, "chefe entra na Fase 2 após a dimensão 3D")
	var arena: Node = jogo.get_node_or_null("ArenaVisual")
	_ok(arena != null and bool(arena.get("fusao")) == true, "arena vira Câmara de Fusão")
	_ok(not get_tree().paused, "jogo 2D volta a rodar")
	print("=== RESULTADO INTEGRAÇÃO 3D: %d falha(s) ===" % falhas)
	get_tree().quit(1 if falhas > 0 else 0)


func _ok(condicao: bool, texto: String) -> void:
	if condicao:
		print("[OK] ", texto)
	else:
		falhas += 1
		print("[FALHA] ", texto)
