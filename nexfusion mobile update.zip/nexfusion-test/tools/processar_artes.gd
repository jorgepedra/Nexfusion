extends SceneTree
## Normaliza as artes geradas: ícone com cantos transparentes e medalhas 128px.


func _initialize() -> void:
	var medalhas: Array[String] = ["cloro", "mercurio", "uranio", "supremo"]
	for nome: String in medalhas:
		var img: Image = Image.load_from_file(ProjectSettings.globalize_path("res://tools/art_raw/%s.jpg" % nome))
		if img == null:
			push_error("Arte ausente: %s" % nome)
			continue
		img.convert(Image.FORMAT_RGBA8)
		img.resize(128, 128, Image.INTERPOLATE_NEAREST)
		img.save_png("res://sprites/conquistas/%s.png" % nome)
		print("MEDALHA ", nome)
	var icone: Image = Image.load_from_file(ProjectSettings.globalize_path("res://tools/art_raw/icon.jpg"))
	if icone != null:
		icone.convert(Image.FORMAT_RGBA8)
		icone.resize(512, 512, Image.INTERPOLATE_NEAREST)
		var raio: float = 92.0
		for y: int in range(512):
			for x: int in range(512):
				var fora: bool = false
				if x < raio and y < raio:
					fora = Vector2(float(x) - raio, float(y) - raio).length() > raio
				elif x > 511.0 - raio and y < raio:
					fora = Vector2(float(x) - (511.0 - raio), float(y) - raio).length() > raio
				elif x < raio and y > 511.0 - raio:
					fora = Vector2(float(x) - raio, float(y) - (511.0 - raio)).length() > raio
				elif x > 511.0 - raio and y > 511.0 - raio:
					fora = Vector2(float(x) - (511.0 - raio), float(y) - (511.0 - raio)).length() > raio
				if fora:
					icone.set_pixel(x, y, Color(0, 0, 0, 0))
		icone.save_png("res://icon.png")
		print("ICONE icon.png")
	quit()
