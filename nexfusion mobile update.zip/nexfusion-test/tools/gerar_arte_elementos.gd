extends SceneTree
## Gera a arte dos novos elementos reaproveitando os sprites já existentes:
## cada espécie recebe a cor do seu elemento (base + folha de animação 4x4).
## Uso: Godot.exe --headless --path . --script tools/gerar_arte_elementos.gd

const GAS: String = "res://sprites/bosses/cloro.png"
const LIQUIDO: String = "res://sprites/bosses/mercurio.png"
const RADIOATIVO: String = "res://sprites/bosses/uranio.png"
const NUCLEO: String = "res://sprites/bosses/elemento_supremo.png"
const ARMA: String = "res://sprites/guns/arma_tungstenio.png"

## destino -> [origem, cor]
const TRABALHOS: Dictionary = {
	# --- inimigos comuns
	"res://sprites/enemies/uranio.png": [RADIOATIVO, Color("b6ff5a")],
	"res://sprites/enemies/cesio.png": [RADIOATIVO, Color("e8e2c4")],
	"res://sprites/enemies/sulfurico.png": [LIQUIDO, Color("ffcf4a")],
	"res://sprites/enemies/cloridrico.png": [LIQUIDO, Color("b6ff5a")],
	"res://sprites/enemies/soda.png": [LIQUIDO, Color("f2f6ff")],
	"res://sprites/enemies/cloro.png": [GAS, Color("8dff5a")],
	"res://sprites/enemies/amonia.png": [GAS, Color("9fd8ff")],
	"res://sprites/enemies/co.png": [GAS, Color("cfd8e0")],
	"res://sprites/enemies/mistura.png": [GAS, Color("e8e07a")],
	"res://sprites/enemies/sodio.png": [LIQUIDO, Color("d8dde6")],
	"res://sprites/enemies/metano.png": [GAS, Color("dff0ff")],
	"res://sprites/enemies/nitroglicerina.png": [LIQUIDO, Color("ffe9a8")],
	"res://sprites/enemies/fosforo.png": [LIQUIDO, Color("fff3c4")],
	"res://sprites/enemies/mercurio.png": [LIQUIDO, Color("d8e8ff")],
	# --- chefes
	"res://sprites/bosses/reator.png": [NUCLEO, Color("b6ff5a")],
	"res://sprites/bosses/nuvem_quimica.png": [GAS, Color("9be86a")],
	# --- armas (amigos)
	"res://sprites/guns/arma_chumbo.png": [ARMA, Color("9ea3b5")],
	"res://sprites/guns/arma_bicarbonato.png": [ARMA, Color("bfe9ff")],
	"res://sprites/guns/arma_vinagre.png": [ARMA, Color("e8c86a")],
	"res://sprites/guns/arma_carvao.png": [ARMA, Color("5a5a6a")],
	"res://sprites/guns/arma_agua.png": [ARMA, Color("4aa8ff")],
	"res://sprites/guns/arma_co2.png": [ARMA, Color("dff2ff")],
	"res://sprites/guns/arma_areia.png": [ARMA, Color("d8b96a")],
	"res://sprites/guns/arma_quelante.png": [ARMA, Color("a78bfa")],
	"res://sprites/guns/arma_tiossulfato.png": [ARMA, Color("b98bd8")],
	"res://sprites/guns/arma_oleo.png": [ARMA, Color("e0b558")],
	"res://sprites/guns/arma_gelo_seco.png": [ARMA, Color("c9f3ff")],
}


func _init() -> void:
	var ok: int = 0
	var falhas: int = 0
	for destino: String in TRABALHOS.keys():
		var cfg: Array = TRABALHOS[destino] as Array
		var origem: String = String(cfg[0])
		var cor: Color = cfg[1] as Color
		if _tintar(origem, destino, cor):
			ok += 1
		else:
			falhas += 1
			printerr("falhou: ", destino)
		# folha de animação (4x4) correspondente
		var folha_origem: String = origem.get_basename() + "_sheet.png"
		var folha_destino: String = destino.get_basename() + "_sheet.png"
		if FileAccess.file_exists(folha_origem):
			if _tintar(folha_origem, folha_destino, cor):
				ok += 1
			else:
				falhas += 1
				printerr("falhou: ", folha_destino)
	print("ARTE: %d imagens geradas, %d falhas" % [ok, falhas])
	quit(0 if falhas == 0 else 1)


func _tintar(origem: String, destino: String, cor: Color) -> bool:
	var absoluto: String = ProjectSettings.globalize_path(origem)
	var img: Image = Image.load_from_file(absoluto)
	if img == null or img.is_empty():
		return false
	img.convert(Image.FORMAT_RGBA8)
	var larg: int = img.get_width()
	var alt: int = img.get_height()
	for y: int in range(alt):
		for x: int in range(larg):
			var c: Color = img.get_pixel(x, y)
			if c.a <= 0.01:
				continue
			# Preserva a luminosidade do desenho original e troca o matiz.
			var lum: float = 0.299 * c.r + 0.587 * c.g + 0.114 * c.b
			var alvo: Color = Color(
				clampf(cor.r * (0.45 + 1.05 * lum), 0.0, 1.0),
				clampf(cor.g * (0.45 + 1.05 * lum), 0.0, 1.0),
				clampf(cor.b * (0.45 + 1.05 * lum), 0.0, 1.0),
				c.a
			)
			img.set_pixel(x, y, c.lerp(alvo, 0.78))
	return img.save_png(ProjectSettings.globalize_path(destino)) == OK
