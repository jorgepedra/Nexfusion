extends Node
## Host de teste: abre uma sala ENet e espera um cliente.


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	await get_tree().process_frame
	var ok: bool = NetworkManager.criar_sala(7899)
	print("HOST create=", ok, " modo=", NetworkManager.modo)
	NetworkManager.jogador_conectado.connect(func(id: int) -> void: print("HOST conectou id=", id))
	await get_tree().create_timer(5.0, true, false, true).timeout
	print("HOST peers=", multiplayer.get_peers().size())
	get_tree().quit(0 if ok and multiplayer.get_peers().size() >= 1 else 1)
