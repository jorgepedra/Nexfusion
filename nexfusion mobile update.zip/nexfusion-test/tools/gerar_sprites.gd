extends SceneTree
## Gerador de pixel art: godot --headless --path . --script tools/gerar_sprites.gd
## Desenha todos os sprites por código e grava PNGs em res://sprites/.
## Também monta as folhas de animação (4x4), as cartas e a decoração da arena.
## Paleta limitada, contorno automático e escala inteira = look pixel art coeso.

const OUTLINE: Color = Color("11121c")
const SPRITES_DIR: String = "res://sprites"

var _img: Image
var _w: int = 0
var _h: int = 0


func _initialize() -> void:
	for d: String in ["player", "guns", "NPC", "map", "HUD", "enemies", "bosses", "props", "particulas"]:
		DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(SPRITES_DIR.path_join(d)))

	_gerar_player()
	_gerar_armas()
	_gerar_inimigos()
	_gerar_chefes()
	_gerar_props()
	_gerar_tiles()
	_gerar_hud()
	_gerar_cartas()
	_gerar_decoracao()
	_gerar_particulas_e_extras()
	# Folhas de animação por último: elas leem os PNGs já gravados.
	_gerar_folhas()
	print("[art] sprites gerados em ", SPRITES_DIR)
	quit()


# ---------------------------------------------------------------- infra
func _novo(w: int, h: int) -> void:
	_w = w
	_h = h
	_img = Image.create_empty(w, h, false, Image.FORMAT_RGBA8)
	_img.fill(Color(0, 0, 0, 0))


func _px(x: int, y: int, c: Color) -> void:
	if x < 0 or y < 0 or x >= _w or y >= _h:
		return
	if c.a <= 0.0:
		return
	_img.set_pixel(x, y, c)


func _rect(x: int, y: int, w: int, h: int, c: Color) -> void:
	for iy: int in range(y, y + h):
		for ix: int in range(x, x + w):
			_px(ix, iy, c)


func _ellipse(cx: float, cy: float, rx: float, ry: float, c: Color) -> void:
	for iy: int in range(int(cy - ry - 1.0), int(cy + ry + 2.0)):
		for ix: int in range(int(cx - rx - 1.0), int(cx + rx + 2.0)):
			var dx: float = (float(ix) - cx) / maxf(rx, 0.001)
			var dy: float = (float(iy) - cy) / maxf(ry, 0.001)
			if dx * dx + dy * dy <= 1.0:
				_px(ix, iy, c)


func _linha(x0: int, y0: int, x1: int, y1: int, c: Color) -> void:
	var dx: int = absi(x1 - x0)
	var dy: int = -absi(y1 - y0)
	var sx: int = 1 if x0 < x1 else -1
	var sy: int = 1 if y0 < y1 else -1
	var err: int = dx + dy
	var x: int = x0
	var y: int = y0
	while true:
		_px(x, y, c)
		if x == x1 and y == y1:
			break
		var e2: int = 2 * err
		if e2 >= dy:
			err += dy
			x += sx
		if e2 <= dx:
			err += dx
			y += sy


func _contorno(c: Color = OUTLINE) -> void:
	var base: Image = _img.duplicate()
	for y: int in range(_h):
		for x: int in range(_w):
			if base.get_pixel(x, y).a > 0.0:
				continue
			var vizinho: bool = false
			for o: Vector2i in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
				var nx: int = x + o.x
				var ny: int = y + o.y
				if nx < 0 or ny < 0 or nx >= _w or ny >= _h:
					continue
				if base.get_pixel(nx, ny).a > 0.0:
					vizinho = true
					break
			if vizinho:
				_px(x, y, c)


func _salvar(caminho: String) -> void:
	var full: String = ProjectSettings.globalize_path(SPRITES_DIR.path_join(caminho))
	var err: int = _img.save_png(full)
	if err != OK:
		printerr("[art] falha ao salvar ", caminho, " err=", err)


func _escurecer(c: Color, f: float = 0.62) -> Color:
	return Color(c.r * f, c.g * f, c.b * f, 1.0)


func _clarear(c: Color, f: float = 0.35) -> Color:
	return Color(lerpf(c.r, 1.0, f), lerpf(c.g, 1.0, f), lerpf(c.b, 1.0, f), 1.0)


# ---------------------------------------------------------------- player
func _gerar_player() -> void:
	var casaco: Color = Color("2b8f95")
	var casaco_escuro: Color = Color("1c666d")
	var visor: Color = Color("9df5ff")
	var pele: Color = Color("d9a37a")
	var bota: Color = Color("242b3d")
	var luva: Color = Color("16202e")

	_novo(16, 16)
	# botas
	_rect(3, 12, 4, 3, bota)
	_rect(9, 12, 4, 3, bota)
	_rect(3, 14, 4, 1, _escurecer(bota, 0.7))
	_rect(9, 14, 4, 1, _escurecer(bota, 0.7))
	# pernas
	_rect(4, 9, 3, 4, casaco_escuro)
	_rect(9, 9, 3, 4, casaco_escuro)
	# tronco
	_rect(3, 5, 10, 5, casaco)
	_rect(3, 5, 10, 1, _clarear(casaco, 0.2))
	_rect(3, 8, 10, 2, casaco_escuro)
	_rect(7, 6, 2, 3, Color("f2c14e"))  # fivela/reator
	# braços
	_rect(1, 6, 2, 4, casaco_escuro)
	_rect(13, 6, 2, 4, casaco_escuro)
	_rect(1, 9, 2, 2, luva)
	_rect(13, 9, 2, 2, luva)
	# cabeça / capacete
	_rect(4, 1, 8, 4, pele)
	_rect(5, 0, 6, 1, Color("3a3f52"))
	_rect(4, 1, 8, 1, Color("3a3f52"))
	_rect(4, 3, 8, 2, visor)
	_rect(4, 3, 8, 1, _clarear(visor, 0.5))
	_rect(11, 3, 1, 2, Color("5fd8ea"))
	# pescoço
	_rect(7, 4, 2, 1, _escurecer(pele, 0.75))
	_contorno()
	_salvar("player/player.png")


# ---------------------------------------------------------------- armas
func _gerar_armas() -> void:
	_arma("tungstenio", Color("8d97ab"), Color("c6cfe0"), "revolver")
	_arma("helio", Color("3fc7c0"), Color("a8f5ef"), "shotgun")
	_arma("ferro", Color("9a5f3c"), Color("d08a5a"), "cannon")
	_arma("litio", Color("8a5cf0"), Color("c9b0ff"), "smg")
	_arma("neonio", Color("ff7a59"), Color("ffc3ad"), "rod")
	_arma("mercurio", Color("b9c3cf"), Color("f0f4f8"), "blob")


func _arma(nome: String, cor: Color, brilho: Color, forma: String) -> void:
	_novo(14, 8)
	match forma:
		"revolver":
			_rect(1, 2, 9, 4, cor)
			_rect(1, 1, 3, 1, cor)
			_rect(6, 3, 4, 2, brilho)
			_rect(9, 2, 5, 2, _escurecer(cor, 0.8))
			_rect(1, 5, 3, 2, _escurecer(cor, 0.6))
			_px(9, 3, Color("fff6cf"))
		"shotgun":
			_rect(1, 2, 6, 4, cor)
			_rect(4, 1, 8, 2, _escurecer(cor, 0.85))
			_rect(4, 5, 8, 1, _escurecer(cor, 0.85))
			_rect(12, 2, 1, 4, brilho)
			_rect(1, 4, 2, 3, _escurecer(cor, 0.6))
		"cannon":
			_rect(0, 1, 6, 6, cor)
			_rect(4, 2, 6, 4, _escurecer(cor, 0.85))
			_rect(9, 1, 4, 6, brilho)
			_rect(11, 2, 3, 4, _escurecer(cor, 0.7))
			_rect(0, 3, 2, 4, _escurecer(cor, 0.55))
			_px(2, 4, Color("ffb45e"))
		"smg":
			_rect(1, 2, 8, 3, cor)
			_rect(8, 3, 5, 2, brilho)
			_rect(2, 5, 2, 3, _escurecer(cor, 0.65))
			_rect(5, 5, 2, 1, _escurecer(cor, 0.65))
			_px(12, 3, Color("fff2a8"))
		"rod":
			_rect(1, 2, 9, 4, cor)
			_rect(3, 3, 9, 2, brilho)
			_rect(11, 2, 2, 4, Color("fff6d5"))
			_px(1, 4, _escurecer(cor, 0.5))
		"blob":
			_ellipse(6.0, 4.0, 5.5, 3.2, cor)
			_ellipse(9.0, 3.5, 4.0, 2.2, brilho)
			_rect(12, 3, 2, 2, _escurecer(cor, 0.6))
			_px(3, 2, Color("ffffff"))
	_contorno()
	_salvar("guns/arma_%s.png" % nome)


# ---------------------------------------------------------------- inimigos
func _gerar_inimigos() -> void:
	_hidrogenio()
	_carbono()
	_ferro_enemy()
	_slime()
	_granadeiro()


func _hidrogenio() -> void:
	var corpo: Color = Color("c9d8ff")
	var gas: Color = Color("6c8cff")
	_novo(14, 14)
	_ellipse(7.0, 7.5, 5.0, 4.6, gas)
	_ellipse(7.0, 7.0, 3.6, 3.2, corpo)
	_ellipse(7.0, 6.4, 2.2, 1.6, _clarear(corpo, 0.5))
	_rect(4, 7, 2, 2, Color("1b2550"))
	_rect(8, 7, 2, 2, Color("1b2550"))
	_rect(3, 10, 8, 1, _escurecer(gas, 0.7))
	_px(2, 4, Color("ffffff"))
	_contorno()
	_salvar("enemies/hidrogenio.png")


func _carbono() -> void:
	var corpo: Color = Color("3d4557")
	var nucleo: Color = Color("ff9c3f")
	_novo(14, 14)
	_ellipse(7.0, 7.0, 4.2, 4.6, corpo)
	_ellipse(7.0, 7.0, 2.0, 2.2, nucleo)
	_ellipse(7.0, 7.0, 1.0, 1.1, Color("fff1c9"))
	for i: int in range(4):
		var ox: int = 1 if i % 2 == 0 else 11
		var oy: int = 3 + i * 2
		_linha(7, 7, ox, oy, _escurecer(corpo, 0.8))
		_px(ox, oy, nucleo)
	_contorno()
	_salvar("enemies/carbono.png")


func _ferro_enemy() -> void:
	var placa: Color = Color("7d848f")
	var placa2: Color = Color("b9c0c9")
	var ferrugem: Color = Color("a35a34")
	_novo(18, 18)
	_rect(3, 3, 12, 12, placa)
	_rect(4, 2, 10, 2, placa2)
	_rect(4, 4, 4, 4, placa2)
	_rect(10, 10, 4, 4, ferrugem)
	_rect(3, 3, 12, 1, _clarear(placa, 0.3))
	_rect(5, 6, 3, 2, Color("ffcf5c"))
	_rect(10, 6, 3, 2, Color("ffcf5c"))
	_rect(4, 14, 3, 2, Color("4a4f5c"))
	_rect(11, 14, 3, 2, Color("4a4f5c"))
	_contorno()
	_salvar("enemies/ferro.png")


func _slime() -> void:
	var corpo: Color = Color("6ee06a")
	var corpo2: Color = Color("3faa4a")
	var brilho: Color = Color("b7ffa1")
	_novo(20, 20)
	_ellipse(10.0, 13.0, 8.5, 6.0, corpo2)
	_ellipse(10.0, 12.0, 7.6, 5.6, corpo)
	_ellipse(7.5, 9.5, 3.6, 2.6, brilho)
	_rect(6, 12, 2, 3, Color("123018"))
	_rect(12, 12, 2, 3, Color("123018"))
	_px(7, 12, Color("ffffff"))
	_px(13, 12, Color("ffffff"))
	_rect(9, 16, 3, 1, Color("123018"))
	# bolhas internas
	_px(14, 8, brilho)
	_px(16, 11, brilho)
	_px(4, 14, brilho)
	_contorno()
	_salvar("enemies/slime.png")


func _granadeiro() -> void:
	var corpo: Color = Color("c8a23c")
	var corpo2: Color = Color("8a6b1f")
	var metal: Color = Color("4c5262")
	_novo(16, 16)
	# mochila de granadas
	_rect(2, 5, 3, 5, corpo2)
	_px(3, 4, Color("e0574a"))
	_px(3, 5, metal)
	# corpo
	_ellipse(8.5, 9.0, 5.2, 4.8, corpo)
	_ellipse(8.5, 7.5, 4.0, 3.4, _clarear(corpo, 0.18))
	# viseira
	_rect(5, 6, 7, 2, Color("2a3145"))
	_rect(6, 6, 2, 1, Color("8ef0ff"))
	# braço arremessador
	_rect(12, 8, 3, 3, corpo2)
	_rect(14, 7, 2, 2, metal)
	# pernas
	_rect(5, 13, 3, 2, metal)
	_rect(10, 13, 3, 2, metal)
	# antena/pavio
	_linha(8, 4, 6, 1, metal)
	_px(5, 1, Color("ff7a3c"))
	_contorno()
	_salvar("enemies/granadeiro.png")


# ---------------------------------------------------------------- chefes
func _gerar_chefes() -> void:
	_cloro()
	_mercurio_boss()
	_uranio()
	_elemento_supremo()


func _elemento_supremo() -> void:
	var casco: Color = Color("1c2a44")
	var casco2: Color = Color("2f4c72")
	var nucleo: Color = Color("9df5ff")
	var nucleo2: Color = Color("3fa8d8")
	var eletron: Color = Color("c8ffe8")
	_novo(40, 40)
	_ellipse(20.0, 20.0, 18.0, 18.0, casco)
	_ellipse(20.0, 19.5, 15.5, 15.5, casco2)
	# anéis de contenção
	for i: int in range(3):
		var y: int = 11 + i * 6
		_rect(7, y, 26, 1, _escurecer(casco, 0.55))
	# órbitas dos elementos
	_linha(4, 20, 36, 20, Color("2b6f8f"))
	_linha(9, 11, 31, 29, Color("2b6f8f"))
	_linha(31, 11, 9, 29, Color("2b6f8f"))
	# núcleo
	_ellipse(20.0, 20.0, 8.5, 8.5, nucleo2)
	_ellipse(20.0, 20.0, 5.6, 5.6, nucleo)
	_ellipse(18.0, 18.0, 2.6, 2.2, Color("ffffff"))
	# elétrons orbitando
	for p: Vector2i in [Vector2i(4, 20), Vector2i(36, 20), Vector2i(9, 29), Vector2i(31, 11)]:
		_ellipse(float(p.x), float(p.y), 2.6, 2.6, eletron)
	# coroa / antenas
	_rect(18, 1, 4, 2, Color("7ff0ff"))
	_rect(19, 3, 2, 3, Color("7ff0ff"))
	_rect(2, 24, 3, 8, _escurecer(casco, 0.35))
	_rect(35, 24, 3, 8, _escurecer(casco, 0.35))
	_contorno()
	_salvar("bosses/elemento_supremo.png")


func _cloro() -> void:
	var gas: Color = Color("7be36b")
	var gas2: Color = Color("3f9c46")
	var mascara: Color = Color("d7e6c8")
	_novo(40, 40)
	for i: int in range(7):
		var ang: float = TAU * float(i) / 7.0
		_ellipse(20.0 + cos(ang) * 10.0, 22.0 + sin(ang) * 9.0, 7.0, 7.0, gas2)
	_ellipse(20.0, 21.0, 13.0, 12.0, gas2)
	_ellipse(20.0, 20.0, 11.5, 10.5, gas)
	_ellipse(15.0, 14.0, 5.0, 4.0, _clarear(gas, 0.35))
	# máscara de gás
	_rect(13, 17, 14, 10, mascara)
	_rect(13, 17, 14, 1, _clarear(mascara, 0.4))
	_rect(15, 19, 4, 3, Color("22303a"))
	_rect(21, 19, 4, 3, Color("22303a"))
	_ellipse(20.0, 25.0, 3.0, 2.5, Color("4a5b46"))
	_rect(14, 29, 12, 2, _escurecer(mascara, 0.5))
	# olhos brilhantes
	_px(16, 20, Color("ffe97a"))
	_px(22, 20, Color("ffe97a"))
	_contorno()
	_salvar("bosses/cloro.png")


func _mercurio_boss() -> void:
	var metal: Color = Color("aeb8c6")
	var metal2: Color = Color("6f7b8c")
	var brilho: Color = Color("eef4fb")
	_novo(40, 40)
	for i: int in range(8):
		var ang: float = TAU * float(i) / 8.0
		_ellipse(20.0 + cos(ang) * 12.0, 21.0 + sin(ang) * 11.0, 4.5, 4.5, metal2)
	_ellipse(20.0, 21.0, 13.0, 12.5, metal2)
	_ellipse(20.0, 20.0, 11.5, 11.0, metal)
	_ellipse(15.0, 15.0, 5.0, 4.0, brilho)
	_rect(15, 18, 4, 3, Color("2b3340"))
	_rect(22, 18, 4, 3, Color("2b3340"))
	_px(16, 19, Color("9df5ff"))
	_px(23, 19, Color("9df5ff"))
	_rect(15, 25, 11, 2, Color("2b3340"))
	for i: int in range(5):
		_px(14 + i * 3, 25, Color("1b2230"))
	_px(26, 9, brilho)
	_px(9, 30, brilho)
	_contorno()
	_salvar("bosses/mercurio.png")


func _uranio() -> void:
	var casco: Color = Color("3a4a3c")
	var nucleo: Color = Color("a6ff4a")
	var nucleo2: Color = Color("4fd12b")
	_novo(44, 44)
	_ellipse(22.0, 24.0, 14.0, 13.0, casco)
	_ellipse(22.0, 22.0, 12.0, 11.0, _clarear(casco, 0.12))
	_ellipse(22.0, 21.0, 6.5, 6.0, nucleo2)
	_ellipse(22.0, 20.0, 4.0, 3.6, nucleo)
	_ellipse(20.0, 18.0, 2.0, 1.6, Color("f4ffd9"))
	# costelas de contenção
	for i: int in range(4):
		var y: int = 13 + i * 5
		_rect(9, y, 26, 1, _escurecer(casco, 0.6))
	_rect(8, 26, 3, 6, _escurecer(casco, 0.4))
	_rect(33, 26, 3, 6, _escurecer(casco, 0.4))
	# braços pesados
	_rect(4, 16, 4, 12, _escurecer(casco, 0.3))
	_rect(36, 16, 4, 12, _escurecer(casco, 0.3))
	_rect(3, 28, 5, 4, nucleo2)
	_rect(36, 28, 5, 4, nucleo2)
	# olhos
	_rect(16, 16, 3, 2, nucleo)
	_rect(26, 16, 3, 2, nucleo)
	_px(13, 9, nucleo)
	_px(31, 11, nucleo)
	_contorno()
	_salvar("bosses/uranio.png")


# ---------------------------------------------------------------- props
func _gerar_props() -> void:
	_moeda()
	_eletron()
	_isotopo()
	_granada_sprite()
	_particula()


func _moeda() -> void:
	_novo(10, 10)
	_ellipse(5.0, 5.0, 4.2, 4.2, Color("b8811f"))
	_ellipse(5.0, 4.6, 3.4, 3.4, Color("ffcf4a"))
	_ellipse(4.0, 3.6, 1.8, 1.6, Color("fff3bc"))
	_rect(4, 3, 2, 4, Color("b8811f"))
	_rect(4, 2, 2, 1, Color("b8811f"))
	_rect(4, 7, 2, 1, Color("b8811f"))
	_contorno()
	_salvar("props/moeda.png")


func _eletron() -> void:
	_novo(7, 7)
	_ellipse(3.0, 3.0, 3.2, 3.2, Color("1d6fa8"))
	_ellipse(3.0, 3.0, 2.2, 2.2, Color("59d8ff"))
	_ellipse(2.4, 2.4, 1.2, 1.0, Color("e8fbff"))
	_salvar("props/eletron.png")


func _isotopo() -> void:
	_novo(9, 9)
	_ellipse(4.0, 4.0, 4.0, 4.0, Color("8c1f45"))
	_rect(3, 1, 3, 7, Color("ff5f92"))
	_rect(1, 3, 7, 3, Color("ff5f92"))
	_rect(3, 2, 2, 2, Color("ffd3e2"))
	_contorno()
	_salvar("props/isotopo.png")


func _granada_sprite() -> void:
	_novo(10, 10)
	_ellipse(5.0, 6.0, 4.2, 3.8, Color("2f3a2c"))
	_ellipse(4.0, 4.6, 2.0, 1.6, Color("6f8a5e"))
	_rect(4, 1, 2, 2, Color("8a8f99"))
	_rect(3, 0, 4, 1, Color("b9bec8"))
	_px(7, 2, Color("ff7a3c"))
	_contorno()
	_salvar("props/granada.png")


func _particula() -> void:
	_novo(4, 4)
	_rect(1, 0, 2, 4, Color("ffffff"))
	_rect(0, 1, 4, 2, Color("ffffff"))
	_salvar("props/particula.png")


# ---------------------------------------------------------------- tiles
func _gerar_tiles() -> void:
	_novo(32, 32)
	var base: Color = Color("141a26")
	var linha: Color = Color("1d2637")
	var ponto: Color = Color("243049")
	_img.fill(base)
	for i: int in range(32):
		_px(i, 0, linha)
		_px(0, i, linha)
	_px(8, 8, ponto)
	_px(9, 8, ponto)
	_px(22, 5, ponto)
	_px(5, 22, ponto)
	_px(24, 24, ponto)
	_px(25, 24, ponto)
	_px(26, 17, linha)
	_salvar("map/tile_arena.png")

	# tile de "grade" para zonas de perigo
	_novo(32, 32)
	_img.fill(Color("1a1220"))
	for i: int in range(0, 32, 4):
		for j: int in range(32):
			if (i + j) % 8 < 2:
				_px(i, j, Color("2a1c33"))
	_salvar("map/tile_perigo.png")


# ---------------------------------------------------------------- hud
func _gerar_hud() -> void:
	# ícone de dash (seta dupla)
	_novo(12, 12)
	var c: Color = Color("9df5ff")
	_linha(2, 2, 6, 6, c)
	_linha(6, 6, 2, 10, c)
	_linha(6, 2, 10, 6, c)
	_linha(10, 6, 6, 10, c)
	_salvar("HUD/icone_dash.png")

	# ícone de coração/isotopo de vida
	_novo(12, 12)
	var v: Color = Color("ff5f92")
	_ellipse(4.0, 4.5, 3.0, 2.8, v)
	_ellipse(8.0, 4.5, 3.0, 2.8, v)
	_ellipse(6.0, 7.0, 3.6, 3.4, v)
	_rect(3, 2, 2, 2, Color("ffd3e2"))
	_contorno()
	_salvar("HUD/icone_vida.png")

	# ícone de estilo (raio)
	_novo(12, 12)
	var raio: Color = Color("ffcf4a")
	_rect(6, 1, 4, 2, raio)
	_rect(4, 3, 4, 2, raio)
	_rect(5, 5, 4, 2, raio)
	_rect(3, 7, 4, 2, raio)
	_rect(4, 9, 3, 2, raio)
	_salvar("HUD/icone_estilo.png")


# ---------------------------------------------------------------- cartas
const CORES_RARIDADE := {
	"comum": Color("93a1b8"),
	"raro": Color("4fa8ff"),
	"epico": Color("b06cff"),
	"isotopico": Color("ff5f92"),
}


func _gerar_cartas() -> void:
	## Uma carta ilustrada por carta de habilidade, com emblema do atributo.
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(SPRITES_DIR.path_join("cartas")))
	var pasta: String = "res://resources/cartas_roguelite"
	var dir: DirAccess = DirAccess.open(pasta)
	if dir == null:
		printerr("[art] pasta de cartas não encontrada")
		return
	dir.list_dir_begin()
	var arquivo: String = dir.get_next()
	while arquivo != "":
		if arquivo.ends_with(".tres"):
			var rec: Resource = load(pasta.path_join(arquivo))
			var carta: CartaRoguelite = rec as CartaRoguelite
			if carta != null:
				_carta_sprite(carta)
		arquivo = dir.get_next()
	dir.list_dir_end()


func _carta_sprite(c: CartaRoguelite) -> void:
	var cor: Color = CORES_RARIDADE.get(c.raridade, Color("93a1b8")) as Color
	_novo(30, 40)
	# moldura e face
	_rect(0, 0, 30, 40, _escurecer(cor, 0.55))
	_rect(1, 1, 28, 38, cor)
	_rect(2, 2, 26, 36, Color("121a27"))
	_rect(3, 3, 24, 9, _escurecer(cor, 0.35))
	_rect(3, 3, 24, 1, _clarear(cor, 0.35))
	# emblema central
	_ellipse(15.0, 19.0, 9.0, 9.0, _escurecer(cor, 0.28))
	_emblema(c.atributo, 15, 19, _clarear(cor, 0.25))
	# rodapé / lacre de raridade
	_rect(3, 30, 24, 1, _escurecer(cor, 0.45))
	_rect(4, 32, 22, 2, _escurecer(cor, 0.6))
	_rect(6, 35, 18, 2, _escurecer(cor, 0.45))
	_rect(25, 4, 3, 6, cor)
	_px(26, 5, _clarear(cor, 0.5))
	_px(26, 8, _escurecer(cor, 0.4))
	_salvar("cartas/%s.png" % c.id)


func _emblema(atributo: String, cx: int, cy: int, c: Color) -> void:
	match atributo:
		"dano":
			_rect(cx - 1, cy - 6, 3, 13, c)
			_rect(cx - 6, cy - 1, 13, 3, c)
			_rect(cx - 2, cy - 2, 5, 5, _clarear(c, 0.45))
		"cadencia":
			for i: int in range(3):
				_rect(cx - 6 + i * 5, cy - 5 + i, 3, 11 - i * 2, c)
			_rect(cx - 6, cy + 5, 13, 2, c)
		"critico":
			_ellipse(float(cx), float(cy), 6.5, 6.5, c)
			_ellipse(float(cx), float(cy), 4.0, 4.0, Color("121a27"))
			_rect(cx - 1, cy - 1, 3, 3, _clarear(c, 0.5))
			_linha(cx, cy - 8, cx, cy - 5, c)
			_linha(cx, cy + 5, cx, cy + 8, c)
			_linha(cx - 8, cy, cx - 5, cy, c)
			_linha(cx + 5, cy, cx + 8, cy, c)
		"projeteis":
			for p: Vector2i in [Vector2i(-5, 3), Vector2i(0, -4), Vector2i(5, 3)]:
				_ellipse(float(cx + p.x), float(cy + p.y), 2.4, 2.4, c)
				_rect(cx + p.x - 1, cy + p.y + 3, 2, 3, _escurecer(c, 0.5))
		"perfuracao":
			_linha(cx - 7, cy + 7, cx + 6, cy - 6, c)
			_linha(cx - 7, cy + 7, cx + 2, cy + 7, c)
			_linha(cx - 7, cy + 7, cx - 7, cy + 2, c)
			_linha(cx - 2, cy + 2, cx + 7, cy - 7, _clarear(c, 0.4))
		"cadeia":
			_linha(cx - 6, cy - 7, cx + 1, cy - 2, c)
			_linha(cx + 1, cy - 2, cx - 3, cy + 2, c)
			_linha(cx - 3, cy + 2, cx + 5, cy + 7, c)
			_linha(cx + 1, cy - 2, cx + 1, cy - 2, Color("ffffff"))
		"ricochete":
			_linha(cx - 8, cy + 6, cx, cy - 2, c)
			_linha(cx, cy - 2, cx + 8, cy + 4, c)
			_ellipse(float(cx), float(cy + 7), 2.0, 2.0, c)
		"area_explosao":
			for i: int in range(8):
				var ang: float = TAU * float(i) / 8.0
				_linha(cx + int(cos(ang) * 3.0), cy + int(sin(ang) * 3.0), cx + int(cos(ang) * 8.0), cy + int(sin(ang) * 8.0), c)
			_ellipse(float(cx), float(cy), 3.2, 3.2, _clarear(c, 0.4))
		"aura":
			_ellipse(float(cx), float(cy), 7.5, 7.5, c)
			_ellipse(float(cx), float(cy), 5.2, 5.2, Color("121a27"))
			_ellipse(float(cx), float(cy), 3.4, 3.4, c)
			_ellipse(float(cx), float(cy), 1.4, 1.4, _clarear(c, 0.5))
		"magnetismo":
			_rect(cx - 7, cy - 6, 4, 10, c)
			_rect(cx + 3, cy - 6, 4, 10, c)
			_rect(cx - 7, cy + 3, 14, 4, c)
			_rect(cx - 7, cy - 6, 4, 3, Color("ff5f5f"))
			_rect(cx + 3, cy - 6, 4, 3, Color("5fb3ff"))
		"cura":
			_rect(cx - 2, cy - 7, 5, 15, c)
			_rect(cx - 7, cy - 2, 15, 5, c)
			_rect(cx - 1, cy - 1, 3, 3, Color("ffffff"))
		"vida":
			_ellipse(float(cx - 3), float(cy - 2), 3.6, 3.4, c)
			_ellipse(float(cx + 3), float(cy - 2), 3.6, 3.4, c)
			_ellipse(float(cx), float(cy + 2), 5.0, 4.6, c)
			_rect(cx - 5, cy - 5, 2, 2, _clarear(c, 0.55))
		"velocidade":
			_linha(cx - 6, cy - 5, cx + 2, cy, c)
			_linha(cx + 2, cy, cx - 6, cy + 5, c)
			_linha(cx - 1, cy - 5, cx + 7, cy, _clarear(c, 0.3))
			_linha(cx + 7, cy, cx - 1, cy + 5, _clarear(c, 0.3))
		"dash":
			for i: int in range(3):
				_linha(cx - 8 + i * 2, cy - 5 + i * 5, cx + 4 + i, cy - 5 + i * 5, c)
			_ellipse(float(cx + 6), float(cy), 2.6, 2.6, _clarear(c, 0.4))
		"blindagem":
			_rect(cx - 7, cy - 7, 14, 8, c)
			for i: int in range(5):
				_rect(cx - 6 + i, cy + 1 + i, 13 - i * 2, 1, c)
			_rect(cx - 2, cy - 5, 4, 5, _clarear(c, 0.5))
		"fusao_acida":
			_rect(cx - 2, cy - 8, 4, 5, c)
			_rect(cx - 4, cy - 3, 8, 2, c)
			_rect(cx - 6, cy - 1, 12, 3, c)
			_rect(cx - 5, cy + 2, 10, 6, c)
			_rect(cx - 4, cy + 4, 8, 4, Color("a6ff4a"))
			_px(cx - 2, cy - 6, Color("ffffff"))
		"isotopo", "isotopo_critico", "isotopo_instavel":
			_ellipse(float(cx), float(cy), 3.0, 3.0, _clarear(c, 0.5))
			_linha(cx - 8, cy, cx + 8, cy, c)
			_linha(cx - 5, cy - 5, cx + 5, cy + 5, c)
			_linha(cx - 5, cy + 5, cx + 5, cy - 5, c)
			_px(cx - 8, cy, Color("ffffff"))
			_px(cx + 7, cy + 4, Color("ffffff"))
		_:
			_rect(cx - 3, cy - 7, 7, 14, c)
			_rect(cx - 7, cy - 3, 14, 7, c)
			_rect(cx - 2, cy - 2, 5, 5, _clarear(c, 0.45))


# ---------------------------------------------------------------- partículas / NPC
func _gerar_particulas_e_extras() -> void:
	## Sprites próprios para cada tipo de partícula (todos claros para o
	## modulate do CPUParticles2D colorir).
	# faísca: estrela de 4 pontas
	_novo(7, 7)
	_rect(3, 0, 1, 7, Color.WHITE)
	_rect(0, 3, 7, 1, Color.WHITE)
	_rect(2, 2, 3, 3, Color(1, 1, 1, 0.85))
	_salvar("particulas/faisca.png")
	# fumaça: círculo suave
	_novo(9, 9)
	_ellipse(4.0, 4.0, 4.2, 4.2, Color(1, 1, 1, 0.25))
	_ellipse(4.0, 4.0, 3.0, 3.0, Color(1, 1, 1, 0.5))
	_ellipse(4.0, 4.0, 1.8, 1.8, Color(1, 1, 1, 0.8))
	_salvar("particulas/fumaca.png")
	# ácido: gota
	_novo(7, 9)
	_rect(3, 0, 1, 2, Color(0.9, 1.0, 0.7))
	_rect(2, 2, 3, 2, Color(0.8, 1.0, 0.5))
	_ellipse(3.0, 6.0, 3.0, 2.8, Color(0.85, 1.0, 0.55))
	_ellipse(2.2, 5.2, 1.2, 1.0, Color.WHITE)
	_salvar("particulas/acido.png")
	# fogo: chama
	_novo(7, 9)
	_ellipse(3.0, 6.0, 3.0, 2.6, Color(1, 0.7, 0.35))
	_rect(2, 1, 3, 4, Color(1, 0.55, 0.2))
	_ellipse(3.0, 6.2, 1.6, 1.5, Color(1, 0.95, 0.6))
	_px(3, 0, Color(1, 0.9, 0.5))
	_salvar("particulas/fogo.png")
	# plasma: anel
	_novo(9, 9)
	_ellipse(4.0, 4.0, 4.2, 4.2, Color(0.8, 1, 1, 0.35))
	_ellipse(4.0, 4.0, 2.4, 2.4, Color(0, 0, 0, 0))
	for i: int in range(16):
		var a: float = TAU * float(i) / 16.0
		_px(4 + int(round(cos(a) * 3.4)), 4 + int(round(sin(a) * 3.4)), Color.WHITE)
	_salvar("particulas/plasma.png")
	# sangue químico: respingo
	_novo(9, 9)
	_ellipse(4.0, 4.5, 3.2, 2.6, Color(1, 0.75, 0.85))
	_px(1, 2, Color(1, 0.8, 0.9))
	_px(7, 1, Color(1, 0.8, 0.9))
	_px(8, 4, Color(1, 0.85, 0.92))
	_px(2, 7, Color(1, 0.8, 0.9))
	_salvar("particulas/sangue.png")
	# estrela / moeda
	_novo(7, 7)
	_rect(3, 0, 1, 7, Color(1, 0.95, 0.6))
	_rect(0, 3, 7, 1, Color(1, 0.95, 0.6))
	_rect(2, 2, 3, 3, Color.WHITE)
	_salvar("particulas/estrela.png")
	# bolha
	_novo(7, 7)
	_ellipse(3.0, 3.0, 3.0, 3.0, Color(1, 1, 1, 0.25))
	for i: int in range(12):
		var a: float = TAU * float(i) / 12.0
		_px(3 + int(round(cos(a) * 2.6)), 3 + int(round(sin(a) * 2.6)), Color(1, 1, 1, 0.8))
	_px(2, 2, Color.WHITE)
	_salvar("particulas/bolha.png")
	# cinza
	_novo(6, 6)
	_rect(1, 1, 4, 4, Color(0.8, 0.8, 0.85, 0.7))
	_px(0, 2, Color(0.7, 0.7, 0.75, 0.5))
	_px(5, 3, Color(0.7, 0.7, 0.75, 0.5))
	_salvar("particulas/cinza.png")

	_gerar_mercante()
	_gerar_guardiao()


func _gerar_mercante() -> void:
	## Mercador encapuzado: aparece na loja e na escolha de cartas.
	var manto: Color = Color("2e3a52")
	var manto2: Color = Color("1d2638")
	var pele: Color = Color("c99a72")
	var ouro: Color = Color("ffcf4a")
	var visor: Color = Color("7ff0ff")
	_novo(24, 32)
	# manto
	_ellipse(12.0, 26.0, 10.5, 6.0, manto2)
	_rect(4, 12, 16, 16, manto)
	_rect(3, 18, 2, 10, manto2)
	_rect(19, 18, 2, 10, manto2)
	_rect(5, 13, 14, 8, _clarear(manto, 0.15))
	# capuz
	_ellipse(12.0, 8.0, 8.0, 8.0, manto2)
	_ellipse(12.0, 9.0, 6.4, 6.6, manto)
	# rosto e viseira
	_ellipse(12.0, 10.0, 4.6, 4.4, pele)
	_rect(8, 9, 9, 2, Color("1a2233"))
	_rect(9, 9, 3, 1, visor)
	# barra de ouro e detalhes
	_rect(4, 21, 16, 2, ouro)
	_rect(11, 23, 3, 5, ouro)
	_px(5, 24, ouro)
	_px(19, 24, ouro)
	_px(12, 6, Color("8ff3ff"))
	# braço com frasco
	_rect(18, 17, 3, 6, manto)
	_rect(19, 22, 4, 5, Color("4fd12b"))
	_px(20, 23, Color("b7ffa1"))
	_contorno()
	_salvar("NPC/mercante.png")


func _gerar_guardiao() -> void:
	## Estátua de contenção: pilar de pedra com núcleo e olho de energia.
	var pedra: Color = Color("46505f")
	var pedra2: Color = Color("66758a")
	var rachadura: Color = Color("25303e")
	var energia: Color = Color("9df5ff")
	_novo(28, 30)
	_rect(5, 8, 18, 20, pedra)
	_rect(4, 6, 20, 3, pedra2)
	_rect(7, 9, 14, 5, pedra2)
	_rect(4, 27, 20, 3, Color("2c3542"))
	# rachaduras
	_linha(9, 14, 12, 20, rachadura)
	_linha(18, 13, 16, 19, rachadura)
	_linha(10, 23, 13, 26, rachadura)
	# núcleo
	_ellipse(14.0, 16.0, 5.0, 5.0, Color("2a6f8f"))
	_ellipse(14.0, 16.0, 3.4, 3.4, energia)
	_ellipse(13.2, 15.2, 1.4, 1.2, Color.WHITE)
	# olho superior
	_rect(10, 4, 8, 2, Color("1a2230"))
	_rect(11, 4, 2, 1, energia)
	# braços laterais
	_rect(1, 11, 4, 12, pedra)
	_rect(23, 11, 4, 12, pedra)
	_rect(2, 10, 3, 2, pedra2)
	_rect(23, 10, 3, 2, pedra2)
	# runas
	_px(8, 12, energia)
	_px(20, 12, energia)
	_px(9, 25, energia)
	_px(19, 25, energia)
	_contorno()
	_salvar("enemies/guardiao_final.png")


# ---------------------------------------------------------------- decoração
func _gerar_decoracao() -> void:
	## Props estáticos espalhados pela arena (sem colisão).
	# tanque de contenção
	_novo(30, 46)
	_rect(3, 6, 24, 38, Color("3a4553"))
	_rect(4, 7, 22, 36, Color("4c5a6b"))
	_rect(6, 12, 18, 20, Color("22303a"))
	_rect(7, 14, 16, 16, Color("2f7f5f"))
	_rect(8, 16, 6, 12, Color("6fe0a8"))
	_rect(7, 22, 16, 3, Color("2a6b52"))
	_rect(2, 3, 26, 4, Color("6b7889"))
	_rect(4, 42, 22, 3, Color("2b3442"))
	_rect(12, 0, 6, 4, Color("8b96a5"))
	_rect(9, 10, 2, 26, Color("6b7889"))
	_px(23, 10, Color("ffcf4a"))
	_contorno()
	_salvar("map/deco_tanque.png")

	# barril químico
	_novo(16, 24)
	_ellipse(8.0, 6.0, 6.5, 4.0, Color("b98a2e"))
	_rect(1, 5, 14, 15, Color("d8a23c"))
	_rect(2, 6, 5, 13, Color("f0c46a"))
	_rect(1, 9, 14, 2, Color("6b5a2a"))
	_rect(1, 16, 14, 2, Color("6b5a2a"))
	_rect(3, 12, 4, 3, Color("3a2f18"))
	_rect(9, 12, 4, 3, Color("3a2f18"))
	_ellipse(8.0, 20.0, 6.5, 3.0, Color("9c7526"))
	_px(4, 7, Color("fff0b8"))
	_contorno()
	_salvar("map/deco_barril.png")

	# caixote
	_novo(20, 20)
	_rect(1, 3, 18, 16, Color("7a5634"))
	_rect(2, 4, 16, 14, Color("9a6f45"))
	_rect(2, 4, 16, 2, Color("c08d59"))
	_linha(3, 5, 17, 17, Color("6b4a2c"))
	_linha(17, 5, 3, 17, Color("6b4a2c"))
	_rect(3, 15, 14, 3, Color("5d3f25"))
	_rect(8, 1, 4, 3, Color("c08d59"))
	_contorno()
	_salvar("map/deco_caixote.png")

	# cano horizontal
	_novo(48, 14)
	_rect(0, 4, 48, 7, Color("59636f"))
	_rect(0, 5, 48, 2, Color("8a95a3"))
	_rect(0, 9, 48, 2, Color("3d454f"))
	for x: int in [6, 22, 38]:
		_rect(x, 3, 3, 9, Color("757f8c"))
		_rect(x, 2, 3, 2, Color("9aa4b0"))
	_px(12, 7, Color("ff7a59"))
	_contorno()
	_salvar("map/deco_cano.png")

	# placa de perigo
	_novo(24, 24)
	_rect(11, 10, 3, 14, Color("59636f"))
	_rect(4, 1, 17, 12, Color("d8a23c"))
	_rect(5, 2, 15, 10, Color("f0c46a"))
	_rect(11, 4, 3, 5, Color("2b2110"))
	_rect(11, 10, 3, 2, Color("2b2110"))
	_contorno()
	_salvar("map/deco_placa.png")

	# poça química
	_novo(36, 20)
	_ellipse(18.0, 11.0, 15.0, 7.0, Color("2f7f5f"))
	_ellipse(17.0, 10.0, 12.0, 5.2, Color("4fd12b"))
	_ellipse(13.0, 8.0, 5.0, 2.4, Color("a6ff8a"))
	_ellipse(24.0, 12.0, 4.0, 2.0, Color("2f7f5f"))
	_px(6, 12, Color("8affb0"))
	_salvar("map/deco_poca.png")

	# luminária
	_novo(14, 28)
	_rect(6, 8, 3, 20, Color("3d454f"))
	_rect(3, 22, 9, 3, Color("2b3442"))
	_rect(2, 2, 11, 4, Color("59636f"))
	_rect(4, 6, 7, 4, Color("ffcf4a"))
	_rect(5, 7, 5, 2, Color("fff0b8"))
	_px(2, 6, Color("ffcf4a"))
	_px(11, 6, Color("ffcf4a"))
	_contorno()
	_salvar("map/deco_luminaria.png")

	# cristal de isótopo
	_novo(18, 22)
	_linha(9, 0, 16, 8, Color("ff5f92"))
	_linha(16, 8, 9, 21, Color("ff5f92"))
	_linha(9, 21, 2, 8, Color("ff5f92"))
	_linha(2, 8, 9, 0, Color("ff5f92"))
	_linha(5, 8, 13, 8, Color("ffd3e2"))
	_linha(9, 3, 9, 18, Color("c73d69"))
	_px(8, 6, Color("ffffff"))
	_contorno()
	_salvar("map/deco_cristal.png")


# ---------------------------------------------------------------- folhas de animação
const FOLHAS := [
	"player/player.png",
	"enemies/hidrogenio.png",
	"enemies/carbono.png",
	"enemies/ferro.png",
	"enemies/slime.png",
	"enemies/granadeiro.png",
	"enemies/guardiao_final.png",
	"bosses/cloro.png",
	"bosses/mercurio.png",
	"bosses/uranio.png",
	"bosses/elemento_supremo.png",
]


func _gerar_folhas() -> void:
	## Folha 4x4: linhas = idle, andar, ataque, dano; colunas = quadros.
	## Cada quadro tem 3px de respiro para o balanço não cortar a arte.
	for caminho: String in FOLHAS:
		_folha_animada(caminho)


func _folha_animada(caminho: String) -> void:
	var origem: String = ProjectSettings.globalize_path(SPRITES_DIR.path_join(caminho))
	if not FileAccess.file_exists(origem):
		return
	var base: Image = Image.load_from_file(origem)
	if base == null:
		return
	var w: int = base.get_width()
	var h: int = base.get_height()
	var cw: int = w + 6
	var ch: int = h + 6
	var folha: Image = Image.create_empty(cw * 4, ch * 4, false, Image.FORMAT_RGBA8)
	folha.fill(Color(0, 0, 0, 0))
	for linha: int in range(4):
		for col: int in range(4):
			var quadro: Image = base.duplicate() as Image
			var dx: int = 0
			var dy: int = 0
			match linha:
				0:  # idle: respiração
					dy = [0, -1, 0, 1][col]
				1:  # andar: passada + sobe/desce
					dy = [0, -2, 0, -2][col]
					dx = [0, 1, 0, -1][col]
				2:  # ataque: avança e clareia
					dx = [0, 1, 2, 1][col]
					dy = [0, -1, -2, -1][col]
					quadro = _tingir(quadro, Color(1.5, 1.22, 0.85))
				_:  # dano: recua e avermelha
					dx = [-1, -2, -1, 0][col]
					quadro = _tingir(quadro, Color(1.75, 0.45, 0.45))
			folha.blit_rect(quadro, Rect2i(0, 0, w, h), Vector2i(col * cw + 3 + dx, linha * ch + 3 + dy))
	var destino: String = ProjectSettings.globalize_path(SPRITES_DIR.path_join(caminho.get_basename() + "_sheet.png"))
	folha.save_png(destino)


func _tingir(img: Image, f: Color) -> Image:
	var copia: Image = img.duplicate() as Image
	for y: int in range(copia.get_height()):
		for x: int in range(copia.get_width()):
			var p: Color = copia.get_pixel(x, y)
			if p.a <= 0.0:
				continue
			copia.set_pixel(x, y, Color(minf(1.0, p.r * f.r), minf(1.0, p.g * f.g), minf(1.0, p.b * f.b), p.a))
	return copia
