extends Node
## Cliente de teste: conecta ao host pelo campo de IP (127.0.0.1).

var conectou: bool = false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	await get_tree().create_timer(0.5, true, false, true).timeout
	NetworkManager.conectado.connect(func() -> void:
		conectou = true
		print("CLIENT conectado, peers=", multiplayer.get_peers().size())
	)
	NetworkManager.conexao_falhou.connect(func(txt: String) -> void: print("CLIENT falhou: ", txt))
	NetworkManager.entrar_sala("127.0.0.1", 7899)
	await get_tree().create_timer(4.5, true, false, true).timeout
	print("CLIENT resultado=", conectou, " modo=", NetworkManager.modo)
	get_tree().quit(0 if conectou else 1)
