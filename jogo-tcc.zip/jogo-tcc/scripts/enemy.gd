extends CharacterBody2D

const CENA_SANGUE = preload("res://scenes/blood.tscn")

enum Estado {
	PERSEGUINDO,
	PREPARANDO,
	AVANCANDO,
	RECUANDO,
	ATORDOADO
}

# Configurações de Limites do Mapa
@export var tamanho_mapa: Vector2 = Vector2(1280.0, 720.0)

# Configurações de Movimento e Investida (Dash)
@export var velocidade: float = 150.0
@export var distancia_ataque: float = 192.0
@export var tempo_preparacao: float = 0.35
@export var velocidade_dash: float = 780.0
@export var duracao_dash: float = 0.25
@export var velocidade_recuo: float = 220.0
@export var duracao_recuo: float = 0.25
@export var cooldown_ataque: float = 1.5
@export var dano_ataque: int = 10

# Configurações de Vida, Pontuação e Impacto
@export var vida_maxima: float = 100.0
@export var pontos_ao_morrer: int = 10
@export var cura_ao_morrer: float = 10.0
@export var intensidade_tremor_morte: float = 12.0

var vida_atual: float = 100.0
var estado_atual: Estado = Estado.PERSEGUINDO
var estado_anterior: Estado = Estado.PERSEGUINDO

var tempo_estado: float = 0.0
var tempo_cooldown: float = 0.0
var direcao_dash: Vector2 = Vector2.ZERO
var acertou_neste_dash: bool = false
var z_index_original: int = 0
var excecoes_ativas: Array[PhysicsBody2D] = []

@onready var barra_vida_enemy: TextureProgressBar = $life_enemy

var alvo_jogador: CharacterBody2D = null

# Variáveis para o efeito de gelatina no sprite visual
var sprite_visual: Node2D = null
var tempo_animacao: float = 0.0
var escala_base: Vector2 = Vector2.ONE

func _ready() -> void:
	add_to_group("inimigos")
	z_index_original = z_index
	
	vida_atual = vida_maxima
	if barra_vida_enemy:
		barra_vida_enemy.max_value = vida_maxima
		barra_vida_enemy.value = vida_atual
		
	for filho in get_children():
		if filho is Sprite2D or filho is AnimatedSprite2D:
			sprite_visual = filho
			escala_base = sprite_visual.scale
			break
			
	tempo_animacao = randf() * 10.0

func _physics_process(delta: float) -> void:
	if tempo_cooldown > 0.0:
		tempo_cooldown -= delta

	if alvo_jogador == null:
		alvo_jogador = get_tree().current_scene.find_child("player", true, false) as CharacterBody2D

	match estado_atual:
		Estado.ATORDOADO:
			velocity = Vector2.ZERO
			move_and_slide()
			_atualizar_gelatina(delta, Vector2.ZERO)

		Estado.PERSEGUINDO:
			_processar_perseguicao(delta)

		Estado.PREPARANDO:
			_processar_preparacao(delta)

		Estado.AVANCANDO:
			_processar_avanco(delta)

		Estado.RECUANDO:
			_processar_recuo(delta)
			
	# Teleporta para o centro caso saia da arena (1280x720)
	_verificar_limites_mapa()

func _verificar_limites_mapa() -> void:
	if global_position.x < 0.0 or global_position.x > tamanho_mapa.x or global_position.y < 0.0 or global_position.y > tamanho_mapa.y:
		global_position = tamanho_mapa / 2.0
		velocity = Vector2.ZERO
		if estado_atual in [Estado.AVANCANDO, Estado.RECUANDO]:
			_restaurar_colisao_colegas()
			estado_atual = Estado.PERSEGUINDO

func _processar_perseguicao(delta: float) -> void:
	if alvo_jogador == null:
		velocity = Vector2.ZERO
		move_and_slide()
		_atualizar_gelatina(delta, Vector2.ZERO)
		return

	var distancia: float = global_position.distance_to(alvo_jogador.global_position)
	var direcao: Vector2 = (alvo_jogador.global_position - global_position).normalized()

	if distancia <= distancia_ataque and tempo_cooldown <= 0.0:
		estado_atual = Estado.PREPARANDO
		tempo_estado = tempo_preparacao
		direcao_dash = direcao
		acertou_neste_dash = false
		velocity = Vector2.ZERO
		
		if direcao_dash.x != 0 and sprite_visual and "flip_h" in sprite_visual:
			sprite_visual.flip_h = direcao_dash.x < 0
	elif distancia <= distancia_ataque:
		velocity = Vector2.ZERO
		move_and_slide()
		_atualizar_gelatina(delta, velocity)
	else:
		velocity = direcao * velocidade
		move_and_slide()
		_atualizar_gelatina(delta, velocity)

func _processar_preparacao(delta: float) -> void:
	velocity = Vector2.ZERO
	move_and_slide()
	tempo_estado -= delta
	
	if sprite_visual:
		var escala_prep := Vector2(escala_base.x * 1.35, escala_base.y * 0.65)
		sprite_visual.scale = sprite_visual.scale.lerp(escala_prep, 18.0 * delta)
		sprite_visual.rotation = lerp(sprite_visual.rotation, 0.0, 18.0 * delta)

	if tempo_estado <= 0.0:
		_iniciar_salto()

func _iniciar_salto() -> void:
	estado_atual = Estado.AVANCANDO
	tempo_estado = duracao_dash
	z_index = z_index_original + 2
	
	excecoes_ativas.clear()
	for colega in get_tree().get_nodes_in_group("inimigos"):
		if colega != self and colega is PhysicsBody2D:
			add_collision_exception_with(colega)
			excecoes_ativas.append(colega)

func _finalizar_salto_para_recuo() -> void:
	_restaurar_colisao_colegas()
	estado_atual = Estado.RECUANDO
	tempo_estado = duracao_recuo

func _restaurar_colisao_colegas() -> void:
	z_index = z_index_original
	for colega in excecoes_ativas:
		if is_instance_valid(colega):
			remove_collision_exception_with(colega)
	excecoes_ativas.clear()

func _processar_avanco(delta: float) -> void:
	velocity = direcao_dash * velocidade_dash
	move_and_slide()
	tempo_estado -= delta
	
	if sprite_visual:
		var escala_pulo := Vector2(escala_base.x * 0.75, escala_base.y * 1.30)
		sprite_visual.scale = sprite_visual.scale.lerp(escala_pulo, 22.0 * delta)
		sprite_visual.rotation = lerp(sprite_visual.rotation, sign(direcao_dash.x) * 0.22, 22.0 * delta)

	if alvo_jogador != null and not acertou_neste_dash:
		for i in get_slide_collision_count():
			var colisao := get_slide_collision(i)
			if colisao.get_collider() == alvo_jogador:
				acertou_neste_dash = true
				if alvo_jogador.has_method("receber_dano"):
					alvo_jogador.receber_dano(dano_ataque)
				_finalizar_salto_para_recuo()
				return

	if tempo_estado <= 0.0:
		_finalizar_salto_para_recuo()

func _processar_recuo(delta: float) -> void:
	velocity = -direcao_dash * velocidade_recuo
	move_and_slide()
	tempo_estado -= delta
	
	if sprite_visual:
		sprite_visual.scale = sprite_visual.scale.lerp(escala_base, 14.0 * delta)
		sprite_visual.rotation = lerp(sprite_visual.rotation, 0.0, 14.0 * delta)

	if tempo_estado <= 0.0:
		estado_atual = Estado.PERSEGUINDO
		tempo_cooldown = cooldown_ataque

func _atualizar_gelatina(delta: float, movimento: Vector2) -> void:
	if sprite_visual == null:
		return
		
	tempo_animacao += delta
	var escala_alvo: Vector2 = escala_base
	var rotacao_alvo: float = 0.0
	
	if movimento.length() > 5.0:
		if movimento.x != 0 and "flip_h" in sprite_visual:
			sprite_visual.flip_h = movimento.x < 0
			
		var pulso_passo: float = sin(tempo_animacao * 14.0) * 0.20
		escala_alvo = Vector2(
			escala_base.x * (1.0 + pulso_passo),
			escala_base.y * (1.0 - pulso_passo)
		)
		rotacao_alvo = sign(movimento.x) * 0.12
	else:
		var respiracao: float = sin(tempo_animacao * 4.0) * 0.08
		escala_alvo = Vector2(
			escala_base.x * (1.0 - respiracao * 0.6),
			escala_base.y * (1.0 + respiracao)
		)
		
	sprite_visual.scale = sprite_visual.scale.lerp(escala_alvo, 15.0 * delta)
	sprite_visual.rotation = lerp(sprite_visual.rotation, rotacao_alvo, 15.0 * delta)

func receber_dano_enemy(quantidade: float) -> void:
	vida_atual -= quantidade
	vida_atual = max(vida_atual, 0.0)
	
	if barra_vida_enemy:
		barra_vida_enemy.value = vida_atual
		
	if vida_atual <= 0.0:
		derrotar_inimigo()
	else:
		aplicar_hitstun()

func aplicar_hitstun() -> void:
	if estado_atual != Estado.ATORDOADO:
		estado_anterior = estado_atual
	
	_restaurar_colisao_colegas()
	estado_atual = Estado.ATORDOADO
	modulate.a = 0.5
	
	if sprite_visual:
		sprite_visual.scale = Vector2(escala_base.x * 1.3, escala_base.y * 0.7)
	
	await get_tree().create_timer(0.1).timeout
	
	if is_instance_valid(self):
		modulate.a = 1.0
		if estado_anterior in [Estado.PREPARANDO, Estado.AVANCANDO, Estado.RECUANDO]:
			estado_atual = Estado.PERSEGUINDO
			tempo_cooldown = cooldown_ataque * 0.5
		else:
			estado_atual = Estado.PERSEGUINDO

func derrotar_inimigo() -> void:
	if CENA_SANGUE != null:
		var sangue = CENA_SANGUE.instantiate()
		sangue.global_position = global_position
		get_tree().current_scene.add_child(sangue)
		
	GlobalManager.alterar_vida(cura_ao_morrer)
	GlobalManager.adicionar_pontos(pontos_ao_morrer)
	GlobalManager.tremer_tela(intensidade_tremor_morte)
		
	get_tree().call_group("gerenciador_gameplay", "registrar_morte_inimigo")
	queue_free()
