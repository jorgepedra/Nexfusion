extends AnimatedSprite2D

const BALA_TUNGSTENIO = preload("res://scenes/bullet_w.tscn")

var bala_atual: PackedScene = BALA_TUNGSTENIO
@export var raio_orbita: float = 20.0
@export var cadencia_tiro_automatico: float = 0.5
@export var forca_recuo: float = 8.0 # Quantos pixels a arma vai para trás no tiro
@export var intensidade_tremor: float = 2.5 # Força do tremor leve na tela ao atirar

var tempo_ate_proximo_tiro: float = 0.0
var recuo_atual: float = 0.0
var escala_base: Vector2 = Vector2.ONE

func _ready() -> void:
	escala_base = scale
	play("Idle")
	animation_finished.connect(_on_animation_finished)

func _physics_process(delta: float) -> void:
	var pos_mouse = get_global_mouse_position()
	var pai = get_parent()
	
	# Faz o recuo e a deformação voltarem suavemente ao normal
	recuo_atual = lerp(recuo_atual, 0.0, 18.0 * delta)
	scale = scale.lerp(escala_base, 18.0 * delta)
	
	if pai is Node2D:
		var direcao = (pos_mouse - pai.global_position).normalized()
		# Subtrai o recuo_atual para empurrar a arma para trás na direção oposta ao tiro
		global_position = pai.global_position + (direcao * (raio_orbita - recuo_atual))
	
	look_at(pos_mouse)
	flip_v = pos_mouse.x < global_position.x
	
	# Tiro automático enquanto segura o botão esquerdo
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		tempo_ate_proximo_tiro -= delta
		if tempo_ate_proximo_tiro <= 0.0:
			atirar()
			tempo_ate_proximo_tiro = cadencia_tiro_automatico

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_1:
			bala_atual = BALA_TUNGSTENIO

	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		atirar()
		tempo_ate_proximo_tiro = cadencia_tiro_automatico

func atirar() -> void:
	play("Fire")
	
	# Aplica o tranco para trás, o achatamento na arma e o tremor leve na tela
	recuo_atual = forca_recuo
	scale = Vector2(escala_base.x * 0.78, escala_base.y * 1.22)
	GlobalManager.tremer_tela(intensidade_tremor)
	
	if bala_atual != null:
		var nova_bala = bala_atual.instantiate()
		nova_bala.global_position = global_position
		nova_bala.global_rotation = global_rotation
		get_tree().current_scene.add_child(nova_bala)

func _on_animation_finished() -> void:
	if animation == "Fire":
		play("Idle")
