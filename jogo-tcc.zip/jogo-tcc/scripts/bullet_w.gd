extends Area2D

@export var dano: float = 25.0
@export var alcance_tiro: float = 256.0 # Coloque aqui o comprimento visual em pixels do seu tiro
@export var tempo_fade: float = 0.25

@onready var sprite: Sprite2D = $Sprite2D

func _ready() -> void:
	animar_desaparecimento()
	aplicar_dano_em_linha()

func aplicar_dano_em_linha() -> void:
	# Calcula o ponto inicial (ponta da arma) e o ponto final do raio
	var inicio: Vector2 = global_position
	var fim: Vector2 = global_position + (transform.x * alcance_tiro)
	
	# Acessa o espaço de física 2D do mundo atual
	var espaco_fisica = get_world_2d().direct_space_state
	
	# Guarda quem já foi atingido para a linha perfurar vários inimigos em fila
	var ignorar_rids: Array[RID] = []
	
	# Acha o player para nunca acertar ele
	var jogador = get_tree().current_scene.find_child("player", true, false)
	if jogador is CollisionObject2D:
		ignorar_rids.append(jogador.get_rid())
	
	# Loop para perfurar todos os inimigos alinhados na frente do tiro
	while true:
		var query = PhysicsRayQueryParameters2D.create(inicio, fim)
		query.exclude = ignorar_rids
		
		var resultado = espaco_fisica.intersect_ray(query)
		
		# Se não bateu em mais nada na linha, encerra o loop
		if resultado.is_empty():
			break
			
		var alvo = resultado.collider
		ignorar_rids.append(resultado.rid) # Ignora este alvo na próxima checagem para o raio atravessar
		
		if alvo.has_method("receber_dano_enemy"):
			alvo.receber_dano_enemy(dano)
			print("Acertou inimigo: ", alvo.name)

func animar_desaparecimento() -> void:
	var tween = create_tween()
	tween.set_parallel(true)
	tween.tween_property(sprite, "modulate:a", 0.0, tempo_fade)
	tween.tween_property(sprite, "scale:y", 0.0, tempo_fade)
	await tween.finished
	queue_free()
