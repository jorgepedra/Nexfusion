extends CharacterBody2D

@export var velocidade: float = 300.0
@export var tamanho_mapa: Vector2 = Vector2(1280.0, 720.0)

var invulneravel: bool = false

var sprite_visual: AnimatedSprite2D = null
var tempo_animacao: float = 0.0
var escala_base: Vector2 = Vector2.ONE

func _ready() -> void:
	# Encontra o nó AnimatedSprite2D filho automaticamente
	for filho in get_children():
		if filho is AnimatedSprite2D:
			sprite_visual = filho
			break
			
	if sprite_visual:
		escala_base = sprite_visual.scale

func _physics_process(delta: float) -> void:
	var direcao = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	velocity = direcao * velocidade
	move_and_slide()
	
	# Teleporta para o centro caso saia da arena (1280x720)
	_verificar_limites_mapa()
	
	_atualizar_visual_e_gelatina(delta, direcao)

func _verificar_limites_mapa() -> void:
	if global_position.x < 0.0 or global_position.x > tamanho_mapa.x or global_position.y < 0.0 or global_position.y > tamanho_mapa.y:
		global_position = tamanho_mapa / 2.0
		velocity = Vector2.ZERO

func _atualizar_visual_e_gelatina(delta: float, direcao: Vector2) -> void:
	if sprite_visual == null:
		return
		
	tempo_animacao += delta
	var escala_alvo: Vector2 = escala_base
	var rotacao_alvo: float = 0.0
	
	if direcao != Vector2.ZERO:
		# --- ESTADO: ANDANDO (Gelatina Equilibrada) ---
		if sprite_visual.sprite_frames and sprite_visual.sprite_frames.has_animation("Walk"):
			sprite_visual.play("Walk")
			
		if direcao.x != 0:
			sprite_visual.flip_h = direcao.x < 0
			
		# Deformação moderada (22% de esticada/achatamento)
		var pulso_passo: float = sin(tempo_animacao * 16.0) * 0.22
		escala_alvo = Vector2(
			escala_base.x * (1.0 + pulso_passo),
			escala_base.y * (1.0 - pulso_passo)
		)
		# Inclinação leve na direção do movimento
		rotacao_alvo = direcao.x * 0.14
	else:
		# --- ESTADO: PARADO (Respiração Suave) ---
		if sprite_visual.sprite_frames and sprite_visual.sprite_frames.has_animation("Idle"):
			sprite_visual.play("Idle")
			
		# Estica 10% na altura e encolhe proporcionalmente na largura
		var respiracao: float = sin(tempo_animacao * 4.0) * 0.10
		escala_alvo = Vector2(
			escala_base.x * (1.0 - respiracao * 0.6),
			escala_base.y * (1.0 + respiracao)
		)
		rotacao_alvo = 0.0
		
	sprite_visual.scale = sprite_visual.scale.lerp(escala_alvo, 16.0 * delta)
	sprite_visual.rotation = lerp(sprite_visual.rotation, rotacao_alvo, 16.0 * delta)

func receber_dano(quantidade: int) -> void:
	if invulneravel:
		return
		
	GlobalManager.alterar_vida(-quantidade)
	
	if GlobalManager.vida_atual <= 0:
		print("O jogador morreu!")
	else:
		_ativar_invulnerabilidade()

func _ativar_invulnerabilidade() -> void:
	invulneravel = true
	modulate.a = 0.5
	await get_tree().create_timer(0.1).timeout
	invulneravel = false
	modulate.a = 1.0
