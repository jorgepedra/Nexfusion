extends Node

func _unhandled_input(event: InputEvent) -> void:
	# Captura o clique da tecla "P" sem repetir ao segurar
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_P:
			_causar_metade_dano_no_inimigo()

func _causar_metade_dano_no_inimigo() -> void:
	var cena_raiz = get_tree().current_scene
	var inimigos_ativos: Array = []
	
	# Procura por todos os monstros ativos no mapa pelo script deles
	_buscar_inimigos_recursivo(cena_raiz, inimigos_ativos)
	
	if inimigos_ativos.size() > 0:
		# Seleciona o monstro mais antigo na tela
		var alvo_teste = inimigos_ativos[0]
		
		# Verifica se o alvo possui as variáveis de vida e o método de dano
		if alvo_teste.has_method("receber_dano_enemy") and "vida_maxima" in alvo_teste:
			# Calcula metade do valor total da vida máxima configurada (Ex: 100 / 2 = 50 de dano)
			var dano_metade: float = alvo_teste.vida_maxima / 2.0
			print("Debug: Aplicando ", dano_metade, " de dano (50%) no inimigo de ID: ", alvo_teste.get_instance_id())
			
			alvo_teste.receber_dano_enemy(dano_metade)
	else:
		print("Debug: Nenhum inimigo restando na tela para sofrer dano.")

# Varre a árvore de nós procurando por instâncias que usem o script "enemy.gd"
func _buscar_inimigos_recursivo(no_atual: Node, lista_resultado: Array) -> void:
	if no_atual is CharacterBody2D:
		var script_do_no = no_atual.get_script()
		if script_do_no and "enemy.gd" in script_do_no.resource_path.to_lower():
			lista_resultado.append(no_atual)
			
	for filho in no_atual.get_children():
		_buscar_inimigos_recursivo(filho, lista_resultado)
