extends Node

# --- DADOS DO JOGADOR ---
var vida_atual: float = 100.0
var vida_maxima: float = 200.0
var limite_decaimento: float = 100.0
var taxa_decaimento: float = 2.0

# --- DADOS DA PARTIDA E HORDAS ---
var pontuacao: int = 0
var rank_atual: String = "F"
var horda_atual: int = 1
var inimigos_restantes: int = 0

# --- TABELA DE CLASSIFICAÇÕES, PONTOS MÍNIMOS E CORES ---
var faixas_rank: Array[Dictionary] = [
	{ "pontos": 0,    "letra": "F",    "cor": Color(0.65, 0.65, 0.65) }, # Cinza
	{ "pontos": 100,  "letra": "D",    "cor": Color(0.20, 0.55, 1.00) }, # Azul
	{ "pontos": 250,  "letra": "C",    "cor": Color(0.20, 0.85, 0.35) }, # Verde
	{ "pontos": 500,  "letra": "B",    "cor": Color(1.00, 0.90, 0.15) }, # Amarelo
	{ "pontos": 750,  "letra": "A",    "cor": Color(1.00, 0.50, 0.10) }, # Laranja
	{ "pontos": 1000, "letra": "S",    "cor": Color(0.35, 0.10, 0.60) }, # Roxo escuro
	{ "pontos": 1250, "letra": "S+",   "cor": Color(0.65, 0.25, 0.95) }, # Roxo normal
	{ "pontos": 1500, "letra": "S++",  "cor": Color(0.85, 0.30, 0.80) }, # Roxo meio rosa
	{ "pontos": 1750, "letra": "S+++", "cor": Color(1.00, 0.35, 0.70) }, # Rosa
	{ "pontos": 2000, "letra": "P",    "cor": Color(1.00, 0.82, 0.00) }  # Base para o Arco-íris Brillhante
]

# --- CONTROLE DE ANIMAÇÃO DA LETRA, ARCO-ÍRIS E TREMOR ---
var tempo_gelatina_rank: float = 0.0
var tempo_arco_iris: float = 0.0
var impulso_rank: float = 0.0
var forca_tremor: float = 0.0
var decaimento_tremor: float = 35.0

func _ready() -> void:
	call_deferred("atualizar_toda_hud")

func _process(delta: float) -> void:
	# 1. Decaimento da vida acima de 100
	if vida_atual > limite_decaimento:
		vida_atual = max(vida_atual - (taxa_decaimento * delta), limite_decaimento)
		_atualizar_hud_vida()
		
	# 2. Processa o tremor da câmera ativa
	var camera = get_viewport().get_camera_2d()
	if camera != null:
		if forca_tremor > 0.1:
			camera.offset = Vector2(
				randf_range(-forca_tremor, forca_tremor),
				randf_range(-forca_tremor, forca_tremor)
			)
			forca_tremor = lerp(forca_tremor, 0.0, decaimento_tremor * delta)
		elif camera.offset != Vector2.ZERO:
			forca_tremor = 0.0
			camera.offset = Vector2.ZERO
			
	# 3. Efeito gelatinoso sutil APENAS na letra da classificação (classe_score)
	_animar_gelatina_classe(delta)
	
	# 4. Efeito brilhante colorido (arco-íris) contínuo ao atingir o rank P
	if rank_atual == "P":
		_atualizar_brilho_rank_p(delta)

func _atualizar_brilho_rank_p(delta: float) -> void:
	var cena = get_tree().current_scene
	if cena == null:
		return
		
	tempo_arco_iris += delta
	
	# Gira o matiz (0.0 a 1.0) continuamente e pulsa o brilho acima de 1.0 (1.15 a 1.35)
	var matiz: float = fmod(tempo_arco_iris * 0.8, 1.0)
	var brilho: float = 1.25 + (sin(tempo_arco_iris * 8.0) * 0.12)
	var cor_arco_iris: Color = Color.from_hsv(matiz, 0.85, brilho)
	
	var label_titulo = cena.find_child("label_score", true, false) as Label
	var label_score = cena.find_child("cont_score", true, false) as Label
	var label_classe = cena.find_child("classe_score", true, false) as Label
	
	if label_titulo:
		label_titulo.self_modulate = cor_arco_iris
	if label_score:
		label_score.self_modulate = cor_arco_iris
	if label_classe:
		label_classe.self_modulate = cor_arco_iris

func _animar_gelatina_classe(delta: float) -> void:
	var cena = get_tree().current_scene
	if cena == null:
		return
		
	var label_classe = cena.find_child("classe_score", true, false) as Label
	if label_classe == null:
		return
		
	tempo_gelatina_rank += delta
	impulso_rank = lerp(impulso_rank, 0.0, 10.0 * delta)
	
	label_classe.pivot_offset = label_classe.size / 2.0
	
	# Balanço bem suave (4%) e rotação discreta (0.03 rad)
	var onda: float = sin(tempo_gelatina_rank * 4.0) * 0.04
	var escala_x: float = 1.0 + onda + impulso_rank
	var escala_y: float = 1.0 - onda + impulso_rank
	
	label_classe.scale = Vector2(escala_x, escala_y)
	label_classe.rotation = cos(tempo_gelatina_rank * 3.0) * 0.03

func tremer_tela(intensidade: float) -> void:
	forca_tremor = max(forca_tremor, intensidade)

# --- CONTROLE DE VIDA ---
func alterar_vida(quantidade: float) -> void:
	vida_atual = clamp(vida_atual + quantidade, 0.0, vida_maxima)
	_atualizar_hud_vida()

# --- CONTROLE DE PONTUAÇÃO E COR GRADUAL ---
func adicionar_pontos(quantidade: int) -> void:
	pontuacao += quantidade
	_atualizar_hud_score()

func _obter_dados_rank_gradual(pontos: int) -> Dictionary:
	var indice_atual: int = 0
	for i in range(faixas_rank.size()):
		if pontos >= faixas_rank[i]["pontos"]:
			indice_atual = i
		else:
			break
			
	var faixa_atual: Dictionary = faixas_rank[indice_atual]
	var letra: String = faixa_atual["letra"]
	var cor_final: Color = faixa_atual["cor"]
	
	if indice_atual < faixas_rank.size() - 1:
		var proxima_faixa: Dictionary = faixas_rank[indice_atual + 1]
		var pts_inicio: float = float(faixa_atual["pontos"])
		var pts_fim: float = float(proxima_faixa["pontos"])
		
		var progresso: float = clamp((float(pontos) - pts_inicio) / (pts_fim - pts_inicio), 0.0, 1.0)
		cor_final = faixa_atual["cor"].lerp(proxima_faixa["cor"], progresso)
		
	return { "letra": letra, "cor": cor_final }

# --- CONTROLE DE INIMIGOS NA HORDA ---
func atualizar_inimigos_horda(restantes: int) -> void:
	inimigos_restantes = max(restantes, 0)
	_atualizar_hud_inimigos()

# --- RESET PARA NOVA PARTIDA ---
func resetar_dados() -> void:
	vida_atual = 100.0
	pontuacao = 0
	rank_atual = "F"
	horda_atual = 1
	inimigos_restantes = 0
	forca_tremor = 0.0
	impulso_rank = 0.0
	tempo_arco_iris = 0.0
	atualizar_toda_hud()

# --- ATUALIZAÇÃO DA INTERFACE (HUD) ---
func atualizar_toda_hud() -> void:
	_atualizar_hud_vida()
	_atualizar_hud_score()
	_atualizar_hud_inimigos()

func _atualizar_hud_vida() -> void:
	var cena = get_tree().current_scene
	if cena == null:
		return
		
	var barra_vida = cena.find_child("bar_vida", true, false) as TextureProgressBar
	var label_vida = cena.find_child("cont_vida", true, false) as Label
	
	if barra_vida:
		barra_vida.max_value = vida_maxima
		barra_vida.value = vida_atual
	if label_vida:
		label_vida.text = str(int(ceil(vida_atual)))

func _atualizar_hud_score() -> void:
	var cena = get_tree().current_scene
	if cena == null:
		return
		
	var label_titulo = cena.find_child("label_score", true, false) as Label
	var label_score = cena.find_child("cont_score", true, false) as Label
	var label_classe = cena.find_child("classe_score", true, false) as Label
	
	var dados: Dictionary = _obter_dados_rank_gradual(pontuacao)
	var nova_letra: String = dados["letra"]
	var cor_atual: Color = dados["cor"]
	
	if label_titulo:
		if nova_letra != "P":
			label_titulo.self_modulate = cor_atual
		
	if label_score:
		label_score.text = "%04d" % pontuacao
		if nova_letra != "P":
			label_score.self_modulate = cor_atual
		
	if label_classe:
		label_classe.text = nova_letra
		if nova_letra != "P":
			label_classe.self_modulate = cor_atual
		
		if nova_letra != rank_atual:
			rank_atual = nova_letra
			impulso_rank = 0.22

func _atualizar_hud_inimigos() -> void:
	var cena = get_tree().current_scene
	if cena == null:
		return
		
	var label_enemy = cena.find_child("cont_enemy", true, false) as Label
	if label_enemy:
		label_enemy.text = "%03d" % inimigos_restantes
