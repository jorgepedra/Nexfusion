extends Node2D

const CENA_INIMIGO = preload("res://scenes/enemy.tscn")

# Configurações das Hordas
var horda_atual: int = 1
var inimigos_derrotados_nesta_horda: int = 0

var configuracao_hordas: Dictionary = {
	1: 3,
	2: 5,
	3: 8,
	4: 12,
	5: 20
}

# Dimensões do mapa e margem das bordas
@export var tamanho_mapa: Vector2 = Vector2(1280.0, 720.0)
@export var distancia_da_borda: float = 100.0

# Velocidade de surgimento progressiva
@export var intervalo_spawn_inicial: float = 0.5
@export var reducao_por_horda: float = 0.06
@export var intervalo_spawn_minimo: float = 0.08

@onready var timer_intervalo: Timer = $Timer

func _ready() -> void:
	add_to_group("gerenciador_gameplay")
	
	if timer_intervalo:
		timer_intervalo.timeout.connect(_on_timer_intervalo_timeout)
		
	await get_tree().create_timer(1.2).timeout
	_iniciar_horda(horda_atual)

func _iniciar_horda(numero_horda: int) -> void:
	inimigos_derrotados_nesta_horda = 0
	GlobalManager.horda_atual = numero_horda
	
	var quantidade_para_spawnar: int = configuracao_hordas.get(numero_horda, numero_horda * 4)
	var intervalo_atual: float = max(intervalo_spawn_minimo, intervalo_spawn_inicial - ((numero_horda - 1) * reducao_por_horda))
	
	# Avisa o GlobalManager quantos inimigos existem nesta horda
	GlobalManager.atualizar_inimigos_horda(quantidade_para_spawnar)
	
	for i in range(quantidade_para_spawnar):
		_spawnar_um_inimigo()
		await get_tree().create_timer(intervalo_atual).timeout

func _spawnar_um_inimigo() -> void:
	if CENA_INIMIGO == null:
		return
		
	var min_x: float = distancia_da_borda
	var max_x: float = tamanho_mapa.x - distancia_da_borda
	var min_y: float = distancia_da_borda
	var max_y: float = tamanho_mapa.y - distancia_da_borda
	
	var posicao_final: Vector2 = Vector2.ZERO
	var lado_sorteado: int = randi() % 4
	
	match lado_sorteado:
		0: # Borda Superior (Y fixo em 100, X aleatório entre 100 e 1180)
			posicao_final = Vector2(randf_range(min_x, max_x), min_y)
		1: # Borda Inferior (Y fixo em 620, X aleatório entre 100 e 1180)
			posicao_final = Vector2(randf_range(min_x, max_x), max_y)
		2: # Borda Esquerda (X fixo em 100, Y aleatório entre 100 e 620)
			posicao_final = Vector2(min_x, randf_range(min_y, max_y))
		3: # Borda Direita (X fixo em 1180, Y aleatório entre 100 e 620)
			posicao_final = Vector2(max_x, randf_range(min_y, max_y))
			
	var novo_inimigo = CENA_INIMIGO.instantiate()
	novo_inimigo.global_position = posicao_final
	get_tree().current_scene.add_child(novo_inimigo)

func registrar_morte_inimigo() -> void:
	inimigos_derrotados_nesta_horda += 1
	var total_da_horda: int = configuracao_hordas.get(horda_atual, horda_atual * 4)
	var inimigos_restantes: int = max(total_da_horda - inimigos_derrotados_nesta_horda, 0)
	
	# Atualiza o contador no GlobalManager
	GlobalManager.atualizar_inimigos_horda(inimigos_restantes)
	
	if inimigos_derrotados_nesta_horda >= total_da_horda:
		if timer_intervalo:
			timer_intervalo.start()

func _on_timer_intervalo_timeout() -> void:
	horda_atual += 1
	_iniciar_horda(horda_atual)
