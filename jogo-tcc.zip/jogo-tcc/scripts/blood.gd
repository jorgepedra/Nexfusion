extends CPUParticles2D

@export var tempo_no_chao: float = 5.0 # Quantos segundos o sangue fica no chão antes de sumir
@export_range(0.0, 1.0) var opacidade_inicial: float = 0.75 # 0.75 = 75% visível (25% transparente)

@onready var timer_congelar: Timer = $Timer

func _ready() -> void:
	# Aplica a transparência inicial (75% de opacidade)
	modulate.a = opacidade_inicial
	
	# Encontra o jogador na cena atual para apontar o espirro para o lado oposto a ele
	var cena = get_tree().current_scene
	if cena != null:
		var jogador = cena.find_child("player", true, false) as Node2D
		if jogador != null:
			var direcao_oposta: Vector2 = (global_position - jogador.global_position).normalized()
			rotation = direcao_oposta.angle()
		else:
			rotation = randf_range(0.0, TAU)
	
	emitting = true
	
	if timer_congelar:
		timer_congelar.wait_time = max(lifetime - 0.02, 0.05)
		timer_congelar.one_shot = true
		timer_congelar.timeout.connect(_on_timer_timeout)
		timer_congelar.start()

func _on_timer_timeout() -> void:
	# Congela o tempo das partículas no instante exato em que caem no chão
	speed_scale = 0.0
	
	# Espera o tempo definido no chão e depois faz sumir suavemente a partir dos 75%
	var tween = create_tween()
	tween.tween_interval(tempo_no_chao)
	tween.tween_property(self, "modulate:a", 0.0, 1.5)
	tween.tween_callback(queue_free)
