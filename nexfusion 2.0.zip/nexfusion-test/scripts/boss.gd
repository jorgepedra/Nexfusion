class_name Boss
extends Enemy
## Chefes de fase (Hordas 10/20/30): leque mirado, explosão radial,
## chuva de granadas e invocação de aliados. Entra em FÚRIA abaixo de 50% de vida.

const CENA_GRANADA: String = "res://scenes/granada_inimiga.tscn"

var _padrao_idx: int = 0
var _padrao_timer: float = 2.4
var _furia: bool = false
var _invocar_timer: float = 5.0
var _cena_granada: PackedScene = null
var _nome: String = "CHEFE"
var _aura_timer: float = 0.0


func _ready() -> void:
	super._ready()
	_nome = dados.nome if dados != null else "CHEFE"
	if ResourceLoader.exists(CENA_GRANADA):
		_cena_granada = load(CENA_GRANADA) as PackedScene
	_padrao_timer = 2.2
	if not como_comum:
		GlobalManager.chefe_surgiu.emit(_nome, vida_max)
		GlobalManager.chefe_vida.emit(vida, vida_max)
		AudioManager.tocar_sfx("chefe", -3.0, 0.02)


func _physics_process(delta: float) -> void:
	if autoridade_remota:
		return
	super._physics_process(delta)
	if morto or not GlobalManager.partida_ativa:
		return
	_padrao_timer -= delta
	_invocar_timer -= delta
	if not _furia and vida <= vida_max * 0.5:
		_entrar_furia()
	if _padrao_timer <= 0.0:
		_padrao_timer = (1.55 if _furia else 2.6)
		_executar_padrao()
	if _invocar_timer <= 0.0:
		_invocar_timer = 8.0 if _furia else 11.0
		_invocar()


func _calcular_direcao(_delta: float) -> Vector2:
	if jogador == null:
		return Vector2.ZERO
	var para: Vector2 = jogador.global_position - global_position
	var dist: float = para.length()
	var dir: Vector2 = para.normalized()
	if dist < 240.0:
		return -dir * 0.6 + dir.orthogonal() * 0.4
	if dist > 480.0:
		return dir * 0.8
	return dir.orthogonal() * 0.5


func _entrar_furia() -> void:
	_furia = true
	velocidade *= 1.25
	_padrao_timer = 0.6
	if corpo != null:
		var tw: Tween = create_tween().set_loops(6)
		tw.tween_property(corpo, "modulate", Color(1.8, 0.5, 0.5), 0.18)
		tw.tween_property(corpo, "modulate", Color.WHITE, 0.18)
	Efeitos.anel(get_parent(), global_position, 180.0, Color(1.0, 0.25, 0.25, 0.9), 0.6, 6.0)
	Efeitos.tremor(12.0)
	AudioManager.tocar_sfx("chefe", -2.0, 0.04)
	GlobalManager.registrar_estilo("FÚRIA DO CHEFE", 10.0, Color("ff5f5f"))


func _executar_padrao() -> void:
	if animador != null:
		animador.tocar("ataque")
	match _padrao_idx % 4:
		0:
			_leque()
		1:
			_radial()
		2:
			_chuva_granadas()
		_:
			_radial()
	_padrao_idx += 1


func _leque() -> void:
	if _cena_projetil == null or jogador == null:
		return
	var dir: Vector2 = (jogador.global_position - global_position).normalized()
	var qtd: int = 7 if _furia else 5
	var abertura: float = deg_to_rad(46.0)
	for i: int in range(qtd):
		var f: float = float(i) / float(qtd - 1) if qtd > 1 else 0.5
		var ang: float = -abertura * 0.5 + abertura * f
		_disparar(dir.rotated(ang), 12.0 + float(horda) * 0.4, 420.0)
	AudioManager.tocar_sfx("tiro_pesado", -8.0, 0.06)


func _radial() -> void:
	var qtd: int = 18 if _furia else 12
	var offset: float = randf() * TAU
	for i: int in range(qtd):
		var ang: float = offset + TAU * float(i) / float(qtd)
		_disparar(Vector2.RIGHT.rotated(ang), 10.0 + float(horda) * 0.35, 320.0)
	Efeitos.anel(get_parent(), global_position, 120.0, Color(1.0, 0.5, 0.3, 0.6), 0.3, 2.0)
	AudioManager.tocar_sfx("explosao", -12.0, 0.08)


func _disparar(dir: Vector2, dano: float, vel: float) -> void:
	if _cena_projetil == null:
		return
	var p: Projetil = _cena_projetil.instantiate() as Projetil
	if p == null:
		return
	get_parent().add_child(p)
	p.global_position = global_position + dir * (raio + 6.0)
	p.configurar({
		"amigavel": false,
		"direcao": dir,
		"dano": dano,
		"velocidade": vel,
		"cor": dados.cor if dados != null else Color("ff7a59"),
		"tamanho": 1.3,
		"alcance": 1200.0,
	})


func _chuva_granadas() -> void:
	if _cena_granada == null or jogador == null:
		return
	var qtd: int = 3 if _furia else 2
	for i: int in range(qtd):
		var g: GranadaInimiga = _cena_granada.instantiate() as GranadaInimiga
		if g == null:
			continue
		get_parent().add_child(g)
		var alvo: Vector2 = jogador.global_position + Vector2(randf_range(-160.0, 160.0), randf_range(-160.0, 160.0))
		g.configurar(global_position, alvo, 84.0, 18.0 + float(horda) * 0.5, self)
	AudioManager.tocar_sfx("perigo", -8.0, 0.1)


func _invocar() -> void:
	var sm: Node = get_tree().get_first_node_in_group("spawn_manager")
	if sm != null and sm.has_method("invocar_minions"):
		sm.call("invocar_minions", global_position, 3 if _furia else 2)
		GlobalManager.registrar_estilo("INVOCAÇÃO", 4.0, Color("c58bff"))


func receber_dano(valor: float, critico: bool = false) -> void:
	super.receber_dano(valor, critico)
	if not morto and not como_comum:
		GlobalManager.chefe_vida.emit(vida, vida_max)


func _morrer() -> void:
	if morto:
		return
	if not como_comum:
		GlobalManager.boss_derrotado.emit(_nome)
		GlobalManager.chefe_vida.emit(0.0, vida_max)
		# O chefe derrotado passa a integrar o enxame comum das próximas hordas.
		var sm: Node = get_tree().get_first_node_in_group("spawn_manager")
		if sm != null and sm.has_method("liberar_como_comum") and dados != null:
			sm.call("liberar_como_comum", dados.id)
	Efeitos.tremor(18.0)
	for i: int in range(5):
		Efeitos.anel(get_parent(), global_position, 140.0 + float(i) * 30.0, Color(1.0, 0.6, 0.3, 0.7), 0.5 + float(i) * 0.1, 4.0)
	super._morrer()
