extends Node2D
## Controla a arena: construção do cenário, jogador, spawner, HUD e fluxo
## de vitória/derrota. Ponto de entrada de jogo.tscn.

const CENA_PLAYER: String = "res://scenes/player.tscn"
const TAMANHO_ARENA: Vector2 = Vector2(2400.0, 1500.0)
const TILE_CHAO: String = "res://sprites/map/tile_arena.png"

var jogador: Player
var _finalizada: bool = false
var _aguardando: bool = false
var _salto_manual: bool = false
var _inimigos_rede: Dictionary = {}
var _projeteis_rede: Array[Node2D] = []
var _jogadores_rede: Dictionary = {}
var _guardioes_rede: Array[Enemy] = []
var _musica_timer: float = 0.0
var _controles_moveis: ControlesMoveis = null


class PropLab extends StaticBody2D:
	## Estrutura fixa de laboratório: tanque de contenção ou bancada.
	var tipo: String = "tanque"
	var tamanho: Vector2 = Vector2(120.0, 120.0)
	var cor_liquido: Color = Color(0.35, 0.9, 0.8, 0.7)

	func _ready() -> void:
		collision_layer = 4
		collision_mask = 0
		var corpo: CollisionShape2D = CollisionShape2D.new()
		var ret: RectangleShape2D = RectangleShape2D.new()
		ret.size = tamanho
		corpo.shape = ret
		add_child(corpo)
		z_index = -4
		queue_redraw()

	func _draw() -> void:
		var r: Rect2 = Rect2(-tamanho * 0.5, tamanho)
		if tipo == "tanque":
			draw_rect(r.grow(4.0), Color(0.06, 0.1, 0.14, 0.9))
			draw_rect(r, Color(0.14, 0.2, 0.26))
			draw_rect(r.grow(-6.0), Color(cor_liquido.r, cor_liquido.g, cor_liquido.b, 0.35))
			# vidro e reflexo
			draw_rect(r.grow(-6.0), Color(0.45, 0.9, 0.95, 0.25), false, 2.0)
			draw_line(r.position + Vector2(16, 10), r.position + Vector2(16, tamanho.y - 10), Color(1, 1, 1, 0.12), 4.0)
			for i: int in range(3):
				var y: float = r.position.y + 20.0 + float(i) * 26.0
				draw_line(Vector2(r.position.x + 8, y), Vector2(r.end.x - 8, y), Color(0.03, 0.08, 0.1, 0.5), 2.0)
			# tampa e base
			draw_rect(Rect2(r.position + Vector2(-6, -10), Vector2(tamanho.x + 12, 12)), Color(0.22, 0.3, 0.36))
			draw_rect(Rect2(r.position + Vector2(-4, tamanho.y - 4), Vector2(tamanho.x + 8, 10)), Color(0.12, 0.17, 0.22))
		else:
			draw_rect(r.grow(3.0), Color(0.05, 0.08, 0.12, 0.9))
			draw_rect(r, Color(0.17, 0.24, 0.3))
			draw_rect(Rect2(r.position + Vector2(0, -3), Vector2(tamanho.x, 6)), Color(0.35, 0.75, 0.85, 0.8))
			draw_line(r.position + Vector2(8, tamanho.y * 0.55), r.end - Vector2(8, tamanho.y * 0.2), Color(0.45, 0.85, 0.95, 0.25), 2.0)

@onready var mundo: Node2D = $Mundo
@onready var hud: HUD = $HUD
@onready var spawn_manager: SpawnManager = $SpawnManager


class ArenaFase2 extends Node2D:
	## Câmara de Fusão: a "nova área" da fase 2 do chefe final.
	func _draw() -> void:
		var r: Rect2 = Rect2(Vector2.ZERO, Vector2(2400.0, 1500.0))
		draw_rect(r, Color(0.07, 0.035, 0.05))
		# placas de metal corrompido
		for x: int in range(0, int(r.size.x), 150):
			draw_line(Vector2(x, 0), Vector2(x, r.size.y), Color(0.22, 0.09, 0.11, 0.5), 2.0)
		for y: int in range(0, int(r.size.y), 150):
			draw_line(Vector2(0, y), Vector2(r.size.x, y), Color(0.22, 0.09, 0.11, 0.5), 2.0)
		# fissuras de magma
		for i: int in range(14):
			var x0: float = 120.0 + float(i) * 165.0
			var y0: float = 180.0 + fmod(float(i) * 231.0, 1100.0)
			draw_line(Vector2(x0, y0), Vector2(x0 + 90.0, y0 + 120.0), Color(0.85, 0.3, 0.16, 0.35), 3.0)
		# anel do reator central
		var centro: Vector2 = r.get_center()
		draw_circle(centro, 330.0, Color(0.12, 0.03, 0.05, 0.85))
		draw_arc(centro, 330.0, 0.0, TAU, 80, Color(0.9, 0.35, 0.2, 0.55), 5.0, true)
		draw_arc(centro, 246.0, 0.0, TAU, 64, Color(0.95, 0.55, 0.28, 0.35), 3.0, true)
		draw_arc(centro, 150.0, 0.0, TAU, 48, Color(0.55, 0.85, 1.0, 0.3), 2.0, true)
		for i: int in range(16):
			var ang: float = TAU * float(i) / 16.0
			draw_line(centro + Vector2(cos(ang), sin(ang)) * 330.0, centro + Vector2(cos(ang), sin(ang)) * 358.0, Color(0.95, 0.6, 0.25, 0.45), 4.0)
		# bordas de contenção
		draw_rect(r.grow(-16.0), Color(0.8, 0.32, 0.2, 0.6), false, 4.0)
		for x: int in range(0, int(r.size.x), 72):
			draw_rect(Rect2(float(x), 0.0, 38.0, 12.0), Color(0.9, 0.45, 0.2, 0.45))
			draw_rect(Rect2(float(x), r.size.y - 12.0, 38.0, 12.0), Color(0.9, 0.45, 0.2, 0.45))


class ArenaVisual extends Node2D:
	func _draw() -> void:
		var r: Rect2 = Rect2(Vector2.ZERO, Vector2(2400.0, 1500.0))
		# piso de laboratório: painéis metálicos e juntas rebitadas
		for x: int in range(0, int(r.size.x), 200):
			draw_line(Vector2(x, 0), Vector2(x, r.size.y), Color(0.09, 0.16, 0.21, 0.55), 2.0)
		for y: int in range(0, int(r.size.y), 150):
			draw_line(Vector2(0, y), Vector2(r.size.x, y), Color(0.09, 0.16, 0.21, 0.55), 2.0)
		# faixas de alerta nas bordas
		var passo: float = 56.0
		for x: int in range(0, int(r.size.x), int(passo)):
			draw_rect(Rect2(float(x), 0.0, 28.0, 10.0), Color(0.85, 0.65, 0.2, 0.5))
			draw_rect(Rect2(float(x), r.size.y - 10.0, 28.0, 10.0), Color(0.85, 0.65, 0.2, 0.5))
		for y: int in range(0, int(r.size.y), int(passo)):
			draw_rect(Rect2(0.0, float(y), 10.0, 28.0), Color(0.85, 0.65, 0.2, 0.5))
			draw_rect(Rect2(r.size.x - 10.0, float(y), 10.0, 28.0), Color(0.85, 0.65, 0.2, 0.5))
		# moldura de contenção
		draw_rect(r.grow(-14.0), Color(0.2, 0.55, 0.65, 0.85), false, 3.0)
		draw_rect(r.grow(-26.0), Color(0.1, 0.25, 0.32, 0.5), false, 1.0)
		# círculo central de contenção química
		var centro: Vector2 = r.get_center()
		draw_circle(centro, 258.0, Color(0.08, 0.17, 0.21, 0.35))
		draw_arc(centro, 258.0, 0.0, TAU, 72, Color(0.3, 0.7, 0.78, 0.45), 3.0, true)
		draw_arc(centro, 176.0, 0.0, TAU, 56, Color(0.25, 0.6, 0.68, 0.3), 2.0, true)
		draw_arc(centro, 92.0, 0.0, TAU, 40, Color(0.25, 0.6, 0.68, 0.22), 2.0, true)
		for i: int in range(12):
			var ang: float = TAU * float(i) / 12.0
			draw_line(centro + Vector2(cos(ang), sin(ang)) * 258.0, centro + Vector2(cos(ang), sin(ang)) * 272.0, Color(0.85, 0.65, 0.2, 0.35), 3.0)
		# tubos no teto e no chão da sala
		for y: float in [64.0, r.size.y - 64.0]:
			draw_line(Vector2(90.0, y), Vector2(r.size.x - 90.0, y), Color(0.24, 0.32, 0.4), 14.0)
			draw_line(Vector2(90.0, y), Vector2(r.size.x - 90.0, y), Color(0.36, 0.55, 0.62, 0.5), 4.0)
			for x: float in [260.0, 760.0, 1640.0, 2140.0]:
				draw_rect(Rect2(x - 8.0, y - 14.0, 16.0, 28.0), Color(0.3, 0.4, 0.48))
		# luminárias embutidas nas paredes
		for x: float in [420.0, 1200.0, 1980.0]:
			draw_rect(Rect2(x - 54.0, 18.0, 108.0, 12.0), Color(0.55, 0.9, 1.0, 0.55))
			draw_rect(Rect2(x - 54.0, r.size.y - 30.0, 108.0, 12.0), Color(0.55, 0.9, 1.0, 0.55))


func _ready() -> void:
	randomize()
	add_to_group("game")
	GlobalManager.definir_cursor(false)
	GlobalManager.iniciar_partida(GlobalManager.horda_skip_alvo)
	# Prepara as trilhas calma/combate antes da ação (sem travadas no meio da horda).
	AudioManager.aquecer_temas(["calmo", "jogo"])
	_criar_controles_moveis()
	_construir_arena()
	_criar_jogador()
	hud.configurar(jogador)
	_conectar_sinais()
	GlobalManager.qualidade_alterada.connect(_ao_mudar_qualidade)
	_aplicar_iluminacao()
	if NetworkManager.modo == "client":
		_iniciar_cliente()
		return
	if NetworkManager.modo == "host":
		NetworkManager.configurar_jogo_host(self, jogador)
	spawn_manager.iniciar(jogador, Rect2(Vector2.ZERO, TAMANHO_ARENA), mundo)
	AudioManager.tocar_bgm("calmo")
	hud.mostrar_banner("HORDA %d" % GlobalManager.horda_atual, UI.COR_CIANO, "SOBREVIVA")


func _iniciar_cliente() -> void:
	## No cliente quem simula tudo é o host: aqui só enviamos entrada e desenhamos.
	spawn_manager.parar()
	NetworkManager.configurar_jogo_cliente(self, jogador)
	NetworkManager.snapshot.connect(_ao_snapshot_rede)
	NetworkManager.conexao_falhou.connect(_ao_rede_perdida)
	AudioManager.tocar_bgm("calmo")
	hud.mostrar_banner("CO-OP LAN", UI.COR_VERDE, "CONECTADO AO HOST")


func _process(delta: float) -> void:
	_musica_timer -= delta
	if _musica_timer <= 0.0:
		_musica_timer = 0.45
		_atualizar_musica()


func _atualizar_musica() -> void:
	## Trilha adaptativa: leve sem inimigos, agitada com enxame, épica com chefe.
	if _finalizada:
		return
	if _existe_chefe():
		AudioManager.tocar_bgm("chefe")
	elif _tem_inimigos():
		AudioManager.tocar_bgm("jogo")
	else:
		AudioManager.tocar_bgm("calmo")


func _existe_chefe() -> bool:
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		var b: Boss = n as Boss
		if b != null and is_instance_valid(b) and not b.morto and not b.como_comum:
			return true
	return false


func _tem_inimigos() -> bool:
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		var e: Enemy = n as Enemy
		if e != null and is_instance_valid(e) and not e.morto:
			return true
	return false


func _criar_controles_moveis() -> void:
	if not GlobalManager.modo_mobile:
		return
	_controles_moveis = ControlesMoveis.new()
	add_child(_controles_moveis)


func _ao_mudar_qualidade(_nivel: int) -> void:
	_aplicar_iluminacao()
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		var e: Enemy = n as Enemy
		if e != null and is_instance_valid(e) and e.has_method("_aplicar_visual"):
			e.call("_aplicar_visual")


func _aplicar_iluminacao() -> void:
	## Qualidade pesada adiciona luz dinâmica + sombras; as demais não têm custo.
	var antigo: Node = get_node_or_null("Iluminacao")
	if antigo != null:
		antigo.queue_free()
	var luz_antiga: Node = jogador.get_node_or_null("LuzJogador") if jogador != null and is_instance_valid(jogador) else null
	if luz_antiga != null:
		luz_antiga.queue_free()
	if not GlobalManager.luzes_ativas():
		return
	var modulador: CanvasModulate = CanvasModulate.new()
	modulador.name = "Iluminacao"
	modulador.color = Color(0.56, 0.62, 0.76)
	add_child(modulador)
	for n: Node in get_tree().get_nodes_in_group("lab_props"):
		var corpo: StaticBody2D = n as StaticBody2D
		if corpo == null or corpo.get_node_or_null("Oclusor") != null:
			continue
		var oclusor: LightOccluder2D = LightOccluder2D.new()
		oclusor.name = "Oclusor"
		var poligono: OccluderPolygon2D = OccluderPolygon2D.new()
		var t: Vector2 = corpo.get("tamanho") as Vector2
		poligono.polygon = PackedVector2Array([
			-t * 0.5, Vector2(t.x * 0.5, -t.y * 0.5), t * 0.5, Vector2(-t.x * 0.5, t.y * 0.5),
		])
		oclusor.occluder = poligono
		corpo.add_child(oclusor)
	if jogador == null or not is_instance_valid(jogador):
		return
	var luz: PointLight2D = PointLight2D.new()
	luz.name = "LuzJogador"
	luz.energy = 1.15
	luz.texture_scale = 3.2
	luz.shadow_enabled = true
	luz.texture = _textura_luz()
	jogador.add_child(luz)


func _textura_luz() -> Texture2D:
	var gradiente: Gradient = Gradient.new()
	gradiente.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0)])
	gradiente.offsets = PackedFloat32Array([0.0, 1.0])
	var tex: GradientTexture2D = GradientTexture2D.new()
	tex.gradient = gradiente
	tex.fill = GradientTexture2D.FILL_RADIAL
	tex.fill_from = Vector2(0.5, 0.5)
	tex.fill_to = Vector2(1.0, 0.5)
	tex.width = 256
	tex.height = 256
	return tex


func _ao_rede_perdida(texto: String) -> void:
	if _finalizada:
		return
	_finalizada = true
	hud.mostrar_banner("CONEXÃO PERDIDA", UI.COR_VERMELHO, texto)
	await get_tree().create_timer(2.0).timeout
	if not is_inside_tree():
		return
	NetworkManager.sair()
	get_tree().change_scene_to_file("res://scenes/menu.tscn")


func criar_jogador_remoto(id: int) -> Player:
	## Chamado pelo host quando um cliente entra na sala.
	if NetworkManager.jogador_remoto(id) != null:
		return NetworkManager.jogador_remoto(id)
	var cena: PackedScene = load(CENA_PLAYER) as PackedScene
	var p: Player = cena.instantiate() as Player
	p.remoto = true
	p.name = "JogadorRemoto_%d" % id
	mundo.add_child(p)
	p.global_position = TAMANHO_ARENA * 0.5 + Vector2(randf_range(-220.0, 220.0), randf_range(60.0, 200.0))
	p.definir_limites(Rect2(Vector2.ZERO, TAMANHO_ARENA))
	var id_nick: String = NetworkManager.nick_de(id)
	p.definir_nick(id_nick if id_nick != "" else "JOGADOR")
	p.morreu.connect(_ao_remoto_morrer.bind(id, p))
	NetworkManager.registrar_remoto(id, p)
	hud.mostrar_banner("JOGADOR CONECTADO", UI.COR_VERDE, id_nick)
	AudioManager.tocar_sfx("levelup", -6.0, 0.03)
	return p


func _ao_remoto_morrer(_id: int, p: Player) -> void:
	if p == null or not is_instance_valid(p):
		return
	if _tentar_ressuscitar(p, "JOGADOR RESSUSCITADO"):
		return
	hud.mostrar_banner("%s CAIU" % p.nome_exibicao, UI.COR_VERMELHO, "AGUARDANDO RESSURREIÇÃO")
	if not _algum_jogador_vivo():
		_ao_morrer()


# ------------------------------------------------------------------ cliente: snapshots
func _ao_snapshot_rede(dados: Dictionary) -> void:
	var horda_rede: int = int(dados.get("horda", GlobalManager.horda_atual))
	if horda_rede != GlobalManager.horda_atual:
		GlobalManager.horda_atual = horda_rede
		GlobalManager.horda_alterada.emit(horda_rede)
	var fase_rede: int = int(dados.get("fase", GlobalManager.fase))
	if fase_rede != GlobalManager.fase:
		GlobalManager.fase = fase_rede
		GlobalManager.fase_alterada.emit(fase_rede)
	GlobalManager.cargas_ressurreicao = int(dados.get("resurreicoes", GlobalManager.cargas_ressurreicao))
	_sincronizar_jogadores(dados.get("jogadores", []))
	_sincronizar_inimigos(dados.get("inimigos", []))
	_sincronizar_guardioes(dados.get("guardioes", []))
	_sincronizar_projeteis(dados.get("projeteis", []))


func _sincronizar_jogadores(lista: Array) -> void:
	var meu_id: int = multiplayer.get_unique_id()
	var vistos: Dictionary = {}
	for item_v: Variant in lista:
		var item: Dictionary = item_v as Dictionary
		var id_item: int = int(item.get("id", 0))
		if id_item == 0:
			continue
		if id_item != meu_id:
			vistos[id_item] = true
			_sincronizar_jogador_rede(id_item, item)
			continue
		var vida: float = float(item.get("vida", jogador.vida))
		if not bool(item.get("vivo", true)) or vida <= 0.0:
			if jogador.vivo:
				jogador.vida = 0.0
				jogador.vida_alterada.emit(0.0, jogador.vida_maxima)
				jogador._morrer()
			continue
		if not jogador.vivo:
			## O host ressuscitou este jogador: volta com vida parcial.
			jogador.reviver(Vector2(float(item.get("x", jogador.global_position.x)), float(item.get("y", jogador.global_position.y))))
		if not is_equal_approx(jogador.vida, vida):
			jogador.vida = vida
			jogador.vida_alterada.emit(vida, jogador.vida_maxima)
		# Correção suave: o host é a autoridade, mas o cliente prevê o próprio
		# movimento — só puxamos de volta quando a diferença passa de 90 px.
		var alvo: Vector2 = Vector2(float(item.get("x", jogador.global_position.x)), float(item.get("y", jogador.global_position.y)))
		if jogador.global_position.distance_to(alvo) > 90.0:
			jogador.global_position = alvo
	for id_v: Variant in _jogadores_rede.keys():
		var id_r: int = int(id_v)
		if vistos.has(id_r):
			continue
		var velho: Player = _jogadores_rede[id_r] as Player
		if velho != null and is_instance_valid(velho):
			velho.queue_free()
		_jogadores_rede.erase(id_r)


func _sincronizar_jogador_rede(id: int, item: Dictionary) -> void:
	## Desenha os outros jogadores no cliente (antes o host era invisível).
	var p: Player = _jogadores_rede.get(id) as Player
	if p == null or not is_instance_valid(p):
		var cena: PackedScene = load(CENA_PLAYER) as PackedScene
		p = cena.instantiate() as Player
		p.remoto = true
		p.name = "JogadorRede_%d" % id
		mundo.add_child(p)
		p.set_physics_process(false)
		if p.camera != null:
			p.camera.enabled = false
		p.definir_limites(Rect2(Vector2.ZERO, TAMANHO_ARENA))
		_jogadores_rede[id] = p
	p.global_position = Vector2(float(item.get("x", p.global_position.x)), float(item.get("y", p.global_position.y)))
	p.nome_exibicao = String(item.get("nick", "JOGADOR"))
	if p._label_nick != null:
		p._label_nick.text = p.nome_exibicao
	var vida: float = float(item.get("vida", p.vida))
	var vida_max: float = float(item.get("max", p.vida_maxima))
	var vivo: bool = bool(item.get("vivo", true)) and vida > 0.0
	p.vida = vida
	p.vida_maxima = vida_max
	p.vivo = vivo
	p.corpo.visible = vivo
	p.arma_pivot.visible = vivo


func _sincronizar_inimigos(lista: Array) -> void:
	var vistos: Dictionary = {}
	for item_v: Variant in lista:
		var item: Dictionary = item_v as Dictionary
		var chave: int = int(item.get("id", 0))
		if chave == 0:
			continue
		vistos[chave] = true
		var e: Enemy = _inimigos_rede.get(chave) as Enemy
		if e == null or not is_instance_valid(e):
			e = _criar_inimigo_remoto(item)
			if e == null:
				continue
			_inimigos_rede[chave] = e
		e.global_position = Vector2(float(item.get("x", 0.0)), float(item.get("y", 0.0)))
		e.vida = float(item.get("vida", e.vida))
		e.vida_max = float(item.get("max", e.vida_max))
		var escala_rede: float = float(item.get("escala", e.escala_visual))
		if not is_equal_approx(e.escala_visual, escala_rede):
			e.escala_visual = escala_rede
			e.call("_aplicar_visual")
		e.queue_redraw()
	for chave_v: Variant in _inimigos_rede.keys():
		var chave2: int = int(chave_v)
		if vistos.has(chave2):
			continue
		var velho: Enemy = _inimigos_rede[chave2] as Enemy
		if velho != null and is_instance_valid(velho):
			velho.queue_free()
		_inimigos_rede.erase(chave2)


func _sincronizar_guardioes(lista: Array) -> void:
	## Guardiões são estáticos; no cliente só desenhamos (o host simula).
	while _guardioes_rede.size() < lista.size():
		var base: Node = (load("res://scenes/enemy.tscn") as PackedScene).instantiate()
		if base == null:
			break
		base.set_script(load("res://scripts/guardiao_chefe.gd"))
		var g: Enemy = base as Enemy
		if g == null:
			break
		var dados_g: DadosInimigo = load("res://resources/inimigos/guardiao_final.tres") as DadosInimigo
		g.autoridade_remota = true
		g.dados = dados_g
		mundo.add_child(g)
		g.configurar(dados_g, 1)
		g.collision_layer = 0
		g.collision_mask = 0
		var col: CollisionShape2D = g.get_node_or_null("Colisao") as CollisionShape2D
		if col != null:
			col.disabled = true
		_guardioes_rede.append(g)
	for i: int in range(_guardioes_rede.size()):
		var g2: Enemy = _guardioes_rede[i]
		if g2 == null or not is_instance_valid(g2):
			continue
		if i >= lista.size():
			g2.queue_free()
			continue
		var item: Dictionary = lista[i] as Dictionary
		g2.global_position = Vector2(float(item.get("x", 0.0)), float(item.get("y", 0.0)))
		g2.vida = float(item.get("vida", g2.vida))
		g2.vida_max = float(item.get("max", g2.vida_max))
		g2.queue_redraw()
	while _guardioes_rede.size() > lista.size():
		_guardioes_rede.pop_back()


func _criar_inimigo_remoto(item: Dictionary) -> Enemy:
	var id_dados: String = String(item.get("dados", ""))
	if id_dados == "":
		return null
	var caminho: String = "res://resources/inimigos/%s.tres" % id_dados
	if not ResourceLoader.exists(caminho):
		return null
	var d: DadosInimigo = load(caminho) as DadosInimigo
	if d == null:
		return null
	var cena_caminho: String = d.cena if ResourceLoader.exists(d.cena) else "res://scenes/enemy.tscn"
	var cena: PackedScene = load(cena_caminho) as PackedScene
	if cena == null:
		return null
	var e: Enemy = cena.instantiate() as Enemy
	e.autoridade_remota = true
	e.como_comum = bool(item.get("comum", false))
	mundo.add_child(e)
	e.configurar(d, GlobalManager.horda_atual)
	e.collision_layer = 0
	e.collision_mask = 0
	var col: CollisionShape2D = e.get_node_or_null("Colisao") as CollisionShape2D
	if col != null:
		col.disabled = true
	return e


func _sincronizar_projeteis(lista: Array) -> void:
	while _projeteis_rede.size() < lista.size():
		var s: Sprite2D = Sprite2D.new()
		if ResourceLoader.exists("res://sprites/props/particula.png"):
			s.texture = load("res://sprites/props/particula.png") as Texture2D
		s.modulate = Color("ff7a59")
		s.z_index = 20
		mundo.add_child(s)
		_projeteis_rede.append(s)
	for i: int in range(_projeteis_rede.size()):
		var sprite: Node2D = _projeteis_rede[i]
		if sprite == null or not is_instance_valid(sprite):
			continue
		if i < lista.size():
			var item: Dictionary = lista[i] as Dictionary
			sprite.visible = true
			sprite.global_position = Vector2(float(item.get("x", 0.0)), float(item.get("y", 0.0)))
		else:
			sprite.visible = false


func _construir_arena() -> void:
	var chao: TextureRect = TextureRect.new()
	chao.name = "Chao"
	if ResourceLoader.exists(TILE_CHAO):
		chao.texture = load(TILE_CHAO) as Texture2D
	chao.stretch_mode = TextureRect.STRETCH_TILE
	chao.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	chao.size = TAMANHO_ARENA
	chao.position = Vector2.ZERO
	chao.z_index = -20
	chao.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(chao)
	move_child(chao, 0)
	var visual: ArenaVisual = ArenaVisual.new()
	visual.name = "ArenaVisual"
	visual.z_index = -10
	add_child(visual)
	move_child(visual, 1)
	_criar_obstaculos_laboratorio()
	_criar_paredes()


func _criar_obstaculos_laboratorio() -> void:
	## Estruturas fixas e simétricas: tanques de contenção e bancadas.
	var tanques: Array[Vector2] = [
		Vector2(390, 360), Vector2(2010, 360), Vector2(390, 1140), Vector2(2010, 1140),
	]
	var liquidos: Array[Color] = [Color(0.35, 0.95, 0.8), Color(0.95, 0.55, 0.9), Color(0.65, 0.9, 0.45), Color(0.55, 0.8, 1.0)]
	for i: int in range(tanques.size()):
		var tanque: PropLab = PropLab.new()
		tanque.tipo = "tanque"
		tanque.tamanho = Vector2(116, 116)
		tanque.cor_liquido = liquidos[i]
		tanque.position = tanques[i]
		tanque.add_to_group("lab_props")
		add_child(tanque)
	var bancadas: Array[Vector2] = [Vector2(1200, 250), Vector2(1200, 1250)]
	for pos: Vector2 in bancadas:
		var bancada: PropLab = PropLab.new()
		bancada.tipo = "bancada"
		bancada.tamanho = Vector2(320, 68)
		bancada.position = pos
		bancada.add_to_group("lab_props")
		add_child(bancada)
	# pilares laterais quebram a linha de tiro sem poluir a arena
	for pos: Vector2 in [Vector2(130, 750), Vector2(2270, 750)]:
		var pilar: PropLab = PropLab.new()
		pilar.tipo = "bancada"
		pilar.tamanho = Vector2(90, 240)
		pilar.position = pos
		pilar.add_to_group("lab_props")
		add_child(pilar)


func _criar_paredes() -> void:
	var espessura: float = 40.0
	var paredes: Array[Rect2] = [
		Rect2(Vector2(-espessura, -espessura), Vector2(TAMANHO_ARENA.x + espessura * 2.0, espessura)),
		Rect2(Vector2(-espessura, TAMANHO_ARENA.y), Vector2(TAMANHO_ARENA.x + espessura * 2.0, espessura)),
		Rect2(Vector2(-espessura, 0.0), Vector2(espessura, TAMANHO_ARENA.y)),
		Rect2(Vector2(TAMANHO_ARENA.x, 0.0), Vector2(espessura, TAMANHO_ARENA.y)),
	]
	for r: Rect2 in paredes:
		var corpo: StaticBody2D = StaticBody2D.new()
		corpo.collision_layer = 4
		corpo.collision_mask = 0
		corpo.position = r.position + r.size * 0.5
		var forma: CollisionShape2D = CollisionShape2D.new()
		var ret: RectangleShape2D = RectangleShape2D.new()
		ret.size = r.size
		forma.shape = ret
		corpo.add_child(forma)
		add_child(corpo)


func _criar_jogador() -> void:
	var cena: PackedScene = load(CENA_PLAYER) as PackedScene
	jogador = cena.instantiate() as Player
	mundo.add_child(jogador)
	jogador.definir_nick(GlobalManager.nick)
	jogador.global_position = TAMANHO_ARENA * 0.5
	jogador.definir_limites(Rect2(Vector2.ZERO, TAMANHO_ARENA))


func _conectar_sinais() -> void:
	jogador.morreu.connect(_ao_morrer)
	spawn_manager.horda_iniciada.connect(_ao_horda_iniciada)
	GlobalManager.horda_concluida.connect(_ao_horda_concluida)
	spawn_manager.run_completa.connect(_ao_vitoria)
	spawn_manager.fase_avancou.connect(_ao_fase_avancou)
	GlobalManager.chefe_surgiu.connect(_ao_chefe_surgir)
	GlobalManager.boss_derrotado.connect(_ao_chefe_morrer)
	hud.recomecar_solicitado.connect(_ao_recomecar)
	hud.loja_solicitada.connect(_ao_ir_loja)
	hud.menu_solicitado.connect(_ao_ir_menu)
	jogador.vida_alterada.connect(hud.atualizar_vida)
	jogador.cargas_alteradas.connect(hud.atualizar_cargas)


func _unhandled_input(evento: InputEvent) -> void:
	if evento.is_action_pressed("pausar"):
		if hud != null:
			hud.alternar_pausa()
			get_viewport().set_input_as_handled()
		return
	if _eh_atalho_dev(evento):
		hud.alternar_dev()
		get_viewport().set_input_as_handled()
		return
	var tecla_tab: InputEventKey = evento as InputEventKey
	if tecla_tab != null and tecla_tab.pressed and not tecla_tab.echo:
		var codigo_tab: int = tecla_tab.physical_keycode if tecla_tab.physical_keycode != 0 else tecla_tab.keycode
		if codigo_tab == KEY_TAB:
			hud.alternar_inventario()
			get_viewport().set_input_as_handled()


func _eh_atalho_dev(evento: InputEvent) -> bool:
	## Shift+P: abre o Painel de Desenvolvedor (não pula mais direto).
	var tecla: InputEventKey = evento as InputEventKey
	if tecla == null or not tecla.pressed or tecla.echo:
		return false
	if not tecla.shift_pressed or tecla.ctrl_pressed or tecla.alt_pressed or tecla.meta_pressed:
		return false
	var codigo: int = tecla.physical_keycode if tecla.physical_keycode != 0 else tecla.keycode
	return codigo == KEY_P


func _ao_chefe_surgir(nome: String, vida_maxima: float) -> void:
	AudioManager.tocar_bgm("chefe")
	if GlobalManager.horda_atual >= GlobalManager.HORDA_MAXIMA:
		_ao_cutscene_final(nome)
		return
	hud.mostrar_banner("CHEFE: %s" % nome.to_upper(), UI.COR_VERMELHO, "PERIGO IMINENTE")


func _ao_cutscene_final(nome: String) -> void:
	## O chefe final despenca do céu enquanto a arena inteira treme.
	hud.iniciar_cinema("O ELEMENTO SUPREMO", "%s DESPERTOU — A ARENA ESTÁ CAINDO" % nome.to_upper())
	if jogador != null and is_instance_valid(jogador):
		jogador.controle_bloqueado = true
	AudioManager.tocar_bgm("chefe")
	var arvore: SceneTree = get_tree()
	var passado: float = 0.0
	while passado < 3.2:
		await arvore.create_timer(0.4).timeout
		if not is_inside_tree():
			return
		passado += 0.4
		Efeitos.tremor(4.0 + passado * 3.5)
	if jogador != null and is_instance_valid(jogador):
		jogador.controle_bloqueado = false
	hud.encerrar_cinema()


func cutscene_furia_chefe(chefe: Boss) -> void:
	## Cutscene do modo fúria: transformação + mudança para a Câmara de Fusão.
	if chefe == null or not is_instance_valid(chefe):
		return
	for n: Node in get_tree().get_nodes_in_group("player"):
		var p: Player = n as Player
		if p != null and is_instance_valid(p):
			p.controle_bloqueado = true
	hud.iniciar_cinema("MODO FÚRIA", "O SELO SE ROMPE — O NÚCLEO SE TRANSFORMA")
	AudioManager.tocar_bgm("chefe")
	AudioManager.tocar_sfx("chefe", -1.0, 0.03)
	Efeitos.tremor(26.0)
	Efeitos.particulas(mundo, chefe.global_position, Color("ff7a59"), 26, 420.0, 1.0, 5.0, "fogo")
	var arvore: SceneTree = get_tree()
	await arvore.create_timer(1.3).timeout
	if not is_inside_tree() or not is_instance_valid(chefe):
		_liberar_controles()
		return
	_construir_camara_fusao()
	_teleportar_para_fase2(chefe)
	await arvore.create_timer(0.9).timeout
	if not is_inside_tree() or not is_instance_valid(chefe):
		_liberar_controles()
		return
	chefe.aplicar_fase2()
	hud.mostrar_banner("CÂMARA DE FUSÃO", UI.COR_VERMELHO, "FASE 2 — NOVOS ATAQUES")
	await arvore.create_timer(1.1).timeout
	if not is_inside_tree():
		return
	_liberar_controles()
	hud.encerrar_cinema()


func _liberar_controles() -> void:
	for n: Node in get_tree().get_nodes_in_group("player"):
		var p: Player = n as Player
		if p != null and is_instance_valid(p):
			p.controle_bloqueado = false


func _construir_camara_fusao() -> void:
	## Troca o laboratório pela câmara de fusão (mesma área, novo cenário).
	var chao: Node = get_node_or_null("Chao")
	if chao is CanvasItem:
		(chao as CanvasItem).modulate = Color(0.72, 0.42, 0.45)
	var visual: Node = get_node_or_null("ArenaVisual")
	if visual != null:
		visual.queue_free()
	for n: Node in get_tree().get_nodes_in_group("lab_props"):
		if is_instance_valid(n):
			n.queue_free()
	var nova: ArenaFase2 = ArenaFase2.new()
	nova.name = "ArenaVisual"
	nova.z_index = -10
	add_child(nova)


func _teleportar_para_fase2(chefe: Boss) -> void:
	var centro: Vector2 = TAMANHO_ARENA * 0.5
	chefe.global_position = centro + Vector2(0.0, -340.0)
	var indice: int = 0
	for n: Node in get_tree().get_nodes_in_group("player"):
		var p: Player = n as Player
		if p == null or not is_instance_valid(p):
			continue
		var ang: float = TAU * float(indice) / 4.0
		p.global_position = centro + Vector2(cos(ang), sin(ang)) * 240.0 + Vector2(0.0, 220.0)
		indice += 1


func _ao_horda_iniciada(horda: int) -> void:
	if _finalizada:
		return
	var subtitulo: String = "SALTO MANUAL — PREPARE-SE" if _salto_manual else "ENXAME QUÍMICO EM APROXIMAÇÃO"
	_salto_manual = false
	hud.mostrar_banner("HORDA %d" % horda, UI.COR_CIANO, subtitulo)
	AudioManager.tocar_sfx("horda", -8.0, 0.06)


func _ao_horda_concluida(horda: int) -> void:
	if _finalizada or horda >= GlobalManager.HORDA_MAXIMA:
		return
	hud.mostrar_banner("HORDA %d LIMPA" % horda, UI.COR_VERDE, "PRÓXIMA ONDA EM INSTANTES")
	AudioManager.tocar_sfx("horda", -6.0, 0.04)


func _ao_chefe_morrer(_nome: String) -> void:
	AudioManager.tocar_bgm("jogo")


func _ao_fase_avancou(nova_fase: int) -> void:
	## Chefe final vencido: a arena recomeça na horda 1, mais difícil.
	hud.mostrar_banner("FASE %d" % nova_fase, UI.COR_MAGENTA, "O ELEMENTO SUPREMO RENASCEU")
	AudioManager.tocar_sfx("chefe", -3.0, 0.03)
	Efeitos.tremor(12.0)


func _ao_morrer() -> void:
	if _finalizada:
		return
	if NetworkManager.modo == "client":
		## Quem manda no renascimento é o host; só avisamos o jogador.
		hud.mostrar_banner("VOCÊ CAIU", UI.COR_VERMELHO, "AGUARDANDO RESSURREIÇÃO")
		return
	if NetworkManager.modo == "host":
		if _tentar_ressuscitar(jogador, "RESSURREIÇÃO"):
			return
		if _algum_jogador_vivo():
			hud.mostrar_banner("VOCÊ CAIU", UI.COR_VERMELHO, "OUTRO JOGADOR AINDA ESTÁ DE PÉ")
			return
	_finalizada = true
	spawn_manager.parar()
	_aguardando = true
	var arvore: SceneTree = get_tree()
	await arvore.create_timer(1.3).timeout
	if not is_inside_tree():
		return
	GlobalManager.finalizar_partida(false)
	spawn_manager.parar()
	hud.mostrar_morte(false)


func _algum_jogador_vivo() -> bool:
	for n: Node in get_tree().get_nodes_in_group("player"):
		var p: Player = n as Player
		if p != null and is_instance_valid(p) and p.vivo:
			return true
	return false


func _tentar_ressuscitar(p: Player, titulo: String) -> bool:
	## Consome uma carga da carta de ressurreição (LAN) e renasce em 1,5 s.
	if p == null or not is_instance_valid(p):
		return false
	if GlobalManager.cargas_ressurreicao <= 0:
		return false
	GlobalManager.cargas_ressurreicao -= 1
	hud.mostrar_banner(titulo, UI.COR_VERDE, "CARTA DE RESSURREIÇÃO USADA")
	AudioManager.tocar_sfx("levelup", -3.0, 0.02)
	_ressuscitar_depois(p)
	return true


func _ressuscitar_depois(p: Player) -> void:
	await get_tree().create_timer(1.5, true, false, true).timeout
	if not is_inside_tree() or p == null or not is_instance_valid(p) or p.vivo:
		return
	p.reviver(TAMANHO_ARENA * 0.5 + Vector2(randf_range(-120.0, 120.0), randf_range(80.0, 160.0)))
	if p == jogador:
		_finalizada = false


func _ao_vitoria() -> void:
	if _finalizada:
		return
	_finalizada = true
	await get_tree().create_timer(1.6).timeout
	if not is_inside_tree():
		return
	GlobalManager.finalizar_partida(true)
	hud.mostrar_morte(true)


func _ao_recomecar(horda: int) -> void:
	get_tree().paused = false
	GlobalManager.horda_skip_alvo = clampi(horda, 1, GlobalManager.HORDA_MAXIMA)
	get_tree().reload_current_scene()


func _ao_ir_loja() -> void:
	## A loja abre como painel sobre a tela atual: fechar volta para a run.
	if hud != null:
		hud.abrir_loja()


func _ao_ir_menu() -> void:
	get_tree().paused = false
	GlobalManager.horda_skip_alvo = 1
	NetworkManager.sair()
	get_tree().change_scene_to_file("res://scenes/menu.tscn")
