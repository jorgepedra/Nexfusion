extends Control
## Multiplayer LAN simplificado: o host abre a sala com uma porta e o convidado
## só informa a mesma porta — o host é encontrado automaticamente na rede local.

var _campo_nick: LineEdit
var _campo_porta: SpinBox
var _status: Label
var _botoes: Array[Button] = []
var _buscando: bool = false


func _ready() -> void:
	GlobalManager.definir_cursor(true)
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var fundo: ColorRect = ColorRect.new()
	fundo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fundo.color = Color(0.03, 0.045, 0.07)
	add_child(fundo)
	var centro: VBoxContainer = VBoxContainer.new()
	centro.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	centro.alignment = BoxContainer.ALIGNMENT_CENTER
	centro.add_theme_constant_override("separation", 10)
	add_child(centro)
	centro.add_child(UI.titulo("MULTIPLAYER LAN", 44, UI.COR_VERDE))
	var sub: Label = UI.rotulo("O host abre a sala; os convidados entram só pela porta, sem digitar IP.", 14, UI.COR_TEXTO_FRACO)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	centro.add_child(sub)
	centro.add_child(UI.separador(12.0))

	var linha_nick: HBoxContainer = HBoxContainer.new()
	linha_nick.alignment = BoxContainer.ALIGNMENT_CENTER
	linha_nick.add_theme_constant_override("separation", 8)
	centro.add_child(linha_nick)
	linha_nick.add_child(UI.rotulo("Seu apelido:", 15, UI.COR_TEXTO))
	_campo_nick = LineEdit.new()
	_campo_nick.text = GlobalManager.nick
	_campo_nick.max_length = 16
	_campo_nick.custom_minimum_size = Vector2(240, 42)
	_campo_nick.add_theme_font_size_override("font_size", 16)
	_campo_nick.text_submitted.connect(_ao_nick)
	_campo_nick.focus_exited.connect(func() -> void: _ao_nick(_campo_nick.text))
	linha_nick.add_child(_campo_nick)

	var linha_porta: HBoxContainer = HBoxContainer.new()
	linha_porta.alignment = BoxContainer.ALIGNMENT_CENTER
	linha_porta.add_theme_constant_override("separation", 8)
	centro.add_child(linha_porta)
	linha_porta.add_child(UI.rotulo("Porta da sala:", 15, UI.COR_TEXTO))
	_campo_porta = SpinBox.new()
	_campo_porta.min_value = 1024
	_campo_porta.max_value = 65535
	_campo_porta.value = float(NetworkManager.PORTA_PADRAO)
	_campo_porta.custom_minimum_size = Vector2(150, 42)
	linha_porta.add_child(_campo_porta)
	var dica: Label = UI.rotulo("Todos os jogadores precisam estar na mesma rede e usar a mesma porta.", 12, UI.COR_TEXTO_FRACO)
	dica.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	centro.add_child(dica)

	var b_host: Button = UI.botao("CRIAR SALA (HOST)", 20, UI.COR_CIANO)
	b_host.custom_minimum_size = Vector2(320, 50)
	b_host.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	b_host.pressed.connect(_ao_criar)
	centro.add_child(b_host)
	var b_entrar: Button = UI.botao("ENTRAR NA SALA", 20, UI.COR_VERDE)
	b_entrar.custom_minimum_size = Vector2(320, 50)
	b_entrar.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	b_entrar.pressed.connect(_ao_entrar)
	centro.add_child(b_entrar)
	var b_voltar: Button = UI.botao("VOLTAR", 18, UI.COR_TEXTO_FRACO)
	b_voltar.custom_minimum_size = Vector2(320, 44)
	b_voltar.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	b_voltar.pressed.connect(func() -> void:
		NetworkManager.sair()
		get_tree().change_scene_to_file("res://scenes/menu.tscn"))
	centro.add_child(b_voltar)
	_botoes = [b_host, b_entrar, b_voltar]
	_status = UI.rotulo("", 15, UI.COR_AMBAR)
	_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	centro.add_child(_status)
	var limite: Label = UI.rotulo("Até 4 jogadores por partida. Inimigos ficam mais fortes com mais gente.", 12, UI.COR_TEXTO_FRACO)
	limite.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	centro.add_child(limite)
	NetworkManager.conexao_falhou.connect(_ao_falha)
	NetworkManager.host_encontrado.connect(_ao_host_encontrado)
	NetworkManager.busca_encerrada.connect(_ao_busca_encerrada)
	AudioManager.tocar_bgm("menu")


func _ao_nick(texto: String) -> void:
	GlobalManager.definir_nick(texto)
	_campo_nick.text = GlobalManager.nick


func _ao_criar() -> void:
	_ao_nick(_campo_nick.text)
	_travar("Abrindo sala...")
	if NetworkManager.criar_sala(int(_campo_porta.value)):
		GlobalManager.horda_skip_alvo = 1
		get_tree().change_scene_to_file("res://scenes/jogo.tscn")
	else:
		_destravar()


func _ao_entrar() -> void:
	_ao_nick(_campo_nick.text)
	_travar("Procurando sala na rede...")
	_buscando = true
	_status.text = "Procurando host na porta %d..." % int(_campo_porta.value)
	if not NetworkManager.procurar_host(int(_campo_porta.value)):
		_buscando = false
		_destravar()


func _ao_host_encontrado(endereco: String, porta_host: int) -> void:
	if not _buscando:
		return
	_buscando = false
	_status.text = "Host encontrado em %s:%d. Conectando..." % [endereco, porta_host]
	NetworkManager.conectado.connect(_ao_conectado, CONNECT_ONE_SHOT)
	if not NetworkManager.entrar_sala(endereco, porta_host):
		_destravar()


func _ao_busca_encerrada() -> void:
	if _buscando:
		_buscando = false
		_destravar()


func _ao_conectado() -> void:
	GlobalManager.horda_skip_alvo = 1
	get_tree().change_scene_to_file("res://scenes/jogo.tscn")


func _ao_falha(texto: String) -> void:
	_status.text = texto
	_buscando = false
	_destravar()


func _travar(texto: String) -> void:
	_status.text = texto
	for b: Button in _botoes:
		b.disabled = true


func _destravar() -> void:
	for b: Button in _botoes:
		b.disabled = false
