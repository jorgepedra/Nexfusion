class_name ChefeFinal
extends Boss
## Chefe final (horda 31) — O ELEMENTO SUPREMO.
## Fase 1: quatro GUARDIÕES DE CONTENÇÃO em cada canto protegem o núcleo.
## Quebrar os quatro derruba a proteção e ATORDOA o chefe por 10 s; a proteção
## só volta depois de 20 s. Em 50% de vida ele entra em FÚRIA numa cutscene,
## transforma-se e leva o jogador para a CÂMARA DE FUSÃO (fase 2), com novos
## ataques e os antigos potencializados.
## Ataques: punho do núcleo, maré ácida com placas seguras, feixe aniquilador,
## chuva isotópica, espiral iônica e órbitas de plasma.

const ARENA: Rect2 = Rect2(0.0, 0.0, 2400.0, 1500.0)
const DURACAO_QUEDA: float = 3.0
const ALTURA_FINAL: float = 430.0
const REDUCAO_ESTAGIO_1: float = 0.7
const VELOCIDADE_FURIA: float = 1.35
const CENA_GUARDIAO: String = "res://scenes/enemy.tscn"
const DADOS_GUARDIAO: String = "res://resources/inimigos/guardiao_final.tres"
const CANTOS_GUARDIOES: Array[Vector2] = [
	Vector2(235.0, 235.0), Vector2(2165.0, 235.0),
	Vector2(235.0, 1265.0), Vector2(2165.0, 1265.0),
]
const DURACAO_ATORDOAMENTO: float = 10.0
const TEMPO_PROTECAO: float = 20.0
const ELEMENTOS: Array[String] = [
	"H", "He", "Li", "Be", "C", "N", "O", "F", "Ne", "Na", "Mg", "Al",
	"Si", "P", "S", "Cl", "K", "Ca", "Fe", "Cu", "Ag", "Hg", "U",
]

var _chegando: bool = true
var _queda_t: float = 0.0
var _inicio_x: float = 1200.0
var _inicio_y: float = -260.0
var _tremor_t: float = 0.0
var _aura: float = 0.0
var _cooldown: float = 3.4
var _em_andamento: int = 0
var _guardioes: Array[Enemy] = []
var _protecao_ativa: bool = false
var _protecao_iniciada: bool = false
var _protecao_timer: float = 0.0
var _atordoado: float = 0.0
var _fase2: bool = false
var _aviso_escudo: float = 0.0
var _proximo: int = 0
var _angulo_aura: float = 0.0


func _ready() -> void:
	super._ready()
	_padrao_timer = 99999.0
	_invocar_timer = 99999.0
	if como_comum:
		# Reaparece como inimigo comum: nada de cutscene de chegada.
		_chegando = false
		_padrao_timer = 2.2
	z_index = 7
	if corpo != null:
		corpo.modulate = Color(0.85, 0.95, 1.0)


func _physics_process(delta: float) -> void:
	if morto or autoridade_remota:
		return
	if _chegando:
		_arrivar(delta)
		return
	_aura += delta
	queue_redraw()
	_atualizar_protecao(delta)
	_aviso_escudo = maxf(0.0, _aviso_escudo - delta)
	if _atordoado > 0.0:
		# Atordoado: fica parado e não ataca (janela de dano livre).
		_atordoado -= delta
		velocity = Vector2.ZERO
		if _atordoado <= 0.0 and not morto:
			_cooldown = 0.9
			GlobalManager.chefe_aviso.emit("O NÚCLEO REAGE", "O CHEFE VOLTOU A SE MOVER")
		return
	super._physics_process(delta)
	if morto or not GlobalManager.partida_ativa:
		return
	if _cooldown > 0.0:
		_cooldown -= delta
	if _cooldown <= 0.0 and _em_andamento == 0:
		_iniciar_rodada()


# ------------------------------------------------------------------ chegada
func _arrivar(delta: float) -> void:
	if _queda_t <= 0.0:
		_inicio_x = global_position.x
		_inicio_y = global_position.y
	_queda_t += delta
	_aura += delta
	var p: float = clampf(_queda_t / DURACAO_QUEDA, 0.0, 1.0)
	var curva: float = p * p
	global_position = Vector2(lerpf(_inicio_x, ARENA.get_center().x, p), lerpf(_inicio_y, ALTURA_FINAL, curva))
	if corpo != null:
		corpo.modulate = Color(0.8 + p * 0.6, 0.9 + p * 0.2, 1.0)
	_tremor_t -= delta
	if _tremor_t <= 0.0:
		_tremor_t = 0.2
		Efeitos.tremor(2.5 + p * 13.0)
		if p > 0.35:
			Efeitos.particulas(get_parent(), global_position + Vector2(0, 80), Color("8ff3ff"), 6, 200.0, 0.5, 3.0)
	queue_redraw()
	if p >= 1.0:
		_chegando = false
		Efeitos.tremor(28.0)
		Efeitos.anel(get_parent(), global_position, 460.0, Color(1.0, 0.4, 0.3, 0.9), 0.9, 9.0)
		Efeitos.anel(get_parent(), global_position, 260.0, Color(0.6, 0.95, 1.0, 0.8), 0.6, 6.0)
		Efeitos.particulas(get_parent(), global_position, Color("ffb347"), 26, 460.0, 0.9, 4.5, "fogo")
		AudioManager.tocar_sfx("explosao", -2.0, 0.05)
		_montar_protecao()
		GlobalManager.chefe_aviso.emit("FASE 1 — SELO DE CONTENÇÃO", "QUEBRE OS 4 GUARDIÕES NOS CANTOS")


# ------------------------------------------------------------------ ataques
func _iniciar_rodada() -> void:
	var disponiveis: Array[String] = ["mao", "acido", "laser", "chuva"]
	if _fase2:
		disponiveis.append_array(["espiral", "orbitais"])
	var qtd: int = 2 if _furia else 1
	var fator: float = 0.72 if qtd > 1 else 1.0
	for i: int in range(qtd):
		if disponiveis.is_empty():
			break
		_proximo = (_proximo + 1) % disponiveis.size()
		var nome: String = disponiveis[_proximo % disponiveis.size()]
		disponiveis.erase(nome)
		_em_andamento += 1
		_executar(nome, fator)
	_cooldown = 1.7 if _furia else 2.5


func _executar(nome: String, fator: float) -> void:
	# Os ataques avisam quando terminam por sinal (nada de await): assim o
	# chefe pode morrer no meio de um ataque sem corrotina órfã.
	if animador != null:
		animador.tocar("ataque")
	match nome:
		"mao":
			_ataque_mao(fator)
		"acido":
			_ataque_acido(fator)
		"laser":
			_ataque_laser(fator)
		"chuva":
			_ataque_chuva(fator)
		"espiral":
			_ataque_espiral(fator)
		"orbitais":
			_ataque_orbitais(fator)


func _fim_ataque() -> void:
	_em_andamento = maxi(0, _em_andamento - 1)


func _ataque_mao(fator: float) -> void:
	if morto or not is_inside_tree():
		_fim_ataque()
		return
	var mao: MaoChefe = MaoChefe.new()
	mao.chefe = self
	get_parent().add_child(mao)
	mao.configurar(posicao_jogador(), 26.0 * fator * (1.25 if _fase2 else 1.0), 118.0)
	mao.terminou.connect(_fim_ataque, CONNECT_ONE_SHOT)
	AudioManager.tocar_sfx("perigo", -6.0, 0.06)
	GlobalManager.chefe_aviso.emit("PUNHO DO NÚCLEO", "SAIA DA MARCA NO CHÃO")


func _ataque_acido(fator: float) -> void:
	if morto or not is_inside_tree():
		_fim_ataque()
		return
	var placas_qtd: int = (5 if _furia else 4) + (2 if _fase2 else 0)
	var placa: PlacasAcido = PlacasAcido.new()
	placa.chefe = self
	get_parent().add_child(placa)
	placa.configurar(self, _posicoes_placas(placas_qtd), 9.0 * fator * (1.2 if _fase2 else 1.0), ARENA)
	placa.terminou.connect(_fim_ataque, CONNECT_ONE_SHOT)
	AudioManager.tocar_sfx("perigo", -6.0, 0.05)
	GlobalManager.chefe_aviso.emit("MARÉ ÁCIDA", "SUBA NAS PLACAS SEGURAS")


func _ataque_laser(fator: float) -> void:
	if morto or not is_inside_tree():
		_fim_ataque()
		return
	var alvo: Player = jogador_atual()
	if alvo == null:
		_fim_ataque()
		return
	var laser: LaserChefe = LaserChefe.new()
	laser.chefe = self
	get_parent().add_child(laser)
	laser.configurar(global_position, alvo.global_position, 32.0 * fator * (1.35 if _fase2 else 1.0))
	laser.terminou.connect(_fim_ataque, CONNECT_ONE_SHOT)
	AudioManager.tocar_sfx("perigo", -5.0, 0.05)
	GlobalManager.chefe_aviso.emit("FEIXE ANIQUILADOR", "ATRAVESSE COM O DASH")


func _ataque_chuva(fator: float) -> void:
	if morto or not is_inside_tree():
		_fim_ataque()
		return
	var chuva: ChuvaDiagonal = ChuvaDiagonal.new()
	chuva.chefe = self
	get_parent().add_child(chuva)
	chuva.configurar(self, ARENA, fator * (1.3 if _fase2 else 1.0))
	chuva.terminou.connect(_fim_ataque, CONNECT_ONE_SHOT)
	AudioManager.tocar_sfx("perigo", -7.0, 0.05)
	GlobalManager.chefe_aviso.emit("CHUVA ISOTÓPICA", "DESVIE DA GOTA SÓLIDA")


func _ataque_espiral(fator: float) -> void:
	## Fase 2: três anéis girando em espiral ao redor do núcleo.
	for anel: int in range(3):
		var qtd: int = 8
		for i: int in range(qtd):
			var ang: float = TAU * float(i) / float(qtd) + float(anel) * 0.32 + _aura * 0.6
			projetil(global_position, Vector2.RIGHT.rotated(ang), 9.0 * fator, 250.0 + float(anel) * 55.0, 1.25)
	Efeitos.anel(get_parent(), global_position, 180.0, Color(0.6, 0.9, 1.0, 0.7), 0.4, 3.0)
	AudioManager.tocar_sfx("tiro_pesado", -8.0, 0.05)
	GlobalManager.chefe_aviso.emit("ESPIRAL IÔNICA", "SEMPRE EM MOVIMENTO")
	_fim_ataque()


func _ataque_orbitais(fator: float) -> void:
	## Fase 2: projéteis grandes e lentos que ricocheteiam nas paredes.
	if _cena_projetil == null:
		_fim_ataque()
		return
	for i: int in range(6):
		var ang: float = TAU * float(i) / 6.0 + _aura
		var p: Projetil = _cena_projetil.instantiate() as Projetil
		if p == null:
			continue
		get_parent().add_child(p)
		p.global_position = global_position + Vector2.RIGHT.rotated(ang) * 60.0
		p.configurar({
			"amigavel": false,
			"direcao": Vector2.RIGHT.rotated(ang),
			"dano": 12.0 * fator,
			"velocidade": 215.0,
			"cor": Color("ff8a5c"),
			"tamanho": 1.9,
			"alcance": 2200.0,
			"ricochetes": 2,
		})
	AudioManager.tocar_sfx("explosao", -6.0, 0.05)
	GlobalManager.chefe_aviso.emit("ÓRBITAS DE PLASMA", "ELAS RICOCHETEIAM NAS PAREDES")
	_fim_ataque()


# ------------------------------------------------------------------ guardiões
func _montar_protecao() -> void:
	## Quatro estátuas guardiãs, uma em cada canto, blindam o chefe.
	if como_comum or _fase2 or morto:
		return
	_destruir_guardioes()
	var dados_g: DadosInimigo = load(DADOS_GUARDIAO) as DadosInimigo
	var cena: PackedScene = load(CENA_GUARDIAO) as PackedScene
	if dados_g == null or cena == null:
		return
	for canto: Vector2 in CANTOS_GUARDIOES:
		var base: Node = cena.instantiate()
		if base == null:
			continue
		base.set_script(load("res://scripts/guardiao_chefe.gd"))
		var g: Enemy = base as Enemy
		if g == null:
			continue
		g.dados = dados_g
		g.como_comum = true
		get_parent().add_child(g)
		g.global_position = canto
		g.configurar(dados_g, 1)
		g.como_comum = true
		g.morreu.connect(_ao_guardiao_morrer)
		_guardioes.append(g)
		Efeitos.anel(get_parent(), canto, 90.0, Color(0.55, 0.9, 1.0, 0.8), 0.5, 3.0)
	_protecao_ativa = not _guardioes.is_empty()
	_protecao_iniciada = true


func _ao_guardiao_morrer(_g: Enemy) -> void:
	var vivos: int = 0
	for g: Enemy in _guardioes:
		if g != null and is_instance_valid(g) and not g.morto:
			vivos += 1
	if vivos == 0 and _protecao_ativa and not morto:
		_quebrar_protecao()


func _quebrar_protecao() -> void:
	if not _protecao_ativa:
		return
	_protecao_ativa = false
	_atordoado = DURACAO_ATORDOAMENTO
	_protecao_timer = TEMPO_PROTECAO
	Efeitos.tremor(20.0)
	Efeitos.anel(get_parent(), global_position, 420.0, Color(0.6, 0.95, 1.0, 0.9), 0.9, 8.0)
	Efeitos.particulas(get_parent(), global_position, Color("9df5ff"), 24, 380.0, 0.8, 4.0, "plasma")
	AudioManager.tocar_sfx("explosao", -1.0, 0.04)
	GlobalManager.chefe_aviso.emit("PROTEÇÃO ROMPIDA", "NÚCLEO ATORDOADO POR 10 SEGUNDOS")


func _atualizar_protecao(delta: float) -> void:
	## Depois de quebrada, a proteção se remonta em 20 s (se o chefe ainda viver).
	if not _protecao_iniciada or _protecao_ativa or _fase2 or como_comum or morto:
		return
	if _protecao_timer <= 0.0:
		return
	_protecao_timer -= delta
	if _protecao_timer <= 0.0:
		GlobalManager.chefe_aviso.emit("SELO RESTAURADO", "OS GUARDIÕES VOLTARAM AOS CANTOS")
		_montar_protecao()


func _destruir_guardioes() -> void:
	for g: Enemy in _guardioes:
		if g != null and is_instance_valid(g):
			g.queue_free()
	_guardioes.clear()
	_protecao_ativa = false


# ------------------------------------------------------------------ dano
func receber_dano(valor: float, critico: bool = false) -> void:
	if morto or _chegando:
		return
	if _protecao_ativa:
		if _aviso_escudo <= 0.0:
			_aviso_escudo = 0.5
			Efeitos.texto_flutuante(get_parent(), global_position, "PROTEÇÃO", Color("9df5ff"), 14)
			Efeitos.anel(get_parent(), global_position, 150.0, Color(0.6, 0.9, 1.0, 0.5), 0.3, 2.0)
		return
	var fator: float = 1.0 if _furia else REDUCAO_ESTAGIO_1
	super.receber_dano(maxf(1.0, valor * fator), critico)


func _entrar_furia() -> void:
	## A fúria é uma cutscene: o jogo troca a arena e chama aplicar_fase2().
	if _furia:
		return
	_furia = true
	_atordoado = 5.0
	var jogo: Node = get_tree().get_first_node_in_group("game")
	if jogo != null and jogo.has_method("cutscene_furia_chefe"):
		jogo.call("cutscene_furia_chefe", self)
		return
	aplicar_fase2()


func aplicar_fase2() -> void:
	## Transformação final: novos ataques, antigos potencializados, sem proteção.
	if _fase2:
		return
	_fase2 = true
	_furia = true
	_atordoado = 1.0
	_protecao_ativa = false
	_protecao_timer = 0.0
	_destruir_guardioes()
	velocidade *= VELOCIDADE_FURIA
	_cooldown = 1.0
	escala_visual *= 1.18
	_aplicar_visual()
	if corpo != null:
		corpo.modulate = Color(1.45, 0.55, 0.5)
		var tw: Tween = create_tween().set_loops(8)
		tw.tween_property(corpo, "modulate", Color(1.9, 0.6, 0.55), 0.18)
		tw.tween_property(corpo, "modulate", Color(1.35, 0.5, 0.5), 0.18)
	Efeitos.tremor(30.0)
	Efeitos.particulas(get_parent(), global_position, Color("ff7a59"), 30, 520.0, 1.0, 5.0, "fogo")
	AudioManager.tocar_sfx("chefe", 0.0, 0.04)
	GlobalManager.registrar_estilo("FÚRIA ELEMENTAL", 20.0, Color("ff5f5f"))
	GlobalManager.chefe_aviso.emit("MODO FÚRIA", "O NÚCLEO SE TRANSFORMOU")


func _morrer() -> void:
	if morto:
		return
	_destruir_guardioes()
	if not como_comum:
		GlobalManager.chefe_aviso.emit("ELEMENTO SUPREMO NEUTRALIZADO", "ARENA ESTABILIZADA")
	super._morrer()


# ------------------------------------------------------------------ auxiliares
func jogador_atual() -> Player:
	if jogador != null and is_instance_valid(jogador):
		return jogador
	var lista: Array[Node] = get_tree().get_nodes_in_group("player")
	if lista.is_empty():
		return null
	return lista[0] as Player


func posicao_jogador() -> Vector2:
	var p: Player = jogador_atual()
	return p.global_position if p != null else global_position


func ferir_jogador(valor: float) -> void:
	var p: Player = jogador_atual()
	if p != null and p.vivo:
		p.receber_dano(valor)


func dano_area(centro: Vector2, raio_area: float, valor: float) -> void:
	var p: Player = jogador_atual()
	if p == null or not p.vivo:
		return
	if centro.distance_to(p.global_position) <= raio_area + 12.0:
		p.receber_dano(valor)


func projetil(origem: Vector2, dir: Vector2, valor: float, vel: float, tam: float) -> void:
	if _cena_projetil == null:
		return
	var proj: Projetil = _cena_projetil.instantiate() as Projetil
	if proj == null:
		return
	get_parent().add_child(proj)
	proj.global_position = origem
	proj.configurar({
		"amigavel": false,
		"direcao": dir,
		"dano": valor,
		"velocidade": vel,
		"cor": dados.cor if dados != null else Color("8ff3ff"),
		"tamanho": tam,
		"alcance": 1400.0,
	})


func _posicoes_placas(qtd: int) -> Array[Vector2]:
	var lista: Array[Vector2] = []
	var tentativas: int = 0
	while lista.size() < qtd and tentativas < 220:
		tentativas += 1
		var p: Vector2 = Vector2(
			randf_range(ARENA.position.x + 300.0, ARENA.end.x - 300.0),
			randf_range(ARENA.position.y + 300.0, ARENA.end.y - 300.0)
		)
		if p.distance_to(global_position) < 230.0:
			continue
		var valido: bool = true
		for q: Vector2 in lista:
			if p.distance_to(q) < 480.0:
				valido = false
				break
		if valido:
			lista.append(p)
	if lista.is_empty():
		lista.append(ARENA.get_center())
	return lista


# ------------------------------------------------------------------ visual
func _draw() -> void:
	var raio_orbita: float = 138.0 if _furia else 116.0
	var qtd: int = 12 if _furia else 8
	var vel: float = 1.9 if _furia else 0.9
	_angulo_aura = _aura * vel
	var cor_anel: Color = Color(1.0, 0.35, 0.3, 0.35) if _furia else Color(0.45, 0.9, 1.0, 0.32)
	draw_arc(Vector2.ZERO, raio_orbita + 16.0, 0.0, TAU, 56, cor_anel, 3.0, true)
	for i: int in range(qtd):
		var ang: float = _angulo_aura + TAU * float(i) / float(qtd)
		var orb: Vector2 = Vector2(cos(ang), sin(ang) * 0.55) * raio_orbita
		draw_circle(orb, 9.0, Color(0.55, 0.85, 1.0, 0.16))
		draw_arc(orb, 9.0, 0.0, TAU, 12, Color(0.7, 0.95, 1.0, 0.85), 1.5, true)
		var fonte: Font = ThemeDB.fallback_font
		if fonte != null:
			var simbolo: String = ELEMENTOS[(i * 3 + 1) % ELEMENTOS.size()]
			draw_string(fonte, orb + Vector2(-8.0, 4.0), simbolo, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 11, Color(0.88, 0.98, 1.0, 0.9))
