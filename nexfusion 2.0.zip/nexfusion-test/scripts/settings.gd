extends Control
## Configurações em categorias: Som, Vídeo, Geral, Controles e Progresso.
## Inclui qualidade gráfica ilustrada, modo mobile, apelido, skins, FPS/ping
## e remapeamento de atalhos com descrição de cada ação.

const ACOES_REMAPEAVEIS: Array[String] = [
	"mover_esquerda", "mover_direita", "mover_cima", "mover_baixo",
	"dash_esquiva", "tiro_primario", "tiro_carregado", "aparar_melee", "pausar",
]

const DESCRICOES := {
	"mover_esquerda": "Andar para a esquerda.",
	"mover_direita": "Andar para a direita.",
	"mover_cima": "Andar para cima.",
	"mover_baixo": "Andar para baixo.",
	"dash_esquiva": "Impulso rápido com invulnerabilidade. Padrão: Espaço ou Shift.",
	"tiro_primario": "Atirar com a arma equipada (segure para atirar continuamente).",
	"tiro_carregado": "Ataque secundário exclusivo da arma equipada.",
	"aparar_melee": "Aparar projéteis/granadas e empurrar inimigos próximos.",
	"pausar": "Abrir e fechar o menu de pausa.",
}

var _categoria: String = "som"
var _corpo: VBoxContainer
var _abas: Dictionary = {}
var _aviso: Label
var _acao_em_espera: String = ""
var _botoes_tecla: Dictionary = {}
var _check_tela: CheckButton


func _ready() -> void:
	GlobalManager.definir_cursor(true)
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var fundo: ColorRect = ColorRect.new()
	fundo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fundo.color = Color(0.03, 0.045, 0.07)
	add_child(fundo)
	_construir()
	GlobalManager.tela_cheia_alterada.connect(func(ativa: bool) -> void:
		if _check_tela != null:
			_check_tela.set_pressed_no_signal(ativa))
	AudioManager.tocar_bgm("menu")


func _construir() -> void:
	var margem: MarginContainer = MarginContainer.new()
	margem.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margem.add_theme_constant_override("margin_left", 70)
	margem.add_theme_constant_override("margin_right", 70)
	margem.add_theme_constant_override("margin_top", 24)
	margem.add_theme_constant_override("margin_bottom", 24)
	add_child(margem)
	var principal: VBoxContainer = VBoxContainer.new()
	principal.add_theme_constant_override("separation", 10)
	margem.add_child(principal)

	var topo: HBoxContainer = HBoxContainer.new()
	principal.add_child(topo)
	topo.add_child(UI.titulo("CONFIGURAÇÕES", 36, UI.COR_CIANO))
	var espaco: Control = Control.new()
	espaco.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	topo.add_child(espaco)
	var b_voltar: Button = UI.botao("VOLTAR", 16, UI.COR_TEXTO_FRACO)
	b_voltar.custom_minimum_size = Vector2(140, 42)
	b_voltar.pressed.connect(func() -> void: get_tree().change_scene_to_file("res://scenes/menu.tscn"))
	topo.add_child(b_voltar)

	var linha_abas: HBoxContainer = HBoxContainer.new()
	linha_abas.add_theme_constant_override("separation", 8)
	principal.add_child(linha_abas)
	for par: Array in [["som", "SOM", UI.COR_CIANO], ["video", "VÍDEO", UI.COR_MAGENTA], ["geral", "GERAL", UI.COR_VERDE], ["controles", "CONTROLES", UI.COR_AMBAR], ["progresso", "PROGRESSO", UI.COR_VERMELHO]]:
		var b: Button = UI.botao(String(par[1]), 15, par[2] as Color)
		b.custom_minimum_size = Vector2(190, 40)
		b.pressed.connect(_ao_aba.bind(String(par[0])))
		linha_abas.add_child(b)
		_abas[String(par[0])] = b

	var rolagem: ScrollContainer = ScrollContainer.new()
	rolagem.size_flags_vertical = Control.SIZE_EXPAND_FILL
	rolagem.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	principal.add_child(rolagem)
	_corpo = VBoxContainer.new()
	_corpo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_corpo.add_theme_constant_override("separation", 10)
	rolagem.add_child(_corpo)
	_ao_aba("som")


func _ao_aba(categoria: String) -> void:
	_categoria = categoria
	_acao_em_espera = ""
	for filho: Node in _corpo.get_children():
		_corpo.remove_child(filho)
		filho.queue_free()
	for chave: Variant in _abas.keys():
		var b: Button = _abas[chave] as Button
		UI.aplicar_tema_botao(b, UI.COR_AMBAR if String(chave) == categoria else UI.COR_TEXTO_FRACO)
	_botoes_tecla.clear()
	match categoria:
		"som":
			_montar_som()
		"video":
			_montar_video()
		"geral":
			_montar_geral()
		"controles":
			_montar_controles()
		_:
			_montar_progresso()
	AudioManager.tocar_sfx("clique", -10.0, 0.02)


# ------------------------------------------------------------------ SOM
func _montar_som() -> void:
	_corpo.add_child(_secao("ÁUDIO", UI.COR_CIANO))
	_corpo.add_child(_linha_slider("Música", GlobalManager.volume_musica, func(v: float) -> void:
		GlobalManager.definir_volume_musica(v)))
	_corpo.add_child(_linha_slider("Efeitos (SFX)", GlobalManager.volume_sfx, func(v: float) -> void:
		GlobalManager.definir_volume_sfx(v)
		AudioManager.tocar_sfx("hit", -14.0)))
	var dica: Label = UI.rotulo("A trilha muda conforme a arena: calma sem inimigos, agitada em combate e orquestral contra chefes.", 13, UI.COR_TEXTO_FRACO)
	dica.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_corpo.add_child(dica)


# ------------------------------------------------------------------ VÍDEO
func _montar_video() -> void:
	_corpo.add_child(_secao("QUALIDADE GRÁFICA", UI.COR_MAGENTA))
	var explicacao: Label = UI.rotulo("Escolha antes de começar: cada nível muda partículas, animações e iluminação.", 13, UI.COR_TEXTO_FRACO)
	_corpo.add_child(explicacao)
	var cartoes: HBoxContainer = HBoxContainer.new()
	cartoes.add_theme_constant_override("separation", 10)
	_corpo.add_child(cartoes)
	for i: int in range(GlobalManager.QUALIDADES.size()):
		cartoes.add_child(_cartao_qualidade(i))

	_corpo.add_child(_secao("TELA", UI.COR_CIANO))
	var linha_tela: HBoxContainer = HBoxContainer.new()
	linha_tela.add_theme_constant_override("separation", 14)
	var lbl_tela: Label = UI.rotulo("Tela cheia", 16, UI.COR_TEXTO)
	lbl_tela.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	linha_tela.add_child(lbl_tela)
	_check_tela = CheckButton.new()
	_check_tela.button_pressed = GlobalManager.tela_cheia
	_check_tela.toggled.connect(func(ativa: bool) -> void: GlobalManager.definir_tela_cheia(ativa))
	linha_tela.add_child(_check_tela)
	_corpo.add_child(_envolver(linha_tela))

	_corpo.add_child(_secao("MODO DE JOGO", UI.COR_VERDE))
	var linha_modo: HBoxContainer = HBoxContainer.new()
	linha_modo.add_theme_constant_override("separation", 10)
	var lbl_modo: Label = UI.rotulo("Controles:", 16, UI.COR_TEXTO)
	lbl_modo.custom_minimum_size = Vector2(150, 32)
	linha_modo.add_child(lbl_modo)
	var b_desktop: Button = UI.botao("DESKTOP (teclado + mouse)", 14, UI.COR_CIANO)
	b_desktop.custom_minimum_size = Vector2(260, 40)
	b_desktop.pressed.connect(func() -> void:
		GlobalManager.definir_modo_mobile(false)
		_ao_aba("video"))
	linha_modo.add_child(b_desktop)
	var b_mobile: Button = UI.botao("MOBILE (toque)", 14, UI.COR_VERDE)
	b_mobile.custom_minimum_size = Vector2(190, 40)
	b_mobile.pressed.connect(func() -> void:
		GlobalManager.definir_modo_mobile(true)
		_ao_aba("video"))
	linha_modo.add_child(b_mobile)
	_corpo.add_child(_envolver(linha_modo))
	var atual: Label = UI.rotulo("Atual: %s" % ("MOBILE" if GlobalManager.modo_mobile else "DESKTOP"), 13, UI.COR_AMBAR)
	_corpo.add_child(atual)

	_corpo.add_child(_secao("INFORMAÇÕES NA TELA", UI.COR_CIANO))
	_corpo.add_child(_linha_check("Mostrar FPS", GlobalManager.mostrar_fps, func(ativo: bool) -> void: GlobalManager.definir_mostrar_fps(ativo)))
	_corpo.add_child(_linha_check("Mostrar ping dos jogadores (LAN)", GlobalManager.mostrar_ping, func(ativo: bool) -> void: GlobalManager.definir_mostrar_ping(ativo)))


func _cartao_qualidade(i: int) -> Control:
	var dados: Dictionary = GlobalManager.QUALIDADES[i] as Dictionary
	var cor: Color = dados["cor"] as Color
	var selecionado: bool = GlobalManager.qualidade == i
	var b: Button = Button.new()
	b.custom_minimum_size = Vector2(340, 210)
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_stylebox_override("normal", UI.estilo_painel(Color(0.06, 0.09, 0.14, 0.96), cor if selecionado else UI.COR_BORDA, 6))
	b.add_theme_stylebox_override("hover", UI.estilo_painel(Color(0.1, 0.14, 0.2, 0.98), cor, 6))
	b.add_theme_stylebox_override("pressed", UI.estilo_painel(Color(0.04, 0.07, 0.1, 1.0), cor, 6))
	b.pressed.connect(func() -> void:
		GlobalManager.definir_qualidade(i)
		_ao_aba("video"))
	var vb: VBoxContainer = VBoxContainer.new()
	vb.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vb.offset_left = 14
	vb.offset_right = -14
	vb.offset_top = 12
	vb.offset_bottom = -12
	vb.add_theme_constant_override("separation", 5)
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(vb)
	var titulo: Label = UI.rotulo("%s%s" % [String(dados["nome"]), "  • SELECIONADA" if selecionado else ""], 20, cor)
	titulo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(titulo)
	var resumo: Label = UI.rotulo(String(dados["resumo"]), 12, UI.COR_TEXTO)
	resumo.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	resumo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(resumo)
	for item: String in dados["itens"] as Array:
		var l: Label = UI.rotulo("•  %s" % item, 12, UI.COR_TEXTO_FRACO)
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.mouse_filter = Control.MOUSE_FILTER_IGNORE
		vb.add_child(l)
	return b


# ------------------------------------------------------------------ GERAL
func _montar_geral() -> void:
	_corpo.add_child(_secao("APELIDO", UI.COR_VERDE))
	var linha_nick: HBoxContainer = HBoxContainer.new()
	linha_nick.add_theme_constant_override("separation", 10)
	var campo: LineEdit = LineEdit.new()
	campo.text = GlobalManager.nick
	campo.max_length = 16
	campo.custom_minimum_size = Vector2(280, 40)
	campo.add_theme_font_size_override("font_size", 15)
	linha_nick.add_child(campo)
	var b_salvar: Button = UI.botao("SALVAR APELIDO", 14, UI.COR_VERDE)
	b_salvar.custom_minimum_size = Vector2(190, 40)
	var aplicar: Callable = func() -> void:
		GlobalManager.definir_nick(campo.text)
		campo.text = GlobalManager.nick
		AudioManager.tocar_sfx("clique", -8.0, 0.02)
	b_salvar.pressed.connect(aplicar)
	campo.focus_exited.connect(aplicar)
	campo.text_submitted.connect(func(_t: String) -> void: aplicar.call())
	linha_nick.add_child(b_salvar)
	_corpo.add_child(_envolver(linha_nick))
	_corpo.add_child(UI.rotulo("Aparece acima do personagem no modo LAN (até 4 jogadores).", 12, UI.COR_TEXTO_FRACO))

	_corpo.add_child(_secao("APARÊNCIA", UI.COR_MAGENTA))
	_corpo.add_child(_linha_skin_player())
	_corpo.add_child(_linha_skin_arma())


func _linha_skin_player() -> Control:
	var h: HBoxContainer = HBoxContainer.new()
	h.add_theme_constant_override("separation", 12)
	var lbl: Label = UI.rotulo("Skin do jogador", 16, UI.COR_TEXTO)
	lbl.custom_minimum_size = Vector2(160, 32)
	h.add_child(lbl)
	var opcoes: OptionButton = OptionButton.new()
	opcoes.custom_minimum_size = Vector2(210, 38)
	opcoes.add_theme_font_size_override("font_size", 14)
	for s: Dictionary in GlobalManager.SKINS_JOGADOR:
		opcoes.add_item(String(s["nome"]))
	opcoes.selected = GlobalManager.skin_player
	var amostra: ColorRect = ColorRect.new()
	amostra.custom_minimum_size = Vector2(52, 32)
	amostra.color = GlobalManager.cor_skin_player()
	h.add_child(opcoes)
	h.add_child(amostra)
	opcoes.item_selected.connect(func(indice: int) -> void:
		GlobalManager.definir_skin_player(indice)
		amostra.color = GlobalManager.cor_skin_player())
	return _envolver(h)


func _linha_skin_arma() -> Control:
	var h: HBoxContainer = HBoxContainer.new()
	h.add_theme_constant_override("separation", 12)
	var lbl: Label = UI.rotulo("Skin da arma", 16, UI.COR_TEXTO)
	lbl.custom_minimum_size = Vector2(160, 32)
	h.add_child(lbl)
	var opcoes: OptionButton = OptionButton.new()
	opcoes.custom_minimum_size = Vector2(210, 38)
	opcoes.add_theme_font_size_override("font_size", 14)
	for s: Dictionary in GlobalManager.SKINS_ARMA:
		opcoes.add_item(String(s["nome"]))
	opcoes.selected = GlobalManager.skin_arma
	var amostra: ColorRect = ColorRect.new()
	amostra.custom_minimum_size = Vector2(52, 32)
	amostra.color = GlobalManager.cor_skin_arma()
	h.add_child(opcoes)
	h.add_child(amostra)
	opcoes.item_selected.connect(func(indice: int) -> void:
		GlobalManager.definir_skin_arma(indice)
		amostra.color = GlobalManager.cor_skin_arma())
	return _envolver(h)


# ------------------------------------------------------------------ CONTROLES
func _montar_controles() -> void:
	_corpo.add_child(_secao("CONTROLES", UI.COR_AMBAR))
	_corpo.add_child(UI.rotulo("Clique em um atalho e pressione a nova tecla ou botão do mouse. ESC cancela.", 13, UI.COR_TEXTO_FRACO))
	_aviso = UI.rotulo("", 14, UI.COR_AMBAR)
	_corpo.add_child(_aviso)
	for acao: String in ACOES_REMAPEAVEIS:
		_corpo.add_child(_linha_controle(acao))
	var resumo: Label = UI.rotulo("Resumo: WASD ou setas para andar · mouse para mirar · botão esquerdo atira · botão direito usa o secundário · Espaço ou Shift dão dash · F apara.", 12, UI.COR_TEXTO_FRACO)
	resumo.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_corpo.add_child(resumo)


func _linha_controle(acao: String) -> Control:
	var h: HBoxContainer = HBoxContainer.new()
	h.add_theme_constant_override("separation", 12)
	var vb: VBoxContainer = VBoxContainer.new()
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var nome: Label = UI.rotulo(_nome_acao(acao), 15, UI.COR_TEXTO)
	vb.add_child(nome)
	var desc: Label = UI.rotulo(String(DESCRICOES.get(acao, "")), 11, UI.COR_TEXTO_FRACO)
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vb.add_child(desc)
	h.add_child(vb)
	var b: Button = UI.botao(GlobalManager.nome_teclas(acao), 13, UI.COR_CIANO)
	b.custom_minimum_size = Vector2(250, 40)
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(_esperar_tecla.bind(acao))
	h.add_child(b)
	_botoes_tecla[acao] = b
	return _envolver(h)


# ------------------------------------------------------------------ PROGRESSO
func _montar_progresso() -> void:
	_corpo.add_child(_secao("PROGRESSO", UI.COR_VERMELHO))
	var linha_reset: HBoxContainer = HBoxContainer.new()
	linha_reset.add_theme_constant_override("separation", 12)
	var lbl_reset: Label = UI.rotulo("Apagar todo o progresso salvo (moedas, upgrades e recordes).", 14, UI.COR_TEXTO_FRACO)
	lbl_reset.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	linha_reset.add_child(lbl_reset)
	var b_reset: Button = UI.botao("APAGAR SAVE", 14, UI.COR_VERMELHO)
	b_reset.custom_minimum_size = Vector2(180, 40)
	b_reset.pressed.connect(func() -> void:
		GlobalManager.resetar_progresso()
		_aviso = UI.rotulo("Progresso apagado.", 14, UI.COR_VERMELHO)
		_corpo.add_child(_aviso))
	linha_reset.add_child(b_reset)
	_corpo.add_child(_envolver(linha_reset))


# ------------------------------------------------------------------ utilitários
func _secao(texto: String, cor: Color) -> Control:
	var v: VBoxContainer = VBoxContainer.new()
	var espaco: Control = Control.new()
	espaco.custom_minimum_size = Vector2(0, 10)
	v.add_child(espaco)
	var h: HBoxContainer = HBoxContainer.new()
	h.add_child(UI.rotulo(texto, 18, cor))
	var linha: HSeparator = HSeparator.new()
	linha.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	linha.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(linha)
	v.add_child(h)
	return v


func _linha_slider(nome: String, valor: float, ao_mudar: Callable) -> Control:
	var h: HBoxContainer = HBoxContainer.new()
	h.add_theme_constant_override("separation", 14)
	var lbl: Label = UI.rotulo(nome, 16, UI.COR_TEXTO)
	lbl.custom_minimum_size = Vector2(200, 32)
	h.add_child(lbl)
	var slider: HSlider = HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.05
	slider.value = valor
	slider.custom_minimum_size = Vector2(340, 28)
	slider.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(slider)
	var pct: Label = UI.rotulo("%d%%" % int(round(valor * 100.0)), 14, UI.COR_CIANO)
	pct.custom_minimum_size = Vector2(60, 30)
	pct.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	h.add_child(pct)
	slider.value_changed.connect(func(v: float) -> void:
		pct.text = "%d%%" % int(round(v * 100.0))
		ao_mudar.call(v))
	return _envolver(h)


func _linha_check(nome: String, valor: bool, ao_mudar: Callable) -> Control:
	var h: HBoxContainer = HBoxContainer.new()
	var lbl: Label = UI.rotulo(nome, 15, UI.COR_TEXTO)
	lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(lbl)
	var check: CheckButton = CheckButton.new()
	check.button_pressed = valor
	check.toggled.connect(ao_mudar)
	h.add_child(check)
	return _envolver(h)


func _envolver(filho: Control) -> Control:
	var p: PanelContainer = PanelContainer.new()
	p.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.06, 0.09, 0.13, 0.95), UI.COR_BORDA, 4))
	p.add_child(filho)
	return p


func _nome_acao(acao: String) -> String:
	match acao:
		"mover_esquerda":
			return "Mover esquerda"
		"mover_direita":
			return "Mover direita"
		"mover_cima":
			return "Mover cima"
		"mover_baixo":
			return "Mover baixo"
		"dash_esquiva":
			return "Dash / esquiva  (Espaço ou Shift)"
		"tiro_primario":
			return "Tiro primário"
		"tiro_carregado":
			return "Ataque secundário"
		"aparar_melee":
			return "Aparar (parry)"
		"pausar":
			return "Pausar"
		_:
			return acao


func _esperar_tecla(acao: String) -> void:
	_acao_em_espera = acao
	if _aviso != null:
		_aviso.text = "Pressione a nova tecla para '%s' (ESC cancela)" % _nome_acao(acao)
		_aviso.add_theme_color_override("font_color", UI.COR_AMBAR)
	var b: Button = _botoes_tecla.get(acao, null) as Button
	if b != null:
		b.text = "…"
		b.release_focus()


func _unhandled_input(evento: InputEvent) -> void:
	if _acao_em_espera == "":
		return
	if evento is InputEventKey:
		var k: InputEventKey = evento as InputEventKey
		if not k.pressed or k.echo:
			return
		if k.physical_keycode == KEY_ESCAPE:
			_acao_em_espera = ""
			if _aviso != null:
				_aviso.text = "Remapeamento cancelado."
			_atualizar_botoes()
			get_viewport().set_input_as_handled()
			return
		GlobalManager.remapear_acao(_acao_em_espera, k)
	elif evento is InputEventMouseButton:
		var m: InputEventMouseButton = evento as InputEventMouseButton
		if not m.pressed:
			return
		GlobalManager.remapear_acao(_acao_em_espera, m)
	else:
		return
	if _aviso != null:
		_aviso.text = "Atalho atualizado."
		_aviso.add_theme_color_override("font_color", UI.COR_VERDE)
	_acao_em_espera = ""
	_atualizar_botoes()
	get_viewport().set_input_as_handled()


func _atualizar_botoes() -> void:
	for acao_v: Variant in _botoes_tecla.keys():
		var acao: String = String(acao_v)
		var b: Button = _botoes_tecla[acao_v] as Button
		if b != null:
			b.text = GlobalManager.nome_teclas(acao)
