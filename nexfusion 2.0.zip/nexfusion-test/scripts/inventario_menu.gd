extends Control
## Acesso ao Inventário / Caderno de Registros fora da partida (menu principal).

func _ready() -> void:
	GlobalManager.definir_cursor(true)
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var tela: TelaInventario = TelaInventario.new()
	add_child(tela)
	tela.fechar_solicitado.connect(_ao_fechar)
	tela.abrir()
	AudioManager.tocar_bgm("menu")


func _ao_fechar() -> void:
	get_tree().change_scene_to_file("res://scenes/menu.tscn")
