class_name PainelDev
extends Control
## Painel de Desenvolvedor (Shift+P): pular hordas, equipar qualquer arma,
## spawnar qualquer mob e limpar a arena. Pausa a árvore enquanto estiver aberto.

signal fechar_solicitado

const PASTA_ARMAS: String = "res://resources/armas"

var _spawn: SpawnManager = null
var _jogador: Player = null
var _conteudo: VBoxContainer
var _status: Label
var _seletor_horda: SpinBox
var _seletor_mob: OptionButton
var _mobs: Array[DadosInimigo] = []


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false


func abrir(spawn: SpawnManager, jogador: Player) -> void:
	_spawn = spawn
	_jogador = jogador
	_reconstruir()
	visible = true
	modulate.a = 0.0
	var tw: Tween = create_tween()
	tw.tween_property(self, "modulate:a", 1.0, 0.18)


func fechar() -> void:
	visible = false


func _unhandled_input(evento: InputEvent) -> void:
	if not visible:
		return
	var tecla: InputEventKey = evento as InputEventKey
	if tecla == null or not tecla.pressed or tecla.echo:
		return
	var codigo: int = tecla.physical_keycode if tecla.physical_keycode != 0 else tecla.keycode
	if codigo == KEY_P and tecla.shift_pressed:
		fechar_solicitado.emit()
		get_viewport().set_input_as_handled()
	elif codigo == KEY_ESCAPE:
		fechar_solicitado.emit()
		get_viewport().set_input_as_handled()


func _reconstruir() -> void:
	for filho: Node in get_children():
		filho.queue_free()
	_mobs.clear()
	if _spawn != null:
		_mobs = _spawn.catalogo()
	var fundo: ColorRect = ColorRect.new()
	fundo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fundo.color = Color(0.02, 0.03, 0.05, 0.92)
	add_child(fundo)
	var centro: VBoxContainer = VBoxContainer.new()
	centro.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	centro.alignment = BoxContainer.ALIGNMENT_CENTER
	centro.add_theme_constant_override("separation", 10)
	add_child(centro)
	centro.add_child(UI.titulo("PAINEL DE DESENVOLVEDOR", 38, UI.COR_MAGENTA))
	var sub: Label = UI.rotulo("Shift + P abre e fecha  ·  a partida fica pausada", 14, UI.COR_TEXTO_FRACO)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	centro.add_child(sub)

	var painel: PanelContainer = PanelContainer.new()
	painel.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.06, 0.09, 0.14, 0.97), UI.COR_MAGENTA.darkened(0.4), 6))
	painel.custom_minimum_size = Vector2(760, 0)
	painel.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	centro.add_child(painel)
	_conteudo = VBoxContainer.new()
	_conteudo.add_theme_constant_override("separation", 12)
	painel.add_child(_conteudo)

	_linha_horda()
	_linha_armas()
	_linha_mobs()
	_linha_acoes()

	_status = UI.rotulo("Pronto.", 13, UI.COR_TEXTO_FRACO)
	_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	centro.add_child(_status)
	var b_fechar: Button = UI.botao("FECHAR  [Shift+P]", 18, UI.COR_CIANO)
	b_fechar.custom_minimum_size = Vector2(260, 44)
	b_fechar.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	b_fechar.pressed.connect(func() -> void: fechar_solicitado.emit())
	centro.add_child(b_fechar)


func _secao(texto: String) -> void:
	_conteudo.add_child(UI.rotulo(texto, 15, UI.COR_CIANO))


func _linha_horda() -> void:
	_secao("PROGRESSÃO DE FASE")
	var linha: HBoxContainer = HBoxContainer.new()
	linha.add_theme_constant_override("separation", 10)
	_conteudo.add_child(linha)
	linha.add_child(UI.rotulo("Horda:", 15, UI.COR_TEXTO))
	_seletor_horda = SpinBox.new()
	_seletor_horda.min_value = 1.0
	_seletor_horda.max_value = float(GlobalManager.HORDA_MAXIMA)
	_seletor_horda.step = 1.0
	_seletor_horda.value = float(GlobalManager.horda_atual)
	_seletor_horda.custom_minimum_size = Vector2(110, 0)
	linha.add_child(_seletor_horda)
	var b: Button = UI.botao("IR PARA HORDA", 15, UI.COR_AMBAR)
	b.custom_minimum_size = Vector2(190, 40)
	b.pressed.connect(_ao_ir_horda)
	linha.add_child(b)
	linha.add_child(UI.rotulo("Fase atual: %d" % GlobalManager.fase, 14, UI.COR_TEXTO_FRACO))


func _linha_armas() -> void:
	_secao("ARSENAL — EQUIPAR QUALQUER ARMA")
	var grade: GridContainer = GridContainer.new()
	grade.columns = 3
	grade.add_theme_constant_override("h_separation", 8)
	grade.add_theme_constant_override("v_separation", 8)
	_conteudo.add_child(grade)
	for arma: DadosArma in _armas_disponiveis():
		var equipada: bool = GlobalManager.arma_equipada == arma.id
		var b: Button = UI.botao("%s (%s)%s" % [arma.nome.to_upper(), arma.elemento, "  •" if equipada else ""], 14, arma.cor)
		b.custom_minimum_size = Vector2(230, 40)
		b.disabled = equipada
		b.pressed.connect(_ao_equipar.bind(arma.id))
		grade.add_child(b)


func _linha_mobs() -> void:
	_secao("ENXAME — SPAWNAR QUALQUER MOB")
	var linha: HBoxContainer = HBoxContainer.new()
	linha.add_theme_constant_override("separation", 10)
	_conteudo.add_child(linha)
	_seletor_mob = OptionButton.new()
	_seletor_mob.custom_minimum_size = Vector2(300, 40)
	_seletor_mob.add_theme_font_size_override("font_size", 14)
	for d: DadosInimigo in _mobs:
		_seletor_mob.add_item("%s (%s)%s" % [d.nome, d.elemento, "  [BOSS]" if d.is_boss else ""])
	linha.add_child(_seletor_mob)
	var b_spawn: Button = UI.botao("SPAWNAR", 15, UI.COR_VERDE)
	b_spawn.custom_minimum_size = Vector2(150, 40)
	b_spawn.pressed.connect(_ao_spawnar)
	linha.add_child(b_spawn)
	var b_matar: Button = UI.botao("MATAR TODOS", 15, UI.COR_VERMELHO)
	b_matar.custom_minimum_size = Vector2(170, 40)
	b_matar.pressed.connect(_ao_matar_todos)
	linha.add_child(b_matar)


func _linha_acoes() -> void:
	var linha: HBoxContainer = HBoxContainer.new()
	linha.add_theme_constant_override("separation", 10)
	_conteudo.add_child(linha)
	var b_vida: Button = UI.botao("CURAR TUDO", 14, UI.COR_VERDE)
	b_vida.custom_minimum_size = Vector2(150, 38)
	b_vida.pressed.connect(_ao_curar)
	linha.add_child(b_vida)


func _armas_disponiveis() -> Array[DadosArma]:
	var lista: Array[DadosArma] = []
	var dir: DirAccess = DirAccess.open(PASTA_ARMAS)
	if dir == null:
		return lista
	dir.list_dir_begin()
	var arquivo: String = dir.get_next()
	while arquivo != "":
		if arquivo.ends_with(".tres"):
			var rec: Resource = load(PASTA_ARMAS.path_join(arquivo))
			if rec is DadosArma:
				lista.append(rec as DadosArma)
		arquivo = dir.get_next()
	dir.list_dir_end()
	lista.sort_custom(func(a: DadosArma, b: DadosArma) -> bool: return a.custo < b.custo)
	return lista


func _ao_ir_horda() -> void:
	if _spawn == null or not is_instance_valid(_spawn):
		_status.text = "Sem gerenciador de hordas na cena."
		return
	var alvo: int = int(_seletor_horda.value)
	if _spawn.definir_horda(alvo):
		_status.text = "Horda %d iniciada (fase %d)." % [alvo, GlobalManager.fase]
		AudioManager.tocar_sfx("horda", -6.0, 0.05)
	else:
		_status.text = "Não foi possível iniciar a horda."


func _ao_equipar(id: String) -> void:
	if not GlobalManager.armas_desbloqueadas.has(id):
		GlobalManager.armas_desbloqueadas.append(id)
	if GlobalManager.equipar_arma(id):
		if _jogador != null and is_instance_valid(_jogador):
			_jogador.atualizar_arma()
		_status.text = "Arma equipada: %s." % id.to_upper()
		AudioManager.tocar_sfx("clique", -6.0, 0.03)
		_reconstruir()


func _ao_spawnar() -> void:
	if _spawn == null or _mobs.is_empty():
		_status.text = "Catálogo de inimigos vazio."
		return
	var indice: int = clampi(_seletor_mob.selected, 0, _mobs.size() - 1)
	var d: DadosInimigo = _mobs[indice]
	if _spawn.spawnar_por_id(d.id) != null:
		_status.text = "%s invocado na arena." % d.nome
	else:
		_status.text = "Falha ao invocar %s." % d.nome


func _ao_matar_todos() -> void:
	if _spawn == null:
		return
	var total: int = _spawn.matar_todos()
	_status.text = "%d inimigo(s) eliminado(s)." % total
	AudioManager.tocar_sfx("explosao", -6.0, 0.06)


func _ao_curar() -> void:
	if _jogador != null and is_instance_valid(_jogador):
		_jogador.curar(_jogador.vida_maxima)
		_status.text = "Vida restaurada."
