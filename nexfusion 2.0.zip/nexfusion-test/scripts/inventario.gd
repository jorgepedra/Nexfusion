class_name TelaInventario
extends Control
## Inventário + Caderno de Registros (aba de cartas de habilidade e bestiário).
## Aberto com TAB durante a partida; mostra o que já foi descoberto/coletado.

signal fechar_solicitado

const PASTA_CARTAS: String = "res://resources/cartas_roguelite"
const PASTA_INIMIGOS: String = "res://resources/inimigos"

var _cartas: Array[CartaRoguelite] = []
var _inimigos: Array[DadosInimigo] = []
var _aba: String = "cartas"
var _lista: VBoxContainer
var _detalhe: RichTextLabel
var _retrato: TextureRect
var _contador: Label
var _abas: HBoxContainer


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false
	_carregar()
	_construir()


func _carregar() -> void:
	_cartas.clear()
	_inimigos.clear()
	_carregar_pasta(PASTA_CARTAS, _cartas)
	_carregar_pasta(PASTA_INIMIGOS, _inimigos)
	_cartas.sort_custom(func(a: CartaRoguelite, b: CartaRoguelite) -> bool: return a.id < b.id)
	_inimigos.sort_custom(func(a: DadosInimigo, b: DadosInimigo) -> bool: return a.horda_minima < b.horda_minima)


func _carregar_pasta(caminho: String, destino: Array) -> void:
	var dir: DirAccess = DirAccess.open(caminho)
	if dir == null:
		return
	dir.list_dir_begin()
	var arquivo: String = dir.get_next()
	while arquivo != "":
		if arquivo.ends_with(".tres"):
			var rec: Resource = load(caminho.path_join(arquivo))
			if rec != null:
				destino.append(rec)
		arquivo = dir.get_next()
	dir.list_dir_end()


func _construir() -> void:
	var fundo: ColorRect = ColorRect.new()
	fundo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fundo.color = Color(0.02, 0.03, 0.05, 0.9)
	add_child(fundo)
	var margem: MarginContainer = MarginContainer.new()
	margem.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margem.add_theme_constant_override("margin_left", 70)
	margem.add_theme_constant_override("margin_right", 70)
	margem.add_theme_constant_override("margin_top", 30)
	margem.add_theme_constant_override("margin_bottom", 30)
	add_child(margem)
	var principal: VBoxContainer = VBoxContainer.new()
	principal.add_theme_constant_override("separation", 10)
	margem.add_child(principal)
	var topo: HBoxContainer = HBoxContainer.new()
	principal.add_child(topo)
	var titulo: Label = UI.titulo("INVENTÁRIO", 38, UI.COR_CIANO)
	titulo.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	topo.add_child(titulo)
	var espaco: Control = Control.new()
	espaco.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	topo.add_child(espaco)
	var b_fechar: Button = UI.botao("FECHAR  [TAB]", 16, UI.COR_TEXTO_FRACO)
	b_fechar.custom_minimum_size = Vector2(180, 42)
	b_fechar.pressed.connect(func() -> void: fechar_solicitado.emit())
	topo.add_child(b_fechar)
	_abas = HBoxContainer.new()
	_abas.add_theme_constant_override("separation", 10)
	principal.add_child(_abas)
	var b_cartas: Button = UI.botao("CADERNO DE CARTAS", 16, UI.COR_MAGENTA)
	b_cartas.custom_minimum_size = Vector2(240, 40)
	b_cartas.pressed.connect(_ao_aba.bind("cartas"))
	_abas.add_child(b_cartas)
	var b_inimigos: Button = UI.botao("BESTIÁRIO", 16, UI.COR_VERDE)
	b_inimigos.custom_minimum_size = Vector2(200, 40)
	b_inimigos.pressed.connect(_ao_aba.bind("inimigos"))
	_abas.add_child(b_inimigos)
	_contador = UI.rotulo("", 14, UI.COR_TEXTO_FRACO)
	_abas.add_child(_contador)
	var corpo: HBoxContainer = HBoxContainer.new()
	corpo.size_flags_vertical = Control.SIZE_EXPAND_FILL
	corpo.add_theme_constant_override("separation", 16)
	principal.add_child(corpo)
	var rolagem: ScrollContainer = ScrollContainer.new()
	rolagem.custom_minimum_size = Vector2(430, 0)
	rolagem.size_flags_vertical = Control.SIZE_EXPAND_FILL
	rolagem.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	corpo.add_child(rolagem)
	_lista = VBoxContainer.new()
	_lista.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_lista.add_theme_constant_override("separation", 6)
	rolagem.add_child(_lista)
	var painel: PanelContainer = PanelContainer.new()
	painel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	painel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	painel.add_theme_stylebox_override("panel", UI.estilo_painel(Color(0.06, 0.09, 0.13, 0.95), UI.COR_BORDA, 6))
	corpo.add_child(painel)
	var painel_vb: VBoxContainer = VBoxContainer.new()
	painel_vb.add_theme_constant_override("separation", 6)
	painel.add_child(painel_vb)
	_retrato = TextureRect.new()
	_retrato.custom_minimum_size = Vector2(190, 190)
	_retrato.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_retrato.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_retrato.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_retrato.visible = false
	painel_vb.add_child(_retrato)
	_detalhe = RichTextLabel.new()
	_detalhe.bbcode_enabled = true
	_detalhe.fit_content = false
	_detalhe.scroll_active = true
	_detalhe.add_theme_font_size_override("normal_font_size", 15)
	_detalhe.add_theme_font_size_override("bold_font_size", 20)
	_detalhe.size_flags_vertical = Control.SIZE_EXPAND_FILL
	painel_vb.add_child(_detalhe)


func abrir() -> void:
	visible = true
	_reconstruir()
	modulate.a = 0.0
	var tw: Tween = create_tween()
	tw.tween_property(self, "modulate:a", 1.0, 0.16)


func fechar() -> void:
	visible = false


func _unhandled_input(evento: InputEvent) -> void:
	if not visible:
		return
	var tecla: InputEventKey = evento as InputEventKey
	if tecla == null or not tecla.pressed or tecla.echo:
		return
	var codigo: int = tecla.physical_keycode if tecla.physical_keycode != 0 else tecla.keycode
	if codigo == KEY_TAB or codigo == KEY_ESCAPE:
		fechar_solicitado.emit()
		get_viewport().set_input_as_handled()


func _ao_aba(aba: String) -> void:
	_aba = aba
	_reconstruir()


func _reconstruir() -> void:
	for filho: Node in _lista.get_children():
		filho.queue_free()
	_detalhe.text = "[color=#8899b0]Selecione um registro à esquerda.[/color]"
	_retrato.texture = null
	_retrato.visible = false
	if _aba == "cartas":
		var achadas: int = 0
		for c: CartaRoguelite in _cartas:
			if GlobalManager.cartas_descobertas.has(c.id):
				achadas += 1
		_contador.text = "Cartas registradas: %d/%d  ·  nesta tentativa: %d" % [achadas, _cartas.size(), GlobalManager.cartas_coletadas.size()]
		for c: CartaRoguelite in _cartas:
			_lista.add_child(_botao_carta(c))
	else:
		var vistos: int = 0
		for d: DadosInimigo in _inimigos:
			if GlobalManager.inimigos_descobertos.has(d.id):
				vistos += 1
		_contador.text = "Espécies registradas: %d/%d" % [vistos, _inimigos.size()]
		for d: DadosInimigo in _inimigos:
			_lista.add_child(_botao_inimigo(d))


func _botao_carta(c: CartaRoguelite) -> Control:
	var conhecida: bool = GlobalManager.cartas_descobertas.has(c.id)
	var cor: Color = UI.cor_raridade(c.raridade) if conhecida else Color(0.35, 0.4, 0.48)
	var b: Button = UI.botao(("%s  %s" % [c.simbolo, c.nome]) if conhecida else "???  CARTA NÃO REGISTRADA", 14, cor)
	b.custom_minimum_size = Vector2(410, 42)
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.add_theme_constant_override("icon_max_width", 26)
	if conhecida:
		b.icon = _icone("res://sprites/cartas/%s.png" % c.id)
		b.pressed.connect(_ao_ver_carta.bind(c))
	return b


func _botao_inimigo(d: DadosInimigo) -> Control:
	var visto: bool = GlobalManager.inimigos_descobertos.has(d.id)
	var b: Button = UI.botao(("%s  (%s)" % [d.nome, d.elemento]) if visto else "???  ESPÉCIE DESCONHECIDA", 14, d.cor if visto else Color(0.35, 0.4, 0.48))
	b.custom_minimum_size = Vector2(410, 44)
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.add_theme_constant_override("icon_max_width", 30)
	if visto:
		b.icon = _icone(d.textura)
		b.pressed.connect(_ao_ver_inimigo.bind(d))
	return b


func _icone(caminho: String) -> Texture2D:
	if caminho == "" or not ResourceLoader.exists(caminho):
		return null
	return load(caminho) as Texture2D


func _ao_ver_carta(c: CartaRoguelite) -> void:
	var cor: Color = UI.cor_raridade(c.raridade)
	_retrato.texture = _icone("res://sprites/cartas/%s.png" % c.id)
	_retrato.visible = _retrato.texture != null
	_detalhe.text = "[b][color=#%s]%s[/color][/b]\n[color=#8899b0]%s · %s[/color]\n\n%s\n\n[color=#8899b0]Atributo: %s (+%.2f)[/color]" % [
		cor.to_html(false), c.nome, c.simbolo, String(c.raridade).to_upper(),
		c.descricao, c.atributo, c.valor,
	]


func _ao_ver_inimigo(d: DadosInimigo) -> void:
	_retrato.texture = _icone(d.textura)
	_retrato.visible = _retrato.texture != null
	_detalhe.text = "[b][color=#%s]%s[/color][/b]\n[color=#8899b0]Elemento %s · horda %d+[/color]\n\n%s\n\n[b]Vida base:[/b] %.0f\n[b]Dano de contato:[/b] %.0f\n[b]Velocidade:[/b] %.0f\n[b]Comportamento:[/b] %s\n[b]Recompensa:[/b] %d pontos, %d moeda(s), %d XP" % [
		Color(d.cor).to_html(false), d.nome, d.elemento if d.elemento != "" else "—", d.horda_minima,
		"Chefe de fase — padrões próprios e fúria." if d.is_boss else "Espécie comum do enxame químico.",
		d.vida, d.dano_contato, d.velocidade, d.comportamento, d.pontos, d.moedas, d.xp_drop,
	]
