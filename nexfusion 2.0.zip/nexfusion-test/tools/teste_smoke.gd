extends Node
## Harness temporário de verificação (headless). Executa o jogo real e valida
## combate, divisão do slime, parry de granada, level up, hordas e save.

var falhas: int = 0
var _jogo: Node2D
var _player: Player
var _spawn: SpawnManager
var _hud: HUD


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	await get_tree().process_frame
	await _rodar()
	print("=== RESULTADO: %d falha(s) ===" % falhas)
	get_tree().quit(1 if falhas > 0 else 0)


func _contar_manchas() -> int:
	var total: int = 0
	for n: Node in _jogo.get_node("Mundo").get_children():
		if n is Efeitos.Mancha:
			total += 1
	return total


func _ok(cond: bool, nome: String) -> void:
	if cond:
		print("[OK] ", nome)
	else:
		falhas += 1
		printerr("[FALHA] ", nome)


func _rodar() -> void:
	_jogo = load("res://scenes/jogo.tscn").instantiate() as Node2D
	add_child(_jogo)
	await get_tree().process_frame
	await get_tree().process_frame

	_player = _jogo.get_node_or_null("Mundo/Player") as Player
	_spawn = _jogo.get_node_or_null("SpawnManager") as SpawnManager
	_hud = _jogo.get_node_or_null("HUD") as HUD
	_ok(_player != null, "jogador instanciado")
	_ok(_spawn != null and _spawn._catalogo.size() >= 9, "catálogo de inimigos carregado (%d)" % (_spawn._catalogo.size() if _spawn != null else 0))
	_ok(_hud != null, "HUD instanciado")
	_ok(GlobalManager.partida_ativa and GlobalManager.horda_atual == 1, "partida iniciada na horda 1")
	_ok(AudioManager._musica_atual == "calmo" and AudioManager._bgm_cache.has("jogo"), "trilha calma sem inimigos e trilha de combate pronta")
	_ok(_player.vida == _player.vida_maxima and _player.dash_cargas == 3, "vida e cargas de dash iniciais")

	# ---------- arte: folhas de animação, cartas e decoração
	_ok(ResourceLoader.exists("res://sprites/player/player_sheet.png"), "folha de animação do jogador")
	_ok(_player.animador != null and _player.animador.sprite == _player.corpo and _player.animador._folha != null, "jogador com animador ativo")
	var folhas_ok: int = 0
	for d: DadosInimigo in _spawn._catalogo:
		if ResourceLoader.exists(d.textura.get_basename() + "_sheet.png"):
			folhas_ok += 1
	_ok(folhas_ok == _spawn._catalogo.size(), "folhas de animação de todos os inimigos (%d/%d)" % [folhas_ok, _spawn._catalogo.size()])
	var tipos_particula: Array[String] = ["faisca", "fumaca", "acido", "fogo", "plasma", "sangue", "estrela", "bolha"]
	var particulas_ok: int = 0
	for tipo: String in tipos_particula:
		if ResourceLoader.exists("res://sprites/particulas/%s.png" % tipo):
			particulas_ok += 1
	_ok(particulas_ok == tipos_particula.size(), "sprites de partículas por tipo (%d/%d)" % [particulas_ok, tipos_particula.size()])
	_ok(ResourceLoader.exists("res://sprites/NPC/mercante.png"), "sprite do mercador existe")
	var cartas_ok: int = 0
	var cartas_total: int = 0
	var dir_cartas: DirAccess = DirAccess.open("res://resources/cartas_roguelite")
	if dir_cartas != null:
		dir_cartas.list_dir_begin()
		var arq: String = dir_cartas.get_next()
		while arq != "":
			if arq.ends_with(".tres"):
				cartas_total += 1
				var c: CartaRoguelite = load("res://resources/cartas_roguelite/" + arq) as CartaRoguelite
				if c != null and ResourceLoader.exists("res://sprites/cartas/%s.png" % c.id):
					cartas_ok += 1
			arq = dir_cartas.get_next()
		dir_cartas.list_dir_end()
	_ok(cartas_total > 0 and cartas_ok == cartas_total, "sprites de todas as cartas (%d/%d)" % [cartas_ok, cartas_total])
	var props_lab: int = get_tree().get_nodes_in_group("lab_props").size()
	_ok(props_lab >= 6, "arena de laboratório com estruturas fixas (%d)" % props_lab)
	var decoracoes_antigas: int = 0
	for n: Node in _jogo.get_children():
		var s: Sprite2D = n as Sprite2D
		if s != null and s.texture != null and s.texture.resource_path.contains("/map/deco_"):
			decoracoes_antigas += 1
	_ok(decoracoes_antigas == 0, "decorações antigas removidas da arena")
	# ---------- qualidade gráfica, apelido, skins e carta de ressurreição
	var qualidade_antes: int = GlobalManager.qualidade
	GlobalManager.definir_qualidade(0)
	_ok(GlobalManager.particulas_reduzidas() and not GlobalManager.animar_inimigos(), "qualidade leve reduz partículas e anima só o jogador")
	GlobalManager.definir_qualidade(2)
	_ok(GlobalManager.luzes_ativas(), "qualidade pesada ativa luz e sombras")
	GlobalManager.definir_qualidade(qualidade_antes)
	var nick_antes: String = GlobalManager.nick
	GlobalManager.definir_nick("teste")
	_ok(GlobalManager.nick == "TESTE", "apelido é normalizado e salvo")
	GlobalManager.definir_nick(nick_antes)
	var skin_antes: int = GlobalManager.skin_player
	GlobalManager.definir_skin_player(1)
	_ok(GlobalManager.nome_skin_player() == "MAGENTA", "skin do jogador pode ser trocada")
	GlobalManager.definir_skin_player(skin_antes)
	var controles: ControlesMoveis = ControlesMoveis.new()
	add_child(controles)
	await get_tree().process_frame
	_ok(controles.is_in_group("mobile_controls"), "controles mobile são criados")
	controles.queue_free()
	var carta_rev: CartaRoguelite = load("res://resources/cartas_roguelite/carta_ressureicao.tres") as CartaRoguelite
	_ok(carta_rev != null and carta_rev.atributo == "ressurreicao" and ResourceLoader.exists("res://sprites/cartas/carta_ressureicao.png"), "carta de ressurreição existe com arte")
	GlobalManager.cargas_ressurreicao = 0
	_player.aplicar_carta(carta_rev)
	_ok(GlobalManager.cargas_ressurreicao == 1, "carta concede carga de ressurreição (LAN)")
	GlobalManager.cargas_ressurreicao = 0

	_player._recuo(2.0)
	_ok(_player.animador != null and _player.animador._estado == "ataque", "animação de ataque dispara")
	# ---------- tiro e dano
	var dados_h: DadosInimigo = load("res://resources/inimigos/hidrogenio.tres") as DadosInimigo
	var alvo: Enemy = _spawn._instanciar(dados_h, _player.global_position + Vector2(200, 0))
	_ok(alvo != null, "inimigo básico spawnado")
	if alvo != null:
		GlobalManager.modo_mobile = true
		_ok(_player.mira_local().distance_to(alvo.global_position) < 60.0, "mira automática no modo mobile")
		GlobalManager.modo_mobile = false
	var vida_antes: float = alvo.vida
	_player.arma_pivot.rotation = 0.0
	_player._disparar(Vector2.RIGHT, 12.0, GlobalManager.arma_atual(), false)
	# Aguarda quadros de física reais (o projétil e o inimigo são simulados neles).
	for _i: int in range(24):
		await get_tree().physics_frame
	var ainda_vivo: bool = is_instance_valid(alvo) and not alvo.morto
	_ok((not ainda_vivo) or alvo.vida < vida_antes, "projétil causa dano/elimina inimigo")
	if is_instance_valid(alvo):
		_ok(alvo.animador != null and alvo.animador._folha != null, "inimigo com animador ativo")
		alvo.receber_dano(1.0)
		_ok(alvo.animador != null and alvo.animador._estado == "dano", "animação de dano dispara")
		var limite_dano: int = Time.get_ticks_msec() + 700
		while Time.get_ticks_msec() < limite_dano:
			await get_tree().process_frame
		_ok(not is_instance_valid(alvo) or alvo.animador == null or alvo.animador._estado != "dano", "animação de dano volta ao normal")

	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		if is_instance_valid(n):
			n.queue_free()
	await get_tree().process_frame

	# ---------- moeda / ricochete (marksman)
	var moeda: MoedaAr = load("res://scenes/moeda_ar.tscn").instantiate() as MoedaAr
	_jogo.get_node("Mundo").add_child(moeda)
	moeda.configurar(_player.global_position, Vector2.RIGHT)
	await get_tree().create_timer(0.5, true, false, true).timeout
	var alvo_r: Enemy = _spawn._instanciar(dados_h, _player.global_position + Vector2(520, -60))
	var direcao_moeda: Vector2 = (moeda.global_position - _player.muzzle.global_position).normalized()
	_player._disparar(direcao_moeda, 20.0, GlobalManager.arma_atual(), false)
	await get_tree().create_timer(0.8, true, false, true).timeout
	_ok(not is_instance_valid(moeda), "tiro acerta a moeda no ar")
	_ok((not is_instance_valid(alvo_r)) or alvo_r.morto or alvo_r.vida < alvo_r.vida_max, "ricochete redireciona ao inimigo mais próximo")
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		if is_instance_valid(n):
			n.queue_free()
	await get_tree().process_frame

	# ---------- slime divisor 1 -> 2 -> 4
	var dados_s: DadosInimigo = load("res://resources/inimigos/slime_quimico.tres") as DadosInimigo
	var grande: EnemySlime = load("res://scenes/slime.tscn").instantiate() as EnemySlime
	_jogo.get_node("Mundo").add_child(grande)
	grande.configurar(dados_s, 3)
	grande.global_position = Vector2(300, 300)
	await get_tree().process_frame
	grande.receber_dano(99999.0)
	await get_tree().process_frame
	await get_tree().create_timer(0.25, true, false, true).timeout
	# conta apenas os slimes médios (o spawner comum também está ativo na arena)
	var medios: Array[Node] = []
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		if n is EnemySlime and (n as EnemySlime).estagio == 1:
			medios.append(n)
	_ok(medios.size() == 2, "slime grande divide em 2 médios (obtido %d)" % medios.size())
	for m: Node in medios:
		(m as Enemy).receber_dano(99999.0)
	await get_tree().process_frame
	var pequenos: int = 0
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		if n is EnemySlime and (n as EnemySlime).estagio == 2:
			pequenos += 1
	_ok(pequenos == 4, "slimes médios dividem em 4 pequenos (obtido %d)" % pequenos)
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		if is_instance_valid(n):
			n.queue_free()
	await get_tree().process_frame

	# ---------- granada rebatida
	var g: GranadaInimiga = load("res://scenes/granada_inimiga.tscn").instantiate() as GranadaInimiga
	_jogo.get_node("Mundo").add_child(g)
	g.configurar(_player.global_position, _player.global_position + Vector2(100, 0), 80.0, 15.0, null)
	var dano_antes: float = g.dano
	g.rebater(Vector2.RIGHT)
	_ok(g.refletida and g.dano > dano_antes, "parry rebate granada e multiplica o dano")
	await get_tree().create_timer(0.1, true, false, true).timeout

	# ---------- estilo / rank
	GlobalManager.registrar_estilo("TESTE", 200.0)
	_ok(GlobalManager.rank_estilo != "D" and GlobalManager.multiplicador_estilo > 1.0, "rank de estilo sobe (%s x%.2f)" % [GlobalManager.rank_estilo, GlobalManager.multiplicador_estilo])
	GlobalManager.registrar_abate(10)
	GlobalManager.registrar_abate(10)
	_ok(GlobalManager.combo_contagem >= 2, "combo registra abates consecutivos")
	GlobalManager.sofrer_dano_penalidade()
	_ok(GlobalManager.combo_contagem == 0, "dano encerra o combo e penaliza o estilo")

	# ---------- level up / cartas
	var nivel_antes: int = GlobalManager.nivel_run
	GlobalManager.adicionar_xp(GlobalManager.xp_necessario)
	await get_tree().process_frame
	_ok(GlobalManager.nivel_run == nivel_antes + 1, "XP sobe de nível")
	_ok(get_tree().paused and _hud._ov.visible, "overlay de level up abre e pausa a partida")
	_ok(_hud._ov._oferecidas.size() == 3, "três cartas são oferecidas")
	var dano_bonus_antes: float = _player.bonus_dano + _player.bonus_cadencia
	_hud._ov._ao_clicar(_hud._ov._oferecidas[0])
	await get_tree().process_frame
	_ok(not get_tree().paused and not _hud._ov.visible, "carta aplicada e partida retomada")
	var dano_bonus_depois: float = _player.bonus_dano + _player.bonus_cadencia + float(_player.projeteis_extra) + _player.critico_extra + _player.aura_dano + _player.velocidade + _player.cura_extra + _player.magnetismo_extra + float(_player.perfuracao_extra) + float(_player.cadeia_extra) + float(_player.ricochete_extra) + _player.area_explosao_extra + _player.dash_bonus + _player.vida_maxima
	_ok(dano_bonus_depois != dano_bonus_antes, "efeito da carta altera o jogador")

	# ---------- hordas e chefe
	var horda_antes: int = GlobalManager.horda_atual
	GlobalManager.concluir_horda()
	_ok(GlobalManager.horda_atual == horda_antes + 1, "horda avança ao limpar a arena")
	_spawn._iniciar_horda(10)
	await get_tree().create_timer(2.0, true, false, true).timeout
	var achou_chefe: bool = false
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		if n is Boss:
			achou_chefe = true
	_ok(achou_chefe, "chefe surge na horda 10")
	_ok(AudioManager._musica_atual == "chefe", "tema de chefe entra na batalha")
	_ok(AudioManager._bgm_cache.has("chefe"), "tema de chefe sintetizado/carregado")
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		if is_instance_valid(n):
			n.queue_free()
	await get_tree().process_frame

	# ---------- Painel de Desenvolvedor (Shift+P)
	_spawn._iniciar_horda(3)
	var ev_dev: InputEventKey = InputEventKey.new()
	ev_dev.physical_keycode = KEY_P
	ev_dev.shift_pressed = true
	ev_dev.pressed = true
	var horda_antes_dev: int = GlobalManager.horda_atual
	_jogo._unhandled_input(ev_dev)
	await get_tree().process_frame
	_ok(_hud._dev != null and _hud._dev.visible and get_tree().paused, "Shift+P abre o painel de dev (não pula horda)")
	_ok(GlobalManager.horda_atual == horda_antes_dev, "Shift+P não altera a horda sozinho")
	_ok(_hud._dev._seletor_horda != null and _hud._dev._seletor_mob != null, "painel tem seletor de horda e de mob")
	_hud._dev._seletor_horda.value = 7.0
	_hud._dev._ao_ir_horda()
	_ok(GlobalManager.horda_atual == 7, "painel pula para a horda escolhida")
	_hud._dev._ao_equipar("neonio")
	_ok(GlobalManager.arma_equipada == "neonio", "painel equipa qualquer arma")
	_hud._dev._seletor_mob.selected = 0
	_hud._dev._ao_spawnar()
	await get_tree().process_frame
	var mortos_dev: int = _spawn.matar_todos()
	_ok(mortos_dev >= 1, "painel spawna e mata todos os mobs (%d)" % mortos_dev)
	_jogo._unhandled_input(ev_dev)
	await get_tree().process_frame
	_ok(not _hud._dev.visible and not get_tree().paused, "Shift+P fecha o painel")
	GlobalManager.equipar_arma("tungstenio")
	_player.atualizar_arma()

	# ---------- armas: secundário único e sem upgrade de dano
	_ok(not GlobalManager.UPGRADES.has("dano"), "upgrade de força das armas removido")
	_ok(not ResourceLoader.exists("res://resources/loja/upgrade_dano.tres"), "item de upgrade de dano removido da loja")
	for id_arma: String in ["tungstenio", "helio", "ferro", "litio", "neonio", "mercurio"]:
		GlobalManager.equipar_arma(id_arma)
		_player.atualizar_arma()
		_player._cooldown_secundario = 0.0
		_player._usar_secundario()
		_ok(_player._cooldown_secundario > 0.0, "secundário próprio de %s dispara" % id_arma)
	GlobalManager.equipar_arma("tungstenio")
	_player.atualizar_arma()

	# ---------- limites do mapa
	_player.global_position = Vector2(-900.0, -900.0)
	await get_tree().physics_frame
	await get_tree().physics_frame
	_ok(_player.global_position.distance_to(Vector2(1200.0, 750.0)) < 400.0, "jogador fora do mapa volta ao centro")
	var e_fora: Enemy = _spawn._instanciar(dados_h, Vector2(1200.0, 750.0))
	await get_tree().process_frame
	e_fora.global_position = Vector2(9000.0, 9000.0)
	await get_tree().physics_frame
	await get_tree().physics_frame
	_ok(e_fora.global_position.distance_to(Vector2(1200.0, 750.0)) < 500.0, "inimigo fora do mapa volta ao centro")
	e_fora.queue_free()
	await get_tree().process_frame

	# ---------- mancha de morte no chão
	var manchas_antes: int = _contar_manchas()
	var e_mancha: Enemy = _spawn._instanciar(dados_h, _player.global_position + Vector2(140.0, 0.0))
	await get_tree().process_frame
	e_mancha.receber_dano(99999.0)
	await get_tree().process_frame
	_ok(_contar_manchas() > manchas_antes, "inimigo morto deixa mancha no chão")

	# ---------- inventário / caderno de registros
	_hud.alternar_inventario()
	await get_tree().process_frame
	_ok(_hud._inventario.visible and get_tree().paused, "TAB abre o inventário")
	_ok(_hud._inventario._cartas.size() >= 18 and _hud._inventario._inimigos.size() >= 9, "caderno lista cartas (%d) e inimigos (%d)" % [_hud._inventario._cartas.size(), _hud._inventario._inimigos.size()])
	_hud._inventario._ao_aba("inimigos")
	_ok(GlobalManager.inimigos_descobertos.size() >= 2, "bestiário registra espécies encontradas")
	_hud.alternar_inventario()
	await get_tree().process_frame
	_ok(not _hud._inventario.visible and not get_tree().paused, "inventário fecha")

	# ---------- LAN
	_ok(NetworkManager != null, "NetworkManager carregado")
	if NetworkManager.criar_sala(7891):
		_ok(NetworkManager.modo == "host", "sala LAN criada (host)")
		_ok(NetworkManager.MAX_CLIENTES == 3, "sala LAN aceita até 4 jogadores")
		var achou_host: Array = [false]
		var ao_achar: Callable = func(_endereco: String, porta_host: int) -> void: achou_host[0] = porta_host == 7891
		NetworkManager.host_encontrado.connect(ao_achar)
		NetworkManager.procurar_host(7891)
		for _i: int in range(120):
			await get_tree().process_frame
			if bool(achou_host[0]):
				break
		_ok(bool(achou_host[0]), "cliente encontra o host automaticamente pela porta")
		NetworkManager.host_encontrado.disconnect(ao_achar)
		NetworkManager._encerrar_busca()
		var remoto: Player = _jogo.criar_jogador_remoto(99)
		_ok(remoto != null and remoto.remoto and not remoto.camera.enabled, "host cria jogador remoto sem câmera")
		var sm_rede: Node = get_tree().get_first_node_in_group("spawn_manager")
		_ok(sm_rede != null and int(sm_rede.call("_total_jogadores")) >= 2, "escalonamento conta os jogadores da partida")
		if remoto != null:
			remoto.queue_free()
		await get_tree().process_frame
		NetworkManager.sair()
		_ok(NetworkManager.modo == "off", "sala LAN encerrada")
	else:
		_ok(false, "sala LAN criada (host)")

	# ---------- 3 slots de save
	_ok(GlobalManager.SLOTS_SAVE == 3, "existem 3 slots de save")
	var slot_origem: int = GlobalManager.slot_ativo
	var existia_2: bool = bool(GlobalManager.info_slot(2)["existe"])
	var existia_3: bool = bool(GlobalManager.info_slot(3)["existe"])
	GlobalManager.definir_slot(2)
	GlobalManager.moedas = 4321
	GlobalManager.salvar()
	GlobalManager.definir_slot(3)
	var moedas_slot3: int = GlobalManager.moedas
	GlobalManager.definir_slot(2)
	_ok(GlobalManager.moedas == 4321, "slots de save são independentes")
	_ok(moedas_slot3 != 4321 or GlobalManager.slot_ativo == 2, "slot 3 não herdou o slot 2")
	if not existia_2:
		DirAccess.remove_absolute(ProjectSettings.globalize_path(GlobalManager.caminho_save(2)))
	if not existia_3:
		DirAccess.remove_absolute(ProjectSettings.globalize_path(GlobalManager.caminho_save(3)))
	GlobalManager.definir_slot(slot_origem)

	_spawn._iniciar_horda(4)

	# ---------- chefe final (horda 31)
	_ok(GlobalManager.HORDA_MAXIMA == 31, "horda máxima é a 31 (chefe final)")
	_ok(not _hud._pausa.has_signal("pular_horda_solicitado"), "menu de pausa não oferece pular horda")
	var dados_final: DadosInimigo = load("res://resources/inimigos/elemento_supremo.tres") as DadosInimigo
	_ok(dados_final != null and dados_final.ordem_chefe == 4, "catálogo tem o chefe final (ordem 4)")
	_ok(_spawn._eh_horda_chefe(31), "horda 31 é marcada como horda de chefe")
	var chefe_final: ChefeFinal = load("res://scenes/chefe_final.tscn").instantiate() as ChefeFinal
	_jogo.get_node("Mundo").add_child(chefe_final)
	chefe_final.configurar(dados_final, 31)
	chefe_final.global_position = Vector2(1200, -260)
	await get_tree().process_frame
	_ok(chefe_final._chegando, "chefe final começa em cutscene de chegada")
	var vida_chegada: float = chefe_final.vida
	chefe_final.receber_dano(500.0)
	_ok(is_equal_approx(chefe_final.vida, vida_chegada), "chefe final é intocável durante a chegada")
	chefe_final._chegando = false
	chefe_final.receber_dano(200.0)
	_ok(chefe_final.vida < vida_chegada, "chefe sem proteção toma dano reduzido na fase 1")
	chefe_final._montar_protecao()
	await get_tree().process_frame
	_ok(chefe_final._guardioes.size() == 4, "quatro guardiões protegem o chefe nos cantos")
	_ok(not chefe_final._guardioes[0].is_in_group("inimigos"), "guardiões não são inimigos comuns")
	_ok(chefe_final._guardioes[0].is_in_group("guardioes_final"), "guardiões têm grupo próprio")
	var vida_protegida: float = chefe_final.vida
	chefe_final.receber_dano(400.0)
	_ok(is_equal_approx(chefe_final.vida, vida_protegida), "com guardiões vivos o chefe não toma dano")
	for guardiao: Enemy in chefe_final._guardioes:
		if is_instance_valid(guardiao):
			guardiao.receber_dano(99999.0)
	await get_tree().process_frame
	_ok(chefe_final._atordoado > 9.0, "quebrar a proteção atordoa o chefe por 10s")
	chefe_final.receber_dano(400.0)
	_ok(chefe_final.vida < vida_protegida, "matar os guardiões destrava o dano")
	chefe_final._protecao_timer = 0.01
	var limite_prot: int = Time.get_ticks_msec() + 1500
	while Time.get_ticks_msec() < limite_prot and chefe_final._guardioes.size() < 4:
		await get_tree().process_frame
	_ok(chefe_final._guardioes.size() == 4, "proteção se remonta depois do intervalo")
	var velocidade_base_final: float = chefe_final.velocidade
	chefe_final.aplicar_fase2()
	_ok(chefe_final._fase2 and is_equal_approx(chefe_final.velocidade, velocidade_base_final * 1.35), "fúria entra na fase 2 e acelera o chefe")
	chefe_final._ataque_espiral(1.0)
	chefe_final._ataque_orbitais(1.0)
	_ok(chefe_final._em_andamento == 0, "ataques novos da fase 2 executam sem travar")
	chefe_final.queue_free()
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		if is_instance_valid(n):
			n.queue_free()
	await get_tree().process_frame

	# ---------- fluxo real da horda 31 (sem vitória precoce)
	_spawn._iniciar_horda(31)
	await get_tree().create_timer(2.3, true, false, true).timeout
	var chefe_h31: ChefeFinal = null
	for n: Node in get_tree().get_nodes_in_group("inimigos"):
		if n is ChefeFinal:
			chefe_h31 = n as ChefeFinal
	_ok(chefe_h31 != null, "horda 31 invoca o chefe final")
	_ok(GlobalManager.partida_ativa and not _jogo._finalizada, "horda 31 não termina antes do chefe morrer")
	if chefe_h31 != null:
		chefe_h31._chegando = false
		chefe_h31.vida = 1.0
		chefe_h31.receber_dano(99999.0)
	await get_tree().create_timer(0.8, true, false, true).timeout
	_ok(GlobalManager.fase == 2, "derrotar o chefe final avança para a fase 2")
	_ok(GlobalManager.horda_atual == 1, "nova fase recomeça na horda 1")
	await get_tree().create_timer(2.8, true, false, true).timeout
	_ok(_spawn._fase != "idle" and GlobalManager.partida_ativa, "spawner retoma a horda 1 na fase 2")
	GlobalManager.fase = 1
	GlobalManager.horda_atual = 1
	_spawn._iniciar_horda(4)
	await get_tree().process_frame

	# ---------- cutscene de fúria + troca de área
	var chefe_cena: ChefeFinal = load("res://scenes/chefe_final.tscn").instantiate() as ChefeFinal
	_jogo.get_node("Mundo").add_child(chefe_cena)
	chefe_cena.configurar(dados_final, 31)
	chefe_cena._chegando = false
	chefe_cena.global_position = Vector2(1200, 420)
	_jogo.cutscene_furia_chefe(chefe_cena)
	var limite_cena: int = Time.get_ticks_msec() + 6000
	while Time.get_ticks_msec() < limite_cena and (not chefe_cena._fase2 or _player.controle_bloqueado):
		await get_tree().process_frame
	_ok(chefe_cena._fase2, "cutscene de fúria transforma o chefe")
	_ok(not _player.controle_bloqueado, "controle volta após a cutscene")
	chefe_cena.queue_free()
	await get_tree().process_frame
	# ---------- mercador troca cartas com moedas da run
	var ov_teste: LevelUpOverlay = LevelUpOverlay.new()
	add_child(ov_teste)
	await get_tree().process_frame
	ov_teste.abrir(2, _player)
	GlobalManager.moedas_partida = 500
	var custo_troca: int = ov_teste._custo_troca()
	ov_teste._trocar_cartas()
	_ok(GlobalManager.moedas_partida == 500 - custo_troca and ov_teste._trocas == 1, "trocar cartas custa moedas da run")
	ov_teste.fechar()
	ov_teste.queue_free()
	GlobalManager.moedas_partida = 0
	await get_tree().process_frame

	# ---------- pause
	await get_tree().process_frame
	_hud.alternar_pausa()
	_ok(get_tree().paused and _hud._pausa.visible, "ESC pausa a partida")
	_ok(_hud._pausa._b_config != null, "menu de pausa tem configurações")
	_hud._pausa._ao_alternar_config()
	_ok(_hud._pausa._config.visible, "painel de configurações abre na pausa")
	_ok(_hud._pausa._sliders.has("musica") and _hud._pausa._sliders.has("sfx"), "pausa tem volumes de música e SFX")
	var tela_antes: bool = GlobalManager.tela_cheia
	var ev_f11: InputEventKey = InputEventKey.new()
	ev_f11.physical_keycode = KEY_F11
	ev_f11.pressed = true
	GlobalManager._input(ev_f11)
	_ok(GlobalManager.tela_cheia != tela_antes, "F11 alterna tela cheia")
	GlobalManager._input(ev_f11)
	_ok(GlobalManager.tela_cheia == tela_antes, "F11 voltou ao estado anterior")
	_hud._pausa._ao_alternar_config()
	_ok(not _hud._pausa._config.visible, "configurações fecham na pausa")
	_hud.alternar_pausa()
	_ok(not get_tree().paused, "pausa é retomada")

	# ---------- save
	var moedas_originais: int = GlobalManager.moedas
	GlobalManager.moedas = 1234
	GlobalManager.salvar()
	GlobalManager.moedas = 0
	GlobalManager.carregar()
	_ok(GlobalManager.moedas == 1234, "save/load preserva moedas")
	GlobalManager.moedas = moedas_originais
	GlobalManager.salvar()

	# ---------- ressurreição no co-op (carta consumida)
	var cena_rev: PackedScene = load("res://scenes/player.tscn") as PackedScene
	var p_rev: Player = cena_rev.instantiate() as Player
	p_rev.remoto = true
	_jogo.get_node("Mundo").add_child(p_rev)
	p_rev.global_position = Vector2(900, 700)
	p_rev.vivo = false
	p_rev.corpo.visible = false
	GlobalManager.cargas_ressurreicao = 1
	_ok(_jogo._tentar_ressuscitar(p_rev, "TESTE"), "carta de ressurreição é consumida ao tentar reviver")
	_ok(GlobalManager.cargas_ressurreicao == 0, "carga de ressurreição diminui")
	var limite_rev: int = Time.get_ticks_msec() + 2400
	while Time.get_ticks_msec() < limite_rev and is_instance_valid(p_rev) and not p_rev.vivo:
		await get_tree().process_frame
	_ok(is_instance_valid(p_rev) and p_rev.vivo and p_rev.vida > 0.0, "jogador caído renasce após a ressurreição")
	if is_instance_valid(p_rev):
		p_rev.queue_free()
	await get_tree().process_frame

	# ---------- morte / tela final
	_player.invulneravel = 0.0
	_player.receber_dano(99999.0)
	await get_tree().create_timer(2.0, true, false, true).timeout
	_ok(_hud._tela_morte.visible, "tela de estatísticas abre após a morte")
	_ok(not GlobalManager.partida_ativa and GlobalManager.ultimo_resultado.has("rank"), "resultado final registrado")
	GlobalManager.ultimo_resultado.clear()

	# ---------- inventário acessível pelo menu (cena separada, no fim do teste)
	var cena_inv: PackedScene = load("res://scenes/inventario.tscn") as PackedScene
	var inv: Control = cena_inv.instantiate() as Control if cena_inv != null else null
	if inv != null:
		add_child(inv)
		await get_tree().process_frame
		var tela: TelaInventario = null
		for n: Node in inv.get_children():
			if n is TelaInventario:
				tela = n as TelaInventario
		_ok(tela != null and tela.visible, "inventário abre pelo menu")
		_ok(tela != null and tela._retrato != null and tela._lista.get_child_count() >= 18, "inventário mostra cartas com retrato")
		inv.queue_free()
	else:
		_ok(false, "cena de inventário do menu carrega")

	# ---------- guardiões no snapshot do cliente
	_jogo._sincronizar_guardioes([{"x": 240.0, "y": 240.0, "vida": 300.0, "max": 360.0}])
	await get_tree().process_frame
	_ok(_jogo._guardioes_rede.size() == 1, "cliente desenha guardiões vindos do host")
	_jogo._sincronizar_guardioes([])
	await get_tree().process_frame
	_ok(_jogo._guardioes_rede.is_empty(), "guardiões somem quando a proteção acaba")

	# ---------- loja embutida (não perde a run)
	_hud.abrir_loja()
	await get_tree().process_frame
	_ok(_hud._loja != null and is_instance_valid(_hud._loja) and bool(_hud._loja.get("embutida")), "loja abre embutida durante a partida")
	if _hud._loja != null:
		_ok(_hud._loja.get("_label_moedas") != null, "loja embutida mostra moedas e itens")
		_hud._loja.call("_ao_voltar")
	await get_tree().process_frame
	_ok(_hud._loja == null, "fechar a loja volta para a tela anterior")
	get_tree().paused = false
